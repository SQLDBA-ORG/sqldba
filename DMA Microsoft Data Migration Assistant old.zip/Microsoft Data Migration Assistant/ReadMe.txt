Data Migration Assistant V3.4
-------------------------------
Overview
----------
Data Migration Assistant (DMA) enables you to upgrade to a modern data platform by detecting compatibility issues that can impact database functionality on your new version of SQL Server. The tool recommends performance and reliability improvements for your target environment. DMA allows you to move your schema, data, and uncontained objects from your source server to your target server. DMA replaces all previous versions of SQL Server Upgrade Advisor (SSUA) and should be used to upgrade most versions of SQL Server (see below for supported versions).

What is new in V3.4?
--------------------

DMA v3.4 enables migration of an on-premises SQL Server 2017 instance to SQL Azure Database, as well fixes number of performance and stability issues.

Existing DMA Features
-----------------------
1. Assess on-premises SQL Server instance(s) migrating to Azure SQL database(s). The assessment workflow helps you to detect the following issues that can affect Azure SQL database migration and provides detailed guidance on how to resolve them. 
	a. Migration blocking issues: DMA discovers the compatibility issues that block migrating on-prem SQL Server database(s)s to Azure SQL Database(s). It then provides recommendations to help customers remediate those issues.
	b. Partially or unsupported features: DMA detects partially or unsupported features that are currently in use at the source SQL Server. It then provides comprehensive set of recommendations, alternative approaches available in Azure and mitigating steps so that customers can plan ahead this effort into their migration projects.

2. Migrate on-premises SQL Server instance to a modern SQL Server instance hosted on-premises or on an Azure Virtual Machine accessible from your on-premises network (via Azure VPN or ExpressRoute). 

	The migration workflow helps you to migrate the following components: 
	a. Schema of databases
	b. Data and Users
	c. Server roles
	d. SQL and Windows logins

	After a successful migration, applications will be able to connect to the target SQL server databases seamlessly.

3. Discovery of issues that can affect an upgrade to an on-premises SQL Server. These are described as compatibility issues categorized under these areas:
	a. Breaking changes
	b. Behavior changes
	c. Deprecated features

4. Discover new features in the target SQL Server platform that the database can benefit from after an upgrade. These are described as feature recommendations and are categorized under these areas:
	a. Performance
	b. Security
	c. Storage

5. Assess databases at scale in an un-attended mode using dmacmd.exe utility. For details on how to use dmaccmd.exe please go here: https://blogs.msdn.microsoft.com/datamigration/2016/11/08/data-migration-assistant-how-to-run-from-command-line/

Supported sources and target versions
---------------------------------------
Source: SQL Server 2005, SQL Server 2008, SQL Server 2008 R2, SQL Server 2012, SQL Server 2014, SQL Server 2016, and SQL Server 2017 (Linux not supported for source in SQL to SQL migrations)
Target: SQL Server 2012, SQL Server 2014, SQL Server 2016, Azure SQL Database, and SQL Server 2017

Installation
--------------
You can install the tool from Microsoft Download Center by simply executing DataMigrationAssistant.msi from the downloadable payload.

Documentation
---------------
Data Migration Assistant MSDN blog: https://blogs.msdn.microsoft.com/datamigration/dma/
Data Migration MSDN blog: https://blogs.msdn.microsoft.com/datamigration/

Feedback, suggestions and questions
-------------------------------------
Please send an email to dmafeedback@microsoft.com