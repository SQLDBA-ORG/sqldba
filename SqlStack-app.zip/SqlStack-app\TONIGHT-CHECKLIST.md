# SqlStack: first run on a client server (checklist, 2026-11-23)

This tool has never run a real SQL Server setup. Tonight is its first. Go slowly. One instance first.
A hostile review of the code ran on 2026-11-23 and its fixes are in this package. The rules below cover what
a review cannot prove.

## Before you leave
- [ ] Take the package that holds THIS file (the final one).
- [ ] Take the SQL media and any update package the client wants applied.
- [ ] Check the client's media has its licence key: the file `x64\DefaultSetup.ini` in the media must hold a `PID=` line.
      Without it setup installs the media's default edition. Evaluation media expires after 180 days.
- [ ] Know the by-hand fallback (bottom of this page).

## On the server, before the window
- [ ] Copy the package, the media and any update package to a LOCAL disk. Not a mapped drive, not a share:
      the administrator window cannot see mapped drives.
- [ ] Right-click the zip > Properties > Unblock, then unzip.
- [ ] In PowerShell run `Get-ExecutionPolicy -List`. If MachinePolicy or UserPolicy is set, the launcher may be
      refused: tell me before going further.
- [ ] Is a Windows restart pending? Setup refuses to install while one is. Either restart the server yourself in
      the client's change window, or tick "Install anyway" on the Install screen (it tells setup to ignore it).
- [ ] ADD THE IP ADDRESSES BY HAND FIRST, the way the client's network team wants (DNS, VLAN). Then the tool adds
      nothing to the network card. The tool now refuses to add an address to a DHCP card, but on a client server
      do not let it add one at all.
- [ ] Check you are a local administrator and can log in to the existing SQL instances.
- [ ] A group managed service account (name ending in `$`) must already be installed on this server.

## In the window
- [ ] Host screen: confirm it lists the server's real instances and addresses.
- [ ] Plan screen: add ONE new instance only. Media, accounts, mixed mode, port, address, folders. Save.
- [ ] Install screen: READ the preview. No line may start with WARNING about adding an address. It must list only
      your new instance. Read the edition line.
- [ ] Press the button; it restarts the window as administrator. Read the preview again, then Install.
- [ ] TYPE every password tonight. Do not leave one blank: the "type it in setup's own window" route has never
      met a real setup. A password must not contain a double quote.
- [ ] Watch the log box. Do not close the window while it runs.

## If it says "reboot needed"
- [ ] Press "Continue later". Restart the server yourself when the client allows. Open SqlStack again and press
      Install again: the installed instance is not installed twice, and it finishes the port and binding.
- [ ] Do NOT use "Restart Windows now and continue" on a client server tonight.

## If it says "failed", "needs attention" or "stopped part way"
- [ ] Do not press Install again yet. Read setup's Summary.txt (the window names it) and `install-log-*.txt` in
      the run folder.
- [ ] If setup itself failed: fix the cause and uninstall the half-installed instance with SQL Server setup.
      The tool will not go on with that instance until you do (it leaves a `<NAME>.setup-failed.txt` note in the
      run folder's `export` folder; delete the note only after you repaired or removed the instance).
- [ ] If it says "installed, check failed": SQL Server IS installed. Test a login by hand over the address and
      port before changing anything. Give it a minute first.

## After a good first instance
- [ ] The tool's check runs from the server itself. OPEN THE PORT IN THE FIREWALL yourself and connect from
      another machine.
- [ ] Check the edition, the service account, the port and the listening address in the SQL error log.
- [ ] Passwords went to setup on its command line. If the client's server records command lines (Sysmon, Defender,
      audit policy), change the sa and service account passwords afterwards, or use group managed accounts.
- [ ] Only then plan and install the rest.

## The by-hand fallback (always works)
The window writes one ini per instance into the run folder:
`C:\temp\SqlStack\runs\<HOST>-<date>-<time>\export\<NAME>-install.ini`.
From an administrator prompt in the media folder:

    setup.exe /ConfigurationFile="<that ini>" /Q /IACCEPTSQLSERVERLICENSETERMS /SAPWD="..." /SQLSVCPASSWORD="..." /AGTSVCPASSWORD="..."

(leave out the password switches you do not need). Then set the port and address in SQL Server Configuration
Manager.

## Bring back
The run folder (`install-log-*.txt`, `window.log`, the ini files) and setup's Summary.txt. They hold server
names: treat them as private.
