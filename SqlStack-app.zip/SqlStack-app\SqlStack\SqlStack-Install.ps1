<#
  SqlStack-Install.ps1

  The install worker of the SqlStack window. It installs the SQL Server
  instances a SqlStack plan exported, one ini at a time, then sets each
  instance's TCP port and IP address, runs its post-install script and checks
  that it answers. The window (SqlStack.ps1) starts it as a hidden child
  process; it also runs by hand.

  Plain Windows PowerShell 5.1. No modules to install, no internet needed.

  USAGE
    .\SqlStack-Install.ps1 -RunFolder D:\SqlStack\run-1
    .\SqlStack-Install.ps1 -RunFolder D:\SqlStack\run-1 -InterfaceAlias Ethernet -Go
    .\SqlStack-Install.ps1 -IniFolder D:\inis -Media E:\ -Go
    .\SqlStack-Install.ps1 -SelfTest

  Without -Go it is a PREVIEW: it prints every step and changes nothing.

  INPUTS
    -RunFolder   the planner's run folder: export\<NAME>-install.ini,
                 export\<NAME>-post-install.sql and spec.json (port, ip, media).
                 The inis carry the service accounts and SECURITYMODE.
    -IniFolder   any folder of *-install.ini. Port and address come from an
                 optional bind.csv beside them (Instance,Ip,Port; blank Ip =
                 listen on all addresses). -Media is then required.
    accounts.csv optional, beside the inis, for hand-made ini folders only:
                 Instance,EngineAccount,AgentAccount,MixedMode (yes/no). A blank
                 cell keeps the ini's value. -EngineAccount, -AgentAccount and
                 -MixedMode apply to every instance the csv does not name. A
                 value that differs from the ini goes on setup's command line;
                 the ini is never rewritten. The window uses none of these.

  THE ONE SAFETY RULE
    This script changes only instances whose names are in the ini set (the
    INSTANCENAME of each ini it was given, after -Only). It never changes any
    other instance. Every registry, service and setup change goes through
    Invoke-InstanceChange, which refuses any other name.

  PASSWORDS
    Asked for with hidden input, or with -PasswordStdin read from standard
    input (one line per password: base64 of the UTF-16 name, a space, base64 of
    the UTF-16 password; a line END ends them). Held as SecureString, put on
    setup's command line only. Never written to the ini, the log, a state line
    or the screen, and never taken from an argument, a file or an environment
    variable.
    EVERY PASSWORD IS OPTIONAL. An instance with a password left blank is
    installed in WINDOW MODE: setup shows its own window and the operator
    types it there. A password that was typed is still passed as a switch; a
    blank one gets no switch. Window mode never relies on a switch overriding
    the ini: the worker writes <NAME>-install-window.ini beside the ini (the
    same keys, QUIET off, no password) and runs setup on that file.
    -ShowSetupWindow puts every instance in window mode, the same way.

  UPDATES
    With -RunFolder, install.json may hold "updates": { "<NAME>": "<folder>" }.
    An instance with a folder gets /UPDATEENABLED="True" and
    /UPDATESOURCE="<folder>", so setup applies the update package it finds
    there during the install. An instance with none gets no update, and when
    its ini does not already say UPDATEENABLED="False" the switch says it.

  RESTART OF WINDOWS
    -WindowsRestart restarts Windows. With -ResumeArguments (base64 of the
    UTF-16 arguments for powershell.exe) it first registers ONE scheduled
    task, SqlStack-Resume, for this user at logon with highest privileges,
    that runs powershell.exe with those arguments; a task that cannot be
    registered restarts nothing. -RemoveResumeTask removes that task.

  FOR THE WINDOW
    Lines that start with @@ are machine-readable, tab separated:
      @@INSTANCE name new|installed     @@STEP name kind text
      @@NEED key label                  @@ADDRESS name ip
      @@PROBLEM text                    @@LOG path
      @@STATE name state detail         @@END exitcode text
      @@PENDING text (a restart of Windows is pending)
    States: waiting, adding address, installing, waiting for you in the SQL
    Server setup window, configuring, restarting, checking, done, failed,
    reboot needed, needs attention (a registered instance whose last setup
    failed or that has no engine service: nothing is changed for it),
    installed, check failed.
    Exit codes: 0 done, 1 nothing was changed, 2 setup failed (or an
    unexpected error stopped the run part way: its END text says so), 3 reboot
    needed, 4 a connection check failed.

  A SETUP THAT FAILED
    Setup ending with any exit code but 0 or 3010, or not starting, leaves
    export\<NAME>.setup-failed.txt (the time and the exit code). While it is
    there that instance is never treated as already installed.

  A PENDING RESTART OF WINDOWS
    -IgnorePendingRestart adds /SKIPRULES=RebootRequiredCheck to every setup
    command of the run.

  FOR TESTS
    -SelfTestHarness makes the run harmless: no address is added, elevation is
    not required, an instance that is really installed is refused, no task is
    registered or removed and Windows is not restarted. Only with it is
    -SetupExeOverride honoured (a stand-in for setup.exe). -HarnessFake (also
    only with it) is a comma list: dhcp = the chosen card uses DHCP; crash =
    an unexpected error once the run has been confirmed.
#>
[CmdletBinding()]
param(
    [string]$RunFolder = '',
    [string]$IniFolder = '',
    [string]$Media = '',
    [string]$InterfaceAlias = '',
    [ValidateRange(1, 128)][int]$PrefixLength = 24,
    [string[]]$Only = @(),
    [string]$EngineAccount = '',
    [string]$AgentAccount = '',
    [ValidateSet('', 'yes', 'no')][string]$MixedMode = '',
    [switch]$ShowSetupWindow,
    [switch]$SkipBind,
    [switch]$Go,
    [switch]$Yes,
    [switch]$PasswordStdin,
    [switch]$SelfTestHarness,
    [string]$SetupExeOverride = '',
    [string]$HarnessFake = '',
    [switch]$IgnorePendingRestart,
    [switch]$WindowsRestart,
    [string]$ResumeArguments = '',
    [switch]$RemoveResumeTask,
    [switch]$SelfTest,
    [switch]$LoadFunctionsOnly
)

$script:ResumeTaskName = 'SqlStack-Resume'
$script:LogPath = ''
$script:SetNames = @()
$script:RegChanged = $false
$script:Rows = New-Object System.Collections.ArrayList
$script:HarnessFakes = @()

# The seams: each read of this machine a test must fake. -SelfTest replaces
# them in its own process; -SelfTestHarness replaces DhcpOn for a child run.
$script:Seam = @{
    DhcpOn        = { param([string]$Alias) @(Get-NetIPInterface -InterfaceAlias $Alias -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { [string]$_.Dhcp -eq 'Enabled' }).Count -gt 0 }
    ServiceExists = { param([string]$Name) [bool](Get-Service -Name $Name -ErrorAction SilentlyContinue) }
    Edition       = { param([string]$InstanceId) $e = Get-ItemProperty -Path ('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\{0}\Setup' -f $InstanceId) -Name 'Edition' -ErrorAction SilentlyContinue; if ($e) { [string]$e.Edition } else { '' } }
    Sleep         = { param([int]$Seconds) Start-Sleep -Seconds $Seconds }
}

# ======================================================================
#  Helpers
# ======================================================================

function Write-Log {
    # The script's own log writer. The log never holds a password.
    param([string]$Text = '', [string]$Color = '')
    if ($Color) { Write-Host $Text -ForegroundColor $Color } else { Write-Host $Text }
    if ($script:LogPath) {
        $line = (Get-Date -Format 'HH:mm:ss') + '  ' + $Text + "`r`n"
        [IO.File]::AppendAllText($script:LogPath, $line, (New-Object Text.UTF8Encoding($false)))
    }
}

function Write-Machine {
    # One machine-readable line for the SqlStack window: @@KIND<TAB>field<TAB>field.
    # A tab or a line break inside a field becomes a space. Never given a password.
    param([string]$Kind, [string[]]$Fields = @())
    $clean = @(foreach ($f in $Fields) { ([string]$f) -replace '[\t\r\n]', ' ' })
    Write-Log (('@@' + $Kind + "`t" + ($clean -join "`t")).TrimEnd("`t"))
}

function Invoke-InstanceChange {
    # THE ONE SAFETY RULE. Every change to an instance (setup, registry,
    # service, post-install SQL) is run through here. A name outside the ini
    # set is refused before anything happens.
    param([string]$InstanceName, [string]$What, [scriptblock]$Action)
    if (@($script:SetNames | Where-Object { $_ -ieq $InstanceName }).Count -eq 0) {
        throw ("REFUSED: '{0}' is not in the ini set ({1}). This script never changes another instance. Step: {2}" -f `
                $InstanceName, ($script:SetNames -join ', '), $What)
    }
    Write-Log ('  ' + $What)
    & $Action
}

function Read-IniFile {
    # The [OPTIONS] keys of one setup ini, quotes removed. Keys are case-insensitive.
    param([string]$Path)
    $keys = @{}
    foreach ($line in [IO.File]::ReadAllLines($Path)) {
        $t = $line.Trim()
        if ($t.StartsWith('; INCOMPLETE')) { $keys['#INCOMPLETE'] = 'yes' }
        if ($t -eq '' -or $t.StartsWith(';') -or $t.StartsWith('[')) { continue }
        $eq = $t.IndexOf('=')
        if ($eq -lt 1) { continue }
        $k = $t.Substring(0, $eq).Trim()
        $v = $t.Substring($eq + 1).Trim()
        if ($k -ne 'SQLSYSADMINACCOUNTS' -and $v.Length -ge 2 -and $v.StartsWith('"') -and $v.EndsWith('"')) { $v = $v.Substring(1, $v.Length - 2) }
        $keys[$k] = $v
    }
    return $keys
}

function Test-AccountNeedsPassword {
    # Virtual accounts (NT Service\...), built-in accounts (NT AUTHORITY\...)
    # and group managed accounts (name ends in $) have no password to give.
    param([string]$Account)
    if ([string]::IsNullOrWhiteSpace($Account)) { return $false }
    $a = $Account.Trim()
    if ($a -like 'NT Service\*' -or $a -like 'NT AUTHORITY\*' -or $a.EndsWith('$')) { return $false }
    return $true
}

function Select-Effective {
    # The accounts.csv cell, else the run-wide parameter, else the ini; and where it came from.
    param([string]$Csv, [string]$Run, [string]$RunName, [string]$Ini)
    if ($Csv.Trim()) { return [pscustomobject]@{ Value = $Csv.Trim(); From = 'from accounts.csv' } }
    if ($Run.Trim()) { return [pscustomobject]@{ Value = $Run.Trim(); From = ('from ' + $RunName) } }
    return [pscustomobject]@{ Value = $Ini; From = 'from the ini' }
}

function Get-ValueProblem {
    # Why a value cannot go on setup's command line, or '' when it can.
    # A SecureString is opened here, so its text never becomes a parameter value.
    param([object]$Value)
    $text = [string]$Value
    if ($Value -is [Security.SecureString]) {
        $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
        try { $text = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
    }
    if ($text.IndexOf('"') -ge 0) { return 'it contains a double quote ("), which cannot be passed to setup safely' }
    foreach ($c in $text.ToCharArray()) {
        if ([int]$c -lt 32 -or [int]$c -eq 127) { return 'it contains a control character (a tab, a line break or similar)' }
    }
    return ''
}

function ConvertTo-SetupArgument {
    # One setup switch: /NAME="value". Windows argv rules: inside quotes a
    # backslash is literal, except a run of backslashes right before a double
    # quote, which must be doubled. The only quote here is the closing one, so
    # the trailing run is doubled. -Value may be a string or a SecureString.
    param([string]$Name, [object]$Value)
    $why = Get-ValueProblem -Value $Value
    if ($why) { throw ("refusing the value for /{0}: {1}" -f $Name, $why) }
    $text = [string]$Value
    if ($Value -is [Security.SecureString]) {
        $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Value)
        try { $text = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) }
    }
    $m = [regex]::Match($text, '\\+$')
    $tail = ''
    if ($m.Success) { $tail = $m.Value }
    return ('/' + $Name + '="' + $text + $tail + '"')
}

function Format-SetupArguments {
    # The command line as it may be shown or logged: every secret is ***.
    param([object[]]$ArgList)
    $parts = foreach ($a in $ArgList) {
        if ($a.Flag) { '/' + $a.Name }
        elseif ($a.Secret) { '/' + $a.Name + '="***"' }
        elseif (Get-ValueProblem -Value $a.Value) { '/' + $a.Name + '=<REFUSED, see PROBLEM below>' }
        else { ConvertTo-SetupArgument -Name $a.Name -Value $a.Value }
    }
    return ($parts -join ' ')
}

function Invoke-Setup {
    # Starts setup.exe with System.Diagnostics.Process. The real argument
    # string is built here, never printed, never logged, and cleared after.
    # No console window is made for it: the window starts this script hidden.
    param([string]$SetupExe, [object[]]$ArgList)
    $sb = New-Object Text.StringBuilder
    foreach ($a in $ArgList) {
        if ($sb.Length -gt 0) { [void]$sb.Append(' ') }
        if ($a.Flag) { [void]$sb.Append('/' + $a.Name) }
        elseif ($a.Secret) { [void]$sb.Append((ConvertTo-SetupArgument -Name $a.Name -Value $a.Secure)) }
        else { [void]$sb.Append((ConvertTo-SetupArgument -Name $a.Name -Value $a.Value)) }
    }
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $SetupExe
    $psi.Arguments = $sb.ToString()
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    $psi.WorkingDirectory = [IO.Path]::GetDirectoryName($SetupExe)
    [void]$sb.Clear()
    $p = [Diagnostics.Process]::Start($psi)
    $psi.Arguments = ''
    $p.WaitForExit()
    return $p.ExitCode
}

function Test-SecureEqual {
    param([Security.SecureString]$A, [Security.SecureString]$B)
    $ba = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($A)
    $bb = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($B)
    try { return ([Runtime.InteropServices.Marshal]::PtrToStringBSTR($ba) -ceq [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bb)) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ba); [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bb) }
}

function ConvertFrom-SecretLine {
    # One line of -PasswordStdin: base64 of the UTF-16 name, a space, base64 of
    # the UTF-16 password. The password goes straight into a SecureString and
    # its decoded bytes and characters are cleared. An error never quotes the line.
    param([string]$Line)
    $t = ([string]$Line) -replace '^[^A-Za-z0-9+/=]+', ''
    $parts = @($t.Trim() -split ' ')
    if ($parts.Count -ne 2) { throw 'a password line is not two base64 fields (name, password)' }
    $nameBytes = $null; $pwBytes = $null
    try { $nameBytes = [Convert]::FromBase64String($parts[0]); $pwBytes = [Convert]::FromBase64String($parts[1]) }
    catch { throw 'a password line is not valid base64' }
    $name = [Text.Encoding]::Unicode.GetString($nameBytes)
    $chars = [Text.Encoding]::Unicode.GetChars($pwBytes)
    $sec = New-Object Security.SecureString
    foreach ($c in $chars) { $sec.AppendChar($c) }
    [Array]::Clear($chars, 0, $chars.Length)
    [Array]::Clear($pwBytes, 0, $pwBytes.Length)
    $sec.MakeReadOnly()
    return [pscustomobject]@{ Key = $name; Secure = $sec }
}

function Read-SecretInput {
    # Every password line up to END (or the end of the input), as key -> SecureString.
    # A line that ends in BEGIN is a marker the window sends first, and is ignored.
    param([IO.TextReader]$Reader)
    $map = @{}
    while ($true) {
        $line = $Reader.ReadLine()
        if ($null -eq $line) { break }
        $t = $line.Trim()
        if ($t -eq 'END') { break }
        if (($t -eq '') -or $t.EndsWith('BEGIN')) { continue }
        $s = ConvertFrom-SecretLine $line
        $map[$s.Key] = $s.Secure
    }
    return $map
}

function Get-InstalledInstanceId {
    # 'MSSQL16.NAME' when the instance is installed, else ''.
    param([string]$Name)
    $p = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' -Name $Name -ErrorAction SilentlyContinue
    if ($p) { return [string]$p.$Name }
    return ''
}

function Get-TcpKeyPath {
    param([string]$InstanceId)
    return ('HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server\{0}\MSSQLServer\SuperSocketNetLib\Tcp' -f $InstanceId)
}

function Get-ServiceNames {
    param([string]$Name)
    if ($Name -ieq 'MSSQLSERVER') { return @('MSSQLSERVER', 'SQLSERVERAGENT') }
    return @(('MSSQL$' + $Name), ('SQLAgent$' + $Name))
}

function Test-SameIp {
    param([string]$A, [string]$B)
    $x = $null; $y = $null
    if (-not [Net.IPAddress]::TryParse($A.Trim(), [ref]$x)) { return $false }
    if (-not [Net.IPAddress]::TryParse($B.Trim(), [ref]$y)) { return $false }
    return $x.Equals($y)
}

function Test-IpOnMachine {
    param([string]$Ip)
    foreach ($nic in [Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces()) {
        foreach ($u in $nic.GetIPProperties().UnicastAddresses) { if (Test-SameIp ([string]$u.Address) $Ip) { return $true } }
    }
    return $false
}

# ---- registry: every function takes the Tcp key path, so a test can point it at HKCU ----

function Set-RegValue {
    # Writes one value only when it differs, and notes that something changed.
    param([string]$Path, [string]$Name, [object]$Value, [string]$Kind)
    $k = Get-Item -Path $Path
    if ($k.GetValueNames() -contains $Name) {
        $old = $k.GetValue($Name, $null, 'DoNotExpandEnvironmentNames')
        if ($k.GetValueKind($Name).ToString() -eq $Kind -and [string]$old -ceq [string]$Value) { return }
    }
    New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Kind -Force | Out-Null
    $script:RegChanged = $true
}

function Get-IpSections {
    # The IP1, IP2, ... sections under a Tcp key (not IPAll).
    param([string]$TcpKey)
    foreach ($k in @(Get-ChildItem -Path $TcpKey)) {
        if ($k.PSChildName -match '^IP(\d+)$') {
            [pscustomobject]@{ Name = $k.PSChildName; Number = [int]$Matches[1]; Path = (Join-Path $TcpKey $k.PSChildName)
                IpAddress = [string]$k.GetValue('IpAddress', ''); Enabled = [string]$k.GetValue('Enabled', '') }
        }
    }
}

function Set-TcpBinding {
    # The static port and the binding for one instance. Order proved on this
    # PC: TcpDynamicPorts = '', then TcpPort, then Enabled = 1 last.
    # No -Ip: IPAll carries the port and the instance listens on all addresses.
    # -Ip: the section holding that address carries it. Setup only makes a
    # section for an address present at install time; when there is none, a
    # new IP<max+1> is made by copying an existing section's value names and
    # kinds (a hand-made section like that IS honoured after a restart).
    param([string]$TcpKey, [int]$Port, [string]$Ip = '')
    $notes = New-Object System.Collections.ArrayList
    if (-not $Ip) {
        $all = Join-Path $TcpKey 'IPAll'
        if (-not (Test-Path $all)) { throw ("there is no IPAll section under {0}" -f $TcpKey) }
        Set-RegValue $all 'TcpDynamicPorts' '' 'String'
        Set-RegValue $all 'TcpPort' ([string]$Port) 'String'
        Set-RegValue $TcpKey 'ListenOnAllIPs' 1 'DWord'
        Set-RegValue $TcpKey 'Enabled' 1 'DWord'
        [void]$notes.Add(('IPAll: port {0}, listening on all addresses' -f $Port))
        return [string[]]$notes.ToArray()
    }
    $sections = @(Get-IpSections $TcpKey)
    $hit = @($sections | Where-Object { Test-SameIp $_.IpAddress $Ip })
    if ($hit.Count -gt 0) {
        $target = $hit[0].Path
        [void]$notes.Add(('{0}: the section that already holds {1}' -f $hit[0].Name, $Ip))
    } else {
        if ($sections.Count -eq 0) { throw ("there is no IP<n> section under {0} to copy" -f $TcpKey) }
        $template = @($sections | Sort-Object Number)[0]
        $newName = 'IP' + ((@($sections | ForEach-Object { $_.Number }) | Measure-Object -Maximum).Maximum + 1)
        $target = Join-Path $TcpKey $newName
        New-Item -Path $target | Out-Null
        $src = Get-Item -Path $template.Path
        foreach ($vn in $src.GetValueNames()) {
            if ($vn -eq '') { continue }
            New-ItemProperty -Path $target -Name $vn -Value $src.GetValue($vn, $null, 'DoNotExpandEnvironmentNames') `
                -PropertyType $src.GetValueKind($vn).ToString() | Out-Null
        }
        Set-RegValue $target 'IpAddress' $Ip 'String'
        if ($src.GetValueNames() -contains 'Active') { Set-RegValue $target 'Active' 1 'DWord' }
        $script:RegChanged = $true
        [void]$notes.Add(('{0}: new section for {1}, copied from {2}' -f $newName, $Ip, $template.Name))
    }
    Set-RegValue $target 'TcpDynamicPorts' '' 'String'
    Set-RegValue $target 'TcpPort' ([string]$Port) 'String'
    Set-RegValue $target 'Enabled' 1 'DWord'
    Set-RegValue $TcpKey 'ListenOnAllIPs' 0 'DWord'
    Set-RegValue $TcpKey 'Enabled' 1 'DWord'
    foreach ($s in @(Get-IpSections $TcpKey)) {
        if ($s.Path -ne $target -and $s.Enabled -eq '1') {
            [void]$notes.Add(('WARN: {0} ({1}) is also Enabled, so the instance listens there too. Left as it is.' -f $s.Name, $s.IpAddress))
        }
    }
    return [string[]]$notes.ToArray()
}

# ---- SQL and service steps ----

function Invoke-SqlFile {
    # Runs a .sql file, split into batches on lines that are only GO.
    param([string]$Server, [string]$Path)
    $text = [IO.File]::ReadAllText($Path, [Text.Encoding]::UTF8)
    $batches = @([regex]::Split($text, '(?im)^[ \t]*GO[ \t]*\r?$') | Where-Object { $_.Trim() -ne '' })
    $cn = New-Object Data.SqlClient.SqlConnection ('Server={0};Database=master;Integrated Security=SSPI;Connect Timeout=30' -f $Server)
    $cn.Open()
    try {
        foreach ($b in $batches) { $cmd = $cn.CreateCommand(); $cmd.CommandText = $b; $cmd.CommandTimeout = 600; [void]$cmd.ExecuteNonQuery() }
    } finally { $cn.Close() }
    return $batches.Count
}

function Restart-Engine {
    # One restart of the engine; the Agent is started again if it was running or is Automatic.
    param([string]$Name)
    $svc, $agt = Get-ServiceNames $Name
    $a = Get-Service -Name $agt -ErrorAction SilentlyContinue
    $agentBack = ($null -ne $a) -and (($a.Status -eq 'Running') -or ([string]$a.StartType -eq 'Automatic'))
    Restart-Service -Name $svc -Force
    (Get-Service -Name $svc).WaitForStatus('Running', [TimeSpan]::FromMinutes(3))
    if ($agentBack) { Start-Service -Name $agt }
}

function Test-Listener {
    # A TCP connect, then one login over tcp:, reading what the connection landed on.
    param([string]$Ip, [int]$Port)
    $addr = $Ip
    if (-not $addr) { $addr = '127.0.0.1' }
    $c = New-Object Net.Sockets.TcpClient
    $tcpOk = $false
    try { $ar = $c.BeginConnect($addr, $Port, $null, $null); $tcpOk = $ar.AsyncWaitHandle.WaitOne(5000) -and $c.Connected } catch { $tcpOk = $false } finally { $c.Close() }
    if (-not $tcpOk) { return [pscustomobject]@{ Ok = $false; Text = ('no TCP answer on {0}:{1}' -f $addr, $Port) } }
    try {
        $cn = New-Object Data.SqlClient.SqlConnection ('Server=tcp:{0},{1};Database=master;Integrated Security=SSPI;Connect Timeout=15' -f $addr, $Port)
        $cn.Open()
        $cmd = $cn.CreateCommand()
        $cmd.CommandText = "SELECT @@SERVERNAME, CONVERT(nvarchar(48), CONNECTIONPROPERTY('local_net_address')), CONVERT(int, CONNECTIONPROPERTY('local_tcp_port'))"
        $r = $cmd.ExecuteReader(); [void]$r.Read()
        $t = ('login OK: {0} on {1}:{2}' -f $r.GetValue(0), $r.GetValue(1), $r.GetValue(2))
        $r.Close(); $cn.Close()
        return [pscustomobject]@{ Ok = $true; Text = $t }
    } catch { return [pscustomobject]@{ Ok = $false; Text = ('TCP answers on {0}:{1}, login failed: {2}' -f $addr, $Port, $_.Exception.Message) } }
}

function Test-PendingReboot {
    $hits = @()
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $hits += 'component servicing' }
    if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $hits += 'Windows Update' }
    if (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue) { $hits += 'pending file renames' }
    return $hits
}

function Get-SetupSummaryPath {
    # The newest Summary.txt setup wrote, or where one would be.
    $log = Get-ChildItem "$env:ProgramFiles\Microsoft SQL Server\*\Setup Bootstrap\Log\Summary.txt" -ErrorAction SilentlyContinue | Sort-Object LastWriteTime | Select-Object -Last 1
    if ($log) { return $log.FullName }
    return '%ProgramFiles%\Microsoft SQL Server\<version>\Setup Bootstrap\Log\Summary.txt'
}

function Get-PasswordKeys {
    # The passwords one instance can be given, as (switch, key) pairs: sa for
    # mixed mode, and each service account that has a password.
    param([object]$Inst)
    $k = New-Object System.Collections.ArrayList
    if ($Inst.Mixed) { [void]$k.Add([pscustomobject]@{ Switch = 'SAPWD'; Key = '#sa' }) }
    if (Test-AccountNeedsPassword $Inst.EngineAccount) { [void]$k.Add([pscustomobject]@{ Switch = 'SQLSVCPASSWORD'; Key = [string]$Inst.EngineAccount }) }
    if (Test-AccountNeedsPassword $Inst.AgentAccount) { [void]$k.Add([pscustomobject]@{ Switch = 'AGTSVCPASSWORD'; Key = [string]$Inst.AgentAccount }) }
    return $k.ToArray()
}

function Get-WindowIniPath {
    # <NAME>-install-window.ini beside <NAME>-install.ini.
    param([string]$IniPath)
    if ($IniPath -notmatch '(?i)-install\.ini$') { throw ("not a *-install.ini file: {0}" -f $IniPath) }
    return ($IniPath.Substring(0, $IniPath.Length - 4) + '-window.ini')
}

function Write-WindowIni {
    # WINDOW MODE: a copy of one setup ini with QUIET (and QUIETSIMPLE) off, so
    # setup shows its own window. Every other line is kept as it is; the first
    # ini is never rewritten. Returns the path of the copy.
    param([string]$IniPath)
    $out = Get-WindowIniPath $IniPath
    $bytes = [IO.File]::ReadAllBytes($IniPath)
    $hasBom = ($bytes.Length -ge 2) -and (($bytes[0] -eq 0xEF) -or ($bytes[0] -eq 0xFF) -or ($bytes[0] -eq 0xFE))
    $reader = New-Object IO.StreamReader($IniPath, $true)
    try { $text = $reader.ReadToEnd(); $enc = $reader.CurrentEncoding } finally { $reader.Close() }
    if (-not $hasBom) { $enc = New-Object Text.UTF8Encoding($false) }
    $lines = New-Object System.Collections.ArrayList
    [void]$lines.Add('; Window copy made by SqlStack-Install.ps1: the same keys as ' + (Split-Path $IniPath -Leaf) + ', QUIET off, so setup shows its own window.')
    foreach ($line in ($text -split "`r?`n")) {
        if ($line -match '^\s*(QUIET|QUIETSIMPLE)\s*=') { [void]$lines.Add($Matches[1].ToUpperInvariant() + '="False"') }
        else { [void]$lines.Add($line) }
    }
    [IO.File]::WriteAllText($out, ($lines -join "`r`n"), $enc)
    return $out
}

function Get-UpdatesNote {
    # What an updates folder is worth, in plain words, or '' when it is usable.
    # A WARNING, never a refusal: setup is still given the folder.
    param([string]$Folder)
    if (-not (Test-Path -LiteralPath $Folder -PathType Container)) { return 'WARNING: that folder does not exist' }
    if (@(Get-ChildItem -LiteralPath $Folder -Filter '*.exe' -File -ErrorAction SilentlyContinue).Count -eq 0) { return 'WARNING: that folder holds no .exe update package' }
    return ''
}

function Get-SetupArgList {
    # The switches for one instance. Passwords are listed as secrets; their
    # SecureString is filled in only when the run really starts setup.
    # -Secrets $null is the PREVIEW: it lists every password the instance may
    # be given. A run lists only the passwords that were typed.
    # WINDOW MODE ($Inst.WindowMode): setup runs on the window copy of the ini
    # (QUIET off, Write-WindowIni) with no /Q, and shows its own window.
    param([object]$Inst, [hashtable]$Secrets)
    $list = New-Object System.Collections.ArrayList
    $add = { param($n, $v, $flag, $secret, $sec) [void]$list.Add([pscustomobject]@{ Name = $n; Value = $v; Flag = $flag; Secret = $secret; Secure = $sec }) }
    & $add 'ConfigurationFile' $(if ($Inst.WindowMode) { Get-WindowIniPath $Inst.Ini } else { $Inst.Ini }) $false $false $null
    $quietSimple = ([string]$Inst.Keys['QUIETSIMPLE'] -ieq 'True')
    if ((-not $Inst.WindowMode) -and (-not $quietSimple)) { & $add 'Q' '' $true $false $null }
    & $add 'IACCEPTSQLSERVERLICENSETERMS' '' $true $false $null
    # -IgnorePendingRestart: setup's own rule against a pending restart is turned off.
    if ($Inst.PSObject.Properties['IgnoreRestart'] -and $Inst.IgnoreRestart) { & $add 'SKIPRULES' 'RebootRequiredCheck' $false $false $null }
    # Accounts and auth mode that differ from the ini go on the command line,
    # which overrides the file (Microsoft documents this; untested here). The
    # ini itself is never rewritten.
    if ($Inst.EngineAccount -ine $Inst.IniEngine) { & $add 'SQLSVCACCOUNT' $Inst.EngineAccount $false $false $null }
    if ($Inst.AgentAccount -ine $Inst.IniAgent) { & $add 'AGTSVCACCOUNT' $Inst.AgentAccount $false $false $null }
    if ($Inst.Mixed -and -not $Inst.IniMixed) { & $add 'SECURITYMODE' 'SQL' $false $false $null }
    # Updates: a folder turns them on from that folder; none keeps them off.
    if ($Inst.Updates) { & $add 'UPDATEENABLED' 'True' $false $false $null; & $add 'UPDATESOURCE' $Inst.Updates $false $false $null }
    elseif ($Inst.UpdatesOff) { & $add 'UPDATEENABLED' 'False' $false $false $null }
    foreach ($k in @(Get-PasswordKeys $Inst)) {
        if ($null -eq $Secrets) { if (-not $Inst.WindowMode) { & $add $k.Switch '' $false $true $null } }
        elseif ($Secrets.ContainsKey($k.Key)) { & $add $k.Switch '' $false $true $Secrets[$k.Key] }
    }
    return $list.ToArray()
}

function Register-ResumeTask {
    # THE ONE scheduled task this script makes: SqlStack-Resume, for this user,
    # at logon, with highest privileges, running powershell.exe with -Arguments.
    param([string]$Arguments)
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $action = New-ScheduledTaskAction -Execute (Join-Path $PSHOME 'powershell.exe') -Argument $Arguments
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
    $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $script:ResumeTaskName -Action $action -Trigger $trigger -Principal $principal -Settings $settings `
        -Description 'Opens the SqlStack window again after a restart of Windows. SqlStack removes it when it starts.' -Force -ErrorAction Stop | Out-Null
}

function Remove-ResumeTask {
    # Removes SqlStack-Resume when it is there. $true when one was removed.
    if (-not (Get-ScheduledTask -TaskName $script:ResumeTaskName -ErrorAction SilentlyContinue)) { return $false }
    Unregister-ScheduledTask -TaskName $script:ResumeTaskName -Confirm:$false -ErrorAction Stop
    return $true
}

function Invoke-WindowsRestart {
    # The restart of Windows, in order, with its three actions handed in as
    # script blocks so -SelfTest drives it with fakes. With -ResumeArguments
    # the task is registered FIRST, and a task that cannot be registered
    # restarts nothing. A restart that fails removes the task again.
    # Returns ONE object: .Ok .Text
    param([string]$ResumeArguments = '', [scriptblock]$Register, [scriptblock]$Remove, [scriptblock]$Restart)
    if ($ResumeArguments) {
        try { & $Register $ResumeArguments }
        catch { return [pscustomobject]@{ Ok = $false; Text = ('the task that opens SqlStack again could not be registered: {0}. Windows was not restarted.' -f $_.Exception.Message) } }
    }
    try { & $Restart }
    catch {
        $left = ''
        if ($ResumeArguments) { try { & $Remove } catch { $left = ' The task SqlStack-Resume could not be removed again.' } }
        return [pscustomobject]@{ Ok = $false; Text = ('Windows could not be restarted: {0}.{1}' -f $_.Exception.Message, $left) }
    }
    return [pscustomobject]@{ Ok = $true; Text = $(if ($ResumeArguments) { 'Windows is restarting; SqlStack opens again after you sign in' } else { 'Windows is restarting' }) }
}

function Write-SetupFailedMarker {
    # <NAME>.setup-failed.txt beside the ini: two lines, the time and setup's
    # exit code; never a password. Written as the window ini is (UTF-8, no BOM).
    param([string]$Path, [string]$Code)
    $text = ('time: {0}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz')) + "`r`n" + ('setup exit code: {0}' -f $Code) + "`r`n"
    [IO.File]::WriteAllText($Path, $text, (New-Object Text.UTF8Encoding($false)))
}

function Get-InstanceAttention {
    # Why a REGISTERED instance cannot be treated as already installed, or ''
    # when it can: a marker a failed setup left, or no engine service.
    # -ServiceExists is a seam, so -SelfTest fakes it.
    param([string]$Name, [string]$InstanceId, [string]$MarkerPath, [scriptblock]$ServiceExists)
    if (-not $InstanceId) { return '' }
    if ($MarkerPath -and (Test-Path -LiteralPath $MarkerPath -PathType Leaf)) {
        $code = '?'
        foreach ($l in @([IO.File]::ReadAllLines($MarkerPath))) { if ($l -match '^setup exit code:\s*(.+)$') { $code = $Matches[1].Trim() } }
        return ('setup failed last time (exit {0}). Uninstall it, or repair it and delete {1}, then press Install again.' -f $code, $MarkerPath)
    }
    $svc = @(Get-ServiceNames $Name)[0]
    if (-not [bool](& $ServiceExists $svc)) { return ('it is registered but has no service ({0}). Uninstall it, or repair it, then press Install again.' -f $svc) }
    return ''
}

function Get-MediaKeyNote {
    # Whether the media carries a product key file: <media>\x64\DefaultSetup.ini
    # with a PID= line. The key itself is never kept, shown or logged.
    param([string]$MediaDir)
    if (-not $MediaDir) { return '' }
    $f = Join-Path $MediaDir 'x64\DefaultSetup.ini'
    $has = $false
    if (Test-Path -LiteralPath $f -PathType Leaf) { foreach ($l in @([IO.File]::ReadAllLines($f))) { if ($l -match '^\s*PID\s*=') { $has = $true; break } } }
    if ($has) { return 'edition key: carried by the media' }
    return 'WARNING: this media carries no product key file. Setup will install whatever edition the media defaults to (Evaluation media expires after 180 days). Check the edition in the result.'
}

function Invoke-ListenerCheck {
    # The check after an install. The engine is restarted ONLY when this run
    # changed the registry binding: a failed check never restarts it on its
    # own. Then up to 13 tries, 5 seconds apart. Every action is handed in,
    # so -SelfTest drives it with fakes. Returns the last check (.Ok .Text).
    param([bool]$RegChanged, [scriptblock]$Restart, [scriptblock]$Listener, [scriptblock]$Sleep, [scriptblock]$OnState = { param($s) })
    if ($RegChanged) { & $OnState 'restarting'; & $Restart }
    & $OnState 'checking'
    $check = & $Listener
    for ($t = 0; ($t -lt 12) -and (-not $check.Ok); $t++) { & $Sleep 5; $check = & $Listener }
    return $check
}

function Get-CheckResult {
    # The last state and result line of an instance that was installed and
    # configured: done, or installed, check failed. -Edition is read after an
    # install; Evaluation puts WARNING first.
    param([object]$Check, [string]$Ip, [int]$Port, [string]$Edition = '')
    $warn = $(if ($Edition -match 'Evaluation') { 'WARNING: ' } else { '' })
    $ed = $(if ($Edition -match 'Evaluation') { ('edition {0} (it expires after 180 days). ' -f $Edition) } elseif ($Edition) { ('edition {0}. ' -f $Edition) } else { '' })
    $addr = $(if ($Ip) { $Ip } else { '127.0.0.1' })
    if ($Check.Ok) {
        return [pscustomobject]@{ State = 'done'; Text = ('{0}{1}{2}. Checked from this server only. Open port {3} in the firewall for other machines.' -f $warn, $ed, ([string]$Check.Text).TrimEnd('.'), $Port) }
    }
    return [pscustomobject]@{ State = 'installed, check failed'; Text = ('{0}{1}SQL Server is installed. The login test over {2},{3} did not answer. Test it by hand before changing anything. ({4})' -f $warn, $ed, $addr, $Port, $Check.Text) }
}

function Write-Summary {
    if ($script:Rows.Count -eq 0) { return }
    Write-Log ''
    Write-Log 'SUMMARY'
    foreach ($line in (($script:Rows | Format-Table -AutoSize | Out-String -Width 200) -split "`r?`n")) { if ($line.Trim()) { Write-Log $line } }
    if ($script:LogPath) { Write-Host ('Log: ' + $script:LogPath) }
}

function Stop-Run {
    param([string]$Message, [int]$Code = 1)
    Write-Log ('STOP: ' + $Message) 'Red'
    Write-Summary
    Write-Machine 'END' @([string]$Code, $Message)
    exit $Code
}

if ($LoadFunctionsOnly) { return }

# ======================================================================
#  -SelfTest: headless. It changes nothing on this machine but a scratch
#  key under HKCU and files under %TEMP%, and removes both.
# ======================================================================
if ($SelfTest) {
    $ErrorActionPreference = 'Stop'
    $script:passes = 0; $script:fails = 0
    function Assert-True {
        param([string]$Name, [bool]$Cond)
        if ($Cond) { Write-Host ("  PASS  {0}" -f $Name); $script:passes++ }
        else { Write-Host ("  FAIL  {0}" -f $Name) -ForegroundColor Red; $script:fails++ }
    }
    $self = $PSCommandPath
    $enc = New-Object Text.UTF8Encoding($false)
    $tmp = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-install-selftest-' + [guid]::NewGuid().ToString('N'))
    [void](New-Item -ItemType Directory -Path $tmp -Force)
    Write-Host 'SqlStack-Install -SelfTest'
    try {
        Write-Host ''
        Write-Host '-- the file itself --'
        $pt = $null; $pe = $null
        [void][System.Management.Automation.Language.Parser]::ParseFile($self, [ref]$pt, [ref]$pe)
        $bytes = [IO.File]::ReadAllBytes($self)
        $high = @($bytes | Where-Object { $_ -gt 0x7F }).Count
        Assert-True ('file: it parses ({0} error(s)) and is plain ASCII ({1} byte(s) above 0x7F of {2})' -f @($pe).Count, $high, $bytes.Length) ((@($pe).Count -eq 0) -and ($high -eq 0))

        Write-Host ''
        Write-Host '-- which accounts have a password to ask for --'
        $np = @('CONTOSO\svc-sqla') | Where-Object { Test-AccountNeedsPassword $_ }
        $no = @('NT Service\MSSQL$A', 'NT AUTHORITY\NETWORK SERVICE', 'CONTOSO\gmsa-sql$', '', '  ') | Where-Object { Test-AccountNeedsPassword $_ }
        Assert-True ('accounts: a domain account needs a password; a virtual, a built-in, a group managed (ends in $) and a blank one do not ({0} / {1})' -f @($np).Count, @($no).Count) ((@($np).Count -eq 1) -and (@($no).Count -eq 0))

        Write-Host ''
        Write-Host '-- a stand-in for setup.exe: it writes each argument it received, as UTF-16 hex, to the file ARGV_OUT names --'
        $exe = Join-Path $tmp 'standin-setup.exe'
        Add-Type -OutputType ConsoleApplication -OutputAssembly $exe -TypeDefinition @'
using System; using System.IO; using System.Text;
public static class SqlStackStandInSetup { public static int Main(string[] a) {
  var sb = new StringBuilder();
  foreach (var s in a) { foreach (char c in s) sb.Append(((int)c).ToString("X4")); sb.Append("\r\n"); }
  File.AppendAllText(Environment.GetEnvironmentVariable("ARGV_OUT"), sb.ToString());
  string code = Environment.GetEnvironmentVariable("STANDIN_EXIT"); return string.IsNullOrEmpty(code) ? 0 : int.Parse(code); } }
'@
        $argvOut = Join-Path $tmp 'argv-out.txt'
        $env:ARGV_OUT = $argvOut
        $hex = { param([string]$s) (@($s.ToCharArray() | ForEach-Object { ([int]$_).ToString('X4') }) -join '') }
        $toSecure = { param([string]$s) $x = New-Object Security.SecureString; foreach ($c in $s.ToCharArray()) { $x.AppendChar($c) }; $x }

        Write-Host ''
        Write-Host '-- quoting: every value reaches the started process byte for byte --'
        $values = @('Abc123!x', 'has a space', '%TEMP%', '& | < > ^', 'ends\', 'ends\\', 'a=b=c', '/starts', ('caf' + [char]0x00E9 + 'X'))
        $same = 0
        foreach ($v in $values) {
            if (Test-Path -LiteralPath $argvOut) { Remove-Item -LiteralPath $argvOut -Force }
            $argList = @(
                [pscustomobject]@{ Name = 'ConfigurationFile'; Value = 'C:\x y\A-install.ini'; Flag = $false; Secret = $false; Secure = $null },
                [pscustomobject]@{ Name = 'Q'; Value = ''; Flag = $true; Secret = $false; Secure = $null },
                [pscustomobject]@{ Name = 'SAPWD'; Value = ''; Flag = $false; Secret = $true; Secure = (& $toSecure $v) })
            $code = Invoke-Setup -SetupExe $exe -ArgList $argList
            $got = @([IO.File]::ReadAllLines($argvOut))
            if (($code -eq 0) -and ($got.Count -eq 3) -and ($got[0] -eq (& $hex '/ConfigurationFile=C:\x y\A-install.ini')) -and ($got[1] -eq (& $hex '/Q')) -and ($got[2] -eq (& $hex ('/SAPWD=' + $v)))) { $same++ }
        }
        Assert-True ('quoting: {0} of {1} values (a space, %VAR%, shell characters, a trailing backslash, two trailing backslashes, =, a leading /, a non-ASCII letter) arrived byte for byte' -f $same, $values.Count) ($same -eq $values.Count)
        $refused = 0
        foreach ($bad in @('has"quote', ('tab' + [char]9 + 'x'))) { try { [void](ConvertTo-SetupArgument -Name 'SAPWD' -Value $bad) } catch { $refused++ } }
        Assert-True ('quoting: a double quote and a control character are refused, never passed ({0} of 2)' -f $refused) ($refused -eq 2)
        $shown = Format-SetupArguments @([pscustomobject]@{ Name = 'SAPWD'; Value = ''; Flag = $false; Secret = $true; Secure = (& $toSecure 'Sup3r secret') })
        Assert-True ("quoting: the command line as shown or logged carries *** for a secret ('{0}')" -f $shown) ($shown -ceq '/SAPWD="***"')

        Write-Host ''
        Write-Host '-- passwords over standard input --'
        $b64 = { param([string]$s) [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($s)) }
        $plain = { param([Security.SecureString]$s) $b = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($s); try { [Runtime.InteropServices.Marshal]::PtrToStringBSTR($b) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($b) } }
        $pwA = 'pass word ' + [char]0x00E9 + '\'
        $reader = New-Object IO.StringReader ((@(([string][char]0xFEFF + 'BEGIN'), ((& $b64 '#sa') + ' ' + (& $b64 $pwA)), ((& $b64 'CONTOSO\svc-sqla') + ' ' + (& $b64 'x y')), 'END', ((& $b64 'late') + ' ' + (& $b64 'ignored'))) -join "`r`n"))
        $got = Read-SecretInput $reader
        Assert-True ('stdin: two password lines between BEGIN and END are read back exactly (a space, a non-ASCII letter, a trailing backslash); a line after END is not read ({0} key(s))' -f $got.Count) `
            (($got.Count -eq 2) -and ((& $plain $got['#sa']) -ceq $pwA) -and ((& $plain $got['contoso\SVC-sqla']) -ceq 'x y'))
        $badLine = ''
        try { [void](ConvertFrom-SecretLine 'not base64 !!') } catch { $badLine = $_.Exception.Message }
        Assert-True ("stdin: a line that is not two base64 fields is refused, and the refusal does not quote it ('{0}')" -f $badLine) (($badLine -ne '') -and ($badLine -notmatch 'not base64 !!'))

        Write-Host ''
        Write-Host '-- the one safety rule --'
        $script:SetNames = @('ZZA')
        $ran = $false; $msg = ''
        try { Invoke-InstanceChange -InstanceName 'NEW2022' -What 'probe' -Action { $ran = $true } } catch { $msg = $_.Exception.Message }
        $ranOwn = Invoke-InstanceChange -InstanceName 'zza' -What 'probe' -Action { 'RAN' } 6>$null
        Assert-True ("safety: a name outside the ini set is refused before its action runs ('{0}'); a name in the set runs" -f $msg) ((-not $ran) -and ($msg -match '^REFUSED') -and ($ranOwn -eq 'RAN'))

        Write-Host ''
        Write-Host '-- the TCP binding, against a scratch key under HKCU shaped like a real Tcp key --'
        $root = 'HKCU:\Software\SqlStackInstallSelfTest-' + [guid]::NewGuid().ToString('N')
        $tcp = "$root\Tcp"
        $newScratch = {
            if (Test-Path $root) { Remove-Item $root -Recurse }
            New-Item -Path $tcp -Force | Out-Null
            New-ItemProperty -Path $tcp -Name 'Enabled' -Value 0 -PropertyType DWord | Out-Null
            New-ItemProperty -Path $tcp -Name 'ListenOnAllIPs' -Value 1 -PropertyType DWord | Out-Null
            foreach ($s in @(@('IP1', '10.0.0.5'), @('IP2', '127.0.0.1'))) {
                $p = "$tcp\$($s[0])"; New-Item $p | Out-Null
                New-ItemProperty -Path $p -Name 'Active' -Value 1 -PropertyType DWord | Out-Null
                New-ItemProperty -Path $p -Name 'Enabled' -Value 0 -PropertyType DWord | Out-Null
                New-ItemProperty -Path $p -Name 'IpAddress' -Value $s[1] -PropertyType String | Out-Null
                New-ItemProperty -Path $p -Name 'TcpDynamicPorts' -Value '0' -PropertyType String | Out-Null
                New-ItemProperty -Path $p -Name 'TcpPort' -Value '' -PropertyType String | Out-Null
            }
            New-Item "$tcp\IPAll" | Out-Null
            New-ItemProperty -Path "$tcp\IPAll" -Name 'TcpDynamicPorts' -Value '0' -PropertyType String | Out-Null
            New-ItemProperty -Path "$tcp\IPAll" -Name 'TcpPort' -Value '' -PropertyType String | Out-Null
        }
        $val = { param($sub, $name) (Get-Item (Join-Path $tcp $sub)).GetValue($name) }
        try {
            & $newScratch
            $script:RegChanged = $false
            [void](Set-TcpBinding -TcpKey $tcp -Port 14341)
            $first = $script:RegChanged; $script:RegChanged = $false
            [void](Set-TcpBinding -TcpKey $tcp -Port 14341)
            Assert-True ('binding: no address = IPAll carries the port, ListenOnAllIPs 1, TCP on; a second run changes nothing ({0}/{1}/{2}; changed {3} then {4})' -f (& $val 'IPAll' 'TcpPort'), (Get-Item $tcp).GetValue('ListenOnAllIPs'), (Get-Item $tcp).GetValue('Enabled'), $first, $script:RegChanged) `
                (((& $val 'IPAll' 'TcpPort') -eq '14341') -and ((& $val 'IPAll' 'TcpDynamicPorts') -eq '') -and ((Get-Item $tcp).GetValue('ListenOnAllIPs') -eq 1) -and ((Get-Item $tcp).GetValue('Enabled') -eq 1) -and $first -and (-not $script:RegChanged))
            & $newScratch
            [void](Set-TcpBinding -TcpKey $tcp -Port 14341 -Ip '10.0.0.5')
            Assert-True ('binding: an address that has a section = that section carries the port and is enabled, ListenOnAllIPs 0 ({0}/{1}/{2})' -f (& $val 'IP1' 'TcpPort'), (& $val 'IP1' 'Enabled'), (Get-Item $tcp).GetValue('ListenOnAllIPs')) `
                (((& $val 'IP1' 'TcpPort') -eq '14341') -and ((& $val 'IP1' 'Enabled') -eq 1) -and ((Get-Item $tcp).GetValue('ListenOnAllIPs') -eq 0) -and ((& $val 'IP2' 'Enabled') -eq 0))
            & $newScratch
            $notes = Set-TcpBinding -TcpKey $tcp -Port 14341 -Ip '10.20.30.41'
            $script:RegChanged = $false
            [void](Set-TcpBinding -TcpKey $tcp -Port 14341 -Ip '10.20.30.41')
            Assert-True ("binding: an address with no section = a new IP3 copied from IP1 carries it; a second run changes nothing ('{0}'; IP3 {1}:{2}; changed again {3})" -f @($notes)[0], (& $val 'IP3' 'IpAddress'), (& $val 'IP3' 'TcpPort'), $script:RegChanged) `
                (((& $val 'IP3' 'IpAddress') -eq '10.20.30.41') -and ((& $val 'IP3' 'TcpPort') -eq '14341') -and ((& $val 'IP3' 'Enabled') -eq 1) -and (-not $script:RegChanged))
        } finally { if (Test-Path $root) { Remove-Item $root -Recurse } }
        Assert-True 'binding: the scratch key is removed' (-not (Test-Path $root))

        Write-Host ''
        Write-Host '-- the whole loop as a child process, on a made-up run folder, with the stand-in for setup --'
        $run = Join-Path $tmp 'run 1'
        $exp = Join-Path $run 'export'
        [void](New-Item -ItemType Directory -Path $exp -Force)
        $mkIni = {
            param($nm, $mixed, $svc, $agt)
            $l = @('; made for SqlStack-Install -SelfTest', '[OPTIONS]', 'ACTION="Install"', 'FEATURES=SQLENGINE', ('INSTANCENAME="' + $nm + '"'), 'QUIET="True"',
                ('SQLSVCACCOUNT="' + $svc + '"'), ('AGTSVCACCOUNT="' + $agt + '"'))
            if ($mixed) { $l += 'SECURITYMODE="SQL"' }
            [IO.File]::WriteAllText((Join-Path $exp ($nm + '-install.ini')), ($l -join "`r`n"), $enc)
            [IO.File]::WriteAllText((Join-Path $exp ($nm + '-post-install.sql')), "SET NOCOUNT ON;`r`nGO", $enc)
        }
        & $mkIni 'ZZHARNA' $true 'CONTOSO\svc-sqla' 'NT Service\SQLAgent$ZZHARNA'
        & $mkIni 'ZZHARNB' $false 'NT Service\MSSQL$ZZHARNB' 'NT Service\SQLAgent$ZZHARNB'
        $spec = [ordered]@{ instances = @(
                [ordered]@{ name = 'NEW2022'; protected = $true },
                [ordered]@{ name = 'ZZHARNA'; ip = '10.20.30.41'; listenAll = $false; ports = [ordered]@{ tcp = 14341 }; mediaPath = 'C:\no\such\media' },
                [ordered]@{ name = 'ZZHARNB'; ports = [ordered]@{ tcp = 14342 }; mediaPath = 'C:\no\such\media' }) }
        [IO.File]::WriteAllText((Join-Path $run 'spec.json'), ($spec | ConvertTo-Json -Depth 6), $enc)
        # The window's install.json: an updates folder (one .exe in it) for ZZHARNA, none for ZZHARNB.
        $updDir = Join-Path $tmp 'updates 2022'
        [void](New-Item -ItemType Directory -Path $updDir -Force)
        [IO.File]::WriteAllText((Join-Path $updDir 'SQLServer2022-KB0000000-x64.exe'), 'not a real package', $enc)
        [IO.File]::WriteAllText((Join-Path $run 'install.json'), ([ordered]@{ host = 'X'; updates = [ordered]@{ ZZHARNA = $updDir } } | ConvertTo-Json -Depth 4), $enc)
        $child = {
            # Runs this script as a child and returns its exit code and output lines.
            param([string]$Arguments, [string[]]$StdinLines = @())
            $psi = New-Object Diagnostics.ProcessStartInfo
            $psi.FileName = (Join-Path $PSHOME 'powershell.exe')
            $psi.Arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $self + '" ' + $Arguments
            $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
            $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
            $p = [Diagnostics.Process]::Start($psi)
            $errTask = $p.StandardError.ReadToEndAsync()
            foreach ($l in $StdinLines) { $p.StandardInput.WriteLine($l) }
            $p.StandardInput.Close()
            $out = $p.StandardOutput.ReadToEnd()
            $p.WaitForExit()
            return [pscustomobject]@{ Code = $p.ExitCode; Lines = [string[]]@($out -split "`r?`n"); Err = [string]$errTask.Result }
        }
        $alias = 'Loopback Pseudo-Interface 1'
        $hasAlias = [bool](Get-NetIPInterface -InterfaceAlias $alias -ErrorAction SilentlyContinue)
        if (-not $hasAlias) { $alias = [string]@(Get-NetIPInterface | Select-Object -First 1)[0].InterfaceAlias }
        $common = ('-RunFolder "{0}" -InterfaceAlias "{1}"' -f $run, $alias)

        $r0 = & $child ($common + ' -SetupExeOverride "' + $exe + '"')
        Assert-True ('harness: -SetupExeOverride without -SelfTestHarness is refused, exit {0}' -f $r0.Code) (($r0.Code -eq 1) -and (@($r0.Lines | Where-Object { $_ -match 'only together with -SelfTestHarness' }).Count -ge 1))

        if (Test-Path -LiteralPath $argvOut) { Remove-Item -LiteralPath $argvOut -Force }
        $r1 = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '"')
        $needs = @($r1.Lines | Where-Object { $_.StartsWith('@@NEED') })
        $steps = @($r1.Lines | Where-Object { $_.StartsWith("@@STEP`tZZHARNA`t") } | ForEach-Object { ($_ -split "`t")[2] })
        Assert-True ('preview: exit {0}, the stand-in was not started; ZZHARNA will get [{1}]; it will ask for {2} password(s); the protected NEW2022 is not in it' -f $r1.Code, ($steps -join ', '), $needs.Count) `
            (($r1.Code -eq 0) -and (($steps -join ',') -ceq 'address,install,edition,bind,sql,restart,check') -and ($needs.Count -eq 2) -and (@($r1.Lines | Where-Object { $_ -match 'NEW2022' }).Count -eq 0) -and (-not (Test-Path -LiteralPath $argvOut)))
        $updA = [string]@($r1.Lines | Where-Object { $_.StartsWith("@@STEP`tZZHARNA`tinstall") })[0]
        $updB = [string]@($r1.Lines | Where-Object { $_.StartsWith("@@STEP`tZZHARNB`tinstall") })[0]
        $cmdB = [string]@($r1.Lines | Where-Object { ($_ -match 'ZZHARNB-install\.ini') -and ($_ -match 'ConfigurationFile') })[0]
        Assert-True ('updates: the preview says "updates from <folder>" for ZZHARNA and "no updates applied" for ZZHARNB, whose ini does not say UPDATEENABLED, so its command line carries /UPDATEENABLED="False"') `
            ($updA.Contains('updates from ' + $updDir) -and (-not $updA.Contains('WARNING')) -and $updB.Contains('no updates applied') -and $cmdB.Contains('/UPDATEENABLED="False"') -and (-not $cmdB.Contains('UPDATESOURCE')))
        Assert-True ('updates: a folder that is missing, or holds no .exe, is a warning in words, never a refusal ({0} / {1})' -f (Get-UpdatesNote (Join-Path $tmp 'no such folder')), (Get-UpdatesNote $tmp)) `
            (((Get-UpdatesNote (Join-Path $tmp 'no such folder')) -match 'does not exist') -and ((Get-UpdatesNote $exp) -match 'holds no \.exe') -and ((Get-UpdatesNote $updDir) -eq ''))
        # Fix 1 (2026-11-23): the address step starts with WARNING and says to add it by hand.
        $addStep = [string]@($r1.Lines | Where-Object { $_.StartsWith("@@STEP`tZZHARNA`taddress") })[0]
        Assert-True ("address: the preview line starts with WARNING and says to add it by hand on a client server ('{0}')" -f ($addStep -replace "`t", ' ')) `
            ((($addStep -split "`t")[3]) -ceq ('WARNING: adds 10.20.30.41/24 to card {0}. On a client server add it by hand first.' -f $alias))
        # Fix 4a: media with no x64\DefaultSetup.ini is a WARNING step.
        $edStep = [string]@($r1.Lines | Where-Object { $_.StartsWith("@@STEP`tZZHARNA`tedition") })[0]
        Assert-True ("edition: media with no key file is a WARNING in the preview ('{0}')" -f ($edStep -replace "`t", ' ')) `
            ((($edStep -split "`t")[3]) -match '^WARNING: this media carries no product key file\..*Evaluation media expires after 180 days')
        $rD = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '" -HarnessFake dhcp')
        Assert-True ('address: a card that uses DHCP is a PROBLEM that stops the preview, exit {0}' -f $rD.Code) `
            (($rD.Code -eq 1) -and (@($rD.Lines | Where-Object { $_ -match '^@@PROBLEM\t.*uses DHCP; adding an address would switch it to static' }).Count -eq 1))
        $rP = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '" -IgnorePendingRestart')
        $cmdP = [string]@($rP.Lines | Where-Object { ($_ -match 'ZZHARNA-install\.ini') -and ($_ -match 'ConfigurationFile') })[0]
        $cmdA = [string]@($r1.Lines | Where-Object { ($_ -match 'ZZHARNA-install\.ini') -and ($_ -match 'ConfigurationFile') })[0]
        Assert-True ('pending restart: -IgnorePendingRestart puts /SKIPRULES="RebootRequiredCheck" on the setup command, and without it there is none (exit {0})' -f $rP.Code) `
            (($rP.Code -eq 0) -and $cmdP.Contains('/SKIPRULES="RebootRequiredCheck"') -and (-not $cmdA.Contains('SKIPRULES')))
        $nnCalls = @([System.Management.Automation.Language.Parser]::ParseFile($self, [ref]$null, [ref]$null).FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'New-NetIPAddress') }, $true))
        Assert-True ('address: the one New-NetIPAddress call passes -SkipAsSource $true ({0} call(s))' -f $nnCalls.Count) `
            (($nnCalls.Count -eq 1) -and ($nnCalls[0].Extent.Text -match '-SkipAsSource \$true'))

        $pwSa = 'Sa pass word 1!'; $pwSvc = 'svc-secret\'
        $lines = @('BEGIN', ((& $b64 '#sa') + ' ' + (& $b64 $pwSa)), ((& $b64 'CONTOSO\svc-sqla') + ' ' + (& $b64 $pwSvc)), 'END')
        $r2 = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '" -Go -Yes -PasswordStdin') $lines
        $states = @($r2.Lines | Where-Object { $_.StartsWith('@@STATE') } | ForEach-Object { $f = $_ -split "`t"; $f[1] + ':' + $f[2] })
        $argv = @(); if (Test-Path -LiteralPath $argvOut) { $argv = @([IO.File]::ReadAllLines($argvOut)) }
        Assert-True ('install: the two passwords reached the stand-in byte for byte as /SAPWD and /SQLSVCPASSWORD ({0} argument(s))' -f $argv.Count) `
            (($argv -contains (& $hex ('/SAPWD=' + $pwSa))) -and ($argv -contains (& $hex ('/SQLSVCPASSWORD=' + $pwSvc))))
        $quietIni = Join-Path $exp 'ZZHARNA-install.ini'
        $windowIni = Join-Path $exp 'ZZHARNA-install-window.ini'
        Assert-True ('install: with every password typed setup ran quiet, on the first ini, with /Q, and no window copy of the ini was written') `
            (($argv -contains (& $hex ('/ConfigurationFile=' + $quietIni))) -and ($argv -contains (& $hex '/Q')) -and (-not (Test-Path -LiteralPath $windowIni)))
        Assert-True ('updates: the stand-in received /UPDATEENABLED=True and /UPDATESOURCE=<the folder, which has a space>') `
            (($argv -contains (& $hex '/UPDATEENABLED=True')) -and ($argv -contains (& $hex ('/UPDATESOURCE=' + $updDir))))
        Assert-True ('install: the state lines arrive in order [{0}]' -f ($states -join ' > ')) `
            (($states -join '>') -ceq 'ZZHARNA:waiting>ZZHARNB:waiting>ZZHARNA:adding address>ZZHARNA:installing>ZZHARNA:failed')
        $endLine = [string]@($r2.Lines | Where-Object { $_.StartsWith('@@END') })[0]
        Assert-True ("install: setup answered 0 for an instance that does not exist, and that is a FAILURE, exit {0} ('{1}')" -f $r2.Code, ($endLine -replace "`t", ' ')) `
            (($r2.Code -eq 2) -and ($endLine -match 'not registered as installed') -and ($states -notcontains 'ZZHARNA:done'))
        $leaks = New-Object System.Collections.ArrayList
        $needles = @($pwSa, $pwSvc, (& $b64 $pwSa), (& $b64 $pwSvc))
        foreach ($l in @($r2.Lines) + @($r2.Err)) { foreach ($nd in $needles) { if ($l -and $l.Contains($nd)) { [void]$leaks.Add('output') } } }
        foreach ($f in @(Get-ChildItem -LiteralPath $run -Recurse -File)) {
            $fb = [IO.File]::ReadAllBytes($f.FullName)
            foreach ($nd in $needles) {
                foreach ($e in @([Text.Encoding]::UTF8, [Text.Encoding]::Unicode)) {
                    if ($e.GetString($fb).Contains($nd)) { [void]$leaks.Add($f.Name) }
                }
            }
        }
        $logs = @(Get-ChildItem -LiteralPath $run -Filter 'install-log-*.txt')
        Assert-True ('install: its log is in the run folder ({0} file(s)); no password, plain or base64, is in any output line or in any of the {1} file(s) under the run folder ({2} hit(s))' -f $logs.Count, @(Get-ChildItem -LiteralPath $run -Recurse -File).Count, $leaks.Count) `
            (($logs.Count -eq 1) -and ($leaks.Count -eq 0))

        # Fix 2 (2026-11-23): a setup that ends with an exit code but 0 or 3010 leaves a marker.
        $markerA = Join-Path $exp 'ZZHARNA.setup-failed.txt'
        $env:STANDIN_EXIT = '1'
        try { $rF = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '" -Go -Yes -PasswordStdin') $lines } finally { Remove-Item Env:\STANDIN_EXIT -ErrorAction SilentlyContinue }
        $mk = @(); if (Test-Path -LiteralPath $markerA) { $mk = @([IO.File]::ReadAllLines($markerA)) }
        $mkLeak = @($mk | Where-Object { $l = $_; @($needles | Where-Object { $l.Contains($_) }).Count -gt 0 }).Count
        Assert-True ("failed setup: exit {0}; the marker holds two lines, the time and 'setup exit code: 1' ({1}), and no password ({2} hit(s))" -f $rF.Code, ($mk -join ' | '), $mkLeak) `
            (($rF.Code -eq 2) -and ($mk.Count -eq 2) -and ($mk[0] -match '^time: ') -and ($mk[1] -ceq 'setup exit code: 1') -and ($mkLeak -eq 0))
        $tmpMk = Join-Path $tmp 'X.setup-failed.txt'
        Write-SetupFailedMarker -Path $tmpMk -Code '1603'
        $atMk = Get-InstanceAttention -Name 'X' -InstanceId 'MSSQL16.X' -MarkerPath $tmpMk -ServiceExists { param($n) $true }
        $atSvc = Get-InstanceAttention -Name 'X' -InstanceId 'MSSQL16.X' -MarkerPath (Join-Path $tmp 'none.txt') -ServiceExists { param($n) $false }
        $atOk = Get-InstanceAttention -Name 'X' -InstanceId 'MSSQL16.X' -MarkerPath (Join-Path $tmp 'none.txt') -ServiceExists { param($n) $n -ceq 'MSSQL$X' }
        $atNew = Get-InstanceAttention -Name 'X' -InstanceId '' -MarkerPath $tmpMk -ServiceExists { param($n) $false }
        Assert-True ("attention: a registered instance with a marker ('{0}') or with no service ('{1}') needs attention; with neither, or not registered, it does not" -f $atMk, $atSvc) `
            (($atMk -match '^setup failed last time \(exit 1603\)\.') -and $atMk.Contains($tmpMk) -and ($atMk -match 'press Install again') -and ($atSvc -match '^it is registered but has no service \(MSSQL\$X\)') -and ($atOk -eq '') -and ($atNew -eq ''))

        # REWRITTEN 2026-11-17 (the owner's ruling: every password is optional).
        # Until then: "a password that was not supplied stops the run before
        # anything starts". Now a blank password means WINDOW MODE for the
        # instance that needs it: no switch for it, and setup runs on the
        # window copy of the ini (QUIET off) and shows its own window.
        if (Test-Path -LiteralPath $argvOut) { Remove-Item -LiteralPath $argvOut -Force }
        $r3 = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '" -Go -Yes -PasswordStdin') @('BEGIN', ((& $b64 'CONTOSO\svc-sqla') + ' ' + (& $b64 $pwSvc)), 'END')
        $argv3 = @(); if (Test-Path -LiteralPath $argvOut) { $argv3 = @([IO.File]::ReadAllLines($argvOut)) }
        $states3 = @($r3.Lines | Where-Object { $_.StartsWith('@@STATE') } | ForEach-Object { $f = $_ -split "`t"; $f[1] + ':' + $f[2] })
        $sapwd3 = @($argv3 | Where-Object { $_.StartsWith((& $hex '/SAPWD')) })
        $wk = @{}; if (Test-Path -LiteralPath $windowIni) { $wk = Read-IniFile $windowIni }
        $qk = Read-IniFile $quietIni
        Assert-True ('window mode: a blank sa password yields NO /SAPWD ({0}) and no /Q; setup ran on the window ini; the service password that WAS typed is still passed' -f $sapwd3.Count) `
            (($sapwd3.Count -eq 0) -and ($argv3 -notcontains (& $hex '/Q')) -and ($argv3 -contains (& $hex ('/ConfigurationFile=' + $windowIni))) -and ($argv3 -contains (& $hex ('/SQLSVCPASSWORD=' + $pwSvc))))
        Assert-True ('window mode: the window ini has the same keys as the first ini with QUIET off ({0} vs {1} key(s); QUIET {2}), holds no password, and the first ini still says QUIET {3}' -f $wk.Count, $qk.Count, $wk['QUIET'], $qk['QUIET']) `
            (($wk.Count -eq $qk.Count) -and ($wk.Count -ge 5) -and ([string]$wk['QUIET'] -ceq 'False') -and ([string]$qk['QUIET'] -ceq 'True') -and
             (@($qk.Keys | Where-Object { ($_ -ne 'QUIET') -and ([string]$wk[$_] -cne [string]$qk[$_]) }).Count -eq 0) -and (@($wk.Keys | Where-Object { $_ -match 'PWD|PASSWORD' }).Count -eq 0))
        Assert-True ('window mode: its state line reads "waiting for you in the SQL Server setup window" [{0}]' -f ($states3 -join ' > ')) `
            ($states3 -contains 'ZZHARNA:waiting for you in the SQL Server setup window')
        Assert-True ('failed setup: a later setup exit of 0 removes the marker ({0})' -f (Test-Path -LiteralPath $markerA)) (-not (Test-Path -LiteralPath $markerA))

        # Fix 7: an error nothing caught ends with END 2 "stopped part way", never "nothing was changed".
        $rC = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '" -Go -Yes -HarnessFake crash')
        $endC = [string]@($rC.Lines | Where-Object { $_.StartsWith('@@END') })[0]
        Assert-True ("crash: exit {0}, END '{1}'" -f $rC.Code, ($endC -replace "`t", ' ')) `
            (($rC.Code -eq 2) -and ($endC -match "^@@END`t2`tunexpected error, the run stopped part way: a crash the test harness asked for"))

        # Fix 4a, 6: pure parts, in this process, with fakes.
        $media = Join-Path $tmp 'media'
        [void](New-Item -ItemType Directory -Path (Join-Path $media 'x64') -Force)
        [IO.File]::WriteAllText((Join-Path $media 'x64\DefaultSetup.ini'), ";SQL Server`r`n[OPTIONS]`r`nPID=""AAAAA-BBBBB-CCCCC-DDDDD-EEEEE""`r`n", $enc)
        $kn1 = Get-MediaKeyNote $media
        Assert-True ("edition: media with a PID= line reads '{0}', never the key; no media folder reads nothing" -f $kn1) (($kn1 -ceq 'edition key: carried by the media') -and ((Get-MediaKeyNote '') -eq ''))
        $ev = New-Object System.Collections.ArrayList
        $n1 = 0
        $c1 = Invoke-ListenerCheck -RegChanged $false -Restart { [void]$ev.Add('restart') } -Listener { $script:lc++; [pscustomobject]@{ Ok = $false; Text = 'no TCP answer' } } -Sleep { param($s) [void]$ev.Add('sleep' + $s) }
        $o1 = $ev.Count; $r1n = @($ev | Where-Object { $_ -eq 'restart' }).Count; $ev.Clear()
        $script:lc = 0
        $c2 = Invoke-ListenerCheck -RegChanged $true -Restart { [void]$ev.Add('restart') } -Listener { $script:lc++; [pscustomobject]@{ Ok = ($script:lc -ge 3); Text = 'login OK: X on 10.0.0.5:14341' } } -Sleep { param($s) [void]$ev.Add('sleep' + $s) }
        Assert-True ("check: a failed check with the binding unchanged restarts nothing and tries 13 times, 5 s apart ({0} sleep(s), {1} restart(s)); a changed binding restarts once, then retries until it answers [{2}]" -f $o1, $r1n, ($ev -join ',')) `
            ((-not $c1.Ok) -and ($o1 -eq 12) -and ($r1n -eq 0) -and $c2.Ok -and (($ev -join ',') -ceq 'restart,sleep5,sleep5'))
        $gOk = Get-CheckResult -Check $c2 -Ip '10.0.0.5' -Port 14341 -Edition 'Enterprise Evaluation Edition (64-bit)'
        $gDev = Get-CheckResult -Check $c2 -Ip '' -Port 14342 -Edition 'Developer Edition (64-bit)'
        $gBad = Get-CheckResult -Check $c1 -Ip '' -Port 14342 -Edition ''
        Assert-True ("result: done ends with the firewall sentence and an Evaluation edition puts WARNING first ('{0}'); a failed check is 'installed, check failed' ('{1}')" -f $gOk.Text, $gBad.Text) `
            (($gOk.State -ceq 'done') -and $gOk.Text.StartsWith('WARNING: edition Enterprise Evaluation') -and $gOk.Text.EndsWith('Checked from this server only. Open port 14341 in the firewall for other machines.') -and
             (-not $gDev.Text.StartsWith('WARNING')) -and $gDev.Text.Contains('edition Developer Edition (64-bit).') -and
             ($gBad.State -ceq 'installed, check failed') -and $gBad.Text.StartsWith('SQL Server is installed. The login test over 127.0.0.1,14342 did not answer. Test it by hand before changing anything.'))
        if (Test-Path -LiteralPath $argvOut) { Remove-Item -LiteralPath $argvOut -Force }
        $r4 = & $child ($common + ' -SelfTestHarness -SetupExeOverride "' + $exe + '" -Go -Yes -ShowSetupWindow')
        $argv4 = @(); if (Test-Path -LiteralPath $argvOut) { $argv4 = @([IO.File]::ReadAllLines($argvOut)) }
        Assert-True ('window mode: -ShowSetupWindow takes the same path: the window ini, no /Q, no password switch ({0} argument(s))' -f $argv4.Count) `
            (($argv4 -contains (& $hex ('/ConfigurationFile=' + $windowIni))) -and ($argv4 -notcontains (& $hex '/Q')) -and (@($argv4 | Where-Object { $_.StartsWith((& $hex '/SAPWD')) -or $_.StartsWith((& $hex '/SQLSVCPASSWORD')) }).Count -eq 0))

        Write-Host ''
        Write-Host '-- the restart of Windows: fakes only; no task is registered and Windows is not restarted --'
        $seen = New-Object System.Collections.ArrayList
        $fReg = { param($a) [void]$seen.Add('register:' + $a) }
        $fRem = { [void]$seen.Add('remove') }
        $fRes = { [void]$seen.Add('restart') }
        $w1 = Invoke-WindowsRestart -ResumeArguments '-File x' -Register $fReg -Remove $fRem -Restart $fRes
        $o1 = ($seen -join ','); $seen.Clear()
        $w2 = Invoke-WindowsRestart -Register $fReg -Remove $fRem -Restart $fRes
        $o2 = ($seen -join ','); $seen.Clear()
        $w3 = Invoke-WindowsRestart -ResumeArguments '-File x' -Register { throw 'access denied' } -Remove $fRem -Restart $fRes
        $o3 = ($seen -join ','); $seen.Clear()
        $w4 = Invoke-WindowsRestart -ResumeArguments '-File x' -Register $fReg -Remove $fRem -Restart { throw 'refused' }
        $o4 = ($seen -join ',')
        Assert-True ('restart: with a resume the task is registered first, then Windows restarts [{0}]; without one only the restart [{1}]; a task that cannot be registered restarts nothing [{2}]; a restart that fails removes the task again [{3}]' -f $o1, $o2, $o3, $o4) `
            ($w1.Ok -and ($o1 -ceq 'register:-File x,restart') -and $w2.Ok -and ($o2 -ceq 'restart') -and (-not $w3.Ok) -and ($o3 -ceq '') -and ($w3.Text -match 'Windows was not restarted') -and (-not $w4.Ok) -and ($o4 -ceq 'register:-File x,remove'))
        $r5 = & $child ('-WindowsRestart -SelfTestHarness -ResumeArguments ' + (& $b64 '-NoProfile -File "C:\a b\SqlStack.ps1" -OpenInstall'))
        $r6 = & $child '-RemoveResumeTask -SelfTestHarness'
        Assert-True ('restart: as a child process under the test harness both modes end 0 and say that nothing was done (exit {0} / {1})' -f $r5.Code, $r6.Code) `
            (($r5.Code -eq 0) -and (@($r5.Lines | Where-Object { $_ -match 'TEST HARNESS: no task is registered' }).Count -eq 1) -and (@($r5.Lines | Where-Object { $_ -match 'TEST HARNESS: Windows is NOT restarted' }).Count -eq 1) -and
             ($r6.Code -eq 0) -and (@($r6.Lines | Where-Object { $_ -match 'TEST HARNESS: no task is looked for or removed' }).Count -eq 1))
    } finally {
        Remove-Item Env:\ARGV_OUT -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
    Write-Host ''
    Write-Host ("RESULT: {0} passed, {1} failed" -f $script:passes, $script:fails)
    if ($script:fails -gt 0) { exit 1 }
    exit 0
}

# ======================================================================
#  Phase 0: checks (preview and -Go)
# ======================================================================
$ErrorActionPreference = 'Stop'
# An error nothing else caught must never read as "nothing was changed": the
# window reads this END line as a run that stopped part way. (Write-Machine
# has no secret scrub; an exception message never holds a password here,
# because passwords travel only as SecureString and the setup command line.)
trap { Write-Machine 'END' @('2', ('unexpected error, the run stopped part way: ' + $_.Exception.Message)); exit 2 }
try { [Console]::OutputEncoding = New-Object Text.UTF8Encoding($false) } catch { }
$isAdmin = (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($SetupExeOverride -and -not $SelfTestHarness) { Stop-Run '-SetupExeOverride is honoured only together with -SelfTestHarness. Nothing was changed.' }
if ($HarnessFake -and -not $SelfTestHarness) { Stop-Run '-HarnessFake is honoured only together with -SelfTestHarness. Nothing was changed.' }
if ($SelfTestHarness) {
    $script:HarnessFakes = @($HarnessFake -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    # A child run under the harness never reads the real card's DHCP state.
    $fakeDhcp = ($script:HarnessFakes -contains 'dhcp')
    $script:Seam.DhcpOn = { param([string]$Alias) $fakeDhcp }.GetNewClosure()
}
if ($Go -and -not $isAdmin -and -not $SelfTestHarness) { Stop-Run '-Go needs an elevated window (Run as administrator). Nothing was changed.' }
if ([Environment]::Is64BitOperatingSystem -and -not [Environment]::Is64BitProcess) { Stop-Run 'this is 32-bit PowerShell; the SQL Server registry is read wrongly from it. Use the 64-bit powershell.exe.' }

# ---- the two modes that install nothing: the resume task and the restart ----
if ($RemoveResumeTask) {
    if ($SelfTestHarness) { Write-Log 'TEST HARNESS: no task is looked for or removed.'; Write-Machine 'END' @('0', 'harness'); exit 0 }
    $had = $false
    try { $had = Remove-ResumeTask } catch { Stop-Run ('the task {0} could not be removed: {1}' -f $script:ResumeTaskName, $_.Exception.Message) 2 }
    Write-Machine 'END' @('0', $(if ($had) { 'the resume task was removed' } else { 'there was no resume task' }))
    exit 0
}
if ($WindowsRestart) {
    $resume = ''
    if ($ResumeArguments) {
        try { $resume = [Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($ResumeArguments)) } catch { Stop-Run '-ResumeArguments is not valid base64. Nothing was changed.' }
    }
    if ($resume -and -not $isAdmin -and -not $SelfTestHarness) { Stop-Run 'registering the task that opens SqlStack again needs an elevated window. Nothing was changed.' }
    $doRegister = { param($a) Register-ResumeTask -Arguments $a }
    $doRemove = { [void](Remove-ResumeTask) }
    $doRestart = { Restart-Computer -Force -ErrorAction Stop }
    if ($SelfTestHarness) {
        $doRegister = { param($a) Write-Log 'TEST HARNESS: no task is registered.' }
        $doRemove = { Write-Log 'TEST HARNESS: no task is removed.' }
        $doRestart = { Write-Log 'TEST HARNESS: Windows is NOT restarted.' }
    }
    $r = Invoke-WindowsRestart -ResumeArguments $resume -Register $doRegister -Remove $doRemove -Restart $doRestart
    if (-not $r.Ok) { Stop-Run $r.Text 2 }
    Write-Machine 'END' @('0', $r.Text)
    exit 0
}

if ([bool]$RunFolder -eq [bool]$IniFolder) { Stop-Run 'give exactly one of -RunFolder or -IniFolder.' }

if ($RunFolder) { $base = [IO.Path]::GetFullPath($RunFolder); $iniDir = Join-Path $base 'export' }
else { $base = [IO.Path]::GetFullPath($IniFolder); $iniDir = $base; if (-not $Media -and -not $SelfTestHarness) { Stop-Run '-IniFolder needs -Media (the folder that holds setup.exe).' } }
if (-not (Test-Path -LiteralPath $iniDir -PathType Container)) { Stop-Run ('no such folder: ' + $iniDir) }
if ($Go) { $script:LogPath = Join-Path $base ('install-log-{0}.txt' -f (Get-Date -Format 'yyyyMMdd-HHmmss')) }

# ---- port, address and media per instance ----
$bind = @{}
if ($RunFolder) {
    $specPath = Join-Path $base 'spec.json'
    if (Test-Path -LiteralPath $specPath) {
        $spec = [IO.File]::ReadAllText($specPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
        foreach ($row in @($spec.instances)) {
            if ($row.PSObject.Properties['protected'] -and $row.protected) { continue }   # an installed instance the planner protects
            $b = [pscustomobject]@{ Ip = ''; Port = 0; Media = '' }
            if ($row.PSObject.Properties['ip']) { $b.Ip = [string]$row.ip }
            if ($row.PSObject.Properties['ports'] -and $row.ports.PSObject.Properties['tcp']) { $b.Port = [int]$row.ports.tcp }
            if ($row.PSObject.Properties['mediaPath']) { $b.Media = [string]$row.mediaPath }
            $bind[[string]$row.name] = $b
        }
    }
} else {
    $csv = Join-Path $base 'bind.csv'
    if (Test-Path -LiteralPath $csv) {
        foreach ($row in @(Import-Csv -LiteralPath $csv)) { $bind[[string]$row.Instance] = [pscustomobject]@{ Ip = ([string]$row.Ip).Trim(); Port = [int]$row.Port; Media = '' } }
    }
}

# ---- updates: an optional folder per instance, from the window's install.json ----
$updates = @{}
$updatesProblem = ''
if ($RunFolder) {
    $choicePath = Join-Path $base 'install.json'
    if (Test-Path -LiteralPath $choicePath) {
        try {
            $choice = [IO.File]::ReadAllText($choicePath, [Text.Encoding]::UTF8) | ConvertFrom-Json
            if ($choice.PSObject.Properties['updates'] -and $choice.updates) {
                foreach ($u in @($choice.updates.PSObject.Properties)) { if (([string]$u.Value).Trim()) { $updates[[string]$u.Name] = ([string]$u.Value).Trim() } }
            }
        } catch { $updatesProblem = ('install.json cannot be read, so the updates folders are unknown: ' + $_.Exception.Message) }
    }
}

# ---- accounts.csv: optional accounts and auth mode per instance ----
# For each instance the EFFECTIVE value is: its accounts.csv cell, else the
# run-wide -EngineAccount / -AgentAccount / -MixedMode, else the ini. A plan
# saved by the SqlStack window carries all three in the ini itself.
$problems = New-Object System.Collections.ArrayList
if ($updatesProblem) { [void]$problems.Add($updatesProblem) }
$accounts = @{}
$acctCsv = Join-Path $iniDir 'accounts.csv'
if (Test-Path -LiteralPath $acctCsv) {
    foreach ($row in @(Import-Csv -LiteralPath $acctCsv)) {
        $n = ([string]$row.Instance).Trim()
        if (-not $n) { continue }
        $accounts[$n] = $row
        if (@('', 'yes', 'no') -notcontains ([string]$row.MixedMode).Trim()) { [void]$problems.Add(('accounts.csv: MixedMode for {0} must be yes, no or blank' -f $n)) }
    }
}

# ---- the ini set ----
$plan = New-Object System.Collections.ArrayList
foreach ($f in @(Get-ChildItem -LiteralPath $iniDir -Filter '*-install.ini' -File)) {
    $keys = Read-IniFile $f.FullName
    $name = [string]$keys['INSTANCENAME']
    if ($name -notmatch '^[A-Za-z][A-Za-z0-9_]{0,15}$') { [void]$problems.Add(('{0}: INSTANCENAME "{1}" is not a valid instance name' -f $f.Name, $name)); continue }
    if ([string]$keys['ACTION'] -ne 'Install') { [void]$problems.Add(('{0}: ACTION is "{1}", not Install; this script only installs' -f $f.Name, $keys['ACTION'])); continue }
    if ($keys.ContainsKey('#INCOMPLETE')) { [void]$problems.Add(('{0}: the planner marked it INCOMPLETE (it must not be run); fix the plan and save again' -f $f.Name)); continue }
    foreach ($pk in @('SAPWD', 'SQLSVCPASSWORD', 'AGTSVCPASSWORD')) { if ($keys.ContainsKey($pk)) { [void]$problems.Add(('{0}: it holds a password ({1}); passwords never go in the ini, remove that line' -f $f.Name, $pk)) } }
    if (@($plan | Where-Object { $_.Name -ieq $name }).Count -gt 0) { [void]$problems.Add(('{0}: a second ini for {1}' -f $f.Name, $name)); continue }
    $sql = Join-Path $iniDir ($name + '-post-install.sql')
    $b = $bind[$name]
    $mediaDir = $Media
    if (-not $mediaDir -and $b) { $mediaDir = $b.Media }
    $a = $accounts[$name]
    $iniMixed = ([string]$keys['SECURITYMODE'] -ieq 'SQL')
    $eng = Select-Effective ([string]$(if ($a) { $a.EngineAccount })) $EngineAccount '-EngineAccount' ([string]$keys['SQLSVCACCOUNT'])
    $agt = Select-Effective ([string]$(if ($a) { $a.AgentAccount })) $AgentAccount '-AgentAccount' ([string]$keys['AGTSVCACCOUNT'])
    $mix = Select-Effective ([string]$(if ($a) { $a.MixedMode })) $MixedMode '-MixedMode' $(if ($iniMixed) { 'yes' } else { 'no' })
    foreach ($v in @($eng, $agt)) {
        $why = Get-ValueProblem -Value $v.Value
        if ($why) { [void]$problems.Add(('{0}: the account {1}: {2}' -f $name, $v.From, $why)) }
    }
    if ($iniMixed -and $mix.Value -ieq 'no') { [void]$problems.Add(('{0}: the ini says SECURITYMODE="SQL"; setup cannot be told "Windows only" on the command line. Remove that line from the ini.' -f $name)) }
    $setupExe = $(if ($mediaDir) { Join-Path $mediaDir 'setup.exe' } else { '' })
    # Honoured ONLY with -SelfTestHarness (refused above otherwise).
    if ($SelfTestHarness -and $SetupExeOverride) { $setupExe = [IO.Path]::GetFullPath($SetupExeOverride) }
    $upd = [string]$updates[$name]
    if ($upd) {
        $why = Get-ValueProblem -Value $upd
        if ($why) { [void]$problems.Add(('{0}: the updates folder: {1}' -f $name, $why)) }
    }
    $updText = 'updates as the ini says'
    if ($upd) { $un = Get-UpdatesNote $upd; $updText = ('updates from {0}' -f $upd) + $(if ($un) { ' (' + $un + ')' } else { '' }) }
    elseif ($RunFolder) { $updText = 'no updates applied' }
    $i = [pscustomobject]@{
        Updates = $upd; UpdatesText = $updText
        UpdatesOff = ([bool]$RunFolder -and (-not $upd) -and ([string]$keys['UPDATEENABLED'] -ine 'False'))
        WindowMode = [bool]$ShowSetupWindow
        Name = $name; Ini = $f.FullName; Keys = $keys
        Sql = $(if (Test-Path -LiteralPath $sql) { $sql } else { '' })
        IniEngine = [string]$keys['SQLSVCACCOUNT']; IniAgent = [string]$keys['AGTSVCACCOUNT']; IniMixed = $iniMixed
        EngineAccount = $eng.Value; EngineFrom = $eng.From; AgentAccount = $agt.Value; AgentFrom = $agt.From
        Mixed = ($mix.Value -ieq 'yes'); MixedFrom = $mix.From
        Ip = $(if ($b) { $b.Ip } else { '' }); Port = $(if ($b) { $b.Port } else { 0 }); HasBind = [bool]$b
        SetupExe = $setupExe; MediaDir = $mediaDir
        IgnoreRestart = [bool]$IgnorePendingRestart
        Marker = (Join-Path $iniDir ($name + '.setup-failed.txt'))
        InstanceId = (Get-InstalledInstanceId $name)
        Attention = ''
    }
    # A registered instance is "already installed" only with no marker of a
    # failed setup AND its engine service there; otherwise it needs attention.
    $i.Attention = Get-InstanceAttention -Name $name -InstanceId $i.InstanceId -MarkerPath $i.Marker -ServiceExists $script:Seam.ServiceExists
    [void]$plan.Add($i)
}
$plan = @($plan | Sort-Object Name)
foreach ($n in @($accounts.Keys)) {
    if (@($plan | Where-Object { $_.Name -ieq $n }).Count -eq 0) { [void]$problems.Add(('accounts.csv names {0}, which has no ini in this set; this script never changes another instance' -f $n)) }
}

$onlyNames = @($Only | ForEach-Object { $_ -split ',' } | ForEach-Object { $_.Trim() } | Where-Object { $_ })
if ($onlyNames.Count -gt 0) {
    foreach ($n in $onlyNames) { if (@($plan | Where-Object { $_.Name -ieq $n }).Count -eq 0) { [void]$problems.Add(('-Only names {0}, which has no ini in {1}' -f $n, $iniDir)) } }
    $plan = @($plan | Where-Object { $onlyNames -icontains $_.Name })
}
if ($plan.Count -eq 0 -and $problems.Count -eq 0) { [void]$problems.Add(('no *-install.ini in {0}' -f $iniDir)) }
$script:SetNames = @($plan | ForEach-Object { $_.Name })

$missingIps = New-Object System.Collections.ArrayList
foreach ($i in $plan) {
    if ($SelfTestHarness -and $i.InstanceId) { [void]$problems.Add(('{0}: it is really installed on this machine; a -SelfTestHarness run never touches a real instance' -f $i.Name)) }
    if (-not $i.InstanceId) {
        if (-not $i.SetupExe) { [void]$problems.Add(('{0}: no install media (spec mediaPath or -Media)' -f $i.Name)) }
        elseif (-not (Test-Path -LiteralPath $i.SetupExe)) { [void]$problems.Add(('{0}: setup.exe not found at {1}' -f $i.Name, $i.SetupExe)) }
    }
    if ($SkipBind) { continue }
    if (-not $i.HasBind -or $i.Port -lt 1 -or $i.Port -gt 65535) { [void]$problems.Add(('{0}: no port for it (spec.json ports.tcp or bind.csv); or use -SkipBind' -f $i.Name)); continue }
    if ($i.Ip) {
        $x = $null
        if (-not [Net.IPAddress]::TryParse($i.Ip, [ref]$x)) { [void]$problems.Add(('{0}: "{1}" is not an IP address' -f $i.Name, $i.Ip)); continue }
        if (-not (Test-IpOnMachine $i.Ip)) { [void]$missingIps.Add($i) }
    }
}
if ($missingIps.Count -gt 0 -and -not $InterfaceAlias) {
    [void]$problems.Add(('address(es) {0} are not on this machine and no network card was chosen to add them to (-InterfaceAlias)' -f (@($missingIps | ForEach-Object { $_.Ip }) -join ', ')))
}
if ($InterfaceAlias -and -not (Get-NetIPInterface -InterfaceAlias $InterfaceAlias -ErrorAction SilentlyContinue)) {
    [void]$problems.Add(('there is no network card named "{0}" (Get-NetIPInterface)' -f $InterfaceAlias))
}
# New-NetIPAddress on a card that uses DHCP switches it to static and drops
# its current address and gateway: refused before anything changes.
if ($missingIps.Count -gt 0 -and $InterfaceAlias -and [bool](& $script:Seam.DhcpOn $InterfaceAlias)) {
    [void]$problems.Add(('the network card "{0}" uses DHCP; adding an address would switch it to static and drop its current address and gateway. Add the address by hand first.' -f $InterfaceAlias))
}

# ---- what -Go would ask for ----
$needs = New-Object System.Collections.ArrayList
if (-not $ShowSetupWindow) {
    foreach ($i in @($plan | Where-Object { -not $_.InstanceId })) {
        foreach ($k in @(Get-PasswordKeys $i)) {
            if (@($needs | Where-Object { $_.Key -ieq $k.Key }).Count -gt 0) { continue }
            [void]$needs.Add([pscustomobject]@{ Key = $k.Key; Label = $(if ($k.Key -eq '#sa') { 'sa (one password for every mixed-mode instance in this run)' } else { $k.Key }) })
        }
    }
}

# ---- tell the operator (and, on the @@ lines, the window) ----
Write-Log ('SqlStack install' + $(if ($Go) { '' } else { '   PREVIEW: nothing will be changed. Add -Go to run it.' }) + $(if ($SelfTestHarness) { '   TEST HARNESS: no address is added and setup is a stand-in.' } else { '' }))
Write-Log ('Ini folder: ' + $iniDir)
if ($script:LogPath) { Write-Machine 'LOG' @($script:LogPath) }
$pending = @(Test-PendingReboot)
if ($pending.Count -gt 0) {
    Write-Log ('WARN: a reboot is pending (' + ($pending -join ', ') + ').') 'Yellow'
    if ($IgnorePendingRestart) { Write-Log '  setup is told to ignore it (/SKIPRULES=RebootRequiredCheck on every setup command).' 'Yellow' }
    else { Write-Log '  setup will very likely refuse to start until Windows is restarted.' 'Yellow' }
    Write-Machine 'PENDING' @(($pending -join ', '))
}
$step = 0
foreach ($i in $plan) {
    Write-Log ''
    $state = $(if ($i.Attention) { 'NEEDS ATTENTION: ' + $i.Attention } elseif ($i.InstanceId) { 'already installed (' + $i.InstanceId + '): install not run again' } else { 'will be installed' })
    Write-Log ('[{0}]  {1}' -f $i.Name, $state)
    Write-Machine 'INSTANCE' @($i.Name, $(if ($i.Attention) { 'attention' } elseif ($i.InstanceId) { 'installed' } else { 'new' }))
    if ($i.Attention) {
        Write-Machine 'STEP' @($i.Name, 'attention', ('nothing is changed for it: ' + $i.Attention))
        Write-Machine 'STATE' @($i.Name, 'needs attention', $i.Attention)
        continue
    }
    Write-Log ('  engine account: {0} ({1})' -f $i.EngineAccount, $i.EngineFrom)
    Write-Log ('  agent account:  {0} ({1})' -f $i.AgentAccount, $i.AgentFrom)
    Write-Log ('  auth mode:      {0} ({1})' -f $(if ($i.Mixed) { 'mixed (SQL logins and Windows)' } else { 'Windows only' }), $i.MixedFrom)
    $svc, $agt = Get-ServiceNames $i.Name
    $step = 0
    if (@($missingIps | Where-Object { $_.Name -eq $i.Name }).Count -gt 0) {
        $addText = ('WARNING: adds {0}/{1} to card {2}. On a client server add it by hand first.' -f $i.Ip, $PrefixLength, $InterfaceAlias)
        $step++; Write-Log ('  {0}. {1} (before any setup runs)' -f $step, $addText)
        Write-Machine 'ADDRESS' @($i.Name, $i.Ip)
        Write-Machine 'STEP' @($i.Name, 'address', $addText)
    }
    if (-not $i.InstanceId) {
        $step++; Write-Log ('  {0}. "{1}" {2}' -f $step, $i.SetupExe, (Format-SetupArguments (Get-SetupArgList $i $null)))
        Write-Log ('     ' + $i.UpdatesText)
        Write-Machine 'STEP' @($i.Name, 'install', ('install SQL Server ({0}; engine account {1}; agent account {2}; {3})' -f $(if ($i.Mixed) { 'mixed mode' } else { 'Windows only' }), $i.EngineAccount, $i.AgentAccount, $i.UpdatesText))
        $keyNote = Get-MediaKeyNote $i.MediaDir
        if ($keyNote) { Write-Log ('     ' + $keyNote); Write-Machine 'STEP' @($i.Name, 'edition', $keyNote) }
    } else {
        Write-Machine 'STEP' @($i.Name, 'installed', 'already installed: the install is not run again')
    }
    if (-not $SkipBind -and $i.HasBind) {
        $where = $(if ($i.Ip) { 'on ' + $i.Ip + ' only (its IP<n> section, made if missing), ListenOnAllIPs = 0' } else { 'in IPAll, ListenOnAllIPs = 1' })
        $step++; Write-Log ('  {0}. TCP on; static port {1} {2}' -f $step, $i.Port, $where)
        Write-Machine 'STEP' @($i.Name, 'bind', ('TCP port {0} on {1}' -f $i.Port, $(if ($i.Ip) { $i.Ip + ' only' } else { 'every address' })))
    }
    $server = $(if ($i.Name -ieq 'MSSQLSERVER') { '.' } else { '.\' + $i.Name })
    if ($i.Sql) {
        $step++; Write-Log ('  {0}. run {1} against {2}' -f $step, (Split-Path $i.Sql -Leaf), $server)
        Write-Machine 'STEP' @($i.Name, 'sql', ('run {0}' -f (Split-Path $i.Sql -Leaf)))
    }
    if (-not $SkipBind -and $i.HasBind) {
        $step++; Write-Log ('  {0}. restart {1} once if this run changed the binding ({2} started again if it was running or is Automatic)' -f $step, $svc, $agt)
        Write-Machine 'STEP' @($i.Name, 'restart', ('restart {0} once if the binding changed' -f $svc))
        $step++; Write-Log ('  {0}. check: TCP connect and a login over tcp:{1},{2}' -f $step, $(if ($i.Ip) { $i.Ip } else { '127.0.0.1' }), $i.Port)
        Write-Machine 'STEP' @($i.Name, 'check', ('check that it answers on {0}, port {1}' -f $(if ($i.Ip) { $i.Ip } else { '127.0.0.1' }), $i.Port))
    }
}
Write-Log ''
if ($ShowSetupWindow) { Write-Log 'Passwords: none asked here. Setup opens its own window; type them there.' }
elseif ($needs.Count -eq 0) { Write-Log 'Passwords -Go would ask for: none.' }
else { Write-Log ('Passwords -Go would ask for, once each (leave one blank to type it in setup''s own window): ' + (@($needs | ForEach-Object { $_.Label }) -join '; ')) }
foreach ($n in $needs) { Write-Machine 'NEED' @($n.Key, $n.Label) }

if ($problems.Count -gt 0) {
    foreach ($p in $problems) { Write-Log ('PROBLEM: ' + $p) 'Red'; Write-Machine 'PROBLEM' @($p) }
    Stop-Run ('{0} problem(s) above. Nothing was changed.' -f $problems.Count)
}
if (-not $Go) { Write-Log 'PREVIEW only. Nothing was changed.'; Write-Machine 'END' @('0', 'preview'); exit 0 }

if (-not $Yes) {
    $answer = Read-Host 'Type YES to run these steps'
    if ($answer -cne 'YES') { Stop-Run 'not confirmed. Nothing was changed.' }
}
if ($script:HarnessFakes -contains 'crash') { throw 'a crash the test harness asked for' }

# ---- passwords: all of them now, before anything changes ----
$secrets = @{}
if ($needs.Count -gt 0 -and $PasswordStdin) {
    $given = @{}
    try { $given = Read-SecretInput ([Console]::In) } catch { Stop-Run ('the passwords could not be read: ' + $_.Exception.Message + '. Nothing was changed.') }
    foreach ($n in $needs) {
        # A password that was not supplied, or is empty, is BLANK: window mode below.
        if (-not $given.ContainsKey($n.Key)) { continue }
        $s = $given[$n.Key]
        if ($s.Length -eq 0) { continue }
        $why = Get-ValueProblem -Value $s
        if ($why) { Stop-Run ('the password for {0} cannot be used: {1}. Nothing was changed.' -f $n.Label, $why) }
        $secrets[$n.Key] = $s
    }
} else {
    foreach ($n in $needs) {
        while ($true) {
            $s = Read-Host -AsSecureString -Prompt ('Password for ' + $n.Label + ' (blank = type it in setup''s own window)')
            if ($s.Length -eq 0) { break }
            $why = Get-ValueProblem -Value $s
            if ($why) { Write-Log ('  refused: ' + $why + '. Type it again.') 'Yellow'; continue }
            if ($n.Key -eq '#sa') {
                $s2 = Read-Host -AsSecureString -Prompt 'sa password again'
                if (-not (Test-SecureEqual $s $s2)) { Write-Log '  the two entries differ. Type it again.' 'Yellow'; continue }
            }
            $secrets[$n.Key] = $s
            break
        }
    }
}


# ---- window mode: an instance with a password left blank (or -ShowSetupWindow) ----
foreach ($i in @($plan | Where-Object { -not $_.InstanceId })) {
    if (@(Get-PasswordKeys $i | Where-Object { -not $secrets.ContainsKey($_.Key) }).Count -gt 0) { $i.WindowMode = $true }
    if ($i.WindowMode) {
        try { $wi = Write-WindowIni $i.Ini } catch { Stop-Run ('{0}: its window copy of the ini could not be written: {1}. Nothing was changed.' -f $i.Name, $_.Exception.Message) }
        Write-Log ('[{0}] a password was left blank: setup will show its own window (it runs on {1})' -f $i.Name, (Split-Path $wi -Leaf))
    }
}

foreach ($i in $plan) { Write-Machine 'STATE' @($i.Name, 'waiting') }

# ======================================================================
#  Phase 1: addresses first. Setup writes a SuperSocketNetLib\Tcp\IP<n>
#  section only for addresses on the machine AT INSTALL, so each new
#  address is added before any setup runs and setup makes its section.
# ======================================================================
foreach ($i in @($missingIps | Where-Object { -not $_.Attention })) {
    Write-Machine 'STATE' @($i.Name, 'adding address', ('{0}/{1} on "{2}"' -f $i.Ip, $PrefixLength, $InterfaceAlias))
    Write-Log ('[{0}] add address {1}/{2} to "{3}"' -f $i.Name, $i.Ip, $PrefixLength, $InterfaceAlias)
    if ($SelfTestHarness) { Write-Log '  TEST HARNESS: the address is NOT added.' }
    else {
        # -SkipAsSource: the new address is never chosen as this server's source address.
        try { New-NetIPAddress -InterfaceAlias $InterfaceAlias -IPAddress $i.Ip -PrefixLength $PrefixLength -SkipAsSource $true | Out-Null }
        catch {
            Write-Machine 'STATE' @($i.Name, 'failed', ('the address {0} could not be added: {1}' -f $i.Ip, $_.Exception.Message))
            Stop-Run ('the address {0} could not be added to "{1}": {2}. No setup was started.' -f $i.Ip, $InterfaceAlias, $_.Exception.Message) 2
        }
    }
}

# ======================================================================
#  Phase 2 and 3: install each instance (name order), then configure it.
# ======================================================================
$rebootNeeded = $false
foreach ($i in $plan) {
    $row = [pscustomobject]@{ Instance = $i.Name; Install = 'already installed'; Bind = '-'; PostSql = '-'; Check = '-' }
    [void]$script:Rows.Add($row)
    Write-Log ''
    Write-Log ('[{0}]' -f $i.Name)
    if ($i.Attention) {
        # Nothing is changed for it, and the run goes on to no further instance.
        $row.Install = 'NEEDS ATTENTION'
        Write-Machine 'STATE' @($i.Name, 'needs attention', $i.Attention)
        Stop-Run ('{0} needs attention: {1}' -f $i.Name, $i.Attention) 2
    }
    $installedNow = $false
    if (-not $i.InstanceId) {
        $argList = Get-SetupArgList $i $secrets
        if ($i.WindowMode) { Write-Machine 'STATE' @($i.Name, 'waiting for you in the SQL Server setup window', 'setup shows its own window: type the passwords there and finish it') }
        else { Write-Machine 'STATE' @($i.Name, 'installing', 'setup is running; this takes a while') }
        Write-Log ('  setup: "{0}" {1}' -f $i.SetupExe, (Format-SetupArguments $argList))
        $code = $null
        try { $code = Invoke-InstanceChange -InstanceName $i.Name -What 'run setup.exe (this takes a while)' -Action { Invoke-Setup -SetupExe $i.SetupExe -ArgList $argList } }
        catch {
            $why = ('setup could not start: {0}' -f $_.Exception.Message)
            try { Write-SetupFailedMarker -Path $i.Marker -Code 'none, setup could not start' } catch { Write-Log ('  WARN: {0} could not be written: {1}' -f $i.Marker, $_.Exception.Message) 'Yellow' }
            Write-Machine 'STATE' @($i.Name, 'failed', $why)
            Stop-Run $why 2
        }
        # The marker: written for any exit but 0 or 3010, removed by a later 0 or 3010.
        try {
            if (($code -ne 0) -and ($code -ne 3010)) { Write-SetupFailedMarker -Path $i.Marker -Code ([string]$code) }
            elseif (Test-Path -LiteralPath $i.Marker) { Remove-Item -LiteralPath $i.Marker -Force }
        } catch { Write-Log ('  WARN: {0} could not be written or removed: {1}' -f $i.Marker, $_.Exception.Message) 'Yellow' }
        $i.InstanceId = Get-InstalledInstanceId $i.Name
        $installedNow = $true
        if ($code -eq 3010) { $rebootNeeded = $true; $row.Install = 'installed, reboot needed' }
        elseif ($code -eq 0) { $row.Install = 'installed' }
        else {
            $row.Install = 'FAILED ' + $code
            $why = ('setup exit code {0}. Read {1}' -f $code, (Get-SetupSummaryPath))
            Write-Machine 'STATE' @($i.Name, 'failed', $why)
            Stop-Run $why 2
        }
        if (-not $i.InstanceId) {
            $row.Install = 'FAILED: not registered'
            $why = ('setup returned {0} but {1} is not registered as installed. Read {2}' -f $code, $i.Name, (Get-SetupSummaryPath))
            Write-Machine 'STATE' @($i.Name, 'failed', $why)
            Stop-Run $why 2
        }
    }
    $svc, $agt = Get-ServiceNames $i.Name
    $server = $(if ($i.Name -ieq 'MSSQLSERVER') { '.' } else { '.\' + $i.Name })
    $tcpKey = Get-TcpKeyPath $i.InstanceId
    $script:RegChanged = $false
    $final = 'done'; $finalText = ''
    try {
        if (-not $SkipBind) {
            Write-Machine 'STATE' @($i.Name, 'configuring', ('TCP port {0}' -f $i.Port))
            $notes = Invoke-InstanceChange -InstanceName $i.Name -What ('TCP on, static port {0}{1}' -f $i.Port, $(if ($i.Ip) { ' on ' + $i.Ip } else { ' on all addresses' })) -Action { Set-TcpBinding -TcpKey $tcpKey -Port $i.Port -Ip $i.Ip }
            foreach ($n in $notes) { Write-Log ('    ' + $n) }
            $row.Bind = $(if ($script:RegChanged) { 'set' } else { 'already set' })
        }
        if ($i.Sql) {
            Write-Machine 'STATE' @($i.Name, 'configuring', ('running {0}' -f (Split-Path $i.Sql -Leaf)))
            if ((Get-Service -Name $svc).Status -ne 'Running') { Invoke-InstanceChange -InstanceName $i.Name -What ('start ' + $svc) -Action { Start-Service -Name $svc } }
            $count = Invoke-InstanceChange -InstanceName $i.Name -What ('run ' + (Split-Path $i.Sql -Leaf) + ' against ' + $server) -Action { Invoke-SqlFile -Server $server -Path $i.Sql }
            $row.PostSql = ('ran ({0} batches)' -f $count)
        }
        $edition = ''
        if ($installedNow) { try { $edition = [string](& $script:Seam.Edition $i.InstanceId) } catch { $edition = '' } }
        if ($edition) { Write-Log ('  edition: ' + $edition) $(if ($edition -match 'Evaluation') { 'Yellow' } else { '' }) }
        if ($SkipBind -and $edition) { $finalText = $(if ($edition -match 'Evaluation') { ('WARNING: edition {0} (it expires after 180 days).' -f $edition) } else { ('edition {0}.' -f $edition) }) }
        if (-not $SkipBind) {
            $check = Invoke-ListenerCheck -RegChanged $script:RegChanged -Sleep $script:Seam.Sleep `
                -Restart { Invoke-InstanceChange -InstanceName $i.Name -What ('restart ' + $svc) -Action { Restart-Engine -Name $i.Name } } `
                -Listener { Test-Listener -Ip $i.Ip -Port $i.Port } `
                -OnState { param($s) Write-Machine 'STATE' @($i.Name, $s, $(if ($s -eq 'restarting') { $svc } else { '' })) }
            Write-Log ('  check: ' + $check.Text) $(if ($check.Ok) { 'Green' } else { 'Red' })
            $row.Check = $(if ($check.Ok) { 'OK' } else { 'FAILED' })
            $res = Get-CheckResult -Check $check -Ip $i.Ip -Port $i.Port -Edition $edition
            $final = $res.State; $finalText = $res.Text
        }
    } catch {
        $why = ('{0}: a step after the install failed: {1}' -f $i.Name, $_.Exception.Message)
        Write-Machine 'STATE' @($i.Name, 'failed', $why)
        Stop-Run $why 4
    }
    if ($rebootNeeded) {
        Write-Machine 'STATE' @($i.Name, 'reboot needed', 'setup asked for a restart of Windows')
        Write-Log ''
        Write-Log ('Setup asked for a reboot after {0}. Reboot, then run the same command again: instances already installed are left as they are.' -f $i.Name) 'Yellow'
        Write-Summary
        Write-Machine 'END' @('3', ('setup asked for a restart of Windows after {0}' -f $i.Name))
        exit 3
    }
    Write-Machine 'STATE' @($i.Name, $final, $finalText)
}
Write-Summary
if (@($script:Rows | Where-Object { $_.Check -eq 'FAILED' }).Count -gt 0) {
    Write-Machine 'END' @('4', ('a connection check failed for {0}' -f ((@($script:Rows | Where-Object { $_.Check -eq 'FAILED' }) | ForEach-Object { $_.Instance }) -join ', ')))
    exit 4
}
Write-Machine 'END' @('0', 'done')
exit 0
