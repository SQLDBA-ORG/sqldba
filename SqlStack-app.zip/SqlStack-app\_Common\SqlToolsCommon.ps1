<#
    SqlToolsCommon.ps1
    Shared, DOT-SOURCED helper functions for the SQLTools PowerShell suite.

    WHAT THIS IS NOT: a PowerShell module (.psm1). The house rule (CLAUDE.md)
    is "single-file PowerShell 5.1 where possible, no modules, no install,
    offline/self-contained." A .psm1 would need to be installed onto
    $env:PSModulePath (or Import-Module'd with a path, which still creates an
    implicit module-management dependency and a different mental model for
    -SelfTest and for copying a tool to another machine). A dot-sourced sibling
    .ps1 avoids all of that: it is just a text file sitting next to the tools
    in the same repo, copied along with them, requiring zero install step and
    zero network/registry state. `Import-Module`/PSGallery/NuGet are explicitly
    out of scope for this suite (offline-first, single-operator laptop/box).

    WHY DOT-SOURCE INSTEAD OF DUPLICATE: five tools (ConfigBaseline, LoginVault,
    QsPlanVault, SetScope, WaitDelta) each carried a byte-for-byte-identical
    ~27-line Invoke-SqlRows and a near-identical Get-ConnString (differing only
    in the Application Name= literal). This file is the amortization point.

    HOW A TOOL USES THIS FILE (robust to any CWD, since PowerShell 5.1 does not
    auto-chdir into the script's folder):

        $script:CommonPath = Join-Path $PSScriptRoot '..\_Common\SqlToolsCommon.ps1'
        if (Test-Path $script:CommonPath) {
            . $script:CommonPath
        } else {
            # inline fallback copy of the same functions - keeps the tool
            # fully self-contained (single-file) if _Common\ is ever missing,
            # e.g. if only the one tool folder was copied to another machine.
            function Get-ConnString ...
            function Invoke-SqlRows ...
        }

    Each tool STAYS runnable standalone (single-file guarantee preserved) even
    if this file is deleted or the tool folder is copied in isolation - the
    dot-source is an optimization, not a hard dependency, wherever a tool
    chooses to keep its own inline fallback.

    CONTENTS:
      Get-ConnString  - build the SqlClient connection string. Takes -AppName
                         so each tool keeps its own Application Name (this was
                         the one field that legitimately differed per tool;
                         it is preserved as a parameter, not lost).
      Invoke-SqlRows  - run a parameterized query, return an array of
                         PSCustomObjects (DBNull -> $null). Read-only DMV
                         reads throughout the suite; CommandTimeout 120s.
      Esc             - single-quote doubling for one literal level of
                         hand-built SQL string literals (shared identically by
                         LoginVault and QsPlanVault; not currently used by
                         ConfigBaseline/SetScope/WaitDelta, included here for
                         any tool that wants it).
      New-Utf8NoBom   - factory for a UTF8Encoding($false) instance, i.e. the
                         UTF-8-no-BOM encoding every tool uses for
                         [IO.File]::WriteAllText(...) so baseline/export files
                         never pick up a BOM.

    MIGRATION STATE (2026-07-11):
      - WaitDelta\WaitDelta.ps1   -> CONVERTED (proof-of-pattern; dot-sources
                                     this file with inline fallback).
      - ConfigBaseline\ConfigBaseline.ps1  -> NOT YET migrated (still inline).
      - LoginVault\LoginVault.ps1          -> NOT YET migrated (still inline).
      - QsPlanVault\QsPlanVault.ps1        -> NOT YET migrated (still inline).
      - SetScope\SetScope.ps1              -> NOT YET migrated (still inline).
      Follow-up: once the WaitDelta pattern is blessed, repeat the same
      dot-source-with-fallback edit in the remaining four tools. Do it one at
      a time, re-running each tool's own -SelfTest after each conversion.

    Usage:
      powershell -NoProfile -File _Common\SqlToolsCommon.ps1 -SelfTest
        (headless assertions on the pure-function pieces; no SQL Server
        needed. Invoke-SqlRows requires a live connection so it is only
        checked for being defined/callable-shaped, not executed.)

    IMPORTANT - NO param() BLOCK ON PURPOSE: this file is designed to be
    DOT-SOURCED by other tools (". $CommonPath", no arguments). A dot-sourced
    script's param() block still re-binds on every dot-source, even with zero
    arguments passed - and because dot-sourcing merges scope into the caller,
    that re-bind SILENTLY CLOBBERS a same-named variable already set in the
    caller (e.g. a caller's own -SelfTest switch gets reset to $false the
    moment it dot-sources this file). Using $args/$MyInvocation instead of
    param() avoids that collision entirely, so callers can safely dot-source
    this file regardless of their own parameters.
#>

$ErrorActionPreference = 'Stop'

# Detect standalone invocation (this file run directly) vs dot-sourced (a
# tool doing ". $CommonPath"). Only a direct, non-dot-sourced invocation with
# -SelfTest on the command line runs the self-test block below.
$script:SqlToolsCommon_IsDotSourced = ($MyInvocation.InvocationName -eq '.')
$script:SqlToolsCommon_SelfTest = (-not $script:SqlToolsCommon_IsDotSourced) -and ($args -contains '-SelfTest')

# ===========================================================================
# Get-ConnString - AppName is now a parameter so each tool keeps its own
# Application Name (the one field that legitimately differed per tool).
# ===========================================================================
function Get-ConnString {
    param(
        [string]$Server,
        [string]$Database,
        [string]$AppName = 'SQLTools'
    )
    return ('Server={0};Database={1};Integrated Security=SSPI;Application Name={2}' -f $Server, $Database, $AppName)
}

# ===========================================================================
# Invoke-SqlRows - canonical shape, identical across all five tools prior to
# this extraction. Read-only DMV reads; DBNull -> $null; returns a (possibly
# empty) array via the unary-comma idiom so PowerShell never unrolls a
# single-row or zero-row result into a scalar/$null.
# ===========================================================================
function Invoke-SqlRows {
    param([string]$Server, [string]$Database, [string]$Sql, [hashtable]$Params, [string]$AppName = 'SQLTools')
    $conn = New-Object System.Data.SqlClient.SqlConnection (Get-ConnString -Server $Server -Database $Database -AppName $AppName)
    $conn.Open()
    try {
        $cmd = $conn.CreateCommand()
        $cmd.CommandText = $Sql
        $cmd.CommandTimeout = 120
        if ($Params) { foreach ($k in $Params.Keys) { [void]$cmd.Parameters.AddWithValue($k, $Params[$k]) } }
        $rdr = $cmd.ExecuteReader()
        $out = New-Object System.Collections.ArrayList
        while ($rdr.Read()) {
            $o = New-Object psobject
            for ($i = 0; $i -lt $rdr.FieldCount; $i++) {
                $name = $rdr.GetName($i)
                if ([string]::IsNullOrEmpty($name)) { $name = ('col{0}' -f $i) }
                $val = $rdr.GetValue($i)
                if ($val -is [System.DBNull]) { $val = $null }
                $o | Add-Member -MemberType NoteProperty -Name $name -Value $val
            }
            [void]$out.Add($o)
        }
        $rdr.Close()
        return ,$out.ToArray()
    } finally { $conn.Close() }
}

# ===========================================================================
# Esc - single-quote doubling for one literal level of hand-built SQL. Shared
# identically by LoginVault and QsPlanVault today.
# ===========================================================================
function Esc([string]$s) { if ($null -eq $s) { '' } else { $s.Replace("'", "''") } }

# ===========================================================================
# New-Utf8NoBom - factory for the UTF8Encoding($false) instance every tool
# uses for [IO.File]::WriteAllText(...) so exported/baseline files never pick
# up a BOM.
# ===========================================================================
function New-Utf8NoBom {
    return New-Object System.Text.UTF8Encoding($false)
}

# ===========================================================================
# New-ScriptDomParser - construct a TSql140Parser for the SQL parse-gate each
# tool's -SelfTest runs. Formerly a byte-identical Get-ScriptDomParser copy
# inside eight tools; hoisted here. Returns $null (caller SKIPs the gate) when
# ScriptDom cannot be loaded from any probe location.
#
# -ToolRoot: the CALLING tool's $PSScriptRoot. Because this function is dot-
# sourced into the tool, its own $PSScriptRoot is _Common\, so the tool-local
# and sibling _lib\ DLL probes must resolve against -ToolRoot to keep finding a
# tool-bundled / _lib copy. Defaults to this file's folder (from which the _lib
# probe still resolves correctly) so an argument-less call degrades safely.
# ===========================================================================
function New-ScriptDomParser {
    param([string]$ToolRoot = $PSScriptRoot)
    if (-not ('Microsoft.SqlServer.TransactSql.ScriptDom.TSql140Parser' -as [type])) {
        try { Add-Type -AssemblyName 'Microsoft.SqlServer.TransactSql.ScriptDom' -ErrorAction Stop } catch {
            $candidates = @(
                # Portable drop-folder first: a copy bundled next to the tool (or in a
                # sibling _lib\) is what makes the parse-gate actually RUN on a clean box
                # with no SSMS, no SqlPackage and no NuGet cache. See Build-Portable.ps1.
                (Join-Path $ToolRoot 'Microsoft.SqlServer.TransactSql.ScriptDom.dll'),
                (Join-Path $ToolRoot '..\_lib\Microsoft.SqlServer.TransactSql.ScriptDom.dll'),
                "${env:ProgramFiles(x86)}\Microsoft SQL Server Management Studio 21\Common7\IDE\Extensions\Application\Microsoft.SqlServer.TransactSql.ScriptDom.dll",
                "${env:ProgramFiles(x86)}\Microsoft SQL Server Management Studio 20\Common7\IDE\Extensions\Application\Microsoft.SqlServer.TransactSql.ScriptDom.dll",
                "${env:ProgramFiles(x86)}\Microsoft SQL Server Management Studio 19\Common7\IDE\Extensions\Application\Microsoft.SqlServer.TransactSql.ScriptDom.dll",
                "${env:ProgramFiles(x86)}\Microsoft SQL Server Management Studio 18\Common7\IDE\Extensions\Application\Microsoft.SqlServer.TransactSql.ScriptDom.dll"
            )
            $dll = $candidates | Where-Object { Test-Path $_ } | Select-Object -First 1
            if (-not $dll) {
                $nuget = Join-Path $env:USERPROFILE '.nuget\packages\microsoft.sqlserver.transactsql.scriptdom'
                if (Test-Path $nuget) {
                    $dll = Get-ChildItem -Path $nuget -Recurse -Filter 'Microsoft.SqlServer.TransactSql.ScriptDom.dll' -ErrorAction SilentlyContinue |
                           Where-Object { $_.FullName -match '\\(net462|net472|net48|net4[56].?[0-9]*)\\' } |
                           Select-Object -First 1 -ExpandProperty FullName
                }
            }
            if ($dll) { try { Add-Type -Path $dll -ErrorAction Stop } catch { return $null } }
            else { return $null }
        }
    }
    if (-not ('Microsoft.SqlServer.TransactSql.ScriptDom.TSql140Parser' -as [type])) { return $null }
    return (New-Object Microsoft.SqlServer.TransactSql.ScriptDom.TSql140Parser($true))
}

# ===========================================================================
# Self-test (headless, no GUI, no SQL Server) - exit 1 on any FAIL.
# ===========================================================================
if ($script:SqlToolsCommon_SelfTest) {
    $script:TestFail = 0
    function Assert-True([string]$Name, [bool]$Condition) {
        if ($Condition) { Write-Host ("PASS  {0}" -f $Name) }
        else            { Write-Host ("FAIL  {0}" -f $Name); $script:TestFail++ }
    }

    # --- Get-ConnString ----------------------------------------------------
    $cs1 = Get-ConnString -Server 'srv01' -Database 'master' -AppName 'WaitDelta'
    Assert-True 'Get-ConnString: contains Server='                ($cs1 -like '*Server=srv01;*')
    Assert-True 'Get-ConnString: contains Database='               ($cs1 -like '*Database=master;*')
    Assert-True 'Get-ConnString: contains Integrated Security=SSPI' ($cs1 -like '*Integrated Security=SSPI;*')
    Assert-True 'Get-ConnString: AppName parameter honoured'       ($cs1 -like '*Application Name=WaitDelta*')

    $cs2 = Get-ConnString -Server 'srv02' -Database 'msdb' -AppName 'LoginVault'
    Assert-True 'Get-ConnString: different AppName per call'       ($cs2 -like '*Application Name=LoginVault*')

    $cs3 = Get-ConnString -Server 'srv03' -Database 'tempdb'
    Assert-True 'Get-ConnString: default AppName is SQLTools'      ($cs3 -like '*Application Name=SQLTools*')

    # --- Invoke-SqlRows: shape-only checks (no live SQL Server here) -------
    $cmd = Get-Command Invoke-SqlRows -ErrorAction SilentlyContinue
    Assert-True 'Invoke-SqlRows: function is defined'               ($null -ne $cmd)
    Assert-True 'Invoke-SqlRows: CommandType is Function'            ($cmd.CommandType -eq 'Function')
    $paramNames = $cmd.Parameters.Keys
    Assert-True 'Invoke-SqlRows: has Server param'                   ($paramNames -contains 'Server')
    Assert-True 'Invoke-SqlRows: has Database param'                 ($paramNames -contains 'Database')
    Assert-True 'Invoke-SqlRows: has Sql param'                      ($paramNames -contains 'Sql')
    Assert-True 'Invoke-SqlRows: has Params param'                   ($paramNames -contains 'Params')
    Assert-True 'Invoke-SqlRows: has AppName param'                  ($paramNames -contains 'AppName')

    # --- Esc -----------------------------------------------------------------
    Assert-True 'Esc: doubles a single embedded quote'               ((Esc "O'Brien") -eq "O''Brien")
    Assert-True 'Esc: no quotes -> unchanged'                        ((Esc 'plainvalue') -eq 'plainvalue')
    Assert-True 'Esc: null -> empty string'                          ((Esc $null) -eq '')
    Assert-True 'Esc: empty -> empty'                                ((Esc '') -eq '')
    Assert-True 'Esc: multiple quotes all doubled'                   ((Esc "a'b'c") -eq "a''b''c")

    # --- New-Utf8NoBom ---------------------------------------------------------
    $enc = New-Utf8NoBom
    Assert-True 'New-Utf8NoBom: returns a UTF8Encoding'                ($enc -is [System.Text.UTF8Encoding])
    Assert-True 'New-Utf8NoBom: GetPreamble is empty (no BOM)'         ($enc.GetPreamble().Length -eq 0)

    # --- New-ScriptDomParser ---------------------------------------------------
    $ndp = Get-Command New-ScriptDomParser -ErrorAction SilentlyContinue
    Assert-True 'New-ScriptDomParser: function is defined'             ($null -ne $ndp)
    Assert-True 'New-ScriptDomParser: has ToolRoot param'              ($ndp.Parameters.Keys -contains 'ToolRoot')
    $parser = New-ScriptDomParser -ToolRoot $PSScriptRoot
    if ($null -eq $parser) {
        Write-Host 'SKIP  New-ScriptDomParser: ScriptDom not available on this box - parse construction skipped'
    } else {
        Assert-True 'New-ScriptDomParser: returns a TSql140Parser'     ($parser -is [Microsoft.SqlServer.TransactSql.ScriptDom.TSql140Parser])
        $ndpErrs = $null
        [void]$parser.Parse((New-Object System.IO.StringReader('SELECT 1 AS x;')), [ref]$ndpErrs)
        Assert-True 'New-ScriptDomParser: parses valid T-SQL cleanly'  ($null -eq $ndpErrs -or $ndpErrs.Count -eq 0)
        $ndpBad = $null
        [void]$parser.Parse((New-Object System.IO.StringReader('SELECT FROM WHERE;')), [ref]$ndpBad)
        Assert-True 'New-ScriptDomParser: flags invalid T-SQL'         ($null -ne $ndpBad -and $ndpBad.Count -gt 0)
    }

    if ($script:TestFail -gt 0) {
        Write-Host ("{0} test(s) FAILED" -f $script:TestFail)
        exit 1
    }
    Write-Host 'All self-tests passed.'
    exit 0
}
