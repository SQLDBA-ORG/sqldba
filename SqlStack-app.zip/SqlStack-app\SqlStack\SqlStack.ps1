<#
    SqlStack.ps1
    WinForms planner for STACKED SQL Server instances (several named instances
    sharing one Windows host).

    What it does:
      - Reads the host: volumes with free space and allocation unit size, RAM,
        cores, installed instances, listening ports, excluded port ranges.
      - Lets you PICK the drive and folder for data, log, tempdb and backup,
        per instance, with a drive grid that shows space and warns about the
        things that actually bite on a stacked box.
      - Computes the port allocation and the memory split across instances and
        shows the arithmetic, not just the answer.
      - Validates the whole plan live and lists every problem with a severity.
      - Saves the plan (spec.json) and one setup ini and one post-install
        T-SQL script per new instance into the run folder.
      - INSTALLS the plan from its Install screen (2026-11-16): it starts the
        install worker SqlStack-Install.ps1, beside this script, as a hidden
        child process, elevated only. Planning and saving change nothing on
        the host; only Install now does, after one confirm and one password
        dialog. This script itself still holds no setup call, no registry,
        service or network write and no SQL client: the worker holds them.

    It shares its engine with SqlStack-Collect.ps1, which is dot-sourced with
    -AsLibrary. The probe registry, the port algorithm and the memory algorithm
    are defined once, over there, so the two tools cannot drift apart.

    Usage:
      powershell -NoProfile -STA -File SqlStack.ps1
        (-STA is required for the folder browser dialogs)
        The rail shows Host, Plan and Install. -Advanced adds the older
        stages (Snapshot A, Dry run, Apply, Verify, Uninstall ...) and the
        drawer with the command to paste for each.

      powershell -NoProfile -File SqlStack.ps1 -SelfTest
        (headless unit tests; no GUI, no SQL Server needed; exit 1 on failure)
#>
param(
    [switch]$SelfTest,
    # The older stages and the paste-a-command drawer (see Usage).
    [switch]$Advanced,
    # Open straight onto the Install screen: how the window starts itself again
    # as administrator on the same run folder.
    [switch]$OpenInstall,
    [string]$Server = 'localhost',
    [int]$PortBase = 14330,
    # The trace file. EMPTY means a default under %TEMP% and logging STAYS ON:
    # a diagnostic you have to switch on before the failure is a diagnostic you
    # do not have when it happens. '-LogPath none' turns it off.
    [string]$LogPath = '',
    # The RUN FOLDER (lane sqlstack-workbench): spec.json, spec-absent.json,
    # snapshot-A, snapshot-B, export and window.log. Empty = a NEW folder,
    # C:\temp\SqlStack\runs\<HOST>-<yyyyMMdd-HHmm>, created when the window opens.
    [string]$RunFolder = '',
    # The ONE host-wide state folder SqlStack-Apply uses (critic K3). Empty = the
    # engine's default (C:\temp\SqlStack\state). Only tests point it elsewhere.
    [string]$StatePath = ''
)

$ErrorActionPreference = 'Stop'
$script:GuiVersion = '0.1.0'

function Get-SqlStackGuiLanguageStop {
    # '' in FullLanguage. Otherwise the ONE message this window shows before it
    # stops: an application control policy put PowerShell in a restricted mode
    # in which the window cannot build itself.
    param([string]$Mode)
    if ($Mode -eq 'FullLanguage') { return '' }
    return ('SqlStack cannot run on this machine: PowerShell runs in {0} here (an application control policy such as AppLocker or WDAC), and SqlStack needs FullLanguage. Ask the administrator of this server to allow the SqlStack scripts, or run them on a machine without that policy. Nothing was changed.' -f $Mode)
}
$languageStop = Get-SqlStackGuiLanguageStop -Mode ([string]$ExecutionContext.SessionState.LanguageMode)
if ($languageStop) {
    Write-Host $languageStop -ForegroundColor Red
    try { [void][System.Windows.Forms.MessageBox]::Show($languageStop, 'SqlStack') } catch { }
    exit 1
}

# ---------------------------------------------------------------------------
# THE TRACE LOG, set up BEFORE the engine dot-source on purpose: the dot-source
# is itself a thing that can fail, and a log that starts after it cannot say so.
# Everything here is .NET and PowerShell built-ins, because no engine function
# exists yet.
#
# It is SAFE TO SEND. Before the window closes, the log is run through the
# engine's own Test-ScrubGate - the same gate the collector's bundles pass - and
# the result is written into the log's own footer. So whoever is about to paste
# it can read, in the file, whether it carries an email address, a UNC path or a
# DOMAIN\account. The gate is the engine's, not a second copy of the rules.
#
# Logging NEVER throws. A tracing feature that breaks the tool it traces is
# worse than no tracing: every write is wrapped, and a failed write disables the
# log rather than taking the window down with it.
# ---------------------------------------------------------------------------
$script:LogEnabled = $false
$script:LogFile = ''
$script:LogLines = 0
# Set by Close-SqlStackGuiLog so the footer is written once even when both the
# trap and the finally block reach it.
$script:LogClosed = $false
# The clock is read HERE, in the same statement that names the file, so the
# stamp in the name is the moment the run started and not a time carried in.
if ([string]$LogPath -ine 'none') {
    $script:LogFile = $(if (-not [string]::IsNullOrWhiteSpace($LogPath)) { $LogPath }
                        else { Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-gui-' + (Get-Date).ToString('yyyyMMdd_HHmmss') + '.log') })
    # -SelfTest writes no file unless one was asked for by name: the suite runs
    # often and should not litter %TEMP% with traces nobody reads.
    if ($SelfTest -and [string]::IsNullOrWhiteSpace($LogPath)) { $script:LogFile = '' }
}

function Write-SqlStackGuiLog {
    <#
      One line: an ISO-ish local stamp, a STAGE, and the text. Appends UTF-8
      with no BOM. Returns nothing and throws nothing, ever.

      -Stage is a short tag so the file can be read by eye and grepped:
      START / HOST / MEDIA / PLAN / FILES / SPEC / UI / WARN / ERROR / END.
    #>
    param([string]$Stage = 'INFO', [string]$Text = '')
    if (-not $script:LogEnabled) { return }
    try {
        $line = ('{0}  {1,-6}  {2}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'), $Stage, $Text)
        [IO.File]::AppendAllText($script:LogFile, ($line + "`r`n"), (New-Object System.Text.UTF8Encoding($false)))
        $script:LogLines++
    } catch {
        # One failed write disables the log. It does NOT propagate: the operator
        # came here to plan an instance, not to debug a log file.
        $script:LogEnabled = $false
    }
}

function Write-SqlStackGuiLogError {
    <#
      An exception, with the things that actually identify a defect: the type,
      the message, the script line it came from, and the stack. Written as
      several ERROR lines rather than one, because a single line holding a
      stack trace is unreadable in the file and unquotable in a message.
    #>
    param([string]$Stage = 'ERROR', [string]$What = '', $Err = $null)
    Write-SqlStackGuiLog $Stage ('FAILED: ' + $What)
    if ($null -eq $Err) { return }
    try {
        Write-SqlStackGuiLog $Stage ('  type   : ' + $Err.Exception.GetType().FullName)
        Write-SqlStackGuiLog $Stage ('  message: ' + $Err.Exception.Message)
        if ($Err.InvocationInfo) {
            Write-SqlStackGuiLog $Stage ('  at     : line ' + $Err.InvocationInfo.ScriptLineNumber + ' - ' + ([string]$Err.InvocationInfo.Line).Trim())
        }
        foreach ($f in @(([string]$Err.ScriptStackTrace) -split "`r?`n")) {
            if (-not [string]::IsNullOrWhiteSpace($f)) { Write-SqlStackGuiLog $Stage ('  stack  : ' + $f.Trim()) }
        }
    } catch { $script:LogEnabled = $false }
}

function Open-SqlStackGuiLog {
    <#
      Open (create or append to) the trace log at -Path and point the log at it.
      THE ONE NAMED EXCEPTION to INV-1 (the window writes only under its run
      folder; critic K6): at start-up no run folder exists yet, so the log opens
      under %TEMP% (or -LogPath); once a run folder is open the window calls this
      again with <run>\window.log from Get-SqlStackGuiRunPath. Census:
      'W1-writes-through-run-folder' names this function and Write-SqlStackGuiLog
      as the exception, and 'W3-log-moves-to-run' holds its call sites.
      Throws nothing; a failure disables the log. Returns $true when it is on.
    #>
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    try {
        $logDir = Split-Path -Parent $Path
        if ($logDir -and (-not (Test-Path -LiteralPath $logDir))) { [void](New-Item -ItemType Directory -Path $logDir -Force) }
        [IO.File]::AppendAllText($Path, '', (New-Object System.Text.UTF8Encoding($false)))
        $script:LogFile = $Path
        $script:LogEnabled = $true
        return $true
    } catch {
        $script:LogEnabled = $false
        Write-Warning ("SqlStack could not open its trace log at {0}: {1}. The window still runs; it just is not tracing." -f $Path, $_.Exception.Message)
        return $false
    }
}

if (-not [string]::IsNullOrWhiteSpace($script:LogFile)) { [void](Open-SqlStackGuiLog -Path $script:LogFile) }
if ($script:LogEnabled) {
    Write-SqlStackGuiLog 'START' ('SqlStack GUI ' + $script:GuiVersion + ' starting')
    Write-SqlStackGuiLog 'START' ('log file        : ' + $script:LogFile)
    Write-SqlStackGuiLog 'START' ('script          : ' + $(if ($PSCommandPath) { $PSCommandPath } else { '(unknown)' }))
    Write-SqlStackGuiLog 'START' ('PowerShell      : ' + $PSVersionTable.PSVersion.ToString() + '  edition ' + [string]$PSVersionTable.PSEdition)
    Write-SqlStackGuiLog 'START' ('OS              : ' + [string][System.Environment]::OSVersion.VersionString + '  64-bit process ' + [Environment]::Is64BitProcess)
    # -STA is what the folder dialogs need. If this says MTA, Browse will fail
    # and the reason is HERE rather than in a dialog that never opens.
    Write-SqlStackGuiLog 'START' ('apartment state : ' + [string][System.Threading.Thread]::CurrentThread.GetApartmentState() + '   (Browse needs STA)')
    Write-SqlStackGuiLog 'START' ('args            : -Server ' + $Server + ' -PortBase ' + $PortBase + ' -SelfTest ' + [bool]$SelfTest)
    Write-Host ("Trace log: {0}" -f $script:LogFile)
}

# THE CATCH-ALL, and the reason it is HERE rather than around ShowDialog: the
# window is BUILT at file scope, hundreds of lines below, and a control that
# throws while it is being built never reaches any try block. Before this trap
# existed, such a failure printed a red PowerShell error to a console that is
# usually closing, and the operator had nothing to send. A script-scope trap
# sees every terminating error that nothing else handled, logs it with its
# stack, and RETHROWS with 'break' so the exit code and the console message are
# exactly what they were. It observes; it does not swallow.
trap {
    Write-SqlStackGuiLogError 'ERROR' 'unhandled - this killed the run' $_
    if (Get-Command Close-SqlStackGuiLog -ErrorAction SilentlyContinue) { Close-SqlStackGuiLog }
    elseif ($script:LogEnabled) {
        # The failure happened BEFORE the footer function existed - which is the
        # common case for a startup failure, and the one where the engine is not
        # loaded so there is no scrub gate to run. The file still gets a footer,
        # because a trace with no verdict invites someone to paste it unread.
        Write-SqlStackGuiLog 'END' ('the run ended early; {0} line(s) written' -f $script:LogLines)
        Write-SqlStackGuiLog 'END' 'SCRUB GATE: NOT RUN - this failed before the engine loaded, so nothing checked this file. Read it before sending it.'
        Write-Host ''
        Write-Host ("Trace log written: {0}" -f $script:LogFile)
        Write-Host 'Scrub gate: NOT RUN - read the file before sending it.'
    }
    break
}

# ---------------------------------------------------------------------------
# INVARIANT: every parameter this entry point declares must survive the
# dot-source of the engine.
#
# Dot-sourcing executes the ENGINE'S param() block in THIS scope, and that
# block declares -SelfTest (and -Instance, -OutDir, -NoRedact, -NoZip ...).
# Any name the two scripts share is rebound to the ENGINE'S default the
# instant the dot-source runs. PROVED 2026-09-17: -SelfTest became $false,
# the self-test block below never executed, and SqlStack.ps1 -SelfTest opened
# the form instead - silently, with exit code 0.
#
# So the entry point's own arguments are snapshotted BEFORE the dot-source and
# read from the snapshot afterwards. The snapshot is built from this script's
# own PARAM BLOCK SYNTAX TREE, not from a hand-written list, so a parameter
# added later is carried automatically and cannot be forgotten. An empty
# enumeration is a hard failure, never a skip: silently losing -SelfTest is
# the exact defect this guards.
#
# Guarded by 'entry args:' assertions in the -SelfTest block below, which
# enumerate the two param blocks from their syntax trees and check every
# shared name.
# ---------------------------------------------------------------------------
$collectPath = Join-Path $PSScriptRoot 'SqlStack-Collect.ps1'
if (-not (Test-Path $collectPath)) { throw "SqlStack-Collect.ps1 not found next to this script ($collectPath)" }

$script:EntryScriptPath = if ($PSCommandPath) { $PSCommandPath } else { $MyInvocation.MyCommand.Path }
$script:EntryParamNames = @()
$selfAst = $null
if ($MyInvocation.MyCommand.ScriptBlock) { $selfAst = $MyInvocation.MyCommand.ScriptBlock.Ast }
if (-not $selfAst -and $script:EntryScriptPath) {
    $selfAst = [System.Management.Automation.Language.Parser]::ParseFile($script:EntryScriptPath, [ref]$null, [ref]$null)
}
if ($selfAst -and $selfAst.ParamBlock) {
    $script:EntryParamNames = @($selfAst.ParamBlock.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })
}
if ($script:EntryParamNames.Count -eq 0) {
    throw 'SqlStack.ps1: could not read its own param block, so it cannot protect -SelfTest and -PortBase from the engine''s param block. Refusing to run.'
}
$script:EntryArgs = @{}
foreach ($n in $script:EntryParamNames) { $script:EntryArgs[$n] = (Get-Variable -Name $n -ValueOnly -ErrorAction SilentlyContinue) }

Write-SqlStackGuiLog 'START' ('dot-sourcing the engine: ' + $collectPath)
try {
    . $collectPath -AsLibrary
} catch {
    # The engine failing to load is the one failure that leaves the window with
    # no planners, no readers and no scrub gate. Say so in the log before it
    # reaches the console, because the console is what disappears.
    Write-SqlStackGuiLogError 'ERROR' ('the engine dot-source of ' + $collectPath) $_
    throw
}
Write-SqlStackGuiLog 'START' ('engine loaded; Get-SqlStackMediaBaseline present = ' + [bool](Get-Command Get-SqlStackMediaBaseline -ErrorAction SilentlyContinue))

# ===========================================================================
# ===========================================================================
#  PURE, TESTABLE CORE
#  No WinForms, no WMI, no SQL. This is what -SelfTest drives.
# ===========================================================================
# ===========================================================================

$script:SqlRecommendedAllocUnit = 65536   # 64KB. 4KB on a data volume is a real finding.
# The words the Plan screen shows for a service account Windows manages
# (spec value 'virtual') and for the two authentication choices. ONE spelling
# each: the editor's lists, the row defaults, the spec writer and the spec
# reader all use these (Resolve-SqlStackGuiAccount, Get-SqlStackGuiSecurityMode).
$script:SqlStackGuiVirtualWords = 'Built-in (virtual)'
$script:SqlStackGuiAuthWindows = 'Windows only'
$script:SqlStackGuiAuthMixed = 'Mixed mode'

function Get-SuggestedInstancePaths {
    <#
      Given a drive letter and an instance name, produce the conventional
      per-instance folder layout. Keeping every instance in its own named
      folder is what makes a stacked host legible two years later.
    #>
    param(
        [Parameter(Mandatory)][string]$InstanceName,
        [string]$DataDrive   = 'E',
        [string]$LogDrive    = 'F',
        [string]$TempDbDrive = 'T',
        [string]$BackupDrive = 'G'
    )
    $clean = { param($d) ($d -replace '[^A-Za-z]','').ToUpperInvariant() }
    return [pscustomobject]@{
        Data   = ('{0}:\{1}\Data'   -f (& $clean $DataDrive),   $InstanceName)
        Log    = ('{0}:\{1}\Log'    -f (& $clean $LogDrive),    $InstanceName)
        TempDb = ('{0}:\{1}\TempDB' -f (& $clean $TempDbDrive), $InstanceName)
        Backup = ('{0}:\{1}\Backup' -f (& $clean $BackupDrive), $InstanceName)
    }
}

function Get-PathDrive {
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path)) { return '' }
    if ($Path -match '^([A-Za-z]):') { return $matches[1].ToUpperInvariant() }
    return ''   # UNC or relative: no local volume
}

function Get-TempDbFileCount {
    # Standard guidance: one file per logical core, capped at 8.
    param([int]$LogicalCores)
    if ($LogicalCores -le 0) { return 1 }
    if ($LogicalCores -gt 8) { return 8 }
    return $LogicalCores
}

function Get-SuggestedMaxDop {
    <#
      On a stacked host MAXDOP must derive from the instance's SHARE of cores,
      not the host total. Every instance otherwise sees all cores and each
      independently decides to claim all of them.
      Guidance caps MAXDOP at 8; a share below 1 still means 1.
    #>
    param([int]$LogicalCores, [int]$InstanceCount = 1)
    if ($LogicalCores -le 0) { return 0 }
    if ($InstanceCount -lt 1) { $InstanceCount = 1 }
    $share = [Math]::Floor($LogicalCores / $InstanceCount)
    if ($share -lt 1) { $share = 1 }
    if ($share -gt 8) { $share = 8 }
    return [int]$share
}

function Get-DriveAdvice {
    <#
      Per-volume advice for the drive grid. Returns a short string, empty when
      the volume is unremarkable. -IntendedUse shapes the judgement: a 4KB
      allocation unit matters on a data volume and not on a backup target.
    #>
    param(
        [object]$Volume,          # DriveLetter, SizeGB, FreeGB, AllocationUnitSize, FileSystem
        [string]$IntendedUse = '' # Data | Log | TempDb | Backup | ''
    )
    $notes = New-Object System.Collections.ArrayList
    $letter = [string]$Volume.DriveLetter

    if ($letter -eq 'C') { [void]$notes.Add('system drive') }

    if ($Volume.AllocationUnitSize -and [int]$Volume.AllocationUnitSize -ne $script:SqlRecommendedAllocUnit) {
        if (@('Data','Log','TempDb','') -contains $IntendedUse) {
            [void]$notes.Add(('alloc {0}KB, 64KB recommended' -f ([int]$Volume.AllocationUnitSize / 1KB)))
        }
    }
    if ($Volume.SizeGB -gt 0) {
        # Judged UNROUNDED (Gemini finding 14: 9.84% rounded to 10 and was never low).
        $rawPct = 100.0 * $Volume.FreeGB / $Volume.SizeGB
        if ($rawPct -lt 10) { [void]$notes.Add(('only {0} free' -f (Get-SqlStackGuiFreeText -Percent $rawPct))) }
    }
    if ($Volume.FileSystem -and $Volume.FileSystem -ne 'NTFS' -and $Volume.FileSystem -ne 'ReFS') {
        [void]$notes.Add(('filesystem {0}' -f $Volume.FileSystem))
    }
    return ($notes -join '; ')
}

function Get-PlannedTempDbSizeMb {
    param([int]$FileCount, [int]$FileSizeMb, [int]$LogSizeMb = 0)
    if ($LogSizeMb -le 0) { $LogSizeMb = $FileSizeMb }
    return [int](($FileCount * $FileSizeMb) + $LogSizeMb)
}

function Test-SqlStackPlan {
    <#
      The validation engine. Returns a flat list of findings:
        Severity  ERROR | WARN | INFO
        Area      which part of the plan
        Message   what is wrong, in plain terms

      ERROR means the plan should not be emitted. WARN means it will work but
      a DBA would object. INFO is informational only.

      $Plan is one pscustomobject per instance:
        Name, Ordinal, Port, DacPort, DataPath, LogPath, TempDbPath, BackupPath,
        MaxMemoryMb, MinMemoryMb, MaxDop, TempDbFileCount, TempDbFileSizeMb
      $Volumes is the vol-inventory shape.

      A row with Fixed = $true is an INSTALLED instance (lane
      sqlstack-gui-glowup, D1): a constraint, never a claimant. Its port is
      handed to the port planner as fixed, its memory is subtracted when it
      was read, and none of the per-instance checks below (paths, memory,
      tempdb, MAXDOP, name shape) runs on it: nothing is planned for it.
      -InstalledNames are the instances installed on the host: a NEW instance
      may not take one of those names.
    #>
    param(
        [object[]]$Plan,
        [object[]]$Volumes = @(),
        [object[]]$ExcludedRanges = @(),
        [int[]]$PortsInUse = @(),
        [int]$PhysicalMb = 0,
        [hashtable]$KnownInstancePorts = @{},
        [string[]]$InstalledNames = @(),
        # The window's spec route needs media read for every NEW instance (finding
        # 2: Validation ignored it, and Save spec failed late, in a dialog).
        [switch]$RequireMedia
    )
    $out = New-Object System.Collections.ArrayList
    $volByLetter = @{}
    foreach ($v in $Volumes) { if ($v.DriveLetter) { $volByLetter[([string]$v.DriveLetter).ToUpperInvariant()] = $v } }

    if (@($Plan).Count -eq 0) {
        [void]$out.Add([pscustomobject]@{ Severity='INFO'; Area='plan'; Message='No instances in the plan yet.' })
        return ,$out.ToArray()
    }
    $claimants = @(@($Plan) | Where-Object { -not $_.Fixed })
    $fixedRows = @(@($Plan) | Where-Object { $_.Fixed })
    if ($claimants.Count -eq 0) {
        [void]$out.Add([pscustomobject]@{ Severity='INFO'; Area='plan'; Message='No new instance in the plan: every row is an installed instance, so nothing will be written.' })
    }

    # ---- ports: the ONE computation Update-ComputedPlan also uses (D4) ----
    $comp = Get-SqlStackGuiPlanComputation -Plan $Plan -PhysicalMb $PhysicalMb -PortBase $script:PortBaseInUse `
                    -ExcludedRanges $ExcludedRanges -PortsInUse $PortsInUse -KnownInstancePorts $KnownInstancePorts
    # ⚠ THE PORT PLANNER IS IP-BLIND, and from 2026-10-09 that matters. It is the
    # engine's, it is shared, and it judges a repeated port a 'Duplicate' because
    # until per-IP binding existed a port WAS the endpoint. Once each instance
    # binds its own IP the endpoint is the PAIR, and a repeated port on distinct
    # IPs is legal and documented. The planner is NOT changed - other callers
    # depend on it - but its 'Duplicate' verdict is reinterpreted HERE, which is
    # the one place that also knows the IPs:
    #   every row holding that port has its own distinct, non-empty IP
    #        -> not an error. The endpoint block below has already judged it, and
    #           warns, because it is legal but off the ruled pattern.
    #   anything else (no IP yet, or two rows sharing one IP)
    #        -> the planner is right and the ERROR stands.
    $portIpSets = @{}
    foreach ($row in @($Plan)) {
        if ($null -eq $row) { continue }
        if ([int]$row.Port -le 0) { continue }
        $pk = [string][int]$row.Port
        if (-not $portIpSets.ContainsKey($pk)) { $portIpSets[$pk] = New-Object System.Collections.ArrayList }
        # ONE KEY for the port verdict and the endpoint verdict below: the strict
        # resolver's CANONICAL address, a refused spelling counting as no IP (so the
        # port Duplicate ERROR stands). Keyed on the typed string until 2026-11-03,
        # two spellings of one IPv6 address read as two IPs (item M2;
        # 'review(w1):' in -SelfTest).
        $ipKeyRes = Resolve-SqlStackIpAddress -Ip ([string]$row.Ip)
        [void]$portIpSets[$pk].Add($(if ($ipKeyRes.Ok) { [string]$ipKeyRes.Canonical } else { '' }))
    }
    $portIsSplitByIp = {
        param([string]$PortKey)
        if (-not $portIpSets.ContainsKey($PortKey)) { return $false }
        $ips = @($portIpSets[$PortKey])
        if (@($ips | Where-Object { [string]::IsNullOrWhiteSpace($_) }).Count -gt 0) { return $false }
        return ((@($ips | Sort-Object -Unique).Count) -eq (@($ips).Count))
    }
    foreach ($p in $comp.Ports.Instances) {
        if ($p.Status -eq 'Fixed') { continue }
        if (($p.Status -eq 'Duplicate') -and (& $portIsSplitByIp ([string][int]$p.Port))) { continue }
        if ($p.Status -ne 'Ok') {
            $why = switch ($p.Status) {
                'Duplicate' { 'another instance in this plan already has it' }
                'Ephemeral' { 'it is inside the Windows dynamic port range, so it will collide eventually' }
                'Excluded'  { 'it is inside a reserved port range (Hyper-V, WinNAT or Docker), so SQL will fail to bind at startup' }
                'Reserved'  { 'port 1433 is what a client reaches with no port and no Browser lookup, so it belongs to the default instance (TCP 1434 is allowed: Browser listens on UDP 1434, not TCP)' }
                'InUse'     { 'something on this host is already listening on it' }
                default     { $p.Status }
            }
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('port/' + $p.Name); Message=("Port {0} cannot be used: {1}." -f $p.Port, $why) })
        }
    }

    # ---- the per-instance endpoint: IP plus port ----
    # RULED by Adrian 2026-10-09: no two instances may share the same IP AND
    # port, and his house pattern is a UNIQUE IP AND a UNIQUE PORT per instance
    # (five instances, five NIC IPs, plus the server's own IP; ports 1434, 1435,
    # 1436 ...).
    #
    # The two are DIFFERENT SEVERITIES on purpose, because they are different
    # kinds of wrong:
    #
    #   same IP AND same port  -> ERROR. A TCP endpoint is the PAIR, so this is
    #     one endpoint claimed twice and the second instance's TCP listener will
    #     not start. It is broken, not merely unusual.
    #   same IP, different port, or same port, different IP -> WARN. Both are
    #     legal and documented (Microsoft: an endpoint is an IP and a port), and
    #     sharing a port across different IPs is a known pattern. It is flagged
    #     because it DEVIATES FROM THE RULED HOUSE PATTERN, not because it fails.
    #     ⚠ It also carries a real caveat worth seeing at plan time: community
    #     reporting is that the same port on different IPs breaks Kerberos,
    #     because a ticket is issued per HOST, not per IP or NIC. That is
    #     BELIEVED, read not run, and the warning says so rather than asserting
    #     it as fact.
    #
    # EVERY row is compared, installed (Fixed) ones included: an installed
    # instance already holding an endpoint is a constraint, and planning a new
    # instance onto it is exactly the collision this exists to catch.
    $endpointRows = @(@($Plan) | Where-Object { ($null -ne $_) -and (-not [string]::IsNullOrWhiteSpace([string]$_.Ip)) })
    foreach ($i in $endpointRows) {
        # The strict resolver, not a bare TryParse: an ambiguous spelling is a
        # DEFECT to report, not a value to quietly re-address.
        $chk = Resolve-SqlStackIpAddress -Ip ([string]$i.Ip)
        if (-not $chk.Ok) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('ip/' + $i.Name)
                Message=("cannot be bound: {0}" -f $chk.Problem) })
        }
    }
    # ⚠ GROUPED ON THE CANONICAL ADDRESS, not on the typed string.
    #
    # Until 2026-10-17 the key was the raw string, trimmed and lowercased. That
    # made '10.0.0.5' and '010.0.0.5' two different keys, so two instances on ONE
    # address passed this rule with zero errors - the exact collision the rule
    # exists to catch, and the one the operator specifically asked for. Adversarial
    # review found it; it was live while every assertion here read green.
    #
    # The engine's strict resolver is used, so an ambiguous spelling is refused
    # above rather than silently keyed as its own address.
    $byEndpoint = @{}
    $byIp = @{}
    $byPort = @{}
    foreach ($i in $endpointRows) {
        $ipRes = Resolve-SqlStackIpAddress -Ip ([string]$i.Ip)
        if (-not $ipRes.Ok) { continue }   # already reported as an ERROR above
        $ipKey = $ipRes.Canonical
        if ([int]$i.Port -le 0) { continue }
        $epKey = ('{0}|{1}' -f $ipKey, [int]$i.Port)
        foreach ($pair in @(@{ H = $byEndpoint; K = $epKey }, @{ H = $byIp; K = $ipKey }, @{ H = $byPort; K = [string][int]$i.Port })) {
            if (-not $pair.H.ContainsKey($pair.K)) { $pair.H[$pair.K] = New-Object System.Collections.ArrayList }
            [void]$pair.H[$pair.K].Add([string]$i.Name)
        }
    }
    foreach ($k in @($byEndpoint.Keys)) {
        $names = @($byEndpoint[$k])
        if ($names.Count -le 1) { continue }
        $bits = $k -split '\|'
        [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('endpoint/' + ($names -join '+'))
            Message=("{0} all claim {1} port {2}. A TCP endpoint is the IP AND the port, so that is one endpoint claimed {3} times and only one listener can start. Give each its own IP or its own port." -f `
                     ($names -join ', '), $bits[0], $bits[1], $names.Count) })
    }
    foreach ($k in @($byIp.Keys)) {
        $names = @($byIp[$k])
        if ($names.Count -le 1) { continue }
        # Suppressed when the pair check already reported these same instances:
        # one collision should not be two findings.
        if (@(@($byEndpoint.Keys) | Where-Object { ($_ -split '\|')[0] -eq $k -and @($byEndpoint[$_]).Count -gt 1 }).Count -gt 0) { continue }
        [void]$out.Add([pscustomobject]@{ Severity='WARN'; Area=('ip/' + ($names -join '+'))
            Message=("{0} share the IP {1} on different ports. That works, but the ruled pattern here is one IP per instance." -f ($names -join ', '), $k) })
    }
    foreach ($k in @($byPort.Keys)) {
        $names = @($byPort[$k])
        if ($names.Count -le 1) { continue }
        if (@(@($byEndpoint.Keys) | Where-Object { ($_ -split '\|')[1] -eq $k -and @($byEndpoint[$_]).Count -gt 1 }).Count -gt 0) { continue }
        [void]$out.Add([pscustomobject]@{ Severity='WARN'; Area=('port-shared/' + ($names -join '+'))
            Message=("{0} share port {1} on different IPs. That is legal and documented, but the ruled pattern here is one port per instance, and it is reported (BELIEVED, read not run) that a shared port across IPs breaks Kerberos, because a ticket is issued per host rather than per IP." -f `
                     ($names -join ', '), $k) })
    }

    # ---- memory ----
    # A new instance with no max server memory would get SQL's default (no
    # limit) on a stacked host, and the post-install script would set 0.
    foreach ($i in $claimants) {
        if ([int]$i.MaxMemoryMb -le 0) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('memory/' + $i.Name)
                Message='Max memory is not set: the split planned nothing for this instance (the Arithmetic box says why). Set Max memory MB.' })
        }
    }
    $unreadFixed = @($fixedRows | Where-Object { $null -eq $_.MaxMemoryMb } | ForEach-Object { [string]$_.Name })
    if (($unreadFixed.Count -gt 0) -and ($claimants.Count -gt 0)) {
        [void]$out.Add([pscustomobject]@{ Severity='WARN'; Area='memory'
            Message=("The over-commit check covers the new instance(s) only: the max server memory of {0} was not read (this window reads it only from snapshot A and opens no SQL connection). Collect snapshot A, or type a planning ceiling on the installed row." -f ($unreadFixed -join ', ')) })
    }
    # K7: an installed instance at the SQL default (2147483647, "unlimited") has no
    # bound to add up. It is named in a WARN and left out of the sum, the way the
    # engine's dry run plans it (OverCommitPlanned, every claimant explicit).
    $unlimitedFixed = @($fixedRows | Where-Object { ($null -ne $_.MaxMemoryMb) -and ([int64]$_.MaxMemoryMb -ge 2147483647) } | ForEach-Object { [string]$_.Name })
    if (($unlimitedFixed.Count -gt 0) -and ($claimants.Count -gt 0)) {
        [void]$out.Add([pscustomobject]@{ Severity='WARN'; Area='memory'
            Message=("The max server memory of {0} is the SQL default (unlimited), as read from snapshot A. The over-commit check cannot bound it, so it is left out of the sum; the dry run plans this as OverCommitPlanned and needs an explicit max memory for every new instance." -f ($unlimitedFixed -join ', ')) })
    }
    if ($PhysicalMb -gt 0) {
        $sumMax = 0
        foreach ($i in $claimants) { $sumMax += [int]$i.MaxMemoryMb }
        foreach ($i in $fixedRows) { if (($null -ne $i.MaxMemoryMb) -and ([int64]$i.MaxMemoryMb -lt 2147483647)) { $sumMax += [int]$i.MaxMemoryMb } }
        $reserve = Get-OsReserveMb -PhysicalMb $PhysicalMb
        if (($sumMax + $reserve) -gt $PhysicalMb) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area='memory'
                Message=("Max memory over-commits the host: {0}MB allocated + {1}MB OS reserve exceeds {2}MB physical." -f $sumMax, $reserve, $PhysicalMb) })
        }
        foreach ($i in $claimants) {
            if ([int]$i.MinMemoryMb -gt [int]$i.MaxMemoryMb) {
                [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('memory/' + $i.Name); Message='Min server memory is above max server memory.' })
            }
            if (([int]$i.MaxMemoryMb -gt 0) -and ([int]$i.MaxMemoryMb -lt 2048)) {
                [void]$out.Add([pscustomobject]@{ Severity='WARN'; Area=('memory/' + $i.Name); Message=("Max memory {0}MB is very low; SQL Server needs headroom above 2GB." -f $i.MaxMemoryMb) })
            }
        }
    }

    # ---- paths ----
    foreach ($i in $claimants) {
        $dataD = Get-PathDrive -Path $i.DataPath
        $logD  = Get-PathDrive -Path $i.LogPath
        $tmpD  = Get-PathDrive -Path $i.TempDbPath

        foreach ($pair in @(
            @{ Name='Data';   Path=$i.DataPath;   Drive=$dataD },
            @{ Name='Log';    Path=$i.LogPath;    Drive=$logD  },
            @{ Name='TempDb'; Path=$i.TempDbPath; Drive=$tmpD  },
            @{ Name='Backup'; Path=$i.BackupPath; Drive=(Get-PathDrive -Path $i.BackupPath) })) {

            if ([string]::IsNullOrWhiteSpace($pair.Path)) {
                [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=($pair.Name + '/' + $i.Name); Message=("{0} path is not set." -f $pair.Name) })
                continue
            }
            if ($pair.Drive -and -not $volByLetter.ContainsKey($pair.Drive)) {
                [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=($pair.Name + '/' + $i.Name); Message=("Drive {0}: does not exist on this host." -f $pair.Drive) })
                continue
            }
            if ($pair.Drive) {
                $vol = $volByLetter[$pair.Drive]
                $adv = Get-DriveAdvice -Volume $vol -IntendedUse $pair.Name
                if ($adv) {
                    $sev = if ($adv -match 'system drive') { 'WARN' } else { 'WARN' }
                    [void]$out.Add([pscustomobject]@{ Severity=$sev; Area=($pair.Name + '/' + $i.Name); Message=("{0} on {1}: - {2}." -f $pair.Name, $pair.Drive, $adv) })
                }
            }
        }

        if ($dataD -and $logD -and $dataD -eq $logD) {
            [void]$out.Add([pscustomobject]@{ Severity='WARN'; Area=('paths/' + $i.Name)
                Message=("Data and log are both on {0}: - separate them so log writes do not queue behind data reads." -f $dataD) })
        }
        if ($dataD -and $tmpD -and $dataD -eq $tmpD) {
            [void]$out.Add([pscustomobject]@{ Severity='WARN'; Area=('paths/' + $i.Name)
                Message=("TempDB shares {0}: with data - on a stacked host tempdb contention is the usual culprit." -f $dataD) })
        }

        # tempdb capacity against the chosen volume
        if ($tmpD -and $volByLetter.ContainsKey($tmpD)) {
            $needMb = Get-PlannedTempDbSizeMb -FileCount ([int]$i.TempDbFileCount) -FileSizeMb ([int]$i.TempDbFileSizeMb)
            $freeMb = [int]([double]$volByLetter[$tmpD].FreeGB * 1024)
            if ($needMb -gt $freeMb) {
                [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('tempdb/' + $i.Name)
                    Message=("TempDB needs {0}MB but {1}: has only {2}MB free." -f $needMb, $tmpD, $freeMb) })
            }
        }

        if ([int]$i.TempDbFileCount -lt 1) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('tempdb/' + $i.Name); Message='TempDB file count must be at least 1.' })
        }
        if ([int]$i.MaxDop -lt 0) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('maxdop/' + $i.Name); Message='MAXDOP cannot be negative.' })
        }
    }

    # ---- cross-instance ----
    $names = @($Plan | ForEach-Object { $_.Name })
    if (($names | Sort-Object -Unique).Count -ne $names.Count) {
        [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area='plan'; Message='Two instances share a name.' })
    }
    foreach ($i in $claimants) {
        if ($i.Name -notmatch '^[A-Za-z][A-Za-z0-9_]{0,15}$') {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('name/' + $i.Name); Message='Instance name must start with a letter and be 1-16 alphanumeric or underscore characters.' })
        }
        if (@($InstalledNames | Where-Object { [string]$_ -ieq [string]$i.Name }).Count -gt 0) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('name/' + $i.Name)
                Message=("An instance named {0} is already installed on this host: a new install cannot use that name (it is in the plan as a locked row already)." -f $i.Name) })
        }
        # Loader rule r17-ip-without-listenall, said at plan time.
        if ((-not [string]::IsNullOrWhiteSpace([string]$i.Ip)) -and ($i.ListenAll -eq $true)) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('ip/' + $i.Name)
                Message='names an IP AND Listen All. With Listen All on, SQL ignores the per-IP sections, so the address would not be bound (loader rule r17-ip-without-listenall). Clear one of them.' })
        }
        if ($RequireMedia -and [string]::IsNullOrWhiteSpace([string]$i.MediaVersion)) {
            [void]$out.Add([pscustomobject]@{ Severity='ERROR'; Area=('media/' + $i.Name)
                Message=("No SQL install media has been read for it{0}, so the spec cannot say what to install from. Choose its media folder (the first field of the editor)." -f $(if ([string]$i.MediaProblem) { ' (' + [string]$i.MediaProblem + ')' } else { '' })) })
        }
    }

    return ,$out.ToArray()
}

function New-ConfigurationIni {
    <#
      Emit a SQL Server setup ConfigurationFile.ini for one instance.

      THIS IS NOW A THIN CALLER of the engine's New-SqlStackConfigurationIni
      (L2 stage 2, PLAN 5.6). There was one ini emitter per entry point and two
      spellings of the same setup contract; now there is ONE emitter in the
      engine and this function only ADAPTS a GUI plan row into the spec-shaped
      instance object that emitter takes.

      WHAT MOVED, AND BY HOW MUCH THE KEY COUNT CHANGES. MEASURED 2026-09-18
      (probe-e1.ps1, frozen as tests\fixtures\spec\ini\gui-twin-keys.json): the
      old body emitted 28 keys with both service accounts supplied and 26
      without - the two account keys were emitted only if a caller named an
      account. This one emits 26 EITHER WAY, because a virtual account is a
      VALUE and not an absence (the engine renders NT Service\MSSQL$<name> and
      NT Service\SQLAgent$<name>, PROVED service spellings on this box), and
      because TWO keys are gone:
        - INSTANCEID, which repeated the instance name. PLAN 5.2: setup uses the
          instance name as the id when /INSTANCEID is omitted (CONFIRMED).
        - SECURITYMODE="SQL", which was hard-coded for EVERY instance. It is now
          rendered only when the plan row's Authentication is Mixed mode
          (2026-11-16: the Plan screen asks; until then a GUI plan row
          carried no authentication mode and every GUI ini was
          Windows-authentication only). The sa password is never here: the
          Install screen asks for it and the worker hands it to setup.
        The service accounts come from the plan row too (EngineAccount,
        AgentAccount, through Get-SqlStackGuiRowAccount); -EngineAccount and
        -AgentAccount, when given, win over the row.
      BROWSERSVCSTARTUPTYPE is shared host state (rail 10). Until 2026-10-01
      the GUI passed an explicit OVERRIDE of 'automatic', and every ini said
      the value was 'an explicit host.shared.browser override in the spec' -
      but there is no spec here, and SQL Browser on the reference host is
      Disabled, so running the ini would have changed a SHARED service (lane
      sqlstack-gui-glowup, D2(ii), PROVED by the brief critic). Now the caller
      passes -ObservedBrowser: THIS HOST'S current SQL Browser start mode, read
      through the engine's own probe body and mapped by the engine's SPEC.md 4.2
      table (ConvertTo-SqlStackGuiBrowser), and the engine renders it as the
      observed value. Nothing read means nothing rendered: the engine then marks
      the ini INCOMPLETE, because unknown is not Disabled.
      -PassThru returns the engine's whole result (.Ok .Problems .Text ...).

      Deliberately contains NO passwords, which is the engine emitter's rule
      too: SAPWD and service-account passwords are passed on the setup command
      line, because this file is a review artifact that will be read by people
      and may be attached to a ticket.
    #>
    param(
        [Parameter(Mandatory)][object]$Instance,
        [string]$Features = 'SQLENGINE,FULLTEXT',
        [string]$Collation = 'SQL_Latin1_General_CP1_CI_AS',
        [string[]]$SysAdmins = @(),
        [string]$EngineAccount = '',
        [string]$AgentAccount = '',
        [string]$ObservedBrowser = '',
        [switch]$PassThru
    )
    $n = $Instance
    $admins = if ($SysAdmins.Count -gt 0) { [string[]](@($SysAdmins)) } else { [string[]]@('BUILTIN\Administrators') }
    $desired = [pscustomobject]@{
        name = [string]$n.Name
        features = [string[]](@(($Features -split ',') | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { $_.Trim() }))
        collation = $Collation
        securityMode = (Get-SqlStackGuiSecurityMode -Row $n)
        serviceAccounts = [pscustomobject]@{
            engine = $(if ([string]::IsNullOrWhiteSpace($EngineAccount)) { [string](Get-SqlStackGuiRowAccount -Row $n -Role 'engine').Value } else { $EngineAccount })
            agent  = $(if ([string]::IsNullOrWhiteSpace($AgentAccount))  { [string](Get-SqlStackGuiRowAccount -Row $n -Role 'agent').Value }  else { $AgentAccount })
        }
        sysadmins = $admins
        ports = [pscustomobject]@{ tcp = [int]$n.Port }
        paths = [pscustomobject]@{
            data = [string]$n.DataPath; log = [string]$n.LogPath
            tempdb = [string]$n.TempDbPath; backup = [string]$n.BackupPath
        }
        tempdb = [pscustomobject]@{ files = [int]$n.TempDbFileCount; fileSizeMb = [int]$n.TempDbFileSizeMb }
    }
    $r = New-SqlStackConfigurationIni -Instance $desired -SharedBrowser 'observed' -ObservedBrowser $ObservedBrowser `
            -Generator ('SqlStack ' + $script:GuiVersion + ' GUI (review artifact; no spec and no plan)')
    if ($PassThru) { return $r }
    return $r.Text
}

function New-PostInstallSql {
    <#
      Post-install configuration T-SQL for ONE NEW instance, for review (lane
      sqlstack-gui-glowup, D2(iii)). It contains EXACTLY what its header says:
      sp_configure for the settings the header lists, rendered by the ENGINE's
      renderer (New-SqlStackSpConfigureBatch: the one spelling of an
      sp_configure call, every setting inside one transaction, and the 'show
      advanced options' wrap described by Get-SqlStackSpConfigureScriptHeader),
      and nothing else. The header's list and the batch are built from the SAME
      statement array, so they cannot disagree.
      Until 2026-10-01 its docstring said 'sp_configure + RECONFIGURE only' and
      the file also carried an xp_instance_regwrite of BackupDirectory: a
      registry write the header never named, and one setup already makes from
      the ini's SQLBACKUPDIR. It is gone; the header says where the backup
      directory is set. Each statement's comment says where its value came from.
    #>
    param([Parameter(Mandatory)][object]$Instance)
    $n = $Instance
    $nm = [string]$n.Name
    $stmts = @(
        [pscustomobject]@{ Setting = 'max server memory (MB)'; Value = [int64]$n.MaxMemoryMb
            Comment = ('-- sets {0}: the plan row''s Max memory MB (the Plan tab''s Arithmetic box shows its working)' -f [int64]$n.MaxMemoryMb) }
        [pscustomobject]@{ Setting = 'min server memory (MB)'; Value = [int64]$n.MinMemoryMb
            Comment = ('-- sets {0}: the plan row''s Min memory MB' -f [int64]$n.MinMemoryMb) }
        [pscustomobject]@{ Setting = 'max degree of parallelism'; Value = [int64]$n.MaxDop
            Comment = ('-- sets {0}: the plan row''s MAXDOP (this instance''s share of the host''s cores, not the host total)' -f [int64]$n.MaxDop) }
        [pscustomobject]@{ Setting = 'cost threshold for parallelism'; Value = [int64]$n.CostThreshold
            Comment = ('-- sets {0}: the plan row''s Cost threshold' -f [int64]$n.CostThreshold) }
        [pscustomobject]@{ Setting = 'remote admin connections'; Value = [int64]1
            Comment = '-- sets 1: this planner''s default (remote DAC, so a stacked host stays reachable under pressure)' }
        [pscustomobject]@{ Setting = 'backup compression default'; Value = [int64]1
            Comment = '-- sets 1: this planner''s default' }
    )
    $head = Get-SqlStackSpConfigureScriptHeader -ShowAdvancedWas $null
    $batch = New-SqlStackSpConfigureBatch -Statement $stmts -ShowAdvancedWas $head.ShowAdvancedWas
    $l = New-Object System.Collections.ArrayList
    [void]$l.Add('-- SqlStack ' + $script:GuiVersion + ' post-install configuration for the NEW instance ' + $nm)
    [void]$l.Add('-- REVIEW BEFORE RUNNING. Run it against ' + $nm + ' only, after setup has installed it.')
    [void]$l.Add(('-- This file contains sp_configure for exactly these {0} settings and nothing else:' -f $stmts.Count))
    [void]$l.Add('--   ' + (@($stmts | ForEach-Object { [string]$_.Setting }) -join '; '))
    [void]$l.Add('-- No registry write and no data change. The backup directory is set by setup, from SQLBACKUPDIR in ' + $nm + '-install.ini.')
    [void]$l.Add('-- Not in this file: trace flag 3226 (stop logging successful backups), which is a startup parameter.')
    foreach ($x in @($head.Lines)) { [void]$l.Add([string]$x) }
    # The engine's wrap comments below say 'read before it'; for a NEW instance
    # nothing was read, as the engine's own header line above says. Said here
    # rather than edited, so the batch stays the engine's rendering.
    [void]$l.Add('-- For this file, where a wrap comment below says a value was read before the write, it was ASSUMED (see above): the instance does not exist yet.')
    [void]$l.Add('SET NOCOUNT ON;')
    [void]$l.Add('GO')
    [void]$l.Add(([string]$batch.Script -replace "`r?`n", "`r`n"))
    [void]$l.Add('GO')
    return ($l -join "`r`n")
}

function Get-SqlStackGuiElevationText {
    <#
      D3 (lane sqlstack-gui-glowup): the header STATES elevation and claims
      nothing else about it. Until 2026-10-01 it said 'NOT elevated - some
      probes will skip', but this window runs no probe and no read in it is
      gated on elevation (the lane's brief critic PROVED every host read the
      window makes returns data unelevated). A skip may be named here only
      together with the read that really skips.
      Guarded by the 'D3:' rows of Test-SqlStackGuiStructure (no code outside
      this function branches on elevation; no UI text claims a skip) and by
      'elevation (D3):' in -SelfTest.
    #>
    param([bool]$IsElevated)
    if ($IsElevated) { return 'elevated (running as administrator)' }
    return 'not elevated'
}

function Get-SqlStackGuiServerNote {
    <#
      D6 (lane sqlstack-gui-glowup): -Server is declared, and the Launcher
      passes it (Launcher.ps1, the SqlStack entry, HasServer), but this window
      reads and plans ONLY the host it runs on. A value naming another host is
      therefore said plainly in the header instead of being silently ignored.
      A local spelling ('localhost', '.', '(local)', a loopback address, this
      computer's name or its FQDN, with or without '\instance' or ',port')
      needs no note. Returns '' or the note.
      Guarded by 'server (D6):' in -SelfTest and the 'D6:' row of
      Test-SqlStackGuiStructure (the header reads the ENTRY-ARGS snapshot).
    #>
    param([string]$Server, [string]$ComputerName = $env:COMPUTERNAME)
    $raw = ([string]$Server).Trim()
    $hostPart = $raw
    if ($hostPart -match '^(?i)tcp:') { $hostPart = $hostPart.Substring(4) }
    $hostPart = ($hostPart -split '[\\,]')[0].Trim()
    $h = $hostPart.ToLowerInvariant()
    $c = ([string]$ComputerName).ToLowerInvariant()
    $isLocal = (@('', '.', 'localhost', '(local)', '127.0.0.1', '::1', '[::1]') -contains $h) -or
               ($c -and (($h -eq $c) -or $h.StartsWith($c + '.')))
    if ($isLocal) { return '' }
    return ("plans the local host only; -Server '{0}' is not used" -f $raw)
}

function New-PlanRowFromInstalled {
    <#
      D1 (lane sqlstack-gui-glowup): an INSTALLED instance as a plan row. It is
      Fixed: a CONSTRAINT the planners subtract, never a claimant, never edited,
      and nothing is ever rendered for it (no ini, no post-install SQL). Until
      2026-10-01 'Import existing' built installed instances with
      New-PlanRowFromName, so each was planned as a NEW install: after Import +
      Generate on this box MSSQLSERVER got TCP 14331 (it is on 1433), all four
      got max memory 6781 and MAXDOP 5, and the ini said ACTION="Install"
      INSTANCENAME="MSSQLSERVER" (PROVED by the lane's brief critic).

      Every value is what was READ from the host, or says it was not read:
        port    the engine's Get-KnownInstancePortMap .Fixed row: an int is
                reserved against new instances; 'dynamic' reserves nothing
        paths   the engine's Get-SqlStackInstanceOwnedPathRows (registry only)
        memory, MAXDOP, tempdb  NOT READ: they live in the instance's own
                configuration, which only a SQL connection can read, and this
                planner opens none (a failed login would itself be written to
                the instance's error log). $null, never 0 and never a default.
                Max server memory is filled in later from snapshot A, when there
                is one, by Read-SqlStackGuiMemoryCeiling (critic K7).
      .Facts holds the lines the Plan tab shows for the row, one fact each.
      Guarded by 'installed (D1):' in -SelfTest and the 'D1-' rows of
      Test-SqlStackGuiStructure.
    #>
    param(
        [Parameter(Mandatory)][object]$Instance,   # Get-SqlInstanceInventory row: Name, InstanceId, IsDefault
        [object]$ObservedPort = $null,             # Get-KnownInstancePortMap .Fixed row: Name, Port
        [string]$TcpText = '',                     # Get-SqlStackGuiTcpText .Text
        [object[]]$OwnedPathRows = @(),            # Get-SqlStackInstanceOwnedPathRows: Kind, Status, Path, Reason
        [int]$Ordinal = 1
    )
    $port = $null
    if ($ObservedPort -and ($null -ne $ObservedPort.Port) -and ([string]$ObservedPort.Port -ne 'dynamic')) { $port = [int]$ObservedPort.Port }
    $pathOf = @{}
    $facts = New-Object System.Collections.ArrayList
    [void]$facts.Add(('{0} is INSTALLED on this host (instance id {1}{2}).' -f $Instance.Name, $Instance.InstanceId, $(if ($Instance.IsDefault) { ', the default instance' } else { '' })))
    [void]$facts.Add('It is a constraint for the new instances: it is never planned, never changed, and no file is written for it.')
    [void]$facts.Add('')
    [void]$facts.Add(('TCP: {0} (its registry, read through the engine).' -f $(if ($TcpText) { $TcpText } else { 'not read' })))
    [void]$facts.Add($(if ($null -ne $port) { ('Port reserved against the new instances: {0} (its static port).' -f $port) } else { 'Port reserved against the new instances: none (it has no static port).' }))
    foreach ($kind in @('DefaultData', 'DefaultLog', 'BackupDirectory', 'SQLDataRoot')) {
        $r = @($OwnedPathRows | Where-Object { [string]$_.Kind -eq $kind }) | Select-Object -First 1
        if ($null -eq $r) { [void]$facts.Add(('{0}: not read.' -f $kind)); continue }
        switch ([string]$r.Status) {
            'read'   { $pathOf[$kind] = [string]$r.Path; [void]$facts.Add(('{0}: {1} (registry).' -f $kind, $r.Path)) }
            'absent' { [void]$facts.Add(('{0}: not set in the registry.' -f $kind)) }
            default  { [void]$facts.Add(('{0}: could not read ({1}).' -f $kind, $r.Reason)) }
        }
    }
    [void]$facts.Add('')
    [void]$facts.Add('Max server memory: NOT READ. This window reads it only from snapshot A and opens no SQL connection, so until then it cannot be subtracted from the memory split.')
    [void]$facts.Add('MAXDOP and tempdb: not read. Only a SQL connection can read them, and this window opens none.')
    return [pscustomobject]@{
        Name = [string]$Instance.Name; Ordinal = $Ordinal; Port = $port; DacPort = $null
        DataPath = [string]$pathOf['DefaultData']; LogPath = [string]$pathOf['DefaultLog']; TempDbPath = ''; BackupPath = [string]$pathOf['BackupDirectory']
        MaxMemoryMb = $null; MinMemoryMb = $null
        MaxDop = $null; CostThreshold = $null
        TempDbFileCount = $null; TempDbFileSizeMb = $null
        MemoryWeight = 0
        IsDefault = [bool]$Instance.IsDefault
        InstanceId = [string]$Instance.InstanceId
        Fixed = $true
        Facts = [string[]]@($facts)
    }
}

function Get-SqlStackGuiPlanComputation {
    <#
      D4 + D1 (lane sqlstack-gui-glowup): THE ONE place this GUI calls the
      engine's two planners, Get-SqlStackPortPlan and Get-SqlStackMemoryPlan.
      Update-ComputedPlan (through Invoke-SqlStackGuiPlanUpdate) and the
      validator Test-SqlStackPlan both call THIS, so the plan the operator sees
      validated is the plan that was computed, with the same fixed rows and the
      same -KnownInstancePorts. Until 2026-10-01 the validator called the port
      planner itself without -FixedInstances, and Update-Validation passed it
      no -KnownInstancePorts. Census: 'D4-planners-one-site' and
      'D4-validator-args' in Test-SqlStackGuiStructure.

      Fixed rows (installed instances) go to both planners as -FixedInstances,
      never as -Instances. A fixed row whose max server memory was NOT READ
      ($null) makes the memory split NOT COMPUTED, said in words: the engine
      would otherwise have to be handed a number nobody read, and an unread
      instance is not zero (the engine's own rule: no limit is the worst case).

      Returns .Fixed .Claimants .Ports (the engine's result) .Memory (the
      engine's result, or a Status 'NotComputed' stand-in) .MemoryComputed
      .PortLines .MemoryLines .MaxDopLines - the working the Plan tab shows.
    #>
    param(
        [object[]]$Plan = @(),
        [int]$PhysicalMb = 0,
        [int]$LogicalCores = 0,
        [int]$PortBase = 14330,
        [object[]]$ExcludedRanges = @(),
        [int[]]$PortsInUse = @(),
        [hashtable]$KnownInstancePorts = @{},
        [string[]]$InstalledNotInPlan = @()
    )
    if ($null -eq $KnownInstancePorts) { $KnownInstancePorts = @{} }
    $fixedRows = @(@($Plan) | Where-Object { ($null -ne $_) -and $_.Fixed })
    $claimants = @(@($Plan) | Where-Object { ($null -ne $_) -and (-not $_.Fixed) })

    $fixedPorts = @($fixedRows | ForEach-Object { [pscustomobject]@{ Name = $_.Name; Port = $(if ($null -ne $_.Port -and [int]$_.Port -gt 0) { [int]$_.Port } else { 'dynamic' }) } })
    $ports = Get-SqlStackPortPlan -Instances $claimants -PortBase $PortBase -ExcludedRanges $ExcludedRanges -PortsInUse $PortsInUse `
                -KnownInstancePorts $KnownInstancePorts -FixedInstances $fixedPorts

    $unread = @($fixedRows | Where-Object { $null -eq $_.MaxMemoryMb } | ForEach-Object { [string]$_.Name })
    $memComputed = ($unread.Count -eq 0)
    if ($memComputed) {
        $fixedMem = @($fixedRows | ForEach-Object { [pscustomobject]@{ Name = $_.Name; MaxMb = [int]$_.MaxMemoryMb } })
        $mem = Get-SqlStackMemoryPlan -PhysicalMb $PhysicalMb -Instances $claimants -FixedInstances $fixedMem
    } else {
        $mem = [pscustomobject]@{ Status = 'NotComputed'; Instances = @(); PhysicalMb = $PhysicalMb
            Arithmetic = ("not computed: the max server memory of the installed instance(s) {0} was not read (this window reads it only from snapshot A and opens no SQL connection), so it cannot be subtracted" -f ($unread -join ', ')) }
    }

    $portLines = New-Object System.Collections.ArrayList
    foreach ($r in @($ports.Instances)) {
        if ([string]$r.Status -eq 'Fixed') {
            [void]$portLines.Add($(if ([string]$r.Port -eq 'dynamic') { ('{0}: installed, no static port, so nothing is reserved' -f $r.Name) } else { ('{0}: installed, keeps {1}, reserved against the new instances' -f $r.Name, $r.Port) }))
            continue
        }
        $c = @($claimants | Where-Object { [string]$_.Name -eq [string]$r.Name }) | Select-Object -First 1
        # A port the plan row already carries reaches the engine as 'explicit'; when
        # it equals the allocation, the working is the allocation's.
        $ord = $(if ($c) { [int]$c.Ordinal } else { 0 })
        $alloc = ('port base {0} + ordinal {1} = {2}' -f $PortBase, $ord, ($PortBase + $ord))
        $how = $(if (([string]$r.Source -eq 'allocated') -or ([int]$r.Port -eq ($PortBase + $ord))) { $alloc } else { ('{0}, typed in the plan row (the allocation would be {1})' -f $r.Port, $alloc) })
        [void]$portLines.Add(('{0}: {1}{2}' -f $r.Name, $how, $(if ([string]$r.Status -ne 'Ok') { (' - cannot be used: ' + $r.Status) } else { '' })))
    }
    if ($claimants.Count -eq 0) { [void]$portLines.Add('No new instance in the plan, so no port is allocated.') }

    $memLines = New-Object System.Collections.ArrayList
    [void]$memLines.Add(('engine: {0}' -f $mem.Arithmetic))
    [void]$memLines.Add(('status: {0}' -f $mem.Status))
    foreach ($c in $claimants) {
        $prop = @(@($mem.Instances) | Where-Object { ([string]$_.Name -eq [string]$c.Name) -and (-not $_.Fixed) }) | Select-Object -First 1
        $rowMax = [int]$c.MaxMemoryMb
        $txt = ('{0}: max server memory in the plan row {1} MB' -f $c.Name, $rowMax)
        if ($prop -and ([string]$prop.Status -eq 'Proposed')) {
            if ([int]$prop.MaxMb -ne $rowMax) { $txt += (' (the split proposes {0} MB)' -f $prop.MaxMb) } else { $txt += (' = the split; min {0} MB = half of max' -f $prop.MinMb) }
        } elseif ($prop) { $txt += (' (the split refused it: {0})' -f $prop.Status) }
        elseif (-not $memComputed) { $txt += $(if ($rowMax -gt 0) { ' (typed: no split was computed)' } else { ' (no split was computed: set it yourself)' }) }
        [void]$memLines.Add($txt)
    }
    if (($fixedRows.Count -eq 0) -and (@($InstalledNotInPlan).Count -gt 0)) {
        [void]$memLines.Add(('note: {0} installed instance(s) ({1}) are not in this plan, so nothing is subtracted or reserved for them. ''Import existing'' adds them as constraints.' -f @($InstalledNotInPlan).Count, (@($InstalledNotInPlan) -join ', ')))
    }

    $dopLines = New-Object System.Collections.ArrayList
    if ($claimants.Count -gt 0) {
        $n = @($Plan).Count
        [void]$dopLines.Add(('MAXDOP suggestion for a new instance: floor({0} logical cores / {1} instance(s) in the plan) = {2}, capped at 8, at least 1: {3}' -f `
                $LogicalCores, $n, $(if ($n -gt 0) { [Math]::Floor($LogicalCores / $n) } else { 0 }), (Get-SuggestedMaxDop -LogicalCores $LogicalCores -InstanceCount $n)))
    }
    return [pscustomobject]@{
        Fixed = $fixedRows; Claimants = $claimants; Ports = $ports; Memory = $mem; MemoryComputed = $memComputed
        PortLines = [string[]]@($portLines); MemoryLines = [string[]]@($memLines); MaxDopLines = [string[]]@($dopLines)
    }
}

function Invoke-SqlStackGuiPlanUpdate {
    <#
      The write-back half of Update-ComputedPlan, pure so -SelfTest can run it
      (lane sqlstack-gui-glowup, D1). It computes through
      Get-SqlStackGuiPlanComputation and writes ports, memory, the DAC text and
      MAXDOP into CLAIMANT rows only. A Fixed row is never written: that is the
      D1 invariant, asserted at runtime by 'installed (D1):' in -SelfTest, which
      compares every fixed row before and after this call.
      Returns the computation of the rows as written.
    #>
    param(
        [object[]]$Plan = @(),
        [int]$PhysicalMb = 0,
        [int]$LogicalCores = 0,
        [int]$PortBase = 14330,
        [object[]]$ExcludedRanges = @(),
        [int[]]$PortsInUse = @(),
        [hashtable]$KnownInstancePorts = @{},
        [string[]]$InstalledNotInPlan = @()
    )
    $comp = Get-SqlStackGuiPlanComputation -Plan $Plan -PhysicalMb $PhysicalMb -LogicalCores $LogicalCores -PortBase $PortBase `
                -ExcludedRanges $ExcludedRanges -PortsInUse $PortsInUse -KnownInstancePorts $KnownInstancePorts -InstalledNotInPlan $InstalledNotInPlan
    $claimants = @($comp.Claimants)
    if ([string]$comp.Memory.Status -eq 'Ok') {
        foreach ($row in @($comp.Memory.Instances)) {
            if ($row.Fixed) { continue }
            $target = $claimants | Where-Object { $_.Name -eq $row.Name } | Select-Object -First 1
            if ($target) { $target.MaxMemoryMb = $row.MaxMb; $target.MinMemoryMb = $row.MinMb }
        }
    }
    foreach ($row in @($comp.Ports.Instances)) {
        if ($row.Status -eq 'Fixed') { continue }
        $target = $claimants | Where-Object { $_.Name -eq $row.Name } | Select-Object -First 1
        if ($target -and -not $target.Port) { $target.Port = $row.Port }
        # The DAC is SQL's dynamic choice (lane sqlstack-L2i, I14): the port planner
        # says 'dynamic' for every claimant, and the row says what that means.
        if ($target) { $target.DacPort = $(if ([string]$row.DacPort -eq 'dynamic') { 'dynamic (SQL chooses at start-up)' } else { [string]$row.DacPort }) }
    }
    foreach ($p in $claimants) {
        if ($p.MaxDop -le 0) { $p.MaxDop = Get-SuggestedMaxDop -LogicalCores $LogicalCores -InstanceCount @($Plan).Count }
    }
    # The computation of the rows AS WRITTEN, so its per-row lines match them.
    return (Get-SqlStackGuiPlanComputation -Plan $Plan -PhysicalMb $PhysicalMb -LogicalCores $LogicalCores -PortBase $PortBase `
                -ExcludedRanges $ExcludedRanges -PortsInUse $PortsInUse -KnownInstancePorts $KnownInstancePorts -InstalledNotInPlan $InstalledNotInPlan)
}

function Format-SqlStackGuiArithmetic {
    <#
      D4 (lane sqlstack-gui-glowup): the file header promises the GUI 'shows the
      arithmetic, not just the answer', and until 2026-10-01 no control did (the
      engine's memory plan returned .Arithmetic and every caller discarded it).
      This is the text the Plan tab's Arithmetic box shows: the engine's own
      working, then each row's value against it.
    #>
    param([Parameter(Mandatory)][object]$Computation)
    $l = New-Object System.Collections.ArrayList
    [void]$l.Add('PORTS (engine Get-SqlStackPortPlan)')
    foreach ($x in @($Computation.PortLines)) { [void]$l.Add('  ' + $x) }
    [void]$l.Add('')
    [void]$l.Add('MEMORY, MB (engine Get-SqlStackMemoryPlan)')
    foreach ($x in @($Computation.MemoryLines)) { [void]$l.Add('  ' + $x) }
    if (@($Computation.MaxDopLines).Count -gt 0) {
        [void]$l.Add('')
        [void]$l.Add('MAXDOP')
        foreach ($x in @($Computation.MaxDopLines)) { [void]$l.Add('  ' + $x) }
    }
    return ($l -join "`r`n")
}

function ConvertTo-SqlStackGuiBrowser {
    <#
      D2(ii) (lane sqlstack-gui-glowup): this host's SQL Browser start mode as
      setup spells it, from the ENGINE's own probe body (inst-browser-service)
      and the ENGINE's SPEC.md 4.2 table (ConvertTo-BrowserStartupType), so the
      ini keeps the shared service as it is. Pure: the caller runs the probe.
      -Rows     what the probe body returned (@() = SQL Browser not installed)
      -Failed   the probe threw; -Reason says why
      Returns .Ok .Value (setup's spelling, or '') .Source (words for the ini's
      provenance line) .Reason
    #>
    param([object[]]$Rows = @(), [switch]$Failed, [string]$Reason = '', [string]$When = '')
    $at = $(if ($When) { ' at ' + $When } else { '' })
    if ($Failed) {
        return [pscustomobject]@{ Ok = $false; Value = ''; Reason = $Reason
            Source = ('this host''s SQL Browser service could not be read{0} ({1}), so no value is rendered' -f $at, $Reason) }
    }
    $r = @($Rows | Where-Object { $null -ne $_ })
    if ($r.Count -eq 0) {
        $m = ConvertTo-BrowserStartupType -StartMode '' -ProbeStatus 'OkEmpty'
        return [pscustomobject]@{ Ok = $true; Value = [string]$m.Value; Reason = [string]$m.Reason
            Source = ('this host has no SQL Browser service (read{0}), so setup must not start one: {1}' -f $at, $m.Value) }
    }
    $mode = [string]$r[0].StartMode
    $m = ConvertTo-BrowserStartupType -StartMode $mode -ProbeStatus 'Ok'
    if (-not $m.Ok) {
        return [pscustomobject]@{ Ok = $false; Value = ''; Reason = [string]$m.Reason
            Source = ('this host''s SQL Browser start mode ''{0}'' (read{1}) has no setup spelling ({2}), so no value is rendered' -f $mode, $at, $m.Reason) }
    }
    return [pscustomobject]@{ Ok = $true; Value = [string]$m.Value; Reason = [string]$m.Reason
        Source = ('this host''s SQL Browser service start mode ''{0}'' (read{1}), kept as setup''s ''{2}'' so the install does not change it' -f $mode, $at, $m.Value) }
}

function Get-SqlStackGuiFileSet {
    <#
      THE ONE place the review files are rendered (lane sqlstack-gui-glowup).
      D1: for CLAIMANTS only - an installed (Fixed) row never gets a file.
      D2(i): one ini and one post-install script PER NEW INSTANCE, each named
      exactly as its own text tells the operator to use it: the engine's ini
      says 'setup.exe /ConfigurationFile=<NAME>-install.ini', so the ini is
      <NAME>-install.ini, and the script is <NAME>-post-install.sql. Until
      2026-10-01 every instance went into ONE ConfigurationFile.ini with one
      [OPTIONS] section each, which setup cannot run.
      D2(ii): every ini starts with provenance lines saying where its values
      came from: the GUI plan row (no spec, no plan hash) and the live read of
      this host's SQL Browser.
      A name that is not a valid instance name is refused before any file name
      is built from it. Generate and Save both use what this returns.
      Returns one row per file: .Name .Instance .Kind (ini|sql) .Text .Ok .Problems
    #>
    param(
        [object[]]$Plan = @(),
        [object]$Browser = $null,       # ConvertTo-SqlStackGuiBrowser result
        [string]$HostName = $env:COMPUTERNAME,
        [string]$When = '',
        # The sysadmins: the SAME list the spec writes (finding 6). Empty = this session's.
        [string[]]$SysAdmin = @()
    )
    $out = New-Object System.Collections.ArrayList
    $admins = $(if (@($SysAdmin).Count -gt 0) { [string[]]@($SysAdmin) } else { Get-SqlStackGuiSysAdmin })
    $bValue = $(if ($Browser -and $Browser.Ok) { [string]$Browser.Value } else { '' })
    $bSource = $(if ($Browser) { [string]$Browser.Source } else { 'this host''s SQL Browser service was not read, so no value is rendered' })
    foreach ($p in @(@($Plan) | Where-Object { ($null -ne $_) -and (-not $_.Fixed) })) {
        $nm = [string]$p.Name
        if ($nm -notmatch '^[A-Za-z][A-Za-z0-9_]{0,15}$') { throw ("refusing to name a file after '{0}': it is not a valid instance name" -f $nm) }
        $r = New-ConfigurationIni -Instance $p -ObservedBrowser $bValue -PassThru -Features ((Get-SqlStackGuiFeatures -Row $p) -join ',') -SysAdmins $admins
        $prov = @(
            ('; Provenance: written by the SqlStack GUI {0} on host {1}{2} for the NEW instance {3}.' -f $script:GuiVersion, $HostName, $(if ($When) { ' at ' + $When } else { '' }), $nm),
            ';   There is no spec file and no plan hash. Every value below is this GUI''s plan row for this instance:',
            ';   the port and memory from the engine''s planners (the Plan tab shows the arithmetic), the paths and',
            ';   tempdb as the row holds them.',
            (';   BROWSERSVCSTARTUPTYPE: {0}.' -f $bSource),
            ';   The engine text below serves spec-driven plans too: where it says "the spec", this file''s source is',
            ';   the GUI plan row; where it says "the observed document", it is the SQL Browser read named above.',
            '')
        # An account the row holds that cannot be used is NEVER rendered as the
        # built-in one: the file is marked INCOMPLETE (the install worker refuses
        # such a file) and the problem is named.
        $acctProblems = [string[]]@(@('engine', 'agent') | ForEach-Object { $ar = Get-SqlStackGuiRowAccount -Row $p -Role $_; if (-not $ar.Ok) { ('{0}: its {1} account cannot be used: {2}' -f $nm, $_, $ar.Problem) } })
        $acctHead = $(if ($acctProblems.Count -gt 0) { ((@($acctProblems) | ForEach-Object { '; INCOMPLETE: ' + $_ }) -join "`r`n") + "`r`n" } else { '' })
        [void]$out.Add([pscustomobject]@{ Name = ($nm + '-install.ini'); Instance = $nm; Kind = 'ini'
            Text = ($acctHead + ($prov -join "`r`n") + "`r`n" + [string]$r.Text); Ok = ([bool]$r.Ok -and ($acctProblems.Count -eq 0)); Problems = [string[]]@(@($r.Problems) + @($acctProblems)) })
        [void]$out.Add([pscustomobject]@{ Name = ($nm + '-post-install.sql'); Instance = $nm; Kind = 'sql'
            Text = (New-PostInstallSql -Instance $p); Ok = $true; Problems = [string[]]@() })
    }
    return $out.ToArray()
}

function Test-SqlStackGuiHasFileSet {
    <#
      Has Generate run? The file set is $null until it has, and @($null).Count
      is 1 in PowerShell, so $null is tested first. Every product question of
      this kind asks HERE (census row D2-generate-first in -SelfTest).
    #>
    param($FileSet)
    return (($null -ne $FileSet) -and (@($FileSet).Count -gt 0))
}

function Read-SqlStackGuiMedia {
    <#
      Read a BROWSED media folder and say what it is, using the ENGINE'S OWN
      readers so this window and rail 7 cannot disagree about the same folder:
      Get-SqlStackSetupExePath for the executable, Get-SqlStackMediaBaseline for
      MediaInfo.xml, Get-SqlStackVersionMajorMap for major -> version.

      This is a READ. It opens no SQL connection and runs nothing off the media.

      The four failure kinds the engine distinguishes (no-file, no-element,
      no-attribute, not-xml) are passed through VERBATIM rather than collapsed
      into 'invalid', because they are four different mistakes and the operator
      fixes each one differently.

      Returns ONE object: .Ok .Version .Baseline .Problem
    #>
    param([string]$MediaPath)
    $media = [pscustomobject]@{ Ok = $false; Version = ''; Baseline = ''; Problem = '' }
    if ([string]::IsNullOrWhiteSpace($MediaPath)) {
        $media.Problem = 'no media folder has been chosen'
        return $media
    }
    if (-not (Test-Path -LiteralPath $MediaPath)) {
        $media.Problem = ('the media folder does not exist: ' + $MediaPath)
        return $media
    }
    $exe = Get-SqlStackSetupExePath -MediaPath $MediaPath
    if (-not (Test-Path -LiteralPath $exe)) {
        $media.Problem = ('the media folder has no {0} in it, so setup cannot be run from it' -f (Get-SqlStackSetupExePath))
        return $media
    }
    $mi = Get-SqlStackMediaBaseline -MediaPath $MediaPath
    if (-not $mi.Ok) {
        # .Reason is the engine's own wording for which of the four it was.
        $media.Problem = [string]$mi.Reason
        return $media
    }
    $media.Baseline = [string]$mi.Baseline
    $major = ([string]$mi.Baseline -split '\.')[0]
    $map = Get-SqlStackVersionMajorMap
    foreach ($k in @($map.Keys)) { if ([string]$map[$k] -eq $major) { $media.Version = [string]$k } }
    if ([string]::IsNullOrWhiteSpace($media.Version)) {
        # A major with no row is NOT a version this tool will plan: the map has a
        # row only where a real media tree was read, so an unknown major means
        # nobody has checked that product. Saying so beats guessing a year.
        $media.Problem = ("the media reports BaselineVersion {0}, and major {1} is not one this tool knows ({2}). A version is added together with its media fixture, or not at all." -f `
                        $mi.Baseline, $major, ((@($map.Keys) | Sort-Object) -join ', '))
        return $media
    }
    $media.Ok = $true
    return $media
}

function Get-SqlStackGuiSysAdmin {
    <#
      The sysadmins for a generated spec, READ off this session rather than typed.

      Two entries, and both are facts about where this window is running:
      BUILTIN\Administrators (the local group setup always offers) and the
      identity running this process. The second is what stops a generated spec
      locking out the person who generated it.

      No domain lookup and no group expansion: this window opens no connection to
      anything, and a membership read would be the first. Returns ONE string[].
    #>
    $out = New-Object System.Collections.ArrayList
    [void]$out.Add('BUILTIN\Administrators')
    try {
        $me = [string][System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        if ((-not [string]::IsNullOrWhiteSpace($me)) -and ($out -notcontains $me)) { [void]$out.Add($me) }
    } catch {
        # A failed identity read is not fatal: the spec still has the local group.
        # It IS reported, because a spec with one fewer sysadmin than the operator
        # expected is exactly the surprise that strands someone out of an instance.
    }
    return [string[]](@($out))
}

function New-SqlStackGuiSpec {
    <#
      Render the plan as a sqlstack-spec-v1 document, so the rails, the plan hash,
      the journal, the verify and the uninstall all apply to what this window
      planned. Until 2026-10-08 the window emitted only an ini, and a human
      retyped its values into a spec by hand.

      ⚠ NOTHING HERE IS TYPED. Every value is either READ from this host or
      planned by the engine from what was read:
        host.name      $env:COMPUTERNAME
        protected[]    the instances read off this host's registry - EVERY one of
                       them, because an installed instance the spec omits is an
                       instance nothing protects
        sysadmins      Get-SqlStackGuiSysAdmin, off this session
        mediaPath      the folder the operator BROWSED to on this box
        version        read back out of that media's MediaInfo.xml, never guessed
        ports, memory, maxDop, tempdb   the engine's planners

      The ONE value that is neither read nor planned is `edition`, and that is
      not an oversight: MediaInfo.xml carries MediaLayout, BaselineVersion,
      SupportSku and ReleaseTrain, and NO edition (MEASURED 2026-10-08 over the
      2017/2022/2025 fixtures). Edition is an operator DECISION, so the window
      asks for it and records the answer rather than inferring one.

      `schema` is $script:SqlStackSpecSchema, the engine's own constant, so this
      writer and the loader cannot drift about what version they speak.

      Returns ONE object: .Ok .Text .Problems .InstanceCount .ProtectedCount
    #>
    param(
        [object[]]$Plan = @(),
        [object[]]$Installed = @(),
        [string]$HostName = $env:COMPUTERNAME,
        [int]$PortBase = 0,
        [string]$Edition = '',
        [string[]]$SysAdmin = @(),
        [object]$Browser = $null,
        # The uninstall copy (spec-absent.json): every THROWAWAY new instance is
        # written state 'absent'; everything else is the same document.
        [switch]$AbsentThrowaway
    )
    $problems = New-Object System.Collections.ArrayList
    $rows = New-Object System.Collections.ArrayList
    $absentCount = 0
    # The secrets the loader demands (SPEC 2.3, rule 8): 'sa' when any new
    # instance is mixed mode, and 'svc-<instance>-<role>' for every account that
    # is not the built-in one. Each is { ref: prompt }: a NAME to ask for, never
    # a password. The Install screen asks; nothing here holds one.
    $needSa = $false
    $svcSecrets = [ordered]@{}

    if ([string]::IsNullOrWhiteSpace($HostName)) {
        [void]$problems.Add('this host has no COMPUTERNAME, so the spec cannot say which machine it is for')
    }
    $admins = [string[]](@($SysAdmin))
    if (@($admins).Count -eq 0) { $admins = Get-SqlStackGuiSysAdmin }

    # ---- the installed instances, EVERY one, protected ----
    $protected = 0
    foreach ($i in @($Installed)) {
        $nm = [string]$i.Name
        if ([string]::IsNullOrWhiteSpace($nm)) { continue }
        [void]$rows.Add([ordered]@{ name = $nm; protected = $true })
        $protected++
    }

    # ---- the new instances ----
    $claimants = @(@($Plan) | Where-Object { ($null -ne $_) -and (-not $_.Fixed) })
    foreach ($p in $claimants) {
        $nm = [string]$p.Name
        if ($nm -notmatch '^[A-Za-z][A-Za-z0-9_]{0,15}$') {
            [void]$problems.Add(("'{0}' is not a valid instance name, so no spec row was written for it" -f $nm)); continue
        }
        if (@($rows | Where-Object { [string]$_.name -eq $nm }).Count -gt 0) {
            [void]$problems.Add(("'{0}' is already installed on this host, so it cannot also be planned as new" -f $nm)); continue
        }
        if ([string]::IsNullOrWhiteSpace([string]$p.MediaPath)) {
            [void]$problems.Add(("{0}: no SQL install media folder has been chosen, so the spec cannot say what to install from" -f $nm)); continue
        }
        if ([string]::IsNullOrWhiteSpace([string]$p.MediaVersion)) {
            [void]$problems.Add(("{0}: the media at '{1}' has not been read successfully, so the version is unknown{2}" -f `
                        $nm, $p.MediaPath, $(if ($p.MediaProblem) { ' - ' + $p.MediaProblem } else { '' }))); continue
        }
        # The IP is written CANONICAL, through the engine's strict resolver (I-1);
        # a refused spelling, or an IP with Listen All (r17), is not written at all.
        $ipText = ([string]$p.Ip).Trim()
        $ipCanon = ''
        if ($ipText) {
            $ipRes = Resolve-SqlStackIpAddress -Ip $ipText
            if (-not $ipRes.Ok) { [void]$problems.Add(("{0}: its IP cannot be bound: {1}" -f $nm, $ipRes.Problem)); continue }
            if ($p.ListenAll -eq $true) { [void]$problems.Add(("{0}: it names an IP AND Listen All, which loader rule r17 refuses: clear one of them" -f $nm)); continue }
            $ipCanon = [string]$ipRes.Canonical
        }
        # The service accounts and the authentication mode, as the Plan screen
        # holds them. An account that cannot be used is a PROBLEM, never written
        # as the built-in one.
        $acctEngine = Get-SqlStackGuiRowAccount -Row $p -Role 'engine'
        $acctAgent = Get-SqlStackGuiRowAccount -Row $p -Role 'agent'
        if (-not $acctEngine.Ok) { [void]$problems.Add(("{0}: its engine account cannot be used: {1}" -f $nm, $acctEngine.Problem)); continue }
        if (-not $acctAgent.Ok) { [void]$problems.Add(("{0}: its agent account cannot be used: {1}" -f $nm, $acctAgent.Problem)); continue }
        $secMode = Get-SqlStackGuiSecurityMode -Row $p
        if ($secMode -eq 'mixed') { $needSa = $true }
        if ($acctEngine.Value -ne 'virtual') { $svcSecrets[('svc-{0}-engine' -f $nm)] = [ordered]@{ ref = 'prompt' } }
        if ($acctAgent.Value -ne 'virtual') { $svcSecrets[('svc-{0}-agent' -f $nm)] = [ordered]@{ ref = 'prompt' } }
        $isThrowaway = ($p.PSObject.Properties['Throwaway'] -and ($p.Throwaway -eq $true))
        $state = 'present'
        if ($AbsentThrowaway -and $isThrowaway) { $state = 'absent'; $absentCount++ }
        $row = [ordered]@{
            name = $nm
            state = $state
            manage = $true
            version = [string]$p.MediaVersion
            edition = $Edition
            mediaPath = [string]$p.MediaPath
            # ONE source with the .ini (finding 6): Get-SqlStackGuiFeatures.
            features = [string[]]@(Get-SqlStackGuiFeatures -Row $p)
            collation = 'SQL_Latin1_General_CP1_CI_AS'
            securityMode = $secMode
            serviceAccounts = [ordered]@{ engine = [string]$acctEngine.Value; agent = [string]$acctAgent.Value }
            sysadmins = $admins
            # The PLANNED port, as an integer, not 'auto': this window has already
            # done the arithmetic against the ports it read off this host, and the
            # Plan tab showed its working. Handing 'auto' back would discard that
            # and let the engine re-derive it against a different observation.
            ports = [ordered]@{ tcp = [int]$p.Port; dac = 'auto' }
            memory = [ordered]@{ maxMb = [int]$p.MaxMemoryMb }
            maxDop = [int]$p.MaxDop
            costThreshold = [int]$p.CostThreshold
            paths = [ordered]@{
                data = [string]$p.DataPath; log = [string]$p.LogPath
                tempdb = [string]$p.TempDbPath; backup = [string]$p.BackupPath
            }
            tempdb = [ordered]@{ files = [int]$p.TempDbFileCount; fileSizeMb = [int]$p.TempDbFileSizeMb }
            config = [ordered]@{ 'backup compression default' = 1; 'remote admin connections' = 1 }
            traceFlags = @()
        }
        # K4 (RULED by Adrian 2026-11-03): written only when ticked; it means only
        # "SqlStack may uninstall it later" (SPEC 6.3.2 leg 1).
        if ($isThrowaway) { $row.Insert(3, 'throwaway', $true) }
        # INV-4: planned into the spec (loader rules r16 and r17 check it), never applied here.
        if ($ipCanon) { $row['ip'] = $ipCanon; $row['listenAll'] = $false }
        elseif ($p.ListenAll -eq $true) { $row['listenAll'] = $true }
        [void]$rows.Add($row)
    }

    $claimantRows = @($rows).Count - $protected
    if ($claimantRows -le 0) {
        [void]$problems.Add('no new instance has everything a spec row needs, so there is nothing to apply')
    }

    $browserValue = $(if ($Browser -and $Browser.Ok) { [string]$Browser.Value } else { 'observed' })
    $secrets = [ordered]@{}
    if ($needSa) { $secrets['sa'] = [ordered]@{ ref = 'prompt' } }
    foreach ($sk in @($svcSecrets.Keys)) { $secrets[[string]$sk] = $svcSecrets[$sk] }
    $doc = [ordered]@{
        schema = $script:SqlStackSpecSchema
        host = [ordered]@{
            name = [string]$HostName
            portBase = $(if ($PortBase -gt 0) { [int]$PortBase } else { $null })
            osReserveMb = $null
            shared = [ordered]@{ browser = $browserValue; firewall = 'none' }
        }
        secrets = $secrets
        instances = [object[]](@($rows))
        cluster = $null
        availabilityGroups = @()
    }
    # -Depth 6: instances[] -> row -> paths -> value is 4, and the margin covers a
    # row gaining a nested block without this silently truncating it to a string.
    $json = ($doc | ConvertTo-Json -Depth 6)
    return [pscustomobject]@{
        Ok = ((@($problems).Count -eq 0) -and ($claimantRows -gt 0))
        Text = [string]$json
        Problems = [string[]](@($problems))
        InstanceCount = $claimantRows
        ProtectedCount = $protected
        AbsentCount = $absentCount
    }
}

function Get-SqlStackGuiPlanFingerprint {
    <#
      D2 (lane sqlstack-gui-glowup): what Save compares against the plan the
      files were generated from, so it never writes files for a plan that has
      changed since Generate. Every field a file is rendered from.
    #>
    param([object[]]$Plan = @())
    return (@(@($Plan) | Where-Object { $null -ne $_ } | ForEach-Object {
                $_ | Select-Object Name, Fixed, Port, DataPath, LogPath, TempDbPath, BackupPath, MaxMemoryMb, MinMemoryMb, MaxDop, CostThreshold, TempDbFileCount, TempDbFileSizeMb, EngineAccount, AgentAccount, Authentication
            }) | ConvertTo-Json -Compress -Depth 3)
}

function Write-SqlStackGuiFileSet {
    <#
      D2(i)/(iv) (lane sqlstack-gui-glowup): the Save path, without the dialog.
      Writes each file of the set under its own name into ONE folder and
      nothing else, and asks before replacing ANY existing file (until
      2026-10-01 Save overwrote without asking). The folder is resolved ONCE
      with GetFullPath; every target is that folder joined with a name that
      matched '<instance name>-install.ini' or '<instance name>-post-install.sql',
      and is checked to sit directly inside the folder before anything is
      written. -ConfirmOverwrite receives the existing file names and must
      return $true to replace them; anything else writes NOTHING.
      -RemoveOthers (the Install screen, 2026-11-16): after the yes, every
      OTHER file in the folder whose name this planner emits is deleted, so
      the folder holds exactly this plan. The install worker installs every
      ini it finds there; a file left from an earlier plan would be installed.
      Returns .Folder .Written .Existing .Cancelled .Removed
    #>
    param(
        [Parameter(Mandatory)][string]$Folder,
        [object[]]$FileSet = @(),
        [Parameter(Mandatory)][scriptblock]$ConfirmOverwrite,
        [switch]$RemoveOthers
    )
    $full = [IO.Path]::GetFullPath($Folder)
    if (-not [IO.Directory]::Exists($full)) { throw ("the folder does not exist: {0}" -f $full) }
    $root = $full.TrimEnd('\')
    $targets = New-Object System.Collections.ArrayList
    $seen = @{}
    foreach ($f in @($FileSet | Where-Object { $null -ne $_ })) {
        $name = [string]$f.Name
        if ($name -notmatch '^[A-Za-z][A-Za-z0-9_]{0,15}-(install\.ini|post-install\.sql)$') { throw ("refusing to write '{0}': not a file name this planner emits" -f $name) }
        if ($seen.ContainsKey($name)) { throw ("refusing to write '{0}' twice" -f $name) }
        $seen[$name] = $true
        $t = [IO.Path]::GetFullPath([IO.Path]::Combine($full, $name))
        if (([IO.Path]::GetDirectoryName($t)).TrimEnd('\') -ne $root) { throw ("refusing to write '{0}': it resolves outside {1}" -f $name, $full) }
        [void]$targets.Add([pscustomobject]@{ Name = $name; Path = $t; Text = [string]$f.Text })
    }
    $existing = [string[]]@($targets | Where-Object { [IO.File]::Exists($_.Path) } | ForEach-Object { $_.Name })
    if ($existing.Count -gt 0) {
        $answer = & $ConfirmOverwrite $existing
        if (-not (($answer -is [bool]) -and $answer)) {
            return [pscustomobject]@{ Folder = $full; Written = [string[]]@(); Existing = $existing; Cancelled = $true; Removed = [string[]]@() }
        }
    }
    $removed = New-Object System.Collections.ArrayList
    if ($RemoveOthers) {
        foreach ($old in @([IO.Directory]::GetFiles($full))) {
            $leaf = [IO.Path]::GetFileName($old)
            if (($leaf -match '^[A-Za-z][A-Za-z0-9_]{0,15}-(install\.ini|post-install\.sql)$') -and (-not $seen.ContainsKey($leaf))) {
                [IO.File]::Delete($old)
                [void]$removed.Add($leaf)
            }
        }
    }
    $enc = New-Object System.Text.UTF8Encoding($false)
    foreach ($t in $targets) { [IO.File]::WriteAllText($t.Path, $t.Text, $enc) }
    return [pscustomobject]@{ Folder = $full; Written = [string[]]@($targets | ForEach-Object { $_.Name }); Existing = $existing; Cancelled = $false; Removed = [string[]]@($removed) }
}

function Get-SqlStackGuiTcpText {
    <#
      D5 (lane sqlstack-gui-glowup): an installed instance's TCP state IN
      WORDS, from the ENGINE's facts only. Until 2026-10-01 the Instances grid
      read the registry itself and showed raw values ('0' under 'Dynamic
      ports' and '0' under 'TCP enabled' for an instance whose TCP is off),
      duplicating Get-KnownInstancePortMap. Now:
        -FixedRow  that instance's row of Get-KnownInstancePortMap's .Fixed
                   (Port = an int, or 'dynamic') - the SAME object the port
                   planner is given, so the grid and the plan cannot disagree
        -Map       Get-KnownInstancePortMap's .Map (Name -> the port the
                   registry names, static or last-assigned dynamic)
        -TcpRead   .Read .Row .Reason, where .Row is the engine's
                   net-tcp-registry probe row (TcpEnabled, IPAllTcpPort,
                   IPAllTcpDynamicPorts, TcpDynamicPortsState): the protocol
                   switch, which the port map does not carry
      Returns .Text (words) and .Tip (the raw values and what the words mean).
      Guarded by 'tcp words (D5):' in -SelfTest and the 'D5-' rows of
      Test-SqlStackGuiStructure.
    #>
    param([string]$Name, [object]$FixedRow, [hashtable]$Map = @{}, [object]$TcpRead)
    $mapPort = $null
    if ($Map -and $Map.ContainsKey($Name)) { $mapPort = [int]$Map[$Name] }
    if (($null -eq $TcpRead) -or (-not [bool]$TcpRead.Read)) {
        $why = $(if ($TcpRead -and $TcpRead.Reason) { [string]$TcpRead.Reason } else { 'no read was made' })
        return [pscustomobject]@{ Text = 'unknown (TCP settings could not be read)'; Tip = ('Could not read this instance''s TCP settings: ' + $why) }
    }
    $r = $TcpRead.Row
    if ($null -eq $r) {
        return [pscustomobject]@{ Text = 'TCP not configured'; Tip = 'The instance''s registry has no SuperSocketNetLib\Tcp key: TCP was never configured for it.' }
    }
    $raw = ("Registry, read through the engine: Tcp\Enabled = '{0}'; IPAll\TcpPort = '{1}'; IPAll\TcpDynamicPorts = '{2}' ({3})." -f `
            [string]$r.TcpEnabled, [string]$r.IPAllTcpPort, [string]$r.IPAllTcpDynamicPorts, [string]$r.TcpDynamicPortsState)
    if ([string]$r.TcpEnabled -eq '0') {
        return [pscustomobject]@{ Text = 'TCP off'; Tip = ('The TCP/IP protocol is disabled in this instance''s network configuration. ' + $raw) }
    }
    if ([string]$r.TcpEnabled -ne '1') {
        return [pscustomobject]@{ Text = 'unknown (Tcp\Enabled is not 0 or 1)'; Tip = $raw }
    }
    $fp = $(if ($FixedRow) { $FixedRow.Port } else { $null })
    if (($null -ne $fp) -and ([string]$fp -ne 'dynamic')) {
        return [pscustomobject]@{ Text = ('static {0}' -f [int]$fp); Tip = ('TCP is on, on the static port the registry names. ' + $raw) }
    }
    if ($null -ne $mapPort) {
        return [pscustomobject]@{ Text = ('dynamic {0}' -f $mapPort); Tip = ('TCP is on with no static port; SQL Server took this dynamic port at its last start and may take another at the next. ' + $raw) }
    }
    return [pscustomobject]@{ Text = 'dynamic (none assigned)'; Tip = ('TCP is on with no static port, and no dynamic port is recorded yet. ' + $raw) }
}

# ===========================================================================
# WORDS, NOT COLOUR ALONE (lane sqlstack-gui-glowup, stage 2). Pure: -SelfTest
# drives each of these, and the window shows exactly what they return.
# ===========================================================================
function Get-SqlStackGuiPlural {
    # '1 volume', '0 volumes', '2 volumes': the count and the right noun.
    param([int]$Count, [string]$One, [string]$Many)
    if ($Count -eq 1) { return ('{0} {1}' -f $Count, $One) }
    return ('{0} {1}' -f $Count, $Many)
}

function Get-SqlStackGuiHeaderFacts {
    <#
      The header card's host facts, one chip each, in words. 'lettered volume'
      because the Volumes list holds only volumes WITH a drive letter (the
      lane's brief critic counted 4 more without one on the build box).
    #>
    param([int]$LogicalCores, [int]$PhysicalMb, [int]$VolumeCount, [int]$InstanceCount)
    return [string[]]@(
        (Get-SqlStackGuiPlural -Count $LogicalCores -One 'logical core' -Many 'logical cores'),
        ('{0} GB RAM' -f [math]::Round($PhysicalMb / 1024, 1)),
        (Get-SqlStackGuiPlural -Count $VolumeCount -One 'lettered volume' -Many 'lettered volumes'),
        (Get-SqlStackGuiPlural -Count $InstanceCount -One 'SQL instance installed' -Many 'SQL instances installed'))
}

function Get-SqlStackGuiCountText {
    # The status bar's counts, in words: '0 errors, 1 warning'.
    # -ReadOnly (gate F13): with a read-only spec open the counts are this window's
    # own check, and stage 1 is the loader's verdict; the words say so.
    param([int]$Errors, [int]$Warnings, [switch]$ReadOnly)
    $t = ('{0}, {1}' -f (Get-SqlStackGuiPlural -Count $Errors -One 'error' -Many 'errors'), (Get-SqlStackGuiPlural -Count $Warnings -One 'warning' -Many 'warnings'))
    if ($ReadOnly) { $t += ' in this window''s check of a read-only spec' }
    return $t
}

function Get-SqlStackGuiActionState {
    <#
      The Review tab's two actions. Generate's rule is the one this window has
      always applied (no ERROR finding, and at least one NEW instance, D1), now
      with the reason in words whenever it is off. Exactly ONE action is the
      primary (accent) button: Save once a generated file set matches the plan
      as it is now, otherwise Generate.
    #>
    param([int]$Errors, [int]$NewRows, [bool]$HasFileSet, [bool]$FileSetCurrent)
    $gen = (($Errors -eq 0) -and ($NewRows -gt 0))
    $reason = ''
    if ($Errors -gt 0) { $reason = ('Generate is off: the plan has {0}. Fix it on the Plan tab.' -f (Get-SqlStackGuiPlural -Count $Errors -One 'error' -Many 'errors')) }
    elseif ($NewRows -eq 0) { $reason = 'Generate is off: the plan has no new instance, and installed instances get no files.' }
    elseif ($HasFileSet -and (-not $FileSetCurrent)) { $reason = 'The plan changed after Generate. Generate again, review, then Save.' }
    elseif ($HasFileSet) { $reason = 'Review both files, then Save.' }
    return [pscustomobject]@{
        GenerateEnabled = $gen
        Primary         = $(if ($HasFileSet -and $FileSetCurrent) { 'Save' } else { 'Generate' })
        Reason          = $reason
    }
}

function New-SqlStackGuiPlanRow {
    <#
      THE ONE SHAPE of a NEW instance's plan row. New-PlanRowFromName (a fresh
      row with this host's suggested folders) and ConvertFrom-SqlStackGuiSpec (a
      row read back from a run folder's spec.json) both build through here, so a
      field added to the row is added once. Every field is said where it matters:
        Ip / ListenAll   RULED 2026-10-09: one unique IP and one unique port per
                         instance. Empty Ip = nothing bound yet (not ListenAll).
                         Planned into the spec only (INV-4); never applied here.
        MediaPath ...    the install media, read by Read-SqlStackGuiMedia; ''
                         means not read yet, never guessed.
        Features         'SQLENGINE' or 'SQLENGINE,FULLTEXT': the ONE source for
                         both the spec and the .ini (finding 6).
        Throwaway        K4 (RULED by Adrian 2026-11-03): OFF by default; it means
                         only "SqlStack may uninstall it later" (SPEC 6.3.2).
        Fixed            $false: a NEW instance (installed rows come from
                         New-PlanRowFromInstalled).
        EngineAccount / AgentAccount   as the Plan screen shows them: the
                         built-in words, or a typed DOMAIN\name (a name ending
                         in $ is a group managed account). ONE reading:
                         Get-SqlStackGuiRowAccount.
        Authentication   'Windows only' or 'Mixed mode'. ONE reading:
                         Get-SqlStackGuiSecurityMode.
    #>
    param(
        [Parameter(Mandatory)][string]$Name, [int]$Ordinal = 1, $Port = $null,
        [string]$DataPath = '', [string]$LogPath = '', [string]$TempDbPath = '', [string]$BackupPath = '',
        [int]$MaxMemoryMb = 0, [int]$MinMemoryMb = 0, [int]$MaxDop = 0, [int]$CostThreshold = 50,
        [int]$TempDbFileCount = 1, [int]$TempDbFileSizeMb = 1024,
        [string]$Ip = '', [bool]$ListenAll = $false, [string]$MediaPath = '', [string]$MediaVersion = '',
        [string]$Features = 'SQLENGINE', [bool]$Throwaway = $false,
        [string]$EngineAccount = $script:SqlStackGuiVirtualWords, [string]$AgentAccount = $script:SqlStackGuiVirtualWords,
        [string]$Authentication = $script:SqlStackGuiAuthWindows,
        # Optional folder of update packages for setup (2026-11-17). NOT in the
        # spec: it is saved in the run folder's install.json and handed to
        # setup by the install worker (Get-SqlStackGuiUpdatesMap).
        [string]$UpdatesPath = ''
    )
    return [pscustomobject]@{
        UpdatesPath = $UpdatesPath
        Name = $Name; Ordinal = $Ordinal; Port = $Port; DacPort = $null
        DataPath = $DataPath; LogPath = $LogPath; TempDbPath = $TempDbPath; BackupPath = $BackupPath
        MaxMemoryMb = $MaxMemoryMb; MinMemoryMb = $MinMemoryMb
        MaxDop = $MaxDop; CostThreshold = $CostThreshold
        TempDbFileCount = $TempDbFileCount; TempDbFileSizeMb = $TempDbFileSizeMb
        MemoryWeight = 1
        IsDefault = $false
        Ip = $Ip
        ListenAll = $ListenAll
        MediaPath = $MediaPath
        MediaVersion = $MediaVersion   # '2017' | '2022' | '2025', from the major map
        MediaBaseline = ''             # e.g. '16.0.1000.6', the media's own BaselineVersion
        MediaProblem = ''              # the engine's own failure text, verbatim
        Features = $Features
        Throwaway = $Throwaway
        Fixed = $false
        EngineAccount = $EngineAccount
        AgentAccount = $AgentAccount
        Authentication = $Authentication
    }
}

function Resolve-SqlStackGuiAccount {
    <#
      THE ONE READING of a service account as the Plan screen holds it. Blank,
      'virtual' or the built-in words: the built-in account (spec value
      'virtual'; setup gets NT Service\MSSQL$<name>). Anything else must be
      DOMAIN\name: one backslash, no double quote, no control character. A name
      ending in $ is a group managed account: it has no password to ask for.
      .Words says, in plain words, what the screen shows as you type.
      Returns ONE object: .Ok .Value .Kind (virtual|domain|gmsa|builtin) .NeedsPassword .Words .Problem
    #>
    param([string]$Text)
    $t = ([string]$Text).Trim()
    $o = [pscustomobject]@{ Ok = $true; Value = 'virtual'; Kind = 'virtual'; NeedsPassword = $false; Words = 'built-in account that Windows manages; no password'; Problem = '' }
    if (($t -eq '') -or ($t -ieq 'virtual') -or ($t -ieq $script:SqlStackGuiVirtualWords)) { return $o }
    $o.Value = ''
    $bad = ''
    if ($t -match '["\x00-\x1F\x7F]') { $bad = 'it holds a double quote or a control character' }
    elseif ($t -notmatch '^[^\\/@]+\\[^\\/]+$') { $bad = 'type it as DOMAIN\name (for example CONTOSO\svc-sql), or choose ' + $script:SqlStackGuiVirtualWords }
    if ($bad) { $o.Ok = $false; $o.Kind = ''; $o.Problem = $bad; $o.Words = ('not usable yet: ' + $bad); return $o }
    $o.Value = $t
    if ($t.EndsWith('$')) { $o.Kind = 'gmsa'; $o.Words = 'group managed account (the name ends in $); no password is asked' }
    elseif (($t -like 'NT Service\*') -or ($t -like 'NT AUTHORITY\*')) { $o.Kind = 'builtin'; $o.Words = 'Windows built-in account; no password is asked' }
    else { $o.Kind = 'domain'; $o.NeedsPassword = $true; $o.Words = 'domain account; Install asks for its password once' }
    return $o
}

function Get-SqlStackGuiRowAccount {
    # A plan row's engine or agent account, through the ONE reading. A row with
    # no such field (an older row shape) is the built-in account.
    param($Row, [ValidateSet('engine', 'agent')][string]$Role)
    $field = $(if ($Role -eq 'engine') { 'EngineAccount' } else { 'AgentAccount' })
    $raw = $(if ($Row -and $Row.PSObject.Properties[$field]) { [string]$Row.$field } else { '' })
    return (Resolve-SqlStackGuiAccount -Text $raw)
}

function Get-SqlStackGuiSecurityMode {
    # A plan row's authentication as the spec says it: 'mixed' only when the
    # row's Authentication is the Mixed mode choice, else 'windows'.
    param($Row)
    $raw = $(if ($Row -and $Row.PSObject.Properties['Authentication']) { [string]$Row.Authentication } else { '' })
    if ($raw.Trim() -ieq $script:SqlStackGuiAuthMixed) { return 'mixed' }
    return 'windows'
}

function Get-SqlStackGuiAccountNote {
    # The line under the two account boxes, as you type: each account in plain
    # words. .Ok is false when either cannot be used.
    param([string]$Engine, [string]$Agent)
    $e = Resolve-SqlStackGuiAccount -Text $Engine
    $a = Resolve-SqlStackGuiAccount -Text $Agent
    return [pscustomobject]@{ Ok = ($e.Ok -and $a.Ok); Text = ('Engine: {0}. Agent: {1}.' -f $e.Words, $a.Words) }
}

function Get-SqlStackGuiFeatures {
    # A row's setup features as a list: the ONE reading of row.Features, used by
    # the spec writer AND the .ini (finding 6: they used to disagree, 'SQLENGINE'
    # against 'SQLENGINE,FULLTEXT'). Empty or absent is 'SQLENGINE'.
    param($Row)
    $raw = $(if ($Row -and $Row.PSObject.Properties['Features']) { [string]$Row.Features } else { '' })
    $f = @(($raw -split ',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
    if ($f.Count -eq 0) { $f = @('SQLENGINE') }
    return [string[]]$f
}

function Get-SqlStackGuiFreeText {
    # A volume's free share in words, judged UNROUNDED (Gemini finding 14: 9.84%
    # rounded to '10%' was never called low). One decimal below 10%.
    param([double]$Percent)
    if ($Percent -lt 10) { return ('{0}%' -f ([Math]::Round($Percent, 1)).ToString('0.0', [Globalization.CultureInfo]::InvariantCulture)) }
    return ('{0}%' -f [Math]::Round($Percent, 0))
}

function Get-SqlStackGuiStatusWord {
    # A stage status as the rail shows it: a WORD, and the colour that repeats it.
    param([string]$Status)
    switch ($Status) {
        'Done'      { return [pscustomobject]@{ Word = 'done';        Color = 'Ok' } }
        'Running'   { return [pscustomobject]@{ Word = 'running';     Color = 'Info' } }
        'Attention' { return [pscustomobject]@{ Word = 'check it';    Color = 'Warning' } }
        'Failed'    { return [pscustomobject]@{ Word = 'FAILED';      Color = 'Error' } }
        'Stale'     { return [pscustomobject]@{ Word = 'stale';       Color = 'Warning' } }
        'Blocked'   { return [pscustomobject]@{ Word = 'greyed';      Color = 'DisabledText' } }
        default     { return [pscustomobject]@{ Word = 'not started'; Color = 'Secondary' } }
    }
}

function Get-SqlStackGuiHostIpRows {
    <#
      SHAPE TABLE ROW S6 (critic K10): the engine's Get-SqlStackLocalIpAddress
      rows as the Host view lists them, read only. A failed read is ONE sentinel
      row (Ip '', .ReadFailed) and is shown as "could not read", never as "no
      addresses". Loopback and link-local (fe80::%scope, 169.254.* on adapters
      that are down) are labelled, not hidden.
      K15 (lane sqlstack-live-blockers, I1): the label shows the ADDRESS's
      origin (PrefixOrigin) only. An IPv4 address with PrefixOrigin 'Dhcp' is
      'IPv4 (DHCP)', and one whose origin was not read (absent, empty or
      'unknown') is 'IPv4 (DHCP state unknown)'. It does not show the CARD's
      DHCP state (net-local-interfaces, which the window does not read): a DHCP
      card holding only a link-local address shows link-local, and an origin
      such as Other or WellKnown shows plain IPv4 though the engine refuses to
      bind it. Test: 'host IPs (K15)' in -SelfTest.
    #>
    param([object[]]$Rows = @())
    $out = New-Object System.Collections.ArrayList
    foreach ($r in @($Rows | Where-Object { $null -ne $_ })) {
        if ($r.PSObject.Properties['ReadFailed'] -and $r.ReadFailed) { [void]$out.Add([pscustomobject]@{ Address = 'could not read'; Kind = [string]$r.ReadFailed; Adapter = '' }); continue }
        $kind = $(if ($r.IsLoopback) { 'loopback' } elseif ($r.IsLinkLocal) { 'link-local' } elseif ([string]$r.Family -eq 'InterNetworkV6') { 'IPv6' } else { 'IPv4' })
        if ($kind -ceq 'IPv4') {
            $po = $(if ($r.PSObject.Properties['PrefixOrigin']) { [string]$r.PrefixOrigin } else { '' })
            if ($po -ceq 'Dhcp') { $kind = 'IPv4 (DHCP)' }
            elseif (($po -eq '') -or ($po -ceq 'unknown')) { $kind = 'IPv4 (DHCP state unknown)' }
        }
        [void]$out.Add([pscustomobject]@{ Address = [string]$r.Ip; Kind = $kind; Adapter = [string]$r.Interface })
    }
    if ($out.Count -eq 0) { [void]$out.Add([pscustomobject]@{ Address = 'none read'; Kind = 'the reader returned no rows'; Adapter = '' }) }
    return $out.ToArray()
}

function Get-SqlStackGuiSpecActionState {
    # Save spec, the ONE primary action (finding 1): off, with the reason in words,
    # while the plan has an error, no new instance, is read-only, or the spec
    # writer itself has a problem (finding 10: never a surprise dialog).
    param([int]$Errors, [int]$NewRows, [bool]$ReadOnly, [string[]]$SpecProblems = @())
    $why = ''
    if ($ReadOnly) { $why = 'Save spec is off: this run folder''s spec is open READ ONLY (the banner says why). Start a new run folder to plan again.' }
    elseif ($NewRows -eq 0) { $why = 'Save spec is off: there is no new instance to plan. Press Add new instance.' }
    elseif ($Errors -gt 0) { $why = ('Save spec is off: the plan has {0}. Read Validation.' -f (Get-SqlStackGuiPlural -Count $Errors -One 'error' -Many 'errors')) }
    elseif (@($SpecProblems).Count -gt 0) { $why = ('Save spec is off: {0}' -f @($SpecProblems)[0]) }
    return [pscustomobject]@{ Enabled = (-not $why); Reason = $why }
}

function Compare-SqlStackGuiJson {
    # Where two parsed JSON documents differ, as paths ($.host.name,
    # $.instances[SQLSTACK1].ports.tcp). Property order is not a difference.
    param($A, $B, [string]$Path = '$')
    if (($null -eq $A) -and ($null -eq $B)) { return [string[]]@() }
    if (($null -eq $A) -or ($null -eq $B)) { return [string[]]@($Path) }
    $diff = New-Object System.Collections.ArrayList
    $isObj = { param($x) $x -is [System.Management.Automation.PSCustomObject] }
    if ((& $isObj $A) -and (& $isObj $B)) {
        $names = @(@($A.PSObject.Properties | ForEach-Object { $_.Name }) + @($B.PSObject.Properties | ForEach-Object { $_.Name }) | Sort-Object -Unique)
        foreach ($n in $names) {
            $pa = $A.PSObject.Properties[$n]; $pb = $B.PSObject.Properties[$n]
            if (($null -eq $pa) -or ($null -eq $pb)) { [void]$diff.Add(('{0}.{1}' -f $Path, $n)); continue }
            foreach ($d in @(Compare-SqlStackGuiJson -A $pa.Value -B $pb.Value -Path ('{0}.{1}' -f $Path, $n))) { [void]$diff.Add($d) }
        }
        return [string[]]@($diff)
    }
    if (($A -is [array]) -or ($B -is [array])) {
        $aa = @($A); $bb = @($B)
        if ($aa.Count -ne $bb.Count) { return [string[]]@(('{0} ({1} item(s) against {2})' -f $Path, $aa.Count, $bb.Count)) }
        for ($i = 0; $i -lt $aa.Count; $i++) {
            $lab = $(if ((& $isObj $aa[$i]) -and $aa[$i].PSObject.Properties['name']) { [string]$aa[$i].name } else { [string]$i })
            foreach ($d in @(Compare-SqlStackGuiJson -A $aa[$i] -B $bb[$i] -Path ('{0}[{1}]' -f $Path, $lab))) { [void]$diff.Add($d) }
        }
        return [string[]]@($diff)
    }
    if ((& $isObj $A) -or (& $isObj $B)) { return [string[]]@($Path) }
    $num = { param($x) ($x -is [int]) -or ($x -is [long]) -or ($x -is [double]) -or ($x -is [decimal]) }
    if ((& $num $A) -and (& $num $B)) { if ([decimal]$A -ne [decimal]$B) { return [string[]]@($Path) } else { return [string[]]@() } }
    if (($A.GetType() -ne $B.GetType()) -or ([string]$A -cne [string]$B)) { return [string[]]@($Path) }
    return [string[]]@()
}

function ConvertFrom-SqlStackGuiSpec {
    <#
      SHAPE TABLE ROW S3: a run folder's parsed spec.json back into plan rows (the
      NEW instances: every instance that is not protected). The plan-wide values
      the writer takes come back too (.Edition .SysAdmin .PortBase). What this
      window cannot model is a PROBLEM, named, never dropped; whether the file
      round-trips is Test-SqlStackGuiSpecRoundTrip's question.
      Returns ONE object: .Rows .Edition .SysAdmin .PortBase .Problems
    #>
    param([Parameter(Mandatory)]$Doc)
    $rows = New-Object System.Collections.ArrayList
    $problems = New-Object System.Collections.ArrayList
    $edition = ''; $admins = @()
    # A number the window plans; a hand-written 'auto' (or anything else) is a
    # PROBLEM named by its key, and the row carries 0 until the operator sets it.
    $num = {
        param([string]$Inst, [string]$Key, $Value)
        if ($null -eq $Value) { return 0 }
        if (([string]$Value) -match '^\d+$') { return [int]$Value }
        [void]$problems.Add(("{0}: {1} is '{2}'; this window plans a number" -f $Inst, $Key, $Value)); return 0
    }
    $n = 0
    foreach ($i in @($Doc.instances | Where-Object { ($null -ne $_) -and ($_.protected -ne $true) })) {
        $n++
        $nm = [string]$i.name
        $st = $(if ($i.PSObject.Properties['state']) { [string]$i.state } else { 'present' })
        if ($st -ne 'present') { [void]$problems.Add(("{0}: state is '{1}'; this window plans present instances only" -f $nm, $st)) }
        $tcp = $null
        if ($i.ports -and ($null -ne $i.ports.tcp)) {
            if (([string]$i.ports.tcp) -match '^\d+$') { $tcp = [int]$i.ports.tcp }
            else { [void]$problems.Add(("{0}: ports.tcp is '{1}'; this window plans a port number" -f $nm, $i.ports.tcp)) }
        }
        $row = New-SqlStackGuiPlanRow -Name $nm -Ordinal $n -Port $tcp `
                -DataPath ([string]$i.paths.data) -LogPath ([string]$i.paths.log) -TempDbPath ([string]$i.paths.tempdb) -BackupPath ([string]$i.paths.backup) `
                -MaxMemoryMb (& $num $nm 'memory.maxMb' $i.memory.maxMb) -MaxDop (& $num $nm 'maxDop' $i.maxDop) -CostThreshold (& $num $nm 'costThreshold' $i.costThreshold) `
                -TempDbFileCount (& $num $nm 'tempdb.files' $i.tempdb.files) -TempDbFileSizeMb (& $num $nm 'tempdb.fileSizeMb' $i.tempdb.fileSizeMb) `
                -Ip ([string]$i.ip) -ListenAll ($i.listenAll -eq $true) -MediaPath ([string]$i.mediaPath) -MediaVersion ([string]$i.version) `
                -Features ((@($i.features) | ForEach-Object { [string]$_ }) -join ',') -Throwaway ($i.throwaway -eq $true)
        # The accounts and the authentication mode, back into the words the
        # Plan screen shows ('virtual' or no key at all = the built-in account).
        foreach ($role in @('engine', 'agent')) {
            $acct = $(if ($i.serviceAccounts -and $i.serviceAccounts.PSObject.Properties[$role]) { [string]$i.serviceAccounts.$role } else { 'virtual' })
            $shown = $(if (($acct -eq 'virtual') -or [string]::IsNullOrWhiteSpace($acct)) { $script:SqlStackGuiVirtualWords } else { $acct })
            if ($role -eq 'engine') { $row.EngineAccount = $shown } else { $row.AgentAccount = $shown }
        }
        $row.Authentication = $(if ([string]$i.securityMode -eq 'mixed') { $script:SqlStackGuiAuthMixed } else { $script:SqlStackGuiAuthWindows })
        [void]$rows.Add($row)
        if (-not $edition) { $edition = [string]$i.edition }
        if (@($admins).Count -eq 0) { $admins = [string[]]@(@($i.sysadmins) | ForEach-Object { [string]$_ }) }
    }
    $pb = 0
    if ($Doc.host -and ($null -ne $Doc.host.portBase) -and (([string]$Doc.host.portBase) -match '^\d+$')) { $pb = [int]$Doc.host.portBase }
    return [pscustomobject]@{ Rows = $rows.ToArray(); Edition = $edition; SysAdmin = [string[]]@($admins); PortBase = $pb; Problems = [string[]]@($problems) }
}

function Test-SqlStackGuiSpecRoundTrip {
    <#
      S3's rule: a spec.json is EDITABLE in this window only if writing the rows
      read from it back, with the inputs Save spec would use (this host's name,
      its installed instances, its SQL Browser read), gives the SAME document.
      Anything else (a hand-written key, a value this window does not model,
      another host, a protected list that is not this host's) is a difference,
      NAMED by its path, and the spec opens read-only.
      Returns ONE object: .Same .Differences
    #>
    param([Parameter(Mandatory)]$Doc, [Parameter(Mandatory)]$Import, [object[]]$Installed = @(), [string]$HostName = $env:COMPUTERNAME, $Browser = $null)
    $regen = New-SqlStackGuiSpec -Plan @($Import.Rows) -Installed $Installed -HostName $HostName -PortBase $Import.PortBase `
                -Edition $Import.Edition -SysAdmin @($Import.SysAdmin) -Browser $Browser
    if (-not $regen.Ok) { return [pscustomobject]@{ Same = $false; Differences = [string[]]@(@($regen.Problems) | ForEach-Object { 'cannot be rewritten: ' + $_ }) } }
    $b = ConvertFrom-Json $regen.Text
    $d = @(Compare-SqlStackGuiJson -A $Doc -B $b)
    return [pscustomobject]@{ Same = ($d.Count -eq 0); Differences = [string[]]$d }
}

function Invoke-SqlStackGuiCompare {
    <#
      Stage 8's comparison, RUN HERE (critic K15, ruled 2026-11-03): the ENGINE's
      Compare-SqlStackSnapshot, in-process, over snapshot A and snapshot B. It only
      READS the two bundles (the engine writer census covers its file). The lines
      put Ok FIRST, then Empty, then the rest, the order RUNBOOK step 8 reads them
      in. -ExcludeInstance comes ONLY from snapshot B's map, through
      Get-SqlStackGuiCompareBlock's token; with no usable map nothing is excluded,
      and the first lines say so. Surviving rows still need BOTH maps to classify
      (tokens renumber between bundles): that stays the operator's step.
      Returns ONE object: .Ran .Headline .Lines .Result
    #>
    param([Parameter(Mandatory)]$State, [string]$MapRoot = '')
    $lines = New-Object System.Collections.ArrayList
    if (($State.SnapshotA.Status -ne 'Done') -or ($State.SnapshotB.Status -ne 'Done')) {
        return [pscustomobject]@{ Ran = $false; Headline = 'No comparison: it needs an intact snapshot A and an intact snapshot B.'; Lines = [string[]]@(); Result = $null }
    }
    $blk = Get-SqlStackGuiCompareBlock -State $State -MapRoot $MapRoot
    $ex = @()
    if ($blk.Token) { $ex = @($blk.Token) }
    $r = $null
    try { $r = Compare-SqlStackSnapshot -Before $State.SnapshotA.Bundle -After $State.SnapshotB.Bundle -ExcludeInstance $ex }
    catch { return [pscustomobject]@{ Ran = $false; Headline = ('The comparison failed: ' + $_.Exception.Message); Lines = [string[]]@(); Result = $null } }
    [void]$lines.Add(('OK={0}   (read this FIRST: true only when the three positive controls fired, so a change could have been seen)' -f $r.Ok))
    [void]$lines.Add(('EMPTY={0}   (meaningless unless OK is true)' -f $r.Empty))
    [void]$lines.Add(('RAW={0}  SURVIVING={1}  EXCLUDED={2}' -f $r.Raw, @($r.Surviving).Count, $(if ($blk.Token) { $blk.Token } else { 'nothing' })))
    if (-not $blk.Token) { [void]$lines.Add(('No instance was excluded: {0}' -f $blk.Reason)) }
    foreach ($p in @($r.Problems)) { [void]$lines.Add(('PROBLEM: ' + [string]$p)) }
    [void]$lines.Add('')
    foreach ($l in @($r.Lines)) { [void]$lines.Add([string]$l) }
    if (@($r.Surviving).Count -gt 0) {
        [void]$lines.Add('')
        [void]$lines.Add('Surviving rows (classify each with BOTH maps: tokens renumber between bundles):')
        foreach ($s in @($r.Surviving)) { [void]$lines.Add(('  {0}  {1}  {2} -> {3}' -f $s.Key, $s.Change, $s.OldValue, $s.NewValue)) }
    }
    $head = ('Compared snapshot A and snapshot B: OK={0}, EMPTY={1}, {2} surviving row(s).' -f $r.Ok, $r.Empty, @($r.Surviving).Count)
    return [pscustomobject]@{ Ran = $true; Headline = $head; Lines = [string[]]@($lines); Result = $r }
}

function Read-SqlStackGuiMemoryCeiling {
    <#
      SHAPE TABLE ROW S4 (critic K7, Adrian's ruling: the ceilings come from
      snapshot A): each INSTALLED instance's 'max server memory (MB)', read from
      snapshot A's probes\sql-configurations.<name-or-token>.json. ONE reader, in
      this file, because the engine's own parsing sits after its library return
      and cannot be called. The shapes, each PROVED in the critic's real bundle:
        - the DEFAULT instance's file keeps its literal name, MSSQLSERVER;
          a named instance's file is its redaction TOKEN (INST<n>, with gaps),
          and a token becomes a name ONLY through the bundle's redaction map;
        - no map, a map this process cannot see, or a map from another host:
          "cannot be matched to this host's instances" for EVERY instance, the
          default one included (the typed ceiling is the fallback);
        - the file absent (the probe was skipped or denied): "not read", with
          the status from probes.jsonl;
        - value_in_use 2147483647: "unlimited (SQL default)";
        - NEVER 0 for an unread value, and NEVER computed-plan.json's number
          (it stores an unread instance as MaxMb 0).
      Returns ONE object: .Ok .Reason .Source .Rows (.Name .Mb .Unlimited .Words)
    #>
    param([Parameter(Mandatory)]$Snapshot, [string[]]$Installed = @(), [string]$MapRoot = '', [string]$ComputerName = $env:COMPUTERNAME)
    $rows = New-Object System.Collections.ArrayList
    $mkRow = { param($n, $mb, [bool]$unl, $w) [pscustomobject]@{ Name = [string]$n; Mb = $mb; Unlimited = $unl; Words = [string]$w } }
    if ([string]$Snapshot.Status -ne 'Done') {
        foreach ($n in $Installed) { [void]$rows.Add((& $mkRow $n $null $false 'not read: there is no intact snapshot A in this run folder yet')) }
        return [pscustomobject]@{ Ok = $false; Reason = 'no intact snapshot A'; Source = ''; Rows = $rows.ToArray() }
    }
    $src = ('snapshot A, {0}' -f $Snapshot.CollectedUtc)
    $map = Read-SqlStackGuiRedactionMap -BundleName $Snapshot.BundleName -HostToken $Snapshot.HostToken -MapRoot $MapRoot -ComputerName $ComputerName
    # Probe statuses by instance token, from probes.jsonl (the skipped files have only this).
    $status = @{}
    $jl = Read-SqlStackGuiText -Path (Join-Path $Snapshot.Bundle 'probes.jsonl')
    if ($jl) {
        foreach ($line in ($jl -split "`r?`n")) {
            if (-not $line.Trim()) { continue }
            try { $rec = ConvertFrom-Json $line } catch { continue }
            if ([string]$rec.probeId -eq 'sql-configurations') { $status[[string]$rec.instance] = ('{0}: {1}' -f $rec.status, $rec.evidence) }
        }
    }
    foreach ($n in $Installed) {
        $tok = ''
        # The map ties the BUNDLE to this host, so it is checked first for EVERY
        # instance, the default one too (gate F2: its file needs no token, but with
        # no map or another host's map its number may be another host's).
        if (-not $map.Ok) { [void]$rows.Add((& $mkRow $n $null $false ('cannot be matched to this host''s instances: ' + $map.Reason))); continue }
        if ([string]$n -ieq 'MSSQLSERVER') { $tok = 'MSSQLSERVER' }
        else {
            $hits = @($map.Map.Keys | Where-Object { ([string]$map.Map[$_].Class -eq 'INST') -and ([string]$map.Map[$_].Value -ieq [string]$n) })
            if ($hits.Count -ne 1) { [void]$rows.Add((& $mkRow $n $null $false ('cannot be matched: snapshot A''s map holds {0} INST token(s) for it' -f $hits.Count))); continue }
            $tok = [string]$hits[0]
        }
        $f = Join-Path $Snapshot.Bundle ('probes\sql-configurations.{0}.json' -f $tok)
        $txt = Read-SqlStackGuiText -Path $f
        if ($null -eq $txt) { [void]$rows.Add((& $mkRow $n $null $false ('not read: {0}' -f $(if ($status.ContainsKey($tok)) { $status[$tok] } else { 'snapshot A has no sql-configurations record for it' })))); continue }
        $doc = $null
        try { $doc = ConvertFrom-Json $txt } catch { $doc = $null }
        $r = @(@($(if ($doc) { $doc.rows } else { @() })) | Where-Object { [string]$_.name -eq 'max server memory (MB)' }) | Select-Object -First 1
        if ($null -eq $r) { [void]$rows.Add((& $mkRow $n $null $false 'not read: snapshot A''s configuration rows have no max server memory (MB)')); continue }
        $v = [string]$r.value_in_use
        if ($v -notmatch '^\d+$' -or ([int64]$v -le 0)) { [void]$rows.Add((& $mkRow $n $null $false ("not read: snapshot A's value '{0}' is not a ceiling" -f $v))); continue }
        if ([int64]$v -ge 2147483647) { [void]$rows.Add((& $mkRow $n 2147483647 $true ('unlimited (SQL default), ' + $src))); continue }
        [void]$rows.Add((& $mkRow $n ([int]$v) $false ('{0} MB, {1}' -f $v, $src)))
    }
    return [pscustomobject]@{ Ok = $true; Reason = $(if ($map.Ok) { '' } else { $map.Reason }); Source = $src; Rows = $rows.ToArray() }
}

function Set-SqlStackGuiInstalledCeiling {
    <#
      Finding 5 (K7): an INSTALLED row's max server memory for the memory split,
      from snapshot A when it was read there, else the ceiling the operator TYPED
      for planning (.TypedCeilingMb, used only for the split and never written
      to the instance), else unread ($null: the split is not computed, said in
      words). The row's fact line says which. Installed rows only.
    #>
    param([object[]]$Plan = @(), $Ceilings = $null)
    foreach ($p in @($Plan | Where-Object { ($null -ne $_) -and $_.Fixed })) {
        if (-not $p.PSObject.Properties['TypedCeilingMb']) { $p | Add-Member -NotePropertyName TypedCeilingMb -NotePropertyValue 0 }
        if (-not $p.PSObject.Properties['CeilingSource']) { $p | Add-Member -NotePropertyName CeilingSource -NotePropertyValue '' }
        $c = $(if ($Ceilings) { @($Ceilings.Rows | Where-Object { [string]$_.Name -ieq [string]$p.Name }) | Select-Object -First 1 } else { $null })
        if ($c -and ($null -ne $c.Mb)) { $p.MaxMemoryMb = [int]$c.Mb; $p.CeilingSource = 'snapshot' ; $line = ('Max server memory: {0}.' -f $c.Words) }
        elseif ([int]$p.TypedCeilingMb -gt 0) { $p.MaxMemoryMb = [int]$p.TypedCeilingMb; $p.CeilingSource = 'typed'; $line = ('Max server memory: {0} MB, TYPED for planning only ({1}). It is never written to the instance.' -f $p.TypedCeilingMb, $(if ($c) { $c.Words } else { 'no snapshot A' })) }
        else { $p.MaxMemoryMb = $null; $p.CeilingSource = ''; $line = ('Max server memory: NOT READ ({0}). This window opens no SQL connection: collect snapshot A, or type a planning ceiling below.' -f $(if ($c) { $c.Words } else { 'no snapshot A' })) }
        $p.Facts = [string[]]@(@($p.Facts) | ForEach-Object { if ([string]$_ -like 'Max server memory:*') { $line } else { [string]$_ } })
    }
}

# ===========================================================================
# ===========================================================================
#  THE WORKBENCH SPINE (lane sqlstack-workbench, 2026-11-03)
#
#  The window is one workbench for the whole journey: plan, snapshot A, dry
#  run, apply, verify, uninstall dry run, uninstall, snapshot B and compare,
#  tidy-up. It RUNS none of them. It reads the files each one leaves and builds
#  the exact command the operator runs next, in their own console.
#  (2026-11-16: ONE thing it now runs, from the Install screen: the install
#  worker, in its own process. THE INSTALL SPINE, further down, says how:
#  INV-5, INV-6, INV-7. The stages above are still only read.)
#
#  INV-1  THIS FILE ITSELF CHANGES NOTHING ON THE HOST. No setup, no Apply, no
#         Collect, no SQL, no registry, service or NIC write: the install
#         worker holds those, and this file only starts it (INV-5). Until
#         2026-11-16 this line also read "no elevation"; Install now needs it
#         (INV-6). It
#         writes files ONLY under the run folder the operator chose, every path
#         from Get-SqlStackGuiRunPath, through the writers
#         Initialize-SqlStackGuiRunFolder, Write-SqlStackGuiRunFile and
#         Write-SqlStackGuiFileSet. ONE named exception: the trace log
#         (Open-SqlStackGuiLog, Write-SqlStackGuiLog), which starts under %TEMP%
#         before a run folder exists and moves to <run>\window.log once one is
#         open. Guarded by rows W1-W3 of Test-SqlStackGuiStructure and by
#         'writer census (INV-1):' in -SelfTest (the ENGINE's
#         Get-SqlStackWriterCensus over this file, 0 offenders).
#  INV-2  ONE COMMAND BUILDER. Every command the drawer shows or copies comes
#         from Get-SqlStackGuiCommand reading Get-SqlStackGuiStageTable. A plan
#         hash is READ by the stage reader from the state folder, never typed.
#         Guarded by rows W4-W6.
#  INV-3  ONE STAGE READER. Every stage's status comes from
#         Get-SqlStackGuiRunState, from files; nothing lives only in memory.
#         Guarded by row W7.
#  The shapes every reader below accepts are the shapes the real producers
#  wrote (brief critic K1-K17); -SelfTest drives them over copies of a real
#  unelevated dry run and a real snapshot in tests\fixtures\window\.
# ===========================================================================
# ===========================================================================

function Get-SqlStackGuiRunItem {
    <#
      The run folder's layout, and the ONLY names Get-SqlStackGuiRunPath resolves.
      The STATE folder is deliberately NOT here (critic K3, ruled 2026-11-03): it
      is ONE host-wide folder, the engine's $script:SqlStackDefaultStatePath,
      because the apply lock and created-instances.json must span runs. This run's
      plans are found in it by their console transcripts (Get-SqlStackGuiPlanSet).
      'TidyUp' records the operator's tick at stage 9, so that stage's state is
      read from a file like every other (INV-3).
    #>
    return [ordered]@{
        Spec       = 'spec.json'
        SpecAbsent = 'spec-absent.json'
        SnapshotA  = 'snapshot-A'
        SnapshotB  = 'snapshot-B'
        Export     = 'export'
        WindowLog  = 'window.log'
        TidyUp     = 'tidy-up.json'
        # The Install screen's choices (the network card for a new address, the
        # prefix length) and the host they were saved on.
        Install    = 'install.json'
    }
}

function Get-SqlStackGuiDefaultRunFolder {
    # C:\temp\SqlStack\runs\<HOST>-<yyyyMMdd-HHmm>. The clock is read by the caller's -Now.
    param([string]$HostName = $env:COMPUTERNAME, [datetime]$Now = (Get-Date))
    return ('C:\temp\SqlStack\runs\{0}-{1}' -f $HostName, $Now.ToString('yyyyMMdd-HHmm'))
}

function Get-SqlStackGuiRunPath {
    <#
      THE ONE RUN-FOLDER RESOLVER (INV-1). Every file this window writes, and
      every run-folder path a command names, comes from here: -Item is one of
      Get-SqlStackGuiRunItem's names, and the result is checked to sit DIRECTLY
      inside the run folder. A drive root is refused as a run folder (spec.json
      would land at C:\spec.json). Throws on a refusal: a caller that cannot name
      its file must not write one.
      Census: 'W1-writes-through-run-folder' and 'W2-writers-resolve-here'.
    #>
    param([Parameter(Mandatory)][AllowEmptyString()][string]$Root, [Parameter(Mandatory)][string]$Item)
    $items = Get-SqlStackGuiRunItem
    if (-not $items.Contains($Item)) { throw ("'{0}' is not an item of a run folder (the items are {1})" -f $Item, (@($items.Keys) -join ', ')) }
    if ([string]::IsNullOrWhiteSpace($Root)) { throw 'no run folder is open' }
    $full = [IO.Path]::GetFullPath($Root).TrimEnd('\')
    if ($full -match '^[A-Za-z]:$') { throw ("refusing a drive root as a run folder: {0}" -f $Root) }
    $p = [IO.Path]::GetFullPath([IO.Path]::Combine($full, [string]$items[$Item]))
    if (([IO.Path]::GetDirectoryName($p)).TrimEnd('\') -ne $full) { throw ("refusing '{0}': it resolves outside the run folder {1}" -f $Item, $full) }
    return $p
}

function Initialize-SqlStackGuiRunFolder {
    # INV-1 writer: creates the run folder, or with -Item Export its export folder.
    # The snapshot folders are created by the collector, never here. Returns the path.
    param([Parameter(Mandatory)][string]$Root, [ValidateSet('', 'Export')][string]$Item = '')
    $rootPath = Split-Path -Parent (Get-SqlStackGuiRunPath -Root $Root -Item 'Spec')
    $target = $(if ($Item) { Get-SqlStackGuiRunPath -Root $Root -Item $Item } else { $rootPath })
    if (-not [IO.Directory]::Exists($rootPath)) { [void](New-Item -ItemType Directory -Path $rootPath -Force) }
    if (-not [IO.Directory]::Exists($target)) { [void](New-Item -ItemType Directory -Path $target -Force) }
    return $target
}

function Write-SqlStackGuiRunFile {
    # INV-1 writer: one run-folder FILE, UTF-8 with no BOM, the path from the resolver.
    param(
        [Parameter(Mandatory)][string]$Root,
        [Parameter(Mandatory)][ValidateSet('Spec', 'SpecAbsent', 'TidyUp', 'Install')][string]$Item,
        [Parameter(Mandatory)][AllowEmptyString()][string]$Text
    )
    $p = Get-SqlStackGuiRunPath -Root $Root -Item $Item
    [void](Initialize-SqlStackGuiRunFolder -Root $Root)
    [IO.File]::WriteAllText($p, $Text, (New-Object System.Text.UTF8Encoding($false)))
    return $p
}

function Read-SqlStackGuiText {
    <#
      A text file another process may still be writing (a dry run's transcript is
      open until its EXIT line). Opened READ-ONLY with FileShare ReadWrite|Delete;
      a BOM is honoured (transcripts carry one, PROVED by the critic's dry run).
      Returns the text, or $null when the file is absent or cannot be read.
    #>
    param([string]$Path)
    if ([string]::IsNullOrWhiteSpace($Path) -or (-not [IO.File]::Exists($Path))) { return $null }
    try {
        $fs = New-Object System.IO.FileStream($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, ([System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete))
        try {
            $sr = New-Object System.IO.StreamReader($fs, (New-Object System.Text.UTF8Encoding($false)), $true)
            return $sr.ReadToEnd()
        } finally { $fs.Dispose() }
    } catch { return $null }
}

function Get-SqlStackGuiFileSha256 {
    # Lower-case hex SHA-256 of a file's BYTES (a plan's name is that hash, K1), or '' if unreadable.
    param([string]$Path)
    try {
        $sha = [System.Security.Cryptography.SHA256]::Create()
        try { return (([BitConverter]::ToString($sha.ComputeHash([IO.File]::ReadAllBytes($Path)))) -replace '-', '').ToLowerInvariant() }
        finally { $sha.Dispose() }
    } catch { return '' }
}

function ConvertFrom-SqlStackGuiTranscript {
    <#
      One console transcript SqlStack-Apply.ps1 wrote (Start-SqlStackApplyConsole:
      <state>\console\<plan|apply|verify>-<yyyyMMddTHHmmssfffZ>.log). The lines read,
      each PROVED present in the critic's real transcripts:
        'Host Application: ... -Spec <path> ...'   the command line (also a rejected run's)
        'SPEC     : <path>'                        a dry run that loaded its spec
        'STATUS   : <status>'                      the plan's status
        'PLAN HASH: <64 hex>'                      a dry run that WROTE a plan
        'SqlStack-Apply x - APPLY|VERIFY of plan <hash>.'   which plan an apply/verify ran
        'OUTCOME: <word>', 'EXIT: <n>'             the result; no EXIT line = still running
        '  - <text>' under 'REFUSED (' / 'PROBLEMS (' / 'UNPROVED OR CHANGED ('
      The stamp comes from the FILE NAME (UTC, the moment the run started).
      Returns ONE object; .Problem is set when the name or the text is unusable.
    #>
    param([Parameter(Mandatory)][string]$Path, [AllowNull()][string]$Text)
    $name = [IO.Path]::GetFileName($Path)
    $o = [pscustomobject]@{ Path = $Path; Name = $name; Entry = ''; Utc = $null; Spec = ''; Hash = ''; Status = ''
        Exit = $null; Outcome = ''; Finished = $false; Lines = [string[]]@(); Problem = '' }
    $m = [regex]::Match($name, '^(plan|apply|verify)-(\d{8}T\d{9}Z)\.log$')
    if (-not $m.Success) { $o.Problem = ('{0}: not a <plan|apply|verify>-<utc>.log name' -f $name); return $o }
    $o.Entry = $m.Groups[1].Value
    $o.Utc = [datetime]::ParseExact($m.Groups[2].Value, 'yyyyMMddTHHmmssfffZ', [Globalization.CultureInfo]::InvariantCulture,
                ([Globalization.DateTimeStyles]::AssumeUniversal -bor [Globalization.DateTimeStyles]::AdjustToUniversal))
    if ($null -eq $Text) { $o.Problem = ('{0}: could not be read' -f $name); return $o }
    $lines = New-Object System.Collections.ArrayList
    $collect = $false
    $cmdSpec = ''
    foreach ($line in ($Text -split "`r?`n")) {
        if ($line -match '^Host Application:.*\s-Spec\s+(''[^'']+''|"[^"]+"|\S+)') { $cmdSpec = $Matches[1].Trim('''', '"') }
        elseif (($line -match '^SPEC\s+:\s*(.+?)\s*$') -and (-not $o.Spec)) { $o.Spec = $Matches[1] }
        elseif ($line -match '^STATUS\s+:\s*(\S+)') { $o.Status = $Matches[1] }
        elseif ($line -match '^PLAN HASH:\s*([0-9a-f]{64})\s*$') { $o.Hash = $Matches[1] }
        elseif ($line -match '^SqlStack-Apply \S+ - (APPLY|VERIFY) of plan ([0-9a-fA-F]*)\.') { $o.Hash = $Matches[2].ToLowerInvariant() }
        elseif ($line -match '^OUTCOME:\s*(\S+)') { $o.Outcome = $Matches[1]; $collect = $false }
        elseif ($line -match '^EXIT:\s*(-?\d+)\s*$') { $o.Exit = [int]$Matches[1]; $o.Finished = $true; $collect = $false }
        elseif ($line -match '^(REFUSED \(|PROBLEMS \(|UNPROVED OR CHANGED \()') { $collect = $true; [void]$lines.Add($line.Trim()) }
        elseif ($collect -and ($line -match '^\s+- (.+)$')) { [void]$lines.Add($Matches[1].Trim()) }
    }
    # A rejected dry run prints no SPEC line (critic, a9: exit 4); its command line names the spec.
    if ((-not $o.Spec) -and $cmdSpec) { $o.Spec = $cmdSpec }
    $o.Lines = [string[]](@($lines))
    return $o
}

function Get-SqlStackGuiTranscripts {
    # Every <Entry>-*.log under <state>\console, parsed, NEWEST FIRST. A missing folder is none.
    param([string]$StatePath, [ValidateSet('plan', 'apply', 'verify')][string]$Entry)
    $dir = $(if ($StatePath) { Join-Path $StatePath 'console' } else { '' })
    if ((-not $dir) -or (-not [IO.Directory]::Exists($dir))) { return [object[]]@() }
    $rows = @(foreach ($f in [IO.Directory]::GetFiles($dir, ($Entry + '-*.log'))) { ConvertFrom-SqlStackGuiTranscript -Path $f -Text (Read-SqlStackGuiText -Path $f) })
    return [object[]](@($rows | Where-Object { $null -ne $_.Utc } | Sort-Object -Property Utc -Descending))
}

function Test-SqlStackGuiSamePath {
    # Two paths name the same file: full-path, case-insensitive. A relative or empty one never matches.
    param([string]$A, [string]$B)
    if ([string]::IsNullOrWhiteSpace($A) -or [string]::IsNullOrWhiteSpace($B)) { return $false }
    if ((-not [IO.Path]::IsPathRooted($A)) -or (-not [IO.Path]::IsPathRooted($B))) { return $false }
    try { return ([IO.Path]::GetFullPath($A).TrimEnd('\') -ieq [IO.Path]::GetFullPath($B).TrimEnd('\')) } catch { return $false }
}

function Get-SqlStackGuiPlanSet {
    <#
      SHAPE TABLE ROW S1, ruled with the critic's K1 and K2 (2026-11-03). A plan
      names no spec, and every dry run makes a NEW hash (observed.utc is inside the
      hashed bytes: PROVED, the same spec twice gave 745386ef... and 345d5659...).
      So a plan belongs to THIS spec only through its transcript
      <state>\console\plan-<utc>.log, whose 'SPEC :' line names this spec's full
      path and whose 'PLAN HASH:' line names the plan, AND whose stamp is later
      than the spec's LastWriteTimeUtc. Among those the NEWEST run decides:
        - still running (no EXIT line)       -> Running
        - wrote no plan (exit 4; exit 2 from rail 14)  -> Failed, its REFUSED lines
        - wrote plan-<hash>.json:
            file absent                       -> Failed
            bytes do not hash to the name     -> Failed (a refusal, never offered)
            status PlanOk                     -> Done: the CURRENT plan
            status Refused (K2: a refused run DOES write a plan) -> Failed: its
              refusals, problems and Blocked actions
      Older plans of this spec are SUPERSEDED (listed, never offered, never called
      conflicting). Runs only from before the last save -> Stale. Plans no
      transcript names at all -> Orphans (listed, never offered). Other specs'
      plans in the shared state folder are not this run's and are ignored (K3).
      Returns ONE object: .SpecPath .SpecExists .SpecWriteUtc .Status .Words
      .Detail .Current (.Hash .Status .Path .MdPath .Utc) .Superseded .Orphans .Runs
    #>
    param([Parameter(Mandatory)][string]$StatePath, [Parameter(Mandatory)][string]$SpecPath)
    $o = [pscustomobject]@{ SpecPath = $SpecPath; SpecExists = $false; SpecWriteUtc = $null; Status = 'NotStarted'; Words = ''
        Detail = [string[]]@(); Current = $null; Superseded = [object[]]@(); Orphans = [string[]]@(); Runs = [object[]]@() }
    $detail = New-Object System.Collections.ArrayList
    $specName = [IO.Path]::GetFileName($SpecPath)
    if (-not [IO.File]::Exists($SpecPath)) {
        $o.Words = ('{0} is not saved yet, so there is nothing to dry-run.' -f $specName)
        return $o
    }
    $o.SpecExists = $true
    $o.SpecWriteUtc = ([IO.FileInfo]$SpecPath).LastWriteTimeUtc
    $all = @(Get-SqlStackGuiTranscripts -StatePath $StatePath -Entry 'plan')
    $mine = @($all | Where-Object { Test-SqlStackGuiSamePath $_.Spec $SpecPath })
    $o.Runs = [object[]]$mine
    $after = @($mine | Where-Object { $_.Utc -gt $o.SpecWriteUtc })
    $named = @{}; foreach ($t in $all) { if ($t.Hash) { $named[$t.Hash] = $true } }
    $orph = New-Object System.Collections.ArrayList
    if ($StatePath -and [IO.Directory]::Exists($StatePath)) {
        foreach ($f in [IO.Directory]::GetFiles($StatePath, 'plan-*.json')) {
            $h = ([IO.Path]::GetFileNameWithoutExtension($f)) -replace '^plan-', ''
            if (-not $named.ContainsKey($h)) { [void]$orph.Add(([IO.Path]::GetFileName($f))) }
        }
    }
    $o.Orphans = [string[]]@($orph)
    $stamp = { param($t) $t.Utc.ToString('yyyy-MM-dd HH:mm:ss') + ' UTC' }
    if ($after.Count -eq 0) {
        if ($mine.Count -gt 0) {
            $o.Status = 'Stale'
            $o.Words = ('{0} was saved after its last dry run ({1}), so no plan belongs to it as it is now. Run the dry run again.' -f $specName, (& $stamp $mine[0]))
        } else {
            $o.Words = ('No dry run of {0} is recorded in {1}.' -f $specName, (Join-Path $StatePath 'console'))
        }
    } else {
        $newest = $after[0]
        if (-not $newest.Finished) {
            $o.Status = 'Running'
            $o.Words = ('A dry run started at {0} has not finished: its transcript has no EXIT line yet. Refresh when it ends.' -f (& $stamp $newest))
        } elseif (-not $newest.Hash) {
            $o.Status = 'Failed'
            $o.Words = ('The newest dry run ({0}) wrote no plan: EXIT {1}. Fix what it says, then run it again.' -f (& $stamp $newest), $newest.Exit)
            foreach ($l in @($newest.Lines)) { [void]$detail.Add($l) }
        } else {
            $planPath = Join-Path $StatePath ('plan-{0}.json' -f $newest.Hash)
            $cur = [pscustomobject]@{ Hash = $newest.Hash; Status = ''; Path = $planPath; MdPath = (Join-Path $StatePath ('plan-{0}.md' -f $newest.Hash)); Utc = $newest.Utc; HashOk = $false }
            $o.Current = $cur
            if (-not [IO.File]::Exists($planPath)) {
                $o.Status = 'Failed'
                $o.Words = ('The newest dry run names plan {0}, but {1} is not in the state folder.' -f $newest.Hash, [IO.Path]::GetFileName($planPath))
            } else {
                $bytesHash = Get-SqlStackGuiFileSha256 -Path $planPath
                $cur.HashOk = ($bytesHash -ceq $newest.Hash)
                $doc = $null
                try { $doc = ConvertFrom-Json (Read-SqlStackGuiText -Path $planPath) } catch { $doc = $null }
                $cur.Status = $(if ($doc) { [string]$doc.status } else { '' })
                if (-not $cur.HashOk) {
                    $o.Status = 'Failed'
                    $o.Words = ('REFUSED: {0} does not hash to its own name (its bytes hash to {1}). SqlStack-Apply would refuse it too (exit 10). Run the dry run again.' -f [IO.Path]::GetFileName($planPath), $(if ($bytesHash) { $bytesHash } else { '(unreadable)' }))
                } elseif ($null -eq $doc) {
                    $o.Status = 'Failed'
                    $o.Words = ('{0} is not readable JSON.' -f [IO.Path]::GetFileName($planPath))
                } elseif ($cur.Status -ceq 'PlanOk') {
                    $o.Status = 'Done'
                    $o.Words = ('Current plan {0} (status PlanOk, dry run {1}). Read plan-{2}.md before the apply.' -f $newest.Hash, (& $stamp $newest), $newest.Hash.Substring(0, 12))
                } else {
                    $o.Status = 'Failed'
                    $o.Words = ('The current plan {0} is {1}: SqlStack-Apply will not run it. Fix what it says, then dry-run again.' -f $newest.Hash, $(if ($cur.Status) { $cur.Status } else { 'without a status' }))
                    foreach ($x in @($doc.refusals)) { if ($x) { [void]$detail.Add(('refusal: ' + [string]$x)) } }
                    foreach ($x in @($doc.problems)) { if ($x) { [void]$detail.Add(('problem: ' + [string]$x)) } }
                    foreach ($a in @($doc.actions)) { if ([string]$a.status -eq 'Blocked') { [void]$detail.Add(('blocked: {0} {1} - {2}' -f $a.action, $a.instance, $a.reason)) } }
                }
            }
        }
    }
    $sup = @($mine | Where-Object { $_.Hash -and ((-not $o.Current) -or ($_.Hash -ne $o.Current.Hash)) })
    $o.Superseded = [object[]]$sup
    foreach ($s in $sup) { [void]$detail.Add(('superseded: plan {0} (dry run {1}, status {2})' -f $s.Hash, (& $stamp $s), $(if ($s.Status) { $s.Status } else { '?' }))) }
    foreach ($orf in @($o.Orphans)) { [void]$detail.Add(('not this run''s: {0} - no transcript names it, so it is never offered' -f $orf)) }
    $o.Detail = [string[]]@($detail)
    return $o
}

function Get-SqlStackGuiApplyState {
    <#
      SHAPE TABLE ROW S2, as the critic's K8 corrected it. The plan-level outcome is
      printed only in the apply transcript (<state>\console\apply-<utc>.log,
      'APPLY of plan <hash>', 'OUTCOME:', 'EXIT:'); the journal
      (journal-<hash12>.jsonl, read by the ENGINE's Read-SqlStackJournalLog) says
      what ran. Exits 4, 5, 7, 9 and 10 write no journal line. The newest transcript
      decides; an unresolved intent outranks everything ('read RUNBOOK 4b').
      Returns ONE object: .Status .Words .Detail .Journal .Runs
    #>
    param([Parameter(Mandatory)][string]$StatePath, [Parameter(Mandatory)][string]$Hash, [switch]$Uninstall)
    $o = [pscustomobject]@{ Status = 'NotStarted'; Words = ''; Detail = [string[]]@(); Journal = $null; Runs = [object[]]@() }
    $detail = New-Object System.Collections.ArrayList
    $what = $(if ($Uninstall) { 'uninstall' } else { 'apply' })
    $jPath = Join-Path $StatePath ('journal-{0}.jsonl' -f $Hash.Substring(0, [Math]::Min(12, $Hash.Length)))
    $j = $null
    if ([IO.File]::Exists($jPath)) {
        $j = Read-SqlStackJournalLog -Path $jPath
        foreach ($p in @($j.Problems)) { [void]$detail.Add(('journal problem: ' + $p)) }
        [void]$detail.Add(('journal {0}: {1}' -f [IO.Path]::GetFileName($jPath), (@($j.States) -join ', ')))
    }
    $o.Journal = $j
    $runs = @(Get-SqlStackGuiTranscripts -StatePath $StatePath -Entry 'apply' | Where-Object { $_.Hash -ceq $Hash })
    $o.Runs = [object[]]$runs
    $newest = $(if ($runs.Count -gt 0) { $runs[0] } else { $null })
    if ($newest) { foreach ($l in @($newest.Lines)) { [void]$detail.Add($l) } }
    $states = $(if ($j) { @($j.States) } else { @() })
    $at = $(if ($newest) { ' (' + $newest.Utc.ToString('yyyy-MM-dd HH:mm:ss') + ' UTC)' } else { '' })
    if ($newest -and (-not $newest.Finished)) {
        $o.Status = 'Running'; $o.Words = ('The {0} that started{1} has not finished: its transcript has no EXIT line yet.' -f $what, $at)
    } elseif ($j -and (@($j.Unresolved).Count -gt 0)) {
        $o.Status = 'Attention'; $o.Words = ('STOP: the journal holds an intent with no outcome for {0}. Read RUNBOOK 4b before anything else.' -f (@($j.Unresolved) -join ', '))
    } elseif ($newest -and ($newest.Exit -eq 0)) {
        $o.Status = 'Done'; $o.Words = ('{0}{1}: OUTCOME {2}, exit 0.' -f $(if ($Uninstall) { 'Uninstalled' } else { 'Applied' }), $at, $newest.Outcome)
    } elseif (($newest -and ($newest.Exit -eq 6)) -or ((-not $newest) -and ($states -contains 'done-reboot-pending'))) {
        $o.Status = 'Attention'; $o.Words = ('Applied, and setup asked for a restart (exit 6){0}. Restart, check the pending-reboot snippet, then run the SAME command: it resumes.' -f $at)
    } elseif ($newest -and ($newest.Exit -eq 8)) {
        $o.Status = 'Failed'; $o.Words = ('STOP: an action failed{0}{1} (exit 8). Read the journal and the transcript before anything else.' -f $at, $(if ($Uninstall) { ', or the uninstall left the instance behind' } else { '' }))
    } elseif ($newest -and (@(4, 5, 7, 9, 10) -contains $newest.Exit)) {
        $o.Status = 'Failed'; $o.Words = ('Refused before anything ran{0}: OUTCOME {1}, exit {2}. Nothing was changed.' -f $at, $newest.Outcome, $newest.Exit)
    } elseif ($newest) {
        $o.Status = 'Failed'; $o.Words = ('Exit {0}{1} (OUTCOME {2}): stop and read the transcript.' -f $newest.Exit, $at, $newest.Outcome)
    } elseif ($j) {
        $o.Status = 'Attention'; $o.Words = ('A journal exists for this plan but no {0} transcript names it. Read the journal.' -f $what)
    } else {
        $o.Words = ('Not run yet: no {0} transcript and no journal for plan {1}.' -f $what, $Hash.Substring(0, [Math]::Min(12, $Hash.Length)))
    }
    if ($Uninstall -and ($states -contains 'uninstall-incomplete')) { $o.Status = 'Failed'; [void]$detail.Add('the journal records uninstall-incomplete: the instance was left behind') }
    $o.Detail = [string[]]@($detail)
    return $o
}

function Get-SqlStackGuiVerifyState {
    <#
      SHAPE TABLE ROW S5, as the critic's K9 corrected it. verify-<hash>.md is
      written for EVERY outcome that got far enough to have a plan path, and a
      re-run overwrites it; the outcome is in console\verify-<utc>.log. Drift is
      NOT called failure (RUNBOOK 5: expected on the first verify).
      Returns ONE object: .Status .Words .Detail .ReportPath .Runs
    #>
    param([Parameter(Mandatory)][string]$StatePath, [Parameter(Mandatory)][string]$Hash)
    $report = Join-Path $StatePath ('verify-{0}.md' -f $Hash)
    $o = [pscustomobject]@{ Status = 'NotStarted'; Words = ''; Detail = [string[]]@(); ReportPath = $(if ([IO.File]::Exists($report)) { $report } else { '' }); Runs = [object[]]@() }
    $detail = New-Object System.Collections.ArrayList
    $runs = @(Get-SqlStackGuiTranscripts -StatePath $StatePath -Entry 'verify' | Where-Object { $_.Hash -ceq $Hash })
    $o.Runs = [object[]]$runs
    $newest = $(if ($runs.Count -gt 0) { $runs[0] } else { $null })
    if ($newest) { foreach ($l in @($newest.Lines)) { [void]$detail.Add($l) } }
    if ($newest -and $o.ReportPath -and (([IO.FileInfo]$report).LastWriteTimeUtc -lt $newest.Utc)) {
        [void]$detail.Add(('verify-{0}.md was written before the newest verify run started: it is from an earlier run.' -f $Hash.Substring(0, 12)))
    }
    if ($newest -and (-not $newest.Finished)) { $o.Status = 'Running'; $o.Words = 'A verify has not finished: its transcript has no EXIT line yet.' }
    elseif ($newest) {
        # S8 rows 28h and 28i: Apply's Verify names an unfinished plan (Get-SqlStackUnfinishedPlan) as
        # 'plan <hash> is unfinished on this host: resume it (...)' or, when its journal does not read cleanly,
        # 'plan <hash> is unfinished on this host: its journal <path> does not read cleanly (...)'. Either way
        # "drift alone is not a failure" (11) and "nothing disagreed" (13) would be the wrong words.
        # Pinned by S5 (28h), S5 (28h-13) and S5 (28i) in this file's self-test.
        $ufNamed = (@($detail | Where-Object { [string]$_ -match 'is unfinished on this host: (resume it|its journal )' }).Count -gt 0)
        switch ($newest.Exit) {
            0  { $o.Status = 'Done';      $o.Words = 'Verified (exit 0).' }
            11 {
                $o.Status = 'Attention'
                if ($ufNamed) {
                    $o.Words = 'VerifyDrift (exit 11): a plan is UNFINISHED on this host, so the running instance may not have read what its writes wrote. Read the lines below: they name the plan and what to do next.'
                } else { $o.Words = 'VerifyDrift (exit 11). Expected on the FIRST verify (RUNBOOK 5): read the drift lines in the report. Drift alone is not a failure.' }
            }
            12 { $o.Status = 'Failed';    $o.Words = 'VerifyDisagrees (exit 12): the independent oracle disagrees. Read the report before anything else.' }
            13 {
                $o.Status = 'Attention'
                if ($ufNamed) {
                    $o.Words = 'VerifyUnproved (exit 13): a plan is UNFINISHED on this host, so the running instance may not have read what its writes wrote, and something could not be answered. That is never the same as verified. Read the lines below: they name the plan and what to do next.'
                } else { $o.Words = 'VerifyUnproved (exit 13): nothing disagreed, but something could not be answered. That is never the same as verified.' }
            }
            default { $o.Status = 'Failed'; $o.Words = ('Exit {0} (OUTCOME {1}): the verify did not complete. If a report exists it may be from this run, overwriting an earlier one.' -f $newest.Exit, $newest.Outcome) }
        }
    } elseif ($o.ReportPath) { $o.Status = 'Attention'; $o.Words = ('verify-{0}.md exists but no verify transcript names this plan.' -f $Hash.Substring(0, 12)) }
    else { $o.Words = 'Not run yet: no verify transcript and no report for this plan.' }
    $o.Detail = [string[]]@($detail)
    return $o
}

function Read-SqlStackGuiSnapshot {
    <#
      A snapshot folder (<run>\snapshot-A or -B, the collector's -OutDir with
      -NoZip). The collector writes ONE bundle folder per run,
      SqlStack-Diag-<HOSTTOKEN>-<utc>\, and its manifest.json LAST (its presence is
      the clean-finish signal). Several bundles (a re-run): the NEWEST by
      manifest.collectedUtc, and the words say so. A bundle with no manifest did
      not finish. Returns ONE object: .Status .Words .Detail .Bundle .BundleName
      .CollectedUtc .Intact .HostToken .Count
    #>
    param([Parameter(Mandatory)][string]$Folder)
    $o = [pscustomobject]@{ Status = 'NotStarted'; Words = ''; Detail = [string[]]@(); Bundle = ''; BundleName = ''; CollectedUtc = ''; Intact = $false; HostToken = ''; Count = 0 }
    $detail = New-Object System.Collections.ArrayList
    if (-not [IO.Directory]::Exists($Folder)) { $o.Words = ('No snapshot yet: {0} does not exist.' -f $Folder); return $o }
    $found = New-Object System.Collections.ArrayList
    foreach ($d in [IO.Directory]::GetDirectories($Folder, 'SqlStack-Diag-*')) {
        $mp = Join-Path $d 'manifest.json'
        if (-not [IO.File]::Exists($mp)) { [void]$detail.Add(('{0}: no manifest.json, so that collection did not finish' -f [IO.Path]::GetFileName($d))); continue }
        $man = $null
        try { $man = ConvertFrom-Json (Read-SqlStackGuiText -Path $mp) } catch { $man = $null }
        if ($null -eq $man) { [void]$detail.Add(('{0}: manifest.json is not readable JSON' -f [IO.Path]::GetFileName($d))); continue }
        [void]$found.Add([pscustomobject]@{ Path = $d; Name = [IO.Path]::GetFileName($d); Utc = [string]$man.collectedUtc; Intact = ($man.intact -eq $true)
            HostToken = [string]$man.hostToken; Emitted = $man.emittedCount; Expected = $man.registryCount })
    }
    $o.Count = $found.Count
    if ($found.Count -eq 0) {
        $o.Words = ('No finished snapshot in {0}.' -f $Folder)
        if ($detail.Count -gt 0) { $o.Status = 'Failed' }
        $o.Detail = [string[]]@($detail); return $o
    }
    # collectedUtc is ISO 8601 UTC, so text order is time order.
    $b = @($found | Sort-Object -Property Utc -Descending)[0]
    $o.Bundle = $b.Path; $o.BundleName = $b.Name; $o.CollectedUtc = $b.Utc; $o.Intact = $b.Intact; $o.HostToken = $b.HostToken
    if ($found.Count -gt 1) { [void]$detail.Add(('{0} bundles here; the newest by collectedUtc is used: {1}' -f $found.Count, $b.Name)) }
    [void]$detail.Add(('{0}: collected {1}, probes expected {2}, emitted {3}, intact {4}' -f $b.Name, $b.Utc, $b.Expected, $b.Emitted, $b.Intact))
    if ($b.Intact) { $o.Status = 'Done'; $o.Words = ('Snapshot collected {0}, intact.' -f $b.Utc) }
    else { $o.Status = 'Failed'; $o.Words = ('Snapshot collected {0} is NOT intact (manifest.intact is false): collect it again.' -f $b.Utc) }
    $o.Detail = [string[]]@($detail)
    return $o
}

function Read-SqlStackGuiSpecFile {
    <#
      SHAPE TABLE ROW S3, with the critic's K17: the window asks the ENGINE's
      Test-SqlStackSpec with the same three inputs Apply passes it
      (-InstalledInstance, -JournalPath <state>\created-instances.json and the host
      name), so the two verdicts cannot disagree. A relative mediaPath resolves
      against the spec's own folder (the loader's rule). Read-only: this never
      changes the file. Returns ONE object: .Path .Exists .ParseOk .Problem .Doc
      .Ok .Errors (texts) .Throwaway (names of new throwaway instances) .HostName
    #>
    param([Parameter(Mandatory)][string]$Path, [string[]]$InstalledInstance = @(), [string]$JournalPath = '', [string]$HostName = $env:COMPUTERNAME)
    $o = [pscustomobject]@{ Path = $Path; Exists = $false; ParseOk = $false; Problem = ''; Doc = $null; Ok = $false; Errors = [string[]]@(); Throwaway = [string[]]@(); HostName = '' }
    if (-not [IO.File]::Exists($Path)) { $o.Problem = 'not saved yet'; return $o }
    $o.Exists = $true
    $txt = Read-SqlStackGuiText -Path $Path
    try { $o.Doc = ConvertFrom-Json $txt; $o.ParseOk = ($null -ne $o.Doc) } catch { $o.Problem = ('not valid JSON: ' + $_.Exception.Message); return $o }
    if (-not $o.ParseOk) { $o.Problem = 'empty'; return $o }
    $o.HostName = [string]$o.Doc.host.name
    $o.Throwaway = [string[]]@(@($o.Doc.instances) | Where-Object { ($_.throwaway -eq $true) -and ($_.protected -ne $true) } | ForEach-Object { [string]$_.name })
    $args2 = @{ Path = $Path; InstalledInstance = [string[]]@($InstalledInstance) }
    if ($JournalPath) { $args2['JournalPath'] = $JournalPath }
    if ($HostName) { $args2['HostName'] = $HostName }
    try {
        $v = Test-SqlStackSpec @args2
        $o.Ok = [bool]$v.Ok
        $o.Errors = [string[]]@(@($v.Errors) | ForEach-Object { [string]$_.Text })
    } catch { $o.Errors = [string[]]@(('the engine''s Test-SqlStackSpec threw: ' + $_.Exception.Message)) }
    return $o
}

function Get-SqlStackGuiRunState {
    <#
      THE ONE STAGE READER (INV-3). Every stage's status, in words, computed from
      the files in the run folder and the host-wide state folder, and nothing else:
      Refresh calls this again and the rail, the centre and the drawer redraw from
      what it returns. Status words: NotStarted, Running, Done, Attention, Failed,
      Stale, Blocked. Census: 'W7-one-stage-reader'.
      Returns ONE object: .Root .StatePath .Spec .AbsentSpec .Plan .AbsentPlan
      .SnapshotA .SnapshotB .Stages (one per row of Get-SqlStackGuiStageTable:
      .Id .Key .Name .Status .Words .Detail .Preview .Elevated)
    #>
    param(
        [Parameter(Mandatory)][string]$Root,
        [Parameter(Mandatory)][string]$StatePath,
        [string[]]$InstalledInstance = @(),
        [string]$HostName = $env:COMPUTERNAME
    )
    $journal = Join-Path $StatePath 'created-instances.json'
    $specPath = Get-SqlStackGuiRunPath -Root $Root -Item 'Spec'
    $absPath = Get-SqlStackGuiRunPath -Root $Root -Item 'SpecAbsent'
    $spec = Read-SqlStackGuiSpecFile -Path $specPath -InstalledInstance $InstalledInstance -JournalPath $journal -HostName $HostName
    $plan = Get-SqlStackGuiPlanSet -StatePath $StatePath -SpecPath $specPath
    $absPlan = Get-SqlStackGuiPlanSet -StatePath $StatePath -SpecPath $absPath
    $snapA = Read-SqlStackGuiSnapshot -Folder (Get-SqlStackGuiRunPath -Root $Root -Item 'SnapshotA')
    $snapB = Read-SqlStackGuiSnapshot -Folder (Get-SqlStackGuiRunPath -Root $Root -Item 'SnapshotB')
    $mk = { param($Status, $Words, $Detail, $Preview) [pscustomobject]@{ Status = $Status; Words = $Words; Detail = [string[]]@($Detail | Where-Object { $null -ne $_ }); Preview = [string]$Preview } }
    $s = @{}
    # 1 Plan
    if (-not $spec.Exists) { $s[1] = & $mk 'NotStarted' 'No spec saved in this run folder yet. Plan the new instance, then Save spec.' @() '' }
    elseif (-not $spec.ParseOk) { $s[1] = & $mk 'Failed' ('spec.json cannot be read: {0}' -f $spec.Problem) @() $specPath }
    elseif (-not $spec.Ok) { $s[1] = & $mk 'Failed' ('spec.json is saved, but the engine''s loader rejects it ({0} error(s)). SqlStack-Apply would refuse it the same way.' -f @($spec.Errors).Count) @($spec.Errors) $specPath }
    else { $s[1] = & $mk 'Done' 'spec.json is saved and the engine''s loader accepts it.' @() $specPath }
    # 2 Snapshot A
    $s[2] = & $mk $snapA.Status $snapA.Words $snapA.Detail $(if ($snapA.Bundle) { Join-Path $snapA.Bundle 'manifest.json' } else { '' })
    # 3 Dry run
    $s[3] = & $mk $plan.Status $plan.Words $plan.Detail $(if ($plan.Current) { $plan.Current.MdPath } else { '' })
    # 4 Apply, 5 Verify: on the CURRENT PlanOk plan only
    $curOk = ($plan.Status -eq 'Done') -and $plan.Current
    if ($curOk) {
        $ap = Get-SqlStackGuiApplyState -StatePath $StatePath -Hash $plan.Current.Hash
        $s[4] = & $mk $ap.Status $ap.Words $ap.Detail $plan.Current.MdPath
    } else {
        $applyRuns = @(Get-SqlStackGuiTranscripts -StatePath $StatePath -Entry 'apply')
        $prior = @(@($plan.Superseded) | Where-Object { $h = $_.Hash; @($applyRuns | Where-Object { $_.Hash -ceq $h }).Count -gt 0 })
        if ($prior.Count -gt 0) { $s[4] = & $mk 'Stale' ('An earlier plan of this spec ({0}) has an apply on record, but it is not the current plan. Verify that plan with the spec it was made from; this window offers no command for it.' -f $prior[0].Hash.Substring(0, 12)) @() '' }
        else { $s[4] = & $mk 'Blocked' 'Needs a current plan with status PlanOk (stage 3).' @() '' }
    }
    if ($curOk -and ($s[4].Status -eq 'Done')) {
        $vf = Get-SqlStackGuiVerifyState -StatePath $StatePath -Hash $plan.Current.Hash
        $s[5] = & $mk $vf.Status $vf.Words $vf.Detail $vf.ReportPath
    } else { $s[5] = & $mk 'Blocked' 'Needs the apply of the current plan to have finished (stage 4).' @() '' }
    # 6 Uninstall dry run, 7 Uninstall (SPEC 6.3.2 leg 1: only a throwaway can be uninstalled)
    if ($spec.ParseOk -and (@($spec.Throwaway).Count -eq 0)) {
        $why = 'No new instance in this spec is marked throwaway, so SqlStack will never plan its uninstall (SPEC 6.3.2, leg 1).'
        $s[6] = & $mk 'Blocked' $why @() ''
        $s[7] = & $mk 'Blocked' $why @() ''
    } else {
        $s[6] = & $mk $absPlan.Status $(if (-not $absPlan.SpecExists) { 'spec-absent.json is not saved yet: Save spec writes it beside spec.json for a throwaway instance.' } else { $absPlan.Words }) $absPlan.Detail $(if ($absPlan.Current) { $absPlan.Current.MdPath } else { '' })
        if (($absPlan.Status -eq 'Done') -and $absPlan.Current) {
            $un = Get-SqlStackGuiApplyState -StatePath $StatePath -Hash $absPlan.Current.Hash -Uninstall
            $s[7] = & $mk $un.Status $un.Words $un.Detail $absPlan.Current.MdPath
        } else { $s[7] = & $mk 'Blocked' 'Needs a current uninstall plan with status PlanOk (stage 6).' @() '' }
    }
    # 8 Snapshot B
    $s[8] = & $mk $snapB.Status $snapB.Words $snapB.Detail $(if ($snapB.Bundle) { Join-Path $snapB.Bundle 'manifest.json' } else { '' })
    # 9 Tidy-up: listed, never deleted by the window (K14)
    $tidy = New-Object System.Collections.ArrayList
    [void]$tidy.Add(('{0}\observed-* and the observed-<hash>.json beside each plan are UNREDACTED (real names and paths). Never send or zip them, or this run folder.' -f $StatePath))
    foreach ($h in @(@($plan.Runs) + @($absPlan.Runs) | Where-Object { $_.Hash } | ForEach-Object { $_.Hash } | Select-Object -Unique)) { [void]$tidy.Add(('  {0}' -f (Join-Path $StatePath ('observed-{0}.json' -f $h)))) }
    foreach ($sn in @($snapA, $snapB)) { if ($sn.BundleName) { [void]$tidy.Add(('redaction map (real values; delete by this full name, never *.map.json): {0}' -f (Join-Path $env:LOCALAPPDATA ('SqlStack\maps\{0}.map.json' -f $sn.BundleName)))) } }
    foreach ($tn in @($spec.Throwaway)) { [void]$tidy.Add(('{0}: after its uninstall, its TempDb files and its MSSQL<nn>.{0}\MSSQL\Log folder stay behind (README Known gaps); remove them in an elevated shell after checking.' -f $tn)) }
    $tidyPath = Get-SqlStackGuiRunPath -Root $Root -Item 'TidyUp'
    $s[9] = & $mk $(if ([IO.File]::Exists($tidyPath)) { 'Done' } else { 'NotStarted' }) $(if ([IO.File]::Exists($tidyPath)) { 'You ticked tidy-up as done.' } else { 'Remove these yourself, then tick it done. The window deletes nothing.' }) @($tidy) ''
    $stages = New-Object System.Collections.ArrayList
    foreach ($row in @(Get-SqlStackGuiStageTable)) {
        $x = $s[[int]$row.Id]
        [void]$stages.Add([pscustomobject]@{ Id = $row.Id; Key = $row.Key; Name = $row.Name; Status = $x.Status; Words = $x.Words; Detail = $x.Detail; Preview = $x.Preview; Elevated = $row.Elevated })
    }
    return [pscustomobject]@{ Root = [IO.Path]::GetFullPath($Root).TrimEnd('\'); StatePath = $StatePath; Spec = $spec; Plan = $plan; AbsentPlan = $absPlan
        SnapshotA = $snapA; SnapshotB = $snapB; Stages = $stages.ToArray() }
}

function Get-SqlStackGuiStageTable {
    <#
      THE ONE STAGE TABLE (INV-2): the rail's rows, the stage reader's order and
      every command the drawer builds. Arguments are TOKENS, resolved only by
      Get-SqlStackGuiCommand:
        {run:<Item>}   a run-folder path, from Get-SqlStackGuiRunPath
        {state}        the ONE host-wide state folder (critic K3)
        {hash:Spec} / {hash:SpecAbsent}  the CURRENT PlanOk plan of that spec, read
                       by the stage reader from the state folder (K1, K2). Never typed.
      -Spec and -StatePath are on every Apply line (critic K12: without
      -StatePath an apply looks in the default folder and exits 10).
      Needs = the stage that must be Done before this command is offered.
    #>
    return @(
        [pscustomobject]@{ Id = 1; Key = 'Plan';            Name = 'Plan';                Script = '';                     Args = @();                                                                                Elevated = $false; Reboot = $false; Needs = 0 }
        [pscustomobject]@{ Id = 2; Key = 'SnapshotA';       Name = 'Snapshot A';          Script = 'SqlStack-Collect.ps1'; Args = @('-OutDir', '{run:SnapshotA}', '-NoZip');                                         Elevated = $false; Reboot = $false; Needs = 0 }
        [pscustomobject]@{ Id = 3; Key = 'DryRun';          Name = 'Dry run';             Script = 'SqlStack-Apply.ps1';   Args = @('-Spec', '{run:Spec}', '-StatePath', '{state}');                                 Elevated = $true;  Reboot = $false; Needs = 1 }
        [pscustomobject]@{ Id = 4; Key = 'Apply';           Name = 'Apply';               Script = 'SqlStack-Apply.ps1';   Args = @('-Spec', '{run:Spec}', '-StatePath', '{state}', '-Apply', '-PlanHash', '{hash:Spec}');  Elevated = $true;  Reboot = $true;  Needs = 3 }
        [pscustomobject]@{ Id = 5; Key = 'Verify';          Name = 'Verify';              Script = 'SqlStack-Apply.ps1';   Args = @('-Spec', '{run:Spec}', '-StatePath', '{state}', '-Verify', '-PlanHash', '{hash:Spec}'); Elevated = $true;  Reboot = $false; Needs = 4 }
        [pscustomobject]@{ Id = 6; Key = 'UninstallDryRun'; Name = 'Uninstall dry run';   Script = 'SqlStack-Apply.ps1';   Args = @('-Spec', '{run:SpecAbsent}', '-StatePath', '{state}');                           Elevated = $true;  Reboot = $false; Needs = 0 }
        [pscustomobject]@{ Id = 7; Key = 'Uninstall';       Name = 'Uninstall';           Script = 'SqlStack-Apply.ps1';   Args = @('-Spec', '{run:SpecAbsent}', '-StatePath', '{state}', '-Apply', '-PlanHash', '{hash:SpecAbsent}'); Elevated = $true; Reboot = $true; Needs = 6 }
        [pscustomobject]@{ Id = 8; Key = 'SnapshotB';       Name = 'Snapshot B, compare'; Script = 'SqlStack-Collect.ps1'; Args = @('-OutDir', '{run:SnapshotB}', '-NoZip');                                         Elevated = $false; Reboot = $false; Needs = 0 }
        [pscustomobject]@{ Id = 9; Key = 'TidyUp';          Name = 'Tidy-up';             Script = '';                     Args = @();                                                                                Elevated = $false; Reboot = $false; Needs = 0 }
    )
}

function Get-SqlStackGuiRebootSnippet {
    # RUNBOOK-live-tier-A.md step 4, lines 195-200 (the same lines are in step 7):
    # three READ-ONLY registry reads. The window shows it before stages 4 and 7; it runs nothing.
    return ((@(
        '$p = (Get-ItemProperty ''HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager'' -Name PendingFileRenameOperations -ErrorAction SilentlyContinue).PendingFileRenameOperations',
        '''non-gaming PFRO entries: '' + @($p | Where-Object { $_ -and $_ -notlike ''*gamingservices*'' }).Count',
        '''CBS: '' + (Test-Path ''HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'')',
        '''WU: '' + (Test-Path ''HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'')'
    )) -join "`r`n")
}

function ConvertTo-SqlStackGuiArg {
    # One argument for a PowerShell console line: bare when it is plain, else
    # single-quoted with any quote doubled. A double quote or a line break is refused.
    param([string]$Value)
    if ($Value -match '["\r\n]') { throw ("refusing to put '{0}' on a command line: it holds a double quote or a line break" -f $Value) }
    if ($Value -match '^[A-Za-z0-9_\-\.:\\]+$') { return $Value }
    return ("'" + ($Value -replace "'", "''") + "'")
}

function Get-SqlStackGuiCommand {
    <#
      THE ONE COMMAND BUILDER (INV-2). The drawer's command text, the Copy button
      and the compare block all come from here, built from ONE row of
      Get-SqlStackGuiStageTable and the stage reader's result (-State, from
      Get-SqlStackGuiRunState). A hash is taken ONLY from that reader's CURRENT
      plan with status PlanOk and bytes that hash to its name; with none, there is
      no command and .Reason says why. Census: 'W4-one-command-builder',
      'W5-clipboard-through-builder', 'W6-no-command-text-elsewhere (tripwire)'.
      Returns ONE object: .Ok .Text .Reason .Elevated .Snippet .Compare .CompareReason
    #>
    param([Parameter(Mandatory)][int]$Stage, [Parameter(Mandatory)]$State, [string]$ToolDir = '', [string]$MapRoot = '')
    $o = [pscustomobject]@{ Ok = $false; Text = ''; Reason = ''; Elevated = $false; Snippet = ''; Compare = ''; CompareReason = '' }
    $row = @(Get-SqlStackGuiStageTable | Where-Object { $_.Id -eq $Stage }) | Select-Object -First 1
    if ($null -eq $row) { $o.Reason = ('there is no stage {0}' -f $Stage); return $o }
    $o.Elevated = [bool]$row.Elevated
    $st =@($State.Stages | Where-Object { $_.Id -eq $Stage }) | Select-Object -First 1
    if ($Stage -eq 8) {
        $cmp = Get-SqlStackGuiCompareBlock -State $State -ToolDir $ToolDir -MapRoot $MapRoot
        $o.Compare = $cmp.Text; $o.CompareReason = $cmp.Reason
    }
    if (-not $row.Script) { $o.Reason = $(if ($Stage -eq 1) { 'Nothing to run for this stage: Save spec is in the window.' } else { 'Nothing to run for this stage: it is yours to do and tick.' }); return $o }
    if ($st -and ($st.Status -eq 'Blocked')) { $o.Reason = [string]$st.Words; return $o }
    if ($row.Needs -gt 0) {
        $need = @($State.Stages | Where-Object { $_.Id -eq $row.Needs }) | Select-Object -First 1
        if ((-not $need) -or ($need.Status -ne 'Done')) {
            $o.Reason = ('No command yet: stage {0} ({1}) must be done first. It is {2}: {3}' -f $row.Needs, $(if ($need) { $need.Name } else { '?' }), $(if ($need) { $need.Status } else { '?' }), $(if ($need) { $need.Words } else { '' }))
            return $o
        }
    }
    if (($Stage -eq 6) -and (-not $State.AbsentPlan.SpecExists)) { $o.Reason = 'No command yet: spec-absent.json is not saved.'; return $o }
    try {
        $dir = $(if ($ToolDir) { $ToolDir } else { $PSScriptRoot })
        $parts = New-Object System.Collections.ArrayList
        foreach ($a in @($row.Args)) {
            $tok = [string]$a
            if ($tok -match '^\{run:(\w+)\}$') { [void]$parts.Add((ConvertTo-SqlStackGuiArg (Get-SqlStackGuiRunPath -Root $State.Root -Item $Matches[1]))) }
            elseif ($tok -eq '{state}') { [void]$parts.Add((ConvertTo-SqlStackGuiArg ([IO.Path]::GetFullPath($State.StatePath).TrimEnd('\')))) }
            elseif ($tok -match '^\{hash:(Spec|SpecAbsent)\}$') {
                $ps = $(if ($Matches[1] -eq 'Spec') { $State.Plan } else { $State.AbsentPlan })
                if ((-not $ps) -or ($ps.Status -ne 'Done') -or (-not $ps.Current) -or (-not $ps.Current.HashOk) -or ($ps.Current.Status -cne 'PlanOk')) {
                    $o.Reason = ('No command: there is no current PlanOk plan for {0} (stage {1}: {2}).' -f $(if ($Matches[1] -eq 'Spec') { 'spec.json' } else { 'spec-absent.json' }), $(if ($Matches[1] -eq 'Spec') { 3 } else { 6 }), $(if ($ps) { $ps.Words } else { 'not read' }))
                    return $o
                }
                [void]$parts.Add([string]$ps.Current.Hash)
            }
            elseif ($tok -match '^\{') { throw ("unknown token {0} in the stage table" -f $tok) }
            else { [void]$parts.Add($tok) }
        }
        $o.Text = ('powershell -NoProfile -ExecutionPolicy Bypass -File {0} {1}' -f (ConvertTo-SqlStackGuiArg (Join-Path $dir $row.Script)), ($parts -join ' '))
        $o.Ok = $true
        # The reboot check runs BEFORE this command, so it exists only WITH it
        # (gate F8; 'command (F8):' in -SelfTest).
        if ($row.Reboot) { $o.Snippet = Get-SqlStackGuiRebootSnippet }
    } catch { $o.Reason = ('No command: ' + $_.Exception.Message) }
    return $o
}

function Copy-SqlStackGuiCommand {
    <#
      THE ONE CLIPBOARD WRITE (INV-2). It takes NO text: it asks the builder for
      the stage's command (or its compare block, or its reboot snippet) and copies
      exactly that. Census: 'W5-clipboard-through-builder'.
      Returns ONE object: .Ok .Text .Reason
    #>
    param([Parameter(Mandatory)][int]$Stage, [Parameter(Mandatory)]$State, [ValidateSet('Command', 'Compare', 'Snippet')][string]$Part = 'Command',
          [string]$ToolDir = '', [string]$MapRoot = '')
    $c = Get-SqlStackGuiCommand -Stage $Stage -State $State -ToolDir $ToolDir -MapRoot $MapRoot
    $t = switch ($Part) { 'Command' { $(if ($c.Ok) { $c.Text } else { '' }) } 'Compare' { $c.Compare } 'Snippet' { $c.Snippet } }
    $why = switch ($Part) { 'Command' { $c.Reason } 'Compare' { $c.CompareReason } 'Snippet' { $(if ($c.Ok) { 'this stage has no snippet' } else { $c.Reason }) } }
    if ([string]::IsNullOrEmpty($t)) { return [pscustomobject]@{ Ok = $false; Text = ''; Reason = $why } }
    # SetDataObject with retries: the clipboard is shared, and another process
    # holding it for a moment made a bare SetText fail (MEASURED in the lane's walk).
    try { [System.Windows.Forms.Clipboard]::SetDataObject($t, $true, 10, 100) }
    catch { return [pscustomobject]@{ Ok = $false; Text = $t; Reason = (Get-SqlStackGuiCopyRefusal -Message $_.Exception.Message) } }
    return [pscustomobject]@{ Ok = $true; Text = $t; Reason = '' }
}

function Get-SqlStackGuiCopyRefusal {
    # The words for a refused clipboard write (gate F7, 2026-11-04). The -STA hint
    # only when this thread is NOT STA: an STA window that is refused has another
    # cause, so it is told to copy the drawer's text by hand. Row 'copy refusal (F7):'
    # in -SelfTest.
    param([string]$Message, [string]$Apartment = ([string][System.Threading.Thread]::CurrentThread.GetApartmentState()))
    if ($Apartment -ne 'STA') { return ('the clipboard refused it: this window is not STA, so start it with -STA ({0})' -f $Message) }
    return ('the clipboard refused it ({0}). Select the text in the drawer and copy it by hand.' -f $Message)
}

function Get-SqlStackGuiCompareBlock {
    <#
      RUNBOOK step 8's compare block, with both bundle paths filled in (critic K15).
      -ExcludeInstance is filled ONLY from snapshot B's redaction map: the token t
      whose map[t] is { class INST, value <the throwaway instance> }. No map, a map
      this window cannot see (the MSIX LocalCache, README 'Where things land'), a
      map from another host, or no such value: NO block, and .Reason says why.
      Returns ONE object: .Text .Reason .Token .MapPath
    #>
    param([Parameter(Mandatory)]$State, [string]$ToolDir = '', [string]$MapRoot = '')
    $o = [pscustomobject]@{ Text = ''; Reason = ''; Token = ''; MapPath = '' }
    if (($State.SnapshotA.Status -ne 'Done') -or ($State.SnapshotB.Status -ne 'Done')) { $o.Reason = 'No compare block yet: it needs an intact snapshot A and an intact snapshot B.'; return $o }
    $tw = @($State.Spec.Throwaway)
    if ($tw.Count -ne 1) { $o.Reason = ('No compare block: it excludes ONE throwaway instance, and this spec names {0}.' -f $tw.Count); return $o }
    $map = Read-SqlStackGuiRedactionMap -BundleName $State.SnapshotB.BundleName -HostToken $State.SnapshotB.HostToken -MapRoot $MapRoot
    $o.MapPath = $map.Path
    if (-not $map.Ok) { $o.Reason = ('No compare block: {0}' -f $map.Reason); return $o }
    $tok = @($map.Map.Keys | Where-Object { ([string]$map.Map[$_].Class -eq 'INST') -and ([string]$map.Map[$_].Value -ieq $tw[0]) })
    if ($tok.Count -ne 1) { $o.Reason = ('No compare block: snapshot B''s map holds {0} INST token(s) for {1}, not one.' -f $tok.Count, $tw[0]); return $o }
    $o.Token = [string]$tok[0]
    $dir = $(if ($ToolDir) { $ToolDir } else { $PSScriptRoot })
    $q = { param($s) "'" + ([string]$s -replace "'", "''") + "'" }
    $o.Text = ((@(
        'powershell -NoProfile -ExecutionPolicy Bypass -Command @"',
        ('  . {0} -AsLibrary' -f (& $q (Join-Path $dir 'SqlStack-Collect.ps1'))),
        '  `$r = Compare-SqlStackSnapshot ``',
        ('        -Before {0} ``' -f (& $q $State.SnapshotA.Bundle)),
        ('        -After  {0} ``' -f (& $q $State.SnapshotB.Bundle)),
        ('        -ExcludeInstance {0}' -f (& $q $o.Token)),
        '  `$r.Lines',
        '  ''OK='' + `$r.Ok + '' EMPTY='' + `$r.Empty + '' RAW='' + `$r.Raw + '' SURVIVING='' + @(`$r.Surviving).Count',
        '  `$r.Surviving | Format-Table Key, Change, OldValue, NewValue -AutoSize',
        '  `$r.Problems',
        '"@')) -join "`r`n")
    return $o
}

function Read-SqlStackGuiRedactionMap {
    <#
      One bundle's redaction map, %LOCALAPPDATA%\SqlStack\maps\<bundle>.map.json
      (the collector writes it OUTSIDE the bundle: { <token>: { class, value } }).
      The map is used ONLY when its host token's value is this computer's name:
      a snapshot from another host cannot be matched to this host's instances.
      Inside the Claude desktop app the file lands in the package's LocalCache and
      a shell outside it does not see it (README 'Where things land', PROVED).
      Returns ONE object: .Ok .Reason .Path .Map (token -> .Class .Value)
    #>
    param([string]$BundleName, [string]$HostToken, [string]$MapRoot = '', [string]$ComputerName = $env:COMPUTERNAME)
    $root = $(if ($MapRoot) { $MapRoot } else { Join-Path $env:LOCALAPPDATA 'SqlStack\maps' })
    $p = Join-Path $root ($BundleName + '.map.json')
    $o = [pscustomobject]@{ Ok = $false; Reason = ''; Path = $p; Map = @{} }
    if (-not $BundleName) { $o.Reason = 'no bundle, so no map'; return $o }
    $txt = Read-SqlStackGuiText -Path $p
    if ($null -eq $txt) { $o.Reason = ('its redaction map is not visible at {0} (absent, deleted, or written inside the Claude desktop app''s package cache)' -f $p); return $o }
    $doc = $null
    try { $doc = ConvertFrom-Json $txt } catch { $o.Reason = ('the map at {0} is not readable JSON' -f $p); return $o }
    foreach ($pr in @($doc.PSObject.Properties)) { $o.Map[[string]$pr.Name] = [pscustomobject]@{ Class = [string]$pr.Value.class; Value = [string]$pr.Value.value } }
    if ((-not $HostToken) -or (-not $o.Map.ContainsKey($HostToken))) { $o.Reason = ('the map names no host token {0}, so it cannot be matched to this host' -f $HostToken); return $o }
    if ([string]$o.Map[$HostToken].Value -ine $ComputerName) { $o.Reason = 'the map is from another host (its host value is not this computer), so it cannot be matched to this host''s instances'; return $o }
    $o.Ok = $true
    return $o
}

# ===========================================================================
# ===========================================================================
#  THE INSTALL SPINE (2026-11-16; the owner's ruling: one window to plan, save,
#  press Install and watch it finish)
#
#  INV-5  THIS WINDOW STARTS TWO THINGS AND NOTHING ELSE: the install worker
#         SqlStack-Install.ps1 from this script's own folder
#         (Start-SqlStackGuiInstallWorker), and this script again as
#         administrator (Start-SqlStackGuiElevatedWindow). Every setup call,
#         registry, service and network write and SQL connection is the
#         WORKER's, in its own process; this file holds none. Census row
#         'I1-process-starts' in Test-SqlStackGuiStructure.
#  INV-6  A REAL INSTALL STARTS AT ONE PLACE, Invoke-SqlStackGuiInstallNow,
#         after Get-SqlStackGuiInstallAction said so (elevated, a preview with
#         no problem). Every other start of the worker is its preview, which
#         changes nothing. The worker itself refuses an install that is not
#         elevated. Census row 'I2-install-one-place'.
#  INV-7  A PASSWORD travels to the worker over its standard input only
#         (ConvertTo-SqlStackGuiSecretLine, Send-SqlStackGuiWorkerSecrets):
#         never an argument, a file or an environment variable, and never
#         into a log line. Setup itself receives it as a command-line switch
#         from the worker: that is the owner's ruling. 'install loop:' in
#         -SelfTest drives the whole loop with a stand-in for setup.
#  Everything below is pure or takes its inputs as parameters, so -SelfTest
#  drives it headless.
# ===========================================================================
# ===========================================================================

function Get-SqlStackGuiWorkerPath {
    # THE ONE name of the install worker: beside this script, nowhere else.
    return (Join-Path $PSScriptRoot 'SqlStack-Install.ps1')
}

function ConvertTo-SqlStackGuiProcessArg {
    # One argument of a process command line (Windows argv rules): bare when it
    # is plain, else in double quotes with a trailing run of backslashes
    # doubled. A double quote or a control character is refused.
    param([string]$Value)
    if ($Value -match '["\x00-\x1F]') { throw ("refusing to start a process with '{0}': it holds a double quote or a control character" -f $Value) }
    if (($Value -match '^[A-Za-z0-9_\-\.:\\/]+$') -and (-not $Value.EndsWith('\'))) { return $Value }
    $m = [regex]::Match($Value, '\\+$')
    return ('"' + $Value + $(if ($m.Success) { $m.Value } else { '' }) + '"')
}

function Initialize-SqlStackGuiWorkerHost {
    <#
      The small C# class that holds the worker process. WHY C#: in Windows
      PowerShell 5.1 a script block used as a .NET event handler on a
      thread-pool thread (Process.OutputDataReceived) has no runspace and
      crashes or hangs the window. So the class collects the child's output
      lines into a ConcurrentQueue on those threads, and PowerShell only ever
      DRAINS the queue, on its own thread (a WinForms timer on the UI thread).
      The class starts exactly the file and arguments it is given; the only
      caller is Start-SqlStackGuiInstallWorker (census 'I1-process-starts').
    #>
    if ('SqlStackGuiWorkerProcess' -as [type]) { return }
    Add-Type -TypeDefinition @'
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
public sealed class SqlStackGuiWorkerProcess : IDisposable {
    private readonly Process p = new Process();
    private readonly ConcurrentQueue<string> q = new ConcurrentQueue<string>();
    private volatile bool outClosed;
    private volatile bool errClosed;
    private DateTime exitSeen = DateTime.MinValue;
    public SqlStackGuiWorkerProcess(string exe, string arguments, string workDir) {
        ProcessStartInfo si = new ProcessStartInfo(exe, arguments);
        si.UseShellExecute = false;
        si.CreateNoWindow = true;
        si.RedirectStandardInput = true;
        si.RedirectStandardOutput = true;
        si.RedirectStandardError = true;
        si.StandardOutputEncoding = Encoding.UTF8;
        si.StandardErrorEncoding = Encoding.UTF8;
        si.WorkingDirectory = workDir;
        p.StartInfo = si;
        p.OutputDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data == null) { outClosed = true; } else { q.Enqueue(e.Data); } };
        p.ErrorDataReceived += delegate(object s, DataReceivedEventArgs e) { if (e.Data == null) { errClosed = true; } else { q.Enqueue("ERROR: " + e.Data); } };
    }
    public void Start() { p.Start(); p.BeginOutputReadLine(); p.BeginErrorReadLine(); }
    public void WriteLine(string line) { p.StandardInput.WriteLine(line); p.StandardInput.Flush(); }
    public void CloseInput() { try { p.StandardInput.Close(); } catch (Exception) { } }
    public string[] ReadAll() {
        List<string> l = new List<string>();
        string s;
        while (q.TryDequeue(out s)) { l.Add(s); }
        return l.ToArray();
    }
    public bool Finished {
        get {
            if (!p.HasExited) { return false; }
            if (outClosed && errClosed) { return true; }
            if (exitSeen == DateTime.MinValue) { exitSeen = DateTime.UtcNow; }
            return (DateTime.UtcNow - exitSeen).TotalSeconds > 3;
        }
    }
    public int ExitCode { get { return p.ExitCode; } }
    public int Id { get { return p.Id; } }
    public void Dispose() { try { p.Dispose(); } catch (Exception) { } }
}
'@
}

function Start-SqlStackGuiInstallWorker {
    <#
      THE ONE START OF THE INSTALL WORKER (INV-5), as a hidden child process
      whose output lines queue up for the caller to drain
      (Read-SqlStackGuiWorkerOutput). -Mode Preview: the worker prints what it
      would do and changes nothing. -Mode Install: it runs, confirmed, taking
      its passwords from its standard input (Send-SqlStackGuiWorkerSecrets).
      -HarnessSetupExe is for -SelfTest ONLY: it makes the run harmless (the
      worker's -SelfTestHarness) with a stand-in for setup.exe; no product
      code passes it (census 'I1-process-starts').
      Returns the worker (a SqlStackGuiWorkerProcess).
    #>
    param(
        [Parameter(Mandatory)][string]$RunFolder,
        [ValidateSet('Preview', 'Install', 'Restart', 'ForgetResume')][string]$Mode = 'Preview',
        [string]$InterfaceAlias = '',
        [int]$PrefixLength = 24,
        [string]$HarnessSetupExe = '',
        # Preview and Install: tell setup to ignore a pending restart of Windows.
        [bool]$IgnorePendingRestart = $false,
        # -Mode Restart only: the arguments the resume task starts powershell
        # with after the restart of Windows; '' = restart with no resume task.
        [string]$ResumeArguments = ''
    )
    $workerPath = Get-SqlStackGuiWorkerPath
    if (-not [IO.File]::Exists($workerPath)) { throw ("the install worker is not beside this script: {0}" -f $workerPath) }
    $full = [IO.Path]::GetFullPath($RunFolder).TrimEnd('\')
    $parts = New-Object System.Collections.ArrayList
    foreach ($a in @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $workerPath, '-RunFolder', $full)) { [void]$parts.Add((ConvertTo-SqlStackGuiProcessArg $a)) }
    if ($InterfaceAlias) {
        foreach ($a in @('-InterfaceAlias', $InterfaceAlias, '-PrefixLength', [string]$PrefixLength)) { [void]$parts.Add((ConvertTo-SqlStackGuiProcessArg $a)) }
    }
    if ($Mode -eq 'Install') { foreach ($a in @('-Go', '-Yes', '-PasswordStdin')) { [void]$parts.Add($a) } }
    if ($IgnorePendingRestart -and (($Mode -eq 'Preview') -or ($Mode -eq 'Install'))) { [void]$parts.Add('-IgnorePendingRestart') }
    # The restart of Windows and the resume task are the WORKER's too (INV-5):
    # this file holds no task or restart command. The arguments travel as
    # base64, so their quotes cannot change the worker's own command line.
    if ($Mode -eq 'Restart') {
        [void]$parts.Add('-WindowsRestart')
        if ($ResumeArguments) { [void]$parts.Add('-ResumeArguments'); [void]$parts.Add([Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($ResumeArguments))) }
    }
    if ($Mode -eq 'ForgetResume') { [void]$parts.Add('-RemoveResumeTask') }
    if ($HarnessSetupExe) { foreach ($a in @('-SelfTestHarness', '-SetupExeOverride', $HarnessSetupExe)) { [void]$parts.Add((ConvertTo-SqlStackGuiProcessArg $a)) } }
    Initialize-SqlStackGuiWorkerHost
    $worker = New-Object SqlStackGuiWorkerProcess((Join-Path $PSHOME 'powershell.exe'), ($parts -join ' '), (Split-Path -Parent $workerPath))
    $worker.Start()
    return $worker
}

function Get-SqlStackGuiElevatedArguments {
    # The arguments this window starts itself with as administrator: the same
    # script, the same run folder, straight onto the Install screen.
    param([Parameter(Mandatory)][string]$ScriptPath, [Parameter(Mandatory)][string]$RunFolder, [bool]$Advanced = $false, [string]$StatePath = '', [int]$PortBase = 0)
    $parts = New-Object System.Collections.ArrayList
    foreach ($a in @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', $ScriptPath, '-RunFolder', ([IO.Path]::GetFullPath($RunFolder).TrimEnd('\')), '-OpenInstall')) { [void]$parts.Add((ConvertTo-SqlStackGuiProcessArg $a)) }
    if ($Advanced) { [void]$parts.Add('-Advanced') }
    if ($StatePath) { [void]$parts.Add('-StatePath'); [void]$parts.Add((ConvertTo-SqlStackGuiProcessArg $StatePath)) }
    if ($PortBase -gt 0) { [void]$parts.Add('-PortBase'); [void]$parts.Add([string]$PortBase) }
    return ($parts -join ' ')
}

function Start-SqlStackGuiElevatedWindow {
    <#
      THE ONE START OF THIS WINDOW AS ADMINISTRATOR (INV-5): this very script
      ($script:EntryScriptPath), on the same run folder, straight onto the
      Install screen. Windows asks the operator (the UAC prompt); a refusal
      throws and nothing was started. Returns the started process.
    #>
    param([Parameter(Mandatory)][string]$RunFolder, [bool]$Advanced = $false, [string]$StatePath = '', [int]$PortBase = 0)
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = (Join-Path $PSHOME 'powershell.exe')
    $psi.Arguments = Get-SqlStackGuiElevatedArguments -ScriptPath $script:EntryScriptPath -RunFolder $RunFolder -Advanced $Advanced -StatePath $StatePath -PortBase $PortBase
    $psi.Verb = 'runas'
    $psi.UseShellExecute = $true
    $psi.WorkingDirectory = (Split-Path -Parent $script:EntryScriptPath)
    return [System.Diagnostics.Process]::Start($psi)
}

function ConvertTo-SqlStackGuiSecretLine {
    # One password line for the worker's standard input (INV-7): base64 of the
    # UTF-16 name, a space, base64 of the UTF-16 password. Plain ASCII, so no
    # code page can change it on the way.
    param([Parameter(Mandatory)][string]$Key, [Parameter(Mandatory)][AllowEmptyString()][string]$Password)
    return ([Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($Key)) + ' ' + [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($Password)))
}

function Send-SqlStackGuiWorkerSecrets {
    # Every password, over the worker's standard input and nowhere else
    # (INV-7), between a BEGIN and an END line; then the input is closed.
    # -Secrets is key -> password (the keys the worker's @@NEED lines named).
    param([Parameter(Mandatory)]$Worker, [System.Collections.IDictionary]$Secrets)
    $Worker.WriteLine('BEGIN')
    if ($Secrets) { foreach ($k in @($Secrets.Keys)) { $Worker.WriteLine((ConvertTo-SqlStackGuiSecretLine -Key ([string]$k) -Password ([string]$Secrets[$k]))) } }
    $Worker.WriteLine('END')
    $Worker.CloseInput()
}

function Get-SqlStackGuiPasswordProblem {
    # Why a typed password cannot be used, in plain words, or '' when it can.
    # The worker applies the same rule again before anything starts.
    param([AllowEmptyString()][string]$Text)
    if ([string]::IsNullOrEmpty($Text)) { return 'it is empty' }
    if ($Text.IndexOf('"') -ge 0) { return 'it holds a double quote ("), which cannot be handed to setup safely' }
    foreach ($c in $Text.ToCharArray()) { if (([int]$c -lt 32) -or ([int]$c -eq 127)) { return 'it holds a control character (a tab, a line break or similar)' } }
    return ''
}

function New-SqlStackGuiInstallModel {
    # What the worker has said so far, built ONLY from its lines
    # (Update-SqlStackGuiInstallModel). The Install screen draws from this.
    return [pscustomobject]@{
        Order = (New-Object System.Collections.ArrayList)       # instance names, in the worker's order
        Instances = @{}                                         # name -> .Name .Installed .Steps .State .Detail
        Needs = (New-Object System.Collections.ArrayList)       # .Key .Label: the passwords Install will ask for
        Addresses = (New-Object System.Collections.ArrayList)   # .Name .Ip: addresses to add to a network card
        Problems = (New-Object System.Collections.ArrayList)
        Trail = (New-Object System.Collections.ArrayList)       # 'name:state', in arrival order
        Lines = (New-Object System.Collections.ArrayList)       # every line, as it arrived
        LogPath = ''; Ended = $false; EndCode = -1; EndText = ''
        Pending = ''                                            # why Windows has a restart pending, or ''
        Finished = $false; ExitCode = $null
    }
}

function Update-SqlStackGuiInstallModel {
    <#
      One line from the worker into the model. A line that starts with @@ is
      machine-readable, tab separated (the worker's header lists them); any
      other line is for the log box only. A @@STATE for a name the worker did
      not announce is kept, never dropped.
    #>
    param([Parameter(Mandatory)]$Model, [AllowEmptyString()][string]$Line)
    [void]$Model.Lines.Add([string]$Line)
    if (-not ([string]$Line).StartsWith('@@')) { return }
    $f = @(([string]$Line).Substring(2) -split "`t")
    $kind = [string]$f[0]
    $arg = { param([int]$i) if ($f.Count -gt $i) { [string]$f[$i] } else { '' } }
    $inst = {
        param([string]$n)
        if (-not $Model.Instances.ContainsKey($n)) {
            $Model.Instances[$n] = [pscustomobject]@{ Name = $n; Installed = $false; Steps = (New-Object System.Collections.ArrayList); State = ''; Detail = '' }
            [void]$Model.Order.Add($n)
        }
        $Model.Instances[$n]
    }
    switch ($kind) {
        'INSTANCE' { $x = & $inst (& $arg 1); $x.Installed = ((& $arg 2) -eq 'installed'); $x.Steps.Clear() }
        'STEP'     { $x = & $inst (& $arg 1); [void]$x.Steps.Add([pscustomobject]@{ Kind = (& $arg 2); Text = (& $arg 3) }) }
        'NEED'     { if (@($Model.Needs | Where-Object { $_.Key -ceq (& $arg 1) }).Count -eq 0) { [void]$Model.Needs.Add([pscustomobject]@{ Key = (& $arg 1); Label = (& $arg 2) }) } }
        'ADDRESS'  { if (@($Model.Addresses | Where-Object { $_.Name -eq (& $arg 1) }).Count -eq 0) { [void]$Model.Addresses.Add([pscustomobject]@{ Name = (& $arg 1); Ip = (& $arg 2) }) } }
        'PROBLEM'  { [void]$Model.Problems.Add((& $arg 1)) }
        'LOG'      { $Model.LogPath = (& $arg 1) }
        'PENDING'  { $Model.Pending = (& $arg 1) }
        'STATE'    { $x = & $inst (& $arg 1); $x.State = (& $arg 2); $x.Detail = (& $arg 3); [void]$Model.Trail.Add(('{0}:{1}' -f $x.Name, $x.State)) }
        'END'      { $Model.Ended = $true; $n = -1; [void][int]::TryParse((& $arg 1), [ref]$n); $Model.EndCode = $n; $Model.EndText = (& $arg 2) }
    }
}

function Read-SqlStackGuiWorkerOutput {
    # Drain the worker's queued lines into the model, on the CALLER's thread.
    # When the worker has ended and its output is drained, the model is
    # Finished and carries the exit code. Returns the lines just read.
    param([Parameter(Mandatory)]$Worker, [Parameter(Mandatory)]$Model)
    $got = New-Object System.Collections.ArrayList
    $done = [bool]$Worker.Finished
    foreach ($l in @($Worker.ReadAll())) { Update-SqlStackGuiInstallModel -Model $Model -Line ([string]$l); [void]$got.Add([string]$l) }
    if ($done -and (-not $Model.Finished)) { $Model.Finished = $true; $Model.ExitCode = [int]$Worker.ExitCode }
    return [string[]]@($got)
}

function Wait-SqlStackGuiWorker {
    # Drain the worker until it ends (the preview, and -SelfTest). A worker that
    # has not ended in -TimeoutSec is a named problem, never a silent wait.
    param([Parameter(Mandatory)]$Worker, [Parameter(Mandatory)]$Model, [int]$TimeoutSec = 120)
    $until = (Get-Date).AddSeconds($TimeoutSec)
    while (-not $Model.Finished) {
        [void](Read-SqlStackGuiWorkerOutput -Worker $Worker -Model $Model)
        if ($Model.Finished) { break }
        if ((Get-Date) -gt $until) { [void]$Model.Problems.Add(('the install worker did not finish in {0} seconds' -f $TimeoutSec)); break }
        Start-Sleep -Milliseconds 50
    }
    return [bool]$Model.Finished
}

function Read-SqlStackGuiInstallChoice {
    # The Install screen's saved choices in a run folder (install.json), and
    # whether the folder already holds exported setup files. A READ.
    # Returns ONE object: .Exists .HostName .InterfaceAlias .PrefixLength .HasFiles
    # .Updates (instance name -> its updates folder; only the ones that have one)
    param([Parameter(Mandatory)][string]$Root)
    $o = [pscustomobject]@{ Exists = $false; HostName = ''; InterfaceAlias = ''; PrefixLength = 24; HasFiles = $false; Updates = @{}; IgnorePendingRestart = $false }
    $txt = Read-SqlStackGuiText -Path (Get-SqlStackGuiRunPath -Root $Root -Item 'Install')
    if ($null -ne $txt) {
        try {
            $d = ConvertFrom-Json $txt
            $o.Exists = $true
            $o.HostName = [string]$d.host
            $o.InterfaceAlias = [string]$d.interfaceAlias
            $n = 0
            if ([int]::TryParse([string]$d.prefixLength, [ref]$n) -and ($n -ge 1) -and ($n -le 128)) { $o.PrefixLength = $n }
            if ($d.PSObject.Properties['ignorePendingRestart']) { $o.IgnorePendingRestart = ($d.ignorePendingRestart -eq $true) }
            if ($d.PSObject.Properties['updates'] -and $d.updates) {
                foreach ($u in @($d.updates.PSObject.Properties)) { if (([string]$u.Value).Trim()) { $o.Updates[[string]$u.Name] = ([string]$u.Value).Trim() } }
            }
        } catch { $o.Exists = $false }
    }
    $exp = Get-SqlStackGuiRunPath -Root $Root -Item 'Export'
    if ([IO.Directory]::Exists($exp)) { $o.HasFiles = (@([IO.Directory]::GetFiles($exp, '*-install.ini')).Count -gt 0) }
    return $o
}

function Get-SqlStackGuiInstallStateWord {
    # A worker state (or none yet) as the word and the colour the grid shows.
    param([string]$State, [bool]$Installed = $false)
    switch ($State) {
        ''               { if ($Installed) { return [pscustomobject]@{ Word = 'already installed'; Color = 'Secondary' } } else { return [pscustomobject]@{ Word = 'will be installed'; Color = 'Info' } } }
        'waiting'        { return [pscustomobject]@{ Word = 'waiting'; Color = 'Secondary' } }
        'done'           { return [pscustomobject]@{ Word = 'done'; Color = 'Ok' } }
        'failed'         { return [pscustomobject]@{ Word = 'FAILED'; Color = 'Error' } }
        'reboot needed'  { return [pscustomobject]@{ Word = 'reboot needed'; Color = 'Warning' } }
        'needs attention' { return [pscustomobject]@{ Word = 'needs attention'; Color = 'Error' } }
        'installed, check failed' { return [pscustomobject]@{ Word = 'installed, check failed'; Color = 'Warning' } }
        default          { return [pscustomobject]@{ Word = [string]$State; Color = 'Info' } }
    }
}

function Get-SqlStackGuiInstallRows {
    # The Install grid's rows, from the model: one per instance, with what
    # will happen to it as numbered plain steps.
    param([Parameter(Mandatory)]$Model)
    $rows = New-Object System.Collections.ArrayList
    foreach ($n in @($Model.Order)) {
        $x = $Model.Instances[$n]
        $w = Get-SqlStackGuiInstallStateWord -State ([string]$x.State) -Installed ([bool]$x.Installed)
        $k = 0
        $steps = @(@($x.Steps) | ForEach-Object { $k++; ('{0}. {1}' -f $k, $_.Text) })
        [void]$rows.Add([pscustomobject]@{ Name = [string]$n; Word = $w.Word; Color = $w.Color; Detail = [string]$x.Detail; Steps = ($steps -join "`r`n") })
    }
    return $rows.ToArray()
}

function Get-SqlStackGuiInstallNeedsText {
    # Which passwords Install will ask for, in one line.
    param([Parameter(Mandatory)]$Model)
    $n = @($Model.Needs)
    if ($n.Count -eq 0) { return 'Passwords: none will be asked.' }
    return ('Passwords Install will ask for, once each: ' + ((@($n) | ForEach-Object { [string]$_.Label }) -join '; ') + '. Leave one blank to type it in SQL Server setup''s own window instead.')
}

function Select-SqlStackGuiTypedSecrets {
    # EVERY PASSWORD IS OPTIONAL (the owner's ruling, 2026-11-17): only the
    # passwords that were typed go to the worker. One left blank is not sent,
    # and the worker then runs that instance's setup with setup's own window.
    param([System.Collections.IDictionary]$Secrets)
    $typed = [ordered]@{}
    if ($Secrets) { foreach ($k in @($Secrets.Keys)) { if (-not [string]::IsNullOrEmpty([string]$Secrets[$k])) { $typed[[string]$k] = [string]$Secrets[$k] } } }
    return $typed
}

function Test-SqlStackGuiUpdatesFolder {
    # What an instance's optional updates folder is worth, in plain words. A
    # READ. A folder that is missing or holds no .exe is a WARNING, never a
    # refusal. Returns ONE object: .Text (the preview's words) .Warning ('' = fine)
    param([AllowEmptyString()][string]$Path)
    $p = ([string]$Path).Trim()
    if (-not $p) { return [pscustomobject]@{ Text = 'no updates applied'; Warning = '' } }
    $warn = ''
    if ($p -match '["\x00-\x1F]') { $warn = 'the updates folder name holds a double quote or a control character, so it cannot be handed to setup' }
    elseif (-not [IO.Directory]::Exists($p)) { $warn = ('the updates folder does not exist: {0}' -f $p) }
    elseif (@([IO.Directory]::GetFiles($p, '*.exe')).Count -eq 0) { $warn = ('the updates folder holds no .exe update package, so setup would find nothing to apply: {0}' -f $p) }
    return [pscustomobject]@{ Text = ('updates from {0}' -f $p); Warning = $warn }
}

function Get-SqlStackGuiUpdatesFinding {
    # The Plan screen's warning rows for the updates folders of the NEW instances.
    param([object[]]$Plan = @())
    $out = New-Object System.Collections.ArrayList
    foreach ($p in @(@($Plan) | Where-Object { ($null -ne $_) -and (-not $_.Fixed) })) {
        $t = Test-SqlStackGuiUpdatesFolder -Path ([string]$p.UpdatesPath)
        if ($t.Warning) { [void]$out.Add([pscustomobject]@{ Severity = 'WARN'; Area = 'Updates'; Message = ('{0}: {1}' -f $p.Name, $t.Warning) }) }
    }
    return $out.ToArray()
}

function Get-SqlStackGuiUpdatesMap {
    # install.json's "updates": instance name -> updates folder, for the NEW
    # instances that have one. The install worker reads it.
    param([object[]]$Plan = @())
    $map = [ordered]@{}
    foreach ($p in @(@($Plan) | Where-Object { ($null -ne $_) -and (-not $_.Fixed) })) {
        $u = ([string]$p.UpdatesPath).Trim()
        if ($u) { $map[[string]$p.Name] = $u }
    }
    return $map
}

function Get-SqlStackGuiPendingText {
    # The Install screen's first line when Windows has a restart pending, or ''.
    param([string]$Pending, [bool]$Ignore = $false)
    if (-not $Pending) { return '' }
    $t = ('Windows has a restart pending ({0}).' -f $Pending)
    if ($Ignore) { return ($t + ' Setup will be told to ignore it.') }
    return ($t + ' Setup will very likely refuse to start until Windows is restarted.')
}

function Test-SqlStackGuiNetworkPath {
    # $true when a path is on a network share (a UNC path) or a drive whose
    # type is Network (a mapped drive): a window started as administrator
    # cannot see a mapped drive. -DriveType reads a root's type; a seam for -SelfTest.
    param([string]$Path, [scriptblock]$DriveType = { param([string]$Root) [string](New-Object System.IO.DriveInfo($Root)).DriveType })
    if (-not $Path) { return $false }
    $full = [IO.Path]::GetFullPath($Path)
    if ($full.StartsWith('\\')) { return $true }
    try { return ([string](& $DriveType ([IO.Path]::GetPathRoot($full))) -eq 'Network') } catch { return $false }
}

function Get-SqlStackGuiRestartQuestion {
    # The ONE confirm before Windows is restarted from this window. It names the machine.
    param([Parameter(Mandatory)][string]$MachineName, [bool]$Resume = $false)
    $l = @(('Restart Windows on {0} now?' -f $MachineName), '', 'Every program on this machine is closed. Save your work in other windows first.')
    if ($Resume) { $l += @('', 'After you sign in again, SqlStack opens by itself on this run folder, on the Install screen, and shows what is left. It asks for the passwords again: none is stored.') }
    return ($l -join "`r`n")
}

function Invoke-SqlStackGuiWindowsRestart {
    <#
      THE ONE WAY Windows is restarted from this window: one confirm that names
      the machine, then the worker in its restart mode. Both are script blocks,
      so -SelfTest drives it with fakes: no task is registered and nothing
      restarts in a test. -Confirm gets the question and answers $true or
      $false. -RunWorker gets -Resume and returns the worker's model; it runs
      ONLY after the confirm said yes (census 'I2-install-one-place').
      Returns ONE object: .Kind (Declined|Failed|Restarting) .Text
    #>
    param([Parameter(Mandatory)][string]$MachineName, [bool]$Resume = $false, [Parameter(Mandatory)][scriptblock]$Confirm, [Parameter(Mandatory)][scriptblock]$RunWorker)
    if (-not [bool](& $Confirm (Get-SqlStackGuiRestartQuestion -MachineName $MachineName -Resume $Resume))) {
        return [pscustomobject]@{ Kind = 'Declined'; Text = 'Windows was not restarted. Nothing was left behind.' }
    }
    $m = $null
    try { $m = & $RunWorker $Resume }
    catch { return [pscustomobject]@{ Kind = 'Failed'; Text = ('Windows was not restarted: {0}' -f $_.Exception.Message) } }
    if (($null -ne $m) -and $m.Finished -and ([int]$m.ExitCode -eq 0)) {
        return [pscustomobject]@{ Kind = 'Restarting'; Text = $(if ($Resume) { 'Windows is restarting. SqlStack opens again on this run folder after you sign in.' } else { 'Windows is restarting.' }) }
    }
    $said = 'the worker did not finish'
    if ($null -ne $m) { $said = $(if ($m.EndText) { [string]$m.EndText } elseif (@($m.Problems).Count -gt 0) { [string]@($m.Problems)[0] } else { ('the worker ended with exit code {0}' -f $m.ExitCode) }) }
    return [pscustomobject]@{ Kind = 'Failed'; Text = ('Windows was not restarted: {0}' -f $said) }
}

function Get-SqlStackGuiInstallAction {
    <#
      THE ONE DECISION about the Install button (INV-6), and one of the two
      places elevation is read (census 'D3-elevation-two-readers'). Off, with
      the reason in words, while an install is running, the plan could not be
      saved, the preview has not run or found a problem, or nothing is planned.
      Otherwise: not elevated = Elevate (the button restarts this window as
      administrator); elevated = Install.
      Returns ONE object: .Kind (Off|Elevate|Install) .Text .Reason
    #>
    param([bool]$IsElevated, $Model = $null, [bool]$Running = $false, [string]$SaveProblem = '')
    $text = $(if ($IsElevated) { 'Install now' } else { 'Restart as administrator to install' })
    $why = ''
    if ($Running) { $why = 'Install is running.' }
    elseif ($SaveProblem) { $why = $SaveProblem }
    elseif (($null -eq $Model) -or (-not $Model.Finished)) { $why = 'The install preview has not run yet.' }
    elseif (@($Model.Problems).Count -gt 0) { $why = ('Fix this first: {0}' -f [string]@($Model.Problems)[0]) }
    elseif ([int]$Model.ExitCode -ne 0) { $why = ('The install preview ended with exit code {0}. Read the log below.' -f $Model.ExitCode) }
    elseif (@($Model.Order).Count -eq 0) { $why = 'There is no instance to install.' }
    if ($why) { return [pscustomobject]@{ Kind = 'Off'; Text = $text; Reason = $why } }
    if (-not $IsElevated) { return [pscustomobject]@{ Kind = 'Elevate'; Text = $text; Reason = 'Installing needs administrator rights. The button saves the plan, opens this window again as administrator on this run folder, and closes this one.' } }
    return [pscustomobject]@{ Kind = 'Install'; Text = $text; Reason = 'Ready. Nothing changes until you confirm.' }
}

function Get-SqlStackGuiInstallOutcome {
    <#
      When the worker has ended: a result per instance and ONE sentence on what
      to do next. An instance is 'done' ONLY when the worker's last state for
      it is done; a worker that ended 0 without every instance done is a
      failure, never a success.
      Returns ONE object: .Kind (Done|Reboot|Failed|NotRun) .Next .Rows (.Name .Result)
    #>
    param([Parameter(Mandatory)]$Model, [string]$RunFolder = '')
    $rows = New-Object System.Collections.ArrayList
    $allDone = (@($Model.Order).Count -gt 0)
    foreach ($n in @($Model.Order)) {
        $x = $Model.Instances[$n]
        $st = [string]$x.State
        $res = switch ($st) {
            'done'          { 'done' + $(if ($x.Detail) { ' (' + $x.Detail + ')' } else { '' }) }
            'failed'        { 'FAILED: ' + [string]$x.Detail }
            'reboot needed' { 'installed; Windows must restart before the rest' }
            'needs attention' { 'NEEDS ATTENTION, nothing was changed for it: ' + [string]$x.Detail }
            'installed, check failed' { 'installed, check failed: ' + [string]$x.Detail }
            'waiting'       { 'not run' }
            ''              { 'not run' }
            default         { 'stopped while ' + $st }
        }
        if ($st -ne 'done') { $allDone = $false }
        [void]$rows.Add([pscustomobject]@{ Name = [string]$n; Result = [string]$res })
    }
    $code = $(if ($null -eq $Model.ExitCode) { -1 } else { [int]$Model.ExitCode })
    $log = $(if ($Model.LogPath) { ' The log is ' + $Model.LogPath + '.' } else { '' })
    $said = $(if ($Model.EndText) { [string]$Model.EndText } elseif (@($Model.Problems).Count -gt 0) { [string]@($Model.Problems)[0] } else { ('the worker ended with exit code {0}' -f $code) })
    $kind = 'Failed'; $next = ''
    # A worker that ended with no END line, or with the END its trap writes,
    # stopped part way: something may already be changed (2026-11-23).
    $partWay = (-not $Model.Ended) -or ([string]$Model.EndText).StartsWith('unexpected error')
    if ($partWay) { $next = ('The run stopped part way. Something may already be changed: read the log before pressing Install again.{0}' -f $log) }
    elseif (($code -eq 0) -and $allDone) { $kind = 'Done'; $next = 'Done. Every instance is installed, configured and answering on its port. Close SqlStack and open it again to see them on the Host screen.' }
    elseif ($code -eq 3) { $kind = 'Reboot'; $next = ('Reboot needed. Press "Restart Windows now and continue": SqlStack opens again on this run folder after you sign in. Or restart Windows yourself later, open SqlStack again, press Open run folder and choose {0}, then press Install again. Both are safe: instances already installed are left as they are.' -f $RunFolder) }
    elseif ($code -eq 1) { $kind = 'NotRun'; $next = ('Nothing was changed: {0}' -f $said) }
    elseif ($code -eq 0) { $next = ('Failed: the worker ended without reporting every instance done.{0}' -f $log) }
    else { $next = ('Failed: {0}.{1} Fix the cause, then press Install again; instances already installed are left as they are.' -f $said.TrimEnd('.'), $log) }
    return [pscustomobject]@{ Kind = $kind; Next = $next; Rows = $rows.ToArray() }
}

# ===========================================================================
# STRUCTURAL CENSUS of this GUI's defect classes (lane sqlstack-gui-glowup,
# stage 1). Each row names the INVARIANT, read off a script's SYNTAX TREE, so
# it can be pointed at ANY copy of this file: -SelfTest runs it on this file
# (green), and the lane's evidence ran the same function on the base copy
# (red). It reads structure (commands, variables, parameters, script blocks),
# never line numbers. The one exception is said where it is: the 'no skip
# claim' row matches CHARACTERS inside string literals and is a TRIPWIRE, not
# the guarantee; the guarantee for D3 is the row beside it (no code branches
# on elevation), which is structural.
# Returns rows: Id, Invariant, Findings (string[]), Checked (int).
# ===========================================================================
function Test-SqlStackGuiStructure {
    param([Parameter(Mandatory)][string]$ScriptPath)
    $L = [System.Management.Automation.Language.Ast]
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($ScriptPath, [ref]$null, [ref]$null)
    $rows = New-Object System.Collections.ArrayList
    $add = {
        param([string]$Id, [string]$Invariant, [object[]]$Findings, [int]$Checked)
        [void]$rows.Add([pscustomobject]@{ Id = $Id; Invariant = $Invariant; Findings = [string[]](@($Findings | Where-Object { $_ })); Checked = $Checked })
    }
    # The -SelfTest block is test code, not the product: find it by STRUCTURE
    # (the top-level if statement whose condition reads EntryArgs['SelfTest']).
    $selfTestIf = @($ast.EndBlock.Statements | Where-Object {
            ($_ -is [System.Management.Automation.Language.IfStatementAst]) -and
            (@($_.Clauses[0].Item1.FindAll({ param($n) ($n -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ($n.Value -eq 'SelfTest') }, $true)).Count -ge 1) })
    $inSelfTest = {
        param($n)
        foreach ($s in $selfTestIf) { if (($n.Extent.StartOffset -ge $s.Extent.StartOffset) -and ($n.Extent.EndOffset -le $s.Extent.EndOffset)) { return $true } }
        return $false
    }
    $fnDef = @{}
    foreach ($f in @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] }, $true))) { $fnDef[$f.Name] = $f }
    $inFn = {
        param($n, [string]$Name)
        if (-not $fnDef.ContainsKey($Name)) { return $false }
        $f = $fnDef[$Name]
        return (($n.Extent.StartOffset -ge $f.Extent.StartOffset) -and ($n.Extent.EndOffset -le $f.Extent.EndOffset))
    }
    $product = { param($n) (-not (& $inSelfTest $n)) -and (-not (& $inFn $n 'Test-SqlStackGuiStructure')) }

    # ---- D3: elevation is read by two functions and nothing else ----
    # REWRITTEN 2026-11-16 (the Install screen). Until then the rule was "no code
    # outside Get-SqlStackGuiElevationText branches on elevation", true of a
    # window that ran nothing. Install needs administrator rights, so ONE more
    # function reads it: Get-SqlStackGuiInstallAction, which decides between
    # Install now and Restart as administrator. Nothing this window READS may
    # depend on elevation: that half is unchanged.
    $elevReaders = @('Get-SqlStackGuiElevationText', 'Get-SqlStackGuiInstallAction')
    $elevRefs = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.VariableExpressionAst]) -and ($n.VariablePath.UserPath -eq 'script:IsElevated') }, $true) |
            Where-Object { & $product $_ })
    $bad = New-Object System.Collections.ArrayList
    foreach ($v in $elevRefs) {
        $p = $v.Parent
        if (($p -is [System.Management.Automation.Language.AssignmentStatementAst]) -and ($p.Left -eq $v)) { continue }
        $cmd = $v
        while ($cmd -and ($cmd -isnot [System.Management.Automation.Language.CommandAst])) { $cmd = $cmd.Parent }
        if ($cmd -and ($elevReaders -contains [string]$cmd.GetCommandName())) { continue }
        [void]$bad.Add(("`$script:IsElevated is read at line {0} by something other than an argument of {1}: '{2}'" -f $v.Extent.StartLineNumber, ($elevReaders -join ' or '), ([string]$p.Extent.Text).Split("`n")[0].Trim()))
    }
    & $add 'D3-elevation-two-readers' 'elevation is handed only to Get-SqlStackGuiElevationText (the header states it) and Get-SqlStackGuiInstallAction (Install needs administrator rights); no other code branches on it, so nothing this window reads is left out when unelevated' $bad.ToArray() $elevRefs.Count
    # TRIPWIRE, NOT THE GUARANTEE: this matches CHARACTERS in string literals.
    $skipLits = @($ast.FindAll({ param($n) (($n -is [System.Management.Automation.Language.StringConstantExpressionAst]) -or ($n -is [System.Management.Automation.Language.ExpandableStringExpressionAst])) -and ([string]$n.Value -match '(?i)\bskip') }, $true) |
            Where-Object { & $product $_ })
    & $add 'D3-no-skip-claim (tripwire)' 'no product string literal claims a skip (a character match over string literals, not a structural guarantee)' @($skipLits | ForEach-Object { "line {0}: {1}" -f $_.Extent.StartLineNumber, $_.Extent.Text }) @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.StringConstantExpressionAst] }, $true)).Count

    # ---- D6: the header names a non-local -Server, read from the entry-args snapshot ----
    $noteCalls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'Get-SqlStackGuiServerNote') }, $true) |
            Where-Object { & $product $_ })
    $d6 = New-Object System.Collections.ArrayList
    if ($noteCalls.Count -eq 0) { [void]$d6.Add('no product code calls Get-SqlStackGuiServerNote, so a non-local -Server is never said') }
    foreach ($c in $noteCalls) {
        $idx = @($c.FindAll({ param($n) ($n -is [System.Management.Automation.Language.IndexExpressionAst]) -and ([string]$n.Target.Extent.Text -eq '$script:EntryArgs') -and
                    ($n.Index -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ($n.Index.Value -eq 'Server') }, $true))
        if ($idx.Count -eq 0) { [void]$d6.Add(("line {0}: Get-SqlStackGuiServerNote is not fed `$script:EntryArgs['Server'] (the raw `$Server can be rebound by the engine dot-source)" -f $c.Extent.StartLineNumber)) }
    }
    & $add 'D6-server-said' 'a non-local -Server is said in the header, from the entry-args snapshot' $d6.ToArray() $noteCalls.Count

    # ---- D5: the Instances grid reads no host state of its own ----
    # Structural: the commands Update-InstanceGrid calls. A registry, CIM or
    # file read inside it is a second source for facts the engine owns.
    $d5 = New-Object System.Collections.ArrayList
    $d5Checked = 0
    if (-not $fnDef.ContainsKey('Update-InstanceGrid')) { [void]$d5.Add('Update-InstanceGrid is not in the syntax tree') }
    else {
        $gridCmds = @($fnDef['Update-InstanceGrid'].FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true))
        $d5Checked = $gridCmds.Count
        foreach ($c in $gridCmds) {
            $cn = [string]$c.GetCommandName()
            if (@('Test-Path', 'Get-ItemProperty', 'Get-Item', 'Get-ChildItem', 'Get-CimInstance', 'Get-WmiObject', 'Get-ItemPropertyValue') -contains $cn) {
                [void]$d5.Add(("line {0}: Update-InstanceGrid reads host state itself ({1})" -f $c.Extent.StartLineNumber, $cn))
            }
        }
        if (@($gridCmds | Where-Object { [string]$_.GetCommandName() -eq 'Get-SqlStackGuiTcpText' }).Count -eq 0) {
            [void]$d5.Add('Update-InstanceGrid does not render TCP through Get-SqlStackGuiTcpText, so TCP is not shown in words')
        }
    }
    & $add 'D5-grid-one-source' 'the Instances grid shows TCP in words from the engine''s facts and reads no host state of its own' $d5.ToArray() $d5Checked
    # The engine's port map is called exactly once, where the host facts are
    # gathered, so the grid and the planner read ONE object.
    $pmCalls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'Get-KnownInstancePortMap') }, $true) |
            Where-Object { & $product $_ })
    & $add 'D5-port-map-once' 'the engine''s Get-KnownInstancePortMap is called at exactly one product site' `
        @($(if ($pmCalls.Count -ne 1) { ('{0} product call site(s) of Get-KnownInstancePortMap, at line(s) {1}' -f $pmCalls.Count, (@($pmCalls | ForEach-Object { $_.Extent.StartLineNumber }) -join ', ')) })) $pmCalls.Count

    # ---- D1: an installed instance is a constraint on EVERY path ----
    $clickBody = {
        param([string]$VarName)
        $calls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.InvokeMemberExpressionAst]) -and
                    ([string]$n.Expression.Extent.Text -eq ('$' + $VarName)) -and ([string]$n.Member.Extent.Text -eq 'Add_Click') }, $true))
        return @($calls | ForEach-Object { @($_.Arguments) } | Where-Object { $_ -is [System.Management.Automation.Language.ScriptBlockExpressionAst] })
    }
    $cmdNamesIn = { param($node) @($node.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true) | ForEach-Object { [string]$_.GetCommandName() }) }
    $fixedReadsIn = { param($node) @($node.FindAll({ param($n) ($n -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$n.Member.Extent.Text -eq 'Fixed') }, $true)) }
    # RETARGETED 2026-11-03 (lane sqlstack-workbench, finding 4), INVARIANT
    # UNCHANGED: 'Import existing' is gone; every installed instance is loaded
    # automatically by the ONE loader Add-SqlStackGuiInstalledRows, which must
    # build Fixed rows and be called by the product.
    $d1a = New-Object System.Collections.ArrayList
    $imp = @(); if ($fnDef.ContainsKey('Add-SqlStackGuiInstalledRows')) { $imp = @($fnDef['Add-SqlStackGuiInstalledRows']) }
    if ($imp.Count -ne 1) { [void]$d1a.Add(("{0} installed-rows loader(s) (Add-SqlStackGuiInstalledRows), not 1" -f $imp.Count)) }
    foreach ($sb in $imp) {
        $names = @(& $cmdNamesIn $sb)
        if ($names -notcontains 'New-PlanRowFromInstalled') { [void]$d1a.Add(("line {0}: the installed-rows loader does not build its rows with New-PlanRowFromInstalled" -f $sb.Extent.StartLineNumber)) }
        if ($names -contains 'New-PlanRowFromName') { [void]$d1a.Add(("line {0}: the installed-rows loader builds an installed instance with New-PlanRowFromName, i.e. as a NEW install" -f $sb.Extent.StartLineNumber)) }
    }
    $impCalls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'Add-SqlStackGuiInstalledRows') }, $true) | Where-Object { & $product $_ })
    if (($imp.Count -eq 1) -and ($impCalls.Count -eq 0)) { [void]$d1a.Add('nothing calls Add-SqlStackGuiInstalledRows, so installed instances never join the plan') }
    if (-not $fnDef.ContainsKey('New-PlanRowFromInstalled')) { [void]$d1a.Add('New-PlanRowFromInstalled is not in the syntax tree') }
    else {
        $fxKv = @($fnDef['New-PlanRowFromInstalled'].FindAll({ param($n) $n -is [System.Management.Automation.Language.HashtableAst] }, $true) | ForEach-Object { @($_.KeyValuePairs) } |
                Where-Object { ([string]$_.Item1.Extent.Text -eq 'Fixed') -and ([string]$_.Item2.Extent.Text -eq '$true') })
        if ($fxKv.Count -ne 1) { [void]$d1a.Add(('New-PlanRowFromInstalled sets Fixed = $true {0} time(s), not once' -f $fxKv.Count)) }
    }
    & $add 'D1-import-builds-fixed' 'every installed instance is loaded automatically by Add-SqlStackGuiInstalledRows as a Fixed row (New-PlanRowFromInstalled, Fixed = $true)' $d1a.ToArray() $imp.Count

    $d1b = New-Object System.Collections.ArrayList
    $renderers = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and (@('New-ConfigurationIni', 'New-PostInstallSql') -contains [string]$n.GetCommandName()) }, $true) |
            Where-Object { & $product $_ })
    foreach ($r in $renderers) {
        if (-not (& $inFn $r 'Get-SqlStackGuiFileSet')) { [void]$d1b.Add(("line {0}: {1} is called outside Get-SqlStackGuiFileSet, the one place that skips installed rows" -f $r.Extent.StartLineNumber, $r.GetCommandName())) }
    }
    if ($renderers.Count -eq 0) { [void]$d1b.Add('no product call of New-ConfigurationIni or New-PostInstallSql: nothing was checked') }
    if (-not $fnDef.ContainsKey('Get-SqlStackGuiFileSet')) { [void]$d1b.Add('Get-SqlStackGuiFileSet is not in the syntax tree') }
    elseif (@(& $fixedReadsIn $fnDef['Get-SqlStackGuiFileSet']).Count -eq 0) { [void]$d1b.Add('Get-SqlStackGuiFileSet never reads a row''s Fixed marker') }
    & $add 'D1-fixed-never-rendered' 'no ini or post-install SQL is rendered outside the one function that skips installed rows' $d1b.ToArray() $renderers.Count

    $d1c = New-Object System.Collections.ArrayList
    $d1cChecked = 0
    foreach ($fnName in @('Save-DetailToPlan', 'Load-PlanToDetail', 'Test-SqlStackPlan', 'Get-SqlStackGuiPlanComputation', 'Invoke-SqlStackGuiPlanUpdate')) {
        if (-not $fnDef.ContainsKey($fnName)) { [void]$d1c.Add(("{0} is not in the syntax tree" -f $fnName)); continue }
        $d1cChecked++
        if (@(& $fixedReadsIn $fnDef[$fnName]).Count -eq 0) { [void]$d1c.Add(("{0} never reads a row's Fixed marker, so it treats an installed instance as a new one" -f $fnName)) }
    }
    & $add 'D1-every-path-knows-fixed' 'the editor, the detail view, the validator, the computation and the write-back each read the Fixed marker' $d1c.ToArray() $d1cChecked

    # ---- D4: one planner site; every validator call gets every argument; the arithmetic is shown ----
    $d4a = New-Object System.Collections.ArrayList
    $plCalls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and (@('Get-SqlStackPortPlan', 'Get-SqlStackMemoryPlan') -contains [string]$n.GetCommandName()) }, $true) |
            Where-Object { & $product $_ })
    foreach ($pl in @('Get-SqlStackPortPlan', 'Get-SqlStackMemoryPlan')) {
        $cs = @($plCalls | Where-Object { [string]$_.GetCommandName() -eq $pl })
        if ($cs.Count -ne 1) { [void]$d4a.Add(("{0} has {1} product call site(s) (line(s) {2}), not 1" -f $pl, $cs.Count, (@($cs | ForEach-Object { $_.Extent.StartLineNumber }) -join ', '))) }
        foreach ($c in $cs) {
            if (-not (& $inFn $c 'Get-SqlStackGuiPlanComputation')) { [void]$d4a.Add(("line {0}: {1} is called outside Get-SqlStackGuiPlanComputation" -f $c.Extent.StartLineNumber, $pl)) }
            $pn = @($c.CommandElements | Where-Object { $_ -is [System.Management.Automation.Language.CommandParameterAst] } | ForEach-Object { $_.ParameterName })
            if ($pn -notcontains 'FixedInstances') { [void]$d4a.Add(("line {0}: {1} is called without -FixedInstances" -f $c.Extent.StartLineNumber, $pl)) }
            if (($pl -eq 'Get-SqlStackPortPlan') -and ($pn -notcontains 'KnownInstancePorts')) { [void]$d4a.Add(("line {0}: the port planner is called without -KnownInstancePorts" -f $c.Extent.StartLineNumber)) }
        }
    }
    & $add 'D4-planners-one-site' 'each engine planner is called at ONE product site, inside Get-SqlStackGuiPlanComputation, with -FixedInstances (and the port planner with -KnownInstancePorts)' $d4a.ToArray() $plCalls.Count

    $d4b = New-Object System.Collections.ArrayList
    $valCalls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'Test-SqlStackPlan') }, $true) | Where-Object { & $product $_ })
    foreach ($c in $valCalls) {
        $pn = @($c.CommandElements | Where-Object { $_ -is [System.Management.Automation.Language.CommandParameterAst] } | ForEach-Object { $_.ParameterName })
        foreach ($want in @('KnownInstancePorts', 'InstalledNames', 'PortsInUse', 'ExcludedRanges', 'PhysicalMb', 'Volumes')) {
            if ($pn -notcontains $want) { [void]$d4b.Add(("line {0}: Test-SqlStackPlan is called without -{1}" -f $c.Extent.StartLineNumber, $want)) }
        }
    }
    if ($valCalls.Count -eq 0) { [void]$d4b.Add('no product call of Test-SqlStackPlan: nothing was checked') }
    & $add 'D4-validator-args' 'every product call of the validator passes every host fact the planners get' $d4b.ToArray() $valCalls.Count

    $d4c = New-Object System.Collections.ArrayList
    $shows = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.AssignmentStatementAst]) -and ($n.Left -is [System.Management.Automation.Language.MemberExpressionAst]) -and
                ([string]$n.Left.Member.Extent.Text -eq 'Text') -and (@($n.Right.FindAll({ param($m) ($m -is [System.Management.Automation.Language.CommandAst]) -and ([string]$m.GetCommandName() -eq 'Format-SqlStackGuiArithmetic') }, $true)).Count -ge 1) }, $true) |
            Where-Object { & $product $_ })
    if ($shows.Count -eq 0) { [void]$d4c.Add('no control''s Text is set from Format-SqlStackGuiArithmetic: the arithmetic is not shown') }
    $planFns = @('Update-ComputedPlan', 'Invoke-SqlStackGuiPlanUpdate', 'Get-SqlStackGuiPlanComputation', 'Get-SqlStackMemoryPlan', 'Get-SqlStackPortPlan')
    $discards = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.ConvertExpressionAst]) -and ([string]$n.Type.TypeName.Name -eq 'void') -and
                (@($n.Child.FindAll({ param($m) ($m -is [System.Management.Automation.Language.CommandAst]) -and ($planFns -contains [string]$m.GetCommandName()) }, $true)).Count -ge 1) }, $true) |
            Where-Object { & $product $_ })
    foreach ($d in $discards) { [void]$d4c.Add(("line {0}: a plan computation is discarded with [void]: '{1}'" -f $d.Extent.StartLineNumber, $d.Extent.Text)) }
    & $add 'D4-arithmetic-shown' 'the Plan tab shows the engine''s arithmetic and no product code discards a plan computation' $d4c.ToArray() ($shows.Count + $discards.Count)

    # ---- D2: the emitted files ----
    # (i)/(iv) Save writes ONLY through the writer that names each file and asks
    # before replacing: no file-writing call inside the Save handler itself.
    $d2a = New-Object System.Collections.ArrayList
    $sav = @(& $clickBody 'btnSave')
    if ($sav.Count -ne 1) { [void]$d2a.Add(("{0} Save click handler(s), not 1" -f $sav.Count)) }
    foreach ($sb in $sav) {
        if (@(& $cmdNamesIn $sb) -notcontains 'Write-SqlStackGuiFileSet') { [void]$d2a.Add(("line {0}: the Save handler does not write through Write-SqlStackGuiFileSet" -f $sb.Extent.StartLineNumber)) }
        foreach ($w in @($sb.FindAll({ param($n) (($n -is [System.Management.Automation.Language.InvokeMemberExpressionAst]) -and (@('WriteAllText', 'WriteAllLines', 'WriteAllBytes', 'AppendAllText') -contains [string]$n.Member.Extent.Text)) -or
                        (($n -is [System.Management.Automation.Language.CommandAst]) -and (@('Set-Content', 'Out-File', 'Add-Content', 'New-Item', 'Copy-Item') -contains [string]$n.GetCommandName())) }, $true))) {
            [void]$d2a.Add(("line {0}: the Save handler writes a file itself: '{1}'" -f $w.Extent.StartLineNumber, ([string]$w.Extent.Text).Split("`n")[0].Trim()))
        }
    }
    & $add 'D2-save-through-writer' 'Save writes only through Write-SqlStackGuiFileSet (one named file per new instance and kind; asks before replacing)' $d2a.ToArray() $sav.Count
    # (vi) "Has Generate run?" is asked only through Test-SqlStackGuiHasFileSet.
    # The file set is $null until Generate and @($null).Count is 1, so a bare
    # count of it compared with 0 or 1 answers "yes" before Generate (the base
    # Save handler said "The plan changed after Generate" instead of "Generate
    # first."). Structural: every comparison of a .Count over
    # $script:LastFileSet against the constant 0 or 1, plus the Save handler's
    # own call of the helper.
    $d2f = New-Object System.Collections.ArrayList
    $cnt01 = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.BinaryExpressionAst]) -and
                ($n.Left -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$n.Left.Member.Extent.Text -eq 'Count') -and
                (@($n.Left.Expression.FindAll({ param($v) ($v -is [System.Management.Automation.Language.VariableExpressionAst]) -and ($v.VariablePath.UserPath -eq 'script:LastFileSet') }, $true)).Count -ge 1) -and
                ($n.Right -is [System.Management.Automation.Language.ConstantExpressionAst]) -and (@(0, 1) -contains $n.Right.Value) }, $true) |
            Where-Object { & $product $_ })
    foreach ($c in $cnt01) { [void]$d2f.Add(("line {0}: '{1}' answers 'Generate has run' while the file set is still `$null; ask Test-SqlStackGuiHasFileSet" -f $c.Extent.StartLineNumber, $c.Extent.Text)) }
    $hasCalls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'Test-SqlStackGuiHasFileSet') }, $true) | Where-Object { & $product $_ })
    if ($hasCalls.Count -eq 0) { [void]$d2f.Add('no product code calls Test-SqlStackGuiHasFileSet') }
    foreach ($sb in $sav) {
        if (@(& $cmdNamesIn $sb) -notcontains 'Test-SqlStackGuiHasFileSet') { [void]$d2f.Add(("line {0}: the Save handler does not ask Test-SqlStackGuiHasFileSet before saving" -f $sb.Extent.StartLineNumber)) }
    }
    & $add 'D2-generate-first' '"Has Generate run?" is asked only through Test-SqlStackGuiHasFileSet (a $null file set is "not yet"), and the Save handler asks it' $d2f.ToArray() $hasCalls.Count

    # (ii) the ini's SQL Browser value is the host's, never a hard-coded override.
    $d2b = New-Object System.Collections.ArrayList
    $iniCalls = @()
    if (-not $fnDef.ContainsKey('New-ConfigurationIni')) { [void]$d2b.Add('New-ConfigurationIni is not in the syntax tree') }
    else {
        $iniCalls = @($fnDef['New-ConfigurationIni'].FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'New-SqlStackConfigurationIni') }, $true))
        if ($iniCalls.Count -ne 1) { [void]$d2b.Add(("New-ConfigurationIni calls the engine's emitter {0} time(s), not once" -f $iniCalls.Count)) }
        foreach ($c in $iniCalls) {
            $els = @($c.CommandElements)
            for ($k = 0; $k -lt $els.Count; $k++) {
                if (($els[$k] -is [System.Management.Automation.Language.CommandParameterAst]) -and ($els[$k].ParameterName -eq 'SharedBrowser')) {
                    $v = $(if ($null -ne $els[$k].Argument) { $els[$k].Argument } elseif ($k + 1 -lt $els.Count) { $els[$k + 1] } else { $null })
                    if (($v -isnot [System.Management.Automation.Language.StringConstantExpressionAst]) -or ($v.Value -ne 'observed')) {
                        [void]$d2b.Add(("line {0}: -SharedBrowser is '{1}', not the constant 'observed', so the ini can change a SHARED service" -f $c.Extent.StartLineNumber, $(if ($v) { $v.Extent.Text } else { '<none>' })))
                    }
                }
            }
            $pn = @($els | Where-Object { $_ -is [System.Management.Automation.Language.CommandParameterAst] } | ForEach-Object { $_.ParameterName })
            if ($pn -notcontains 'SharedBrowser') { [void]$d2b.Add(("line {0}: -SharedBrowser is not passed" -f $c.Extent.StartLineNumber)) }
            if ($pn -notcontains 'ObservedBrowser') { [void]$d2b.Add(("line {0}: -ObservedBrowser is not passed, so the host's SQL Browser value never reaches the ini" -f $c.Extent.StartLineNumber)) }
        }
    }
    & $add 'D2-browser-from-host' 'the ini renders the host''s own SQL Browser start mode (SharedBrowser observed + ObservedBrowser), never an override' $d2b.ToArray() $iniCalls.Count

    # (iii) the post-install script is the engine's sp_configure rendering.
    $d2c = New-Object System.Collections.ArrayList
    $pisCmds = @()
    if (-not $fnDef.ContainsKey('New-PostInstallSql')) { [void]$d2c.Add('New-PostInstallSql is not in the syntax tree') }
    else {
        $pisCmds = @(& $cmdNamesIn $fnDef['New-PostInstallSql'])
        if ($pisCmds -notcontains 'New-SqlStackSpConfigureBatch') { [void]$d2c.Add('New-PostInstallSql does not render through the engine''s New-SqlStackSpConfigureBatch') }
        # TRIPWIRE, NOT THE GUARANTEE: a character match over its string literals.
        foreach ($x in @($fnDef['New-PostInstallSql'].FindAll({ param($n) (($n -is [System.Management.Automation.Language.StringConstantExpressionAst]) -or ($n -is [System.Management.Automation.Language.ExpandableStringExpressionAst])) -and ([string]$n.Value -match '(?i)xp_(instance_)?reg') }, $true))) {
            [void]$d2c.Add(("line {0}: New-PostInstallSql emits a registry procedure (tripwire): {1}" -f $x.Extent.StartLineNumber, $x.Extent.Text))
        }
    }
    & $add 'D2-sql-engine-rendered' 'the post-install script is rendered by the engine''s sp_configure renderer and emits no registry procedure (the latter a tripwire)' $d2c.ToArray() @($pisCmds).Count

    # ---- G (stage 2): legible at every display scale, fixed at the ROOT ----
    # These rows read STRUCTURE (assignments, New-Object types, calls and their
    # offsets). They guard the CAUSES the lane's runtime census found at 150% on
    # the base: no design DPI was declared, so no pixel constant ever scaled
    # while every font grew; text sat in controls of a fixed pixel height; grid
    # headers had a fixed height. The runtime census itself (every control's
    # text measured against its space at 100/150/200%) needs a live window, so
    # it is the lane's harness evidence, not a row here.
    $varIs = { param($e, [string]$Name) ($e -is [System.Management.Automation.Language.VariableExpressionAst]) -and ([string]$e.VariablePath.UserPath -eq $Name) }
    $productAssigns = @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.AssignmentStatementAst] }, $true) | Where-Object { & $product $_ })
    $ctlType = @{}
    foreach ($a in $productAssigns) {
        if ($a.Left -isnot [System.Management.Automation.Language.VariableExpressionAst]) { continue }
        $cmd = $null
        if (($a.Right -is [System.Management.Automation.Language.PipelineAst]) -and ($a.Right.PipelineElements.Count -ge 1)) { $cmd = $a.Right.PipelineElements[0] }
        if (($cmd -isnot [System.Management.Automation.Language.CommandAst]) -or ([string]$cmd.GetCommandName() -ne 'New-Object')) { continue }
        $els = @($cmd.CommandElements)
        for ($k = 1; $k -lt $els.Count; $k++) {
            if ($els[$k] -is [System.Management.Automation.Language.CommandParameterAst]) { continue }
            if ($els[$k] -is [System.Management.Automation.Language.StringConstantExpressionAst]) { $ctlType[[string]$a.Left.VariablePath.UserPath] = ([string]$els[$k].Value -split '\.')[-1] }
            break
        }
    }
    $invokes = @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.InvokeMemberExpressionAst] }, $true) | Where-Object { & $product $_ })
    $cmdCalls = { param([string]$Name) @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq $Name) }, $true) | Where-Object { & $product $_ }) }
    $passedTo = { param($calls, [string]$VarName) @($calls | Where-Object { @($_.CommandElements | Where-Object { & $varIs $_ $VarName }).Count -ge 1 }).Count -ge 1 }

    # G1: the design DPI is declared ONCE, after every control is added to the
    # form, so ONE scaling pass sees the whole tree. (Declared earlier, the pass
    # stays pending while the tree is built and re-runs at each child
    # ResumeLayout: on 2026-10-01 a number box's minimum width was scaled nine
    # times at 150%.)
    $g1 = New-Object System.Collections.ArrayList
    $forms = @($ctlType.Keys | Where-Object { $ctlType[$_] -eq 'Form' })
    if ($forms.Count -eq 0) { [void]$g1.Add('no product variable is created as a System.Windows.Forms.Form: nothing was checked') }
    foreach ($fv in $forms) {
        $onForm = @($productAssigns | Where-Object { ($_.Left -is [System.Management.Automation.Language.MemberExpressionAst]) -and (& $varIs $_.Left.Expression $fv) })
        $asd = @($onForm | Where-Object { [string]$_.Left.Member.Extent.Text -eq 'AutoScaleDimensions' })
        $asm = @($onForm | Where-Object { [string]$_.Left.Member.Extent.Text -eq 'AutoScaleMode' })
        $adds = @($invokes | Where-Object { ($_.Expression -is [System.Management.Automation.Language.MemberExpressionAst]) -and (& $varIs $_.Expression.Expression $fv) -and
                    ([string]$_.Expression.Member.Extent.Text -eq 'Controls') -and (@('Add', 'AddRange') -contains [string]$_.Member.Extent.Text) })
        if ($asd.Count -ne 1) { [void]$g1.Add(("`${0}.AutoScaleDimensions is assigned {1} time(s), not once: without a design DPI, AutoScaleMode Dpi scales no pixel constant" -f $fv, $asd.Count)) }
        if (($asm.Count -ne 1) -or ([string]$asm[0].Right.Extent.Text -notmatch "Dpi'?$")) { [void]$g1.Add(("`${0}.AutoScaleMode is not assigned Dpi exactly once" -f $fv)) }
        if ($adds.Count -eq 0) { [void]$g1.Add(("nothing is added to `${0}.Controls" -f $fv)) }
        if (($asd.Count -eq 1) -and ($asm.Count -eq 1)) {
            $o = $asd[0].Extent.StartOffset
            if ($asm[0].Extent.StartOffset -lt $o) { [void]$g1.Add(("`${0}.AutoScaleMode is set before AutoScaleDimensions: the mode's own pass runs at factor 1 and uses up every control's pending scaling" -f $fv)) }
            foreach ($ad in $adds) {
                if ($ad.Extent.StartOffset -gt $o) { [void]$g1.Add(("line {0}: a control is added to `${1} after its design DPI is declared, so a scaling pass is pending while the tree is built" -f $ad.Extent.StartLineNumber, $fv)) }
            }
        }
    }
    & $add 'G1-autoscale-at-root' 'the form declares its design DPI once (AutoScaleDimensions, then AutoScaleMode Dpi), after every control is added, so one scaling pass scales every pixel constant with the display' $g1.ToArray() $forms.Count

    # G2: no text-bearing control, and no table row, has a constant pixel height.
    $g2 = New-Object System.Collections.ArrayList
    $g2Checked = 0
    $sizeMembers = @('Height', 'Size', 'ClientSize', 'ItemHeight', 'ColumnHeadersHeight')
    foreach ($a in $productAssigns) {
        if ($a.Left -isnot [System.Management.Automation.Language.MemberExpressionAst]) { continue }
        if ($sizeMembers -notcontains [string]$a.Left.Member.Extent.Text) { continue }
        $g2Checked++
        $root = $a.Left.Expression
        while ($root -is [System.Management.Automation.Language.MemberExpressionAst]) { $root = $root.Expression }
        $rootName = $(if ($root -is [System.Management.Automation.Language.VariableExpressionAst]) { [string]$root.VariablePath.UserPath } else { '' })
        # The window's own size is the one logical constant, and the form scales it.
        if ($rootName -and ($ctlType[$rootName] -eq 'Form')) { continue }
        if (@($a.Right.FindAll({ param($n) $n -is [System.Management.Automation.Language.VariableExpressionAst] }, $true)).Count -eq 0) {
            [void]$g2.Add(("line {0}: a constant pixel size: '{1}'" -f $a.Extent.StartLineNumber, ([string]$a.Extent.Text).Split("`n")[0].Trim()))
        }
    }
    foreach ($rs in @(& $cmdCalls 'New-Object' | Where-Object { @($_.CommandElements | Where-Object { ($_ -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$_.Value -match 'RowStyle$') }).Count -ge 1 })) {
        $g2Checked++
        $abs = @($rs.FindAll({ param($n) (($n -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ($n.Value -eq 'Absolute')) -or
                    (($n -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$n.Member.Extent.Text -eq 'Absolute')) }, $true))
        if ($abs.Count -gt 0) { [void]$g2.Add(("line {0}: a table row of a constant pixel height: '{1}'" -f $rs.Extent.StartLineNumber, $rs.Extent.Text)) }
    }
    & $add 'G2-no-fixed-text-height' 'no control but the window itself is given a constant pixel height or size, and no table row is Absolute: text-bearing controls size from their text' $g2.ToArray() $g2Checked

    # G3 / G4: every grid and every button goes through its ONE look function
    # (generation discipline 2: one shared thing, and a census that it is used).
    $oneLook = {
        param([string]$Id, [string]$Invariant, [string]$Type, [string]$Fn, [hashtable]$Want)
        $fs = New-Object System.Collections.ArrayList
        $vars = @($ctlType.Keys | Where-Object { $ctlType[$_] -eq $Type })
        $calls = @(& $cmdCalls $Fn)
        if ($vars.Count -eq 0) { [void]$fs.Add(("no product {0}: nothing was checked" -f $Type)) }
        foreach ($v in $vars) { if (-not (& $passedTo $calls $v)) { [void]$fs.Add(("`${0} is a {1} that never goes through {2}" -f $v, $Type, $Fn)) } }
        if (-not $fnDef.ContainsKey($Fn)) { if ($vars.Count -gt 0) { [void]$fs.Add(("{0} is not in the syntax tree" -f $Fn)) } }
        else {
            $inFnAssigns = @($fnDef[$Fn].FindAll({ param($n) ($n -is [System.Management.Automation.Language.AssignmentStatementAst]) -and ($n.Left -is [System.Management.Automation.Language.MemberExpressionAst]) }, $true))
            foreach ($m in $Want.Keys) {
                if (@($inFnAssigns | Where-Object { ([string]$_.Left.Member.Extent.Text -eq $m) -and ([string]$_.Right.Extent.Text -match $Want[$m]) }).Count -eq 0) {
                    [void]$fs.Add(("{0} does not set {1} to match {2}" -f $Fn, $m, $Want[$m]))
                }
            }
        }
        & $add $Id $Invariant $fs.ToArray() $vars.Count
    }
    & $oneLook 'G3-grids-one-look' 'every grid goes through Set-SqlStackGuiGridLook, which sizes its header and its rows from their fonts and shows no row headers' 'DataGridView' 'Set-SqlStackGuiGridLook' `
        @{ ColumnHeadersHeightSizeMode = "^'AutoSize'$"; AutoSizeRowsMode = "^'(AllCells|DisplayedCells)'$"; RowHeadersVisible = '^\$false$' }
    & $oneLook 'G4-buttons-one-look' 'every button goes through Initialize-SqlStackGuiButton: flat, sized from its text, coloured by its role and whether it is enabled' 'Button' 'Initialize-SqlStackGuiButton' `
        @{ AutoSize = '^\$true$'; FlatStyle = "^'Flat'$" }

    # ---- W (lane sqlstack-workbench): the workbench invariants INV-1..INV-3 ----
    # Structural: commands, member calls, New-Object types, redirections and the
    # functions they sit in. W6 alone matches characters and says so.
    $insideAny = { param($n, [string[]]$Names) foreach ($nm in $Names) { if (& $inFn $n $nm) { return $true } }; return $false }
    $callsIn = { param([string]$FnName, [string]$Callee) ($fnDef.ContainsKey($FnName)) -and (@(& $cmdNamesIn $fnDef[$FnName]) -contains $Callee) }
    $argOf = {
        # the argument a CommandAst passes to -Name (its next element, or -Name:value)
        param($Cmd, [string]$Name)
        $els = @($Cmd.CommandElements)
        for ($k = 0; $k -lt $els.Count; $k++) {
            if (($els[$k] -is [System.Management.Automation.Language.CommandParameterAst]) -and ($els[$k].ParameterName -eq $Name)) {
                if ($null -ne $els[$k].Argument) { return $els[$k].Argument }
                if ($k + 1 -lt $els.Count) { return $els[$k + 1] }
            }
        }
        return $null
    }
    $mentions = { param($node, [string[]]$Callees) ($null -ne $node) -and (@($node.FindAll({ param($m) ($m -is [System.Management.Automation.Language.CommandAst]) -and ($Callees -contains [string]$m.GetCommandName()) }, $true)).Count -ge 1) }

    # W1: every file write in product code sits in a run-folder writer, or is the named trace-log exception (K6).
    $writerFns = @('Initialize-SqlStackGuiRunFolder', 'Write-SqlStackGuiRunFile', 'Write-SqlStackGuiFileSet')
    $logFns = @('Open-SqlStackGuiLog', 'Write-SqlStackGuiLog')
    # WIDENED 2026-11-04 (gate F5): stream openers (OpenWrite on any receiver,
    # [IO.File]::Open), any .Save/.SaveAs (an image, an XML document, settings),
    # the zip writers and XmlWriter. Each is planted in -SelfTest ('workbench plant:').
    $writeMembers = @('WriteAllText', 'WriteAllLines', 'WriteAllBytes', 'AppendAllText', 'AppendAllLines', 'CreateText', 'AppendText', 'OpenWrite', 'Save', 'SaveAs',
                      'CreateFromDirectory', 'ExtractToDirectory', 'ExtractToFile', 'CreateEntryFromFile')
    $fsMembers = @('Copy', 'Move', 'Delete', 'Replace', 'Create', 'CreateDirectory', 'Encrypt', 'SetAttributes', 'Open')
    $writeCmds = @('Set-Content', 'Out-File', 'Add-Content', 'New-Item', 'Copy-Item', 'Move-Item', 'Remove-Item', 'Rename-Item', 'Clear-Content', 'Export-Csv', 'Export-Clixml', 'Tee-Object', 'Start-Transcript', 'Set-ItemProperty', 'New-ItemProperty',
                   'Compress-Archive', 'Expand-Archive')
    $w1 = New-Object System.Collections.ArrayList
    $writeSites = @($ast.FindAll({ param($n)
                (($n -is [System.Management.Automation.Language.InvokeMemberExpressionAst]) -and (($writeMembers -contains [string]$n.Member.Extent.Text) -or
                    (($fsMembers -contains [string]$n.Member.Extent.Text) -and ($n.Expression -is [System.Management.Automation.Language.TypeExpressionAst]) -and ([string]$n.Expression.TypeName.Name -match '(^|\.)(File|Directory|XmlWriter)$')))) -or
                (($n -is [System.Management.Automation.Language.CommandAst]) -and ($writeCmds -contains [string]$n.GetCommandName())) -or
                (($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'New-Object') -and (@($n.CommandElements | Where-Object { ($_ -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$_.Value -match '(StreamWriter|FileStream|BinaryWriter|XmlTextWriter)$') }).Count -ge 1)) -or
                ($n -is [System.Management.Automation.Language.FileRedirectionAst]) }, $true) | Where-Object { & $product $_ })
    foreach ($w in $writeSites) {
        if (& $insideAny $w ($writerFns + $logFns)) { continue }
        if ((& $inFn $w 'Read-SqlStackGuiText') -and ($w -is [System.Management.Automation.Language.CommandAst]) -and
            (@($w.FindAll({ param($m) ($m -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$m.Member.Extent.Text -match '^(Write|ReadWrite)$') -and ([string]$m.Expression.Extent.Text -match 'FileAccess') }, $true)).Count -eq 0)) { continue }
        [void]$w1.Add(("line {0}: a file write outside the run-folder writers ({1}): '{2}'" -f $w.Extent.StartLineNumber, (($writerFns + $logFns) -join ', '), ([string]$w.Extent.Text).Split("`n")[0].Trim()))
    }
    if ($writeSites.Count -eq 0) { [void]$w1.Add('no file write found in product code: nothing was checked') }
    & $add 'W1-writes-through-run-folder' 'every file write in the product sits in a run-folder writer (Initialize-SqlStackGuiRunFolder, Write-SqlStackGuiRunFile, Write-SqlStackGuiFileSet) or is the named trace-log exception (Open-SqlStackGuiLog, Write-SqlStackGuiLog); Read-SqlStackGuiText opens files read-only' $w1.ToArray() $writeSites.Count

    # W2: the writers take their path from the ONE resolver, and every export goes into the run folder.
    $w2 = New-Object System.Collections.ArrayList
    $w2Checked = 0
    foreach ($fnName in @('Initialize-SqlStackGuiRunFolder', 'Write-SqlStackGuiRunFile')) {
        $w2Checked++
        if (-not $fnDef.ContainsKey($fnName)) { [void]$w2.Add(("{0} is not in the syntax tree" -f $fnName)); continue }
        if (-not (& $callsIn $fnName 'Get-SqlStackGuiRunPath')) { [void]$w2.Add(("{0} does not take its path from Get-SqlStackGuiRunPath" -f $fnName)) }
    }
    foreach ($c in @(& $cmdCalls 'Write-SqlStackGuiFileSet')) {
        $w2Checked++
        if (-not (& $mentions (& $argOf $c 'Folder') @('Get-SqlStackGuiRunPath', 'Initialize-SqlStackGuiRunFolder'))) {
            [void]$w2.Add(("line {0}: Write-SqlStackGuiFileSet is given a -Folder that does not come from the run folder" -f $c.Extent.StartLineNumber))
        }
    }
    # WIDENED 2026-11-04 (gate F6): -Root must BE the open run folder. Every call of
    # a run-folder writer passes $script:WbRoot, except where one writer calls the
    # other with its own -Root, and Set-SqlStackGuiRunFolder, which opens the folder
    # and is the one function that sets $script:WbRoot (besides the start-up line).
    $rootOpener = 'Set-SqlStackGuiRunFolder'
    foreach ($wfn in @('Write-SqlStackGuiRunFile', 'Initialize-SqlStackGuiRunFolder')) {
        foreach ($c in @(& $cmdCalls $wfn)) {
            if (& $insideAny $c $writerFns) { continue }
            $w2Checked++
            $ra = & $argOf $c 'Root'
            if ($null -eq $ra) { [void]$w2.Add(("line {0}: {1} is called without -Root" -f $c.Extent.StartLineNumber, $wfn)); continue }
            if (& $inFn $c $rootOpener) { continue }
            if (-not (& $varIs $ra 'script:WbRoot')) { [void]$w2.Add(("line {0}: {1} -Root is not the open run folder (`$script:WbRoot): '{2}'" -f $c.Extent.StartLineNumber, $wfn, $ra.Extent.Text)) }
        }
    }
    foreach ($a in @($productAssigns | Where-Object { & $varIs $_.Left 'script:WbRoot' })) {
        $w2Checked++
        $inAFn = $false; for ($p = $a.Parent; $null -ne $p; $p = $p.Parent) { if ($p -is [System.Management.Automation.Language.FunctionDefinitionAst]) { $inAFn = $true; break } }
        if ($inAFn -and (-not (& $inFn $a $rootOpener))) { [void]$w2.Add(("line {0}: `$script:WbRoot is assigned outside {1}, so the run folder can be re-pointed without opening it" -f $a.Extent.StartLineNumber, $rootOpener)) }
    }
    & $add 'W2-writers-resolve-here' 'the run-folder writers resolve every path through Get-SqlStackGuiRunPath, and every product export passes a -Folder from the run folder' $w2.ToArray() $w2Checked

    # W3: the trace log opens once outside a run folder (start-up, K6) and moves to <run>\window.log.
    $w3 = New-Object System.Collections.ArrayList
    $logOpens = @(& $cmdCalls 'Open-SqlStackGuiLog')
    $topOpens = @($logOpens | Where-Object { $null -eq (& { param($n) for ($p = $n.Parent; $null -ne $p; $p = $p.Parent) { if ($p -is [System.Management.Automation.Language.FunctionDefinitionAst]) { return $p } }; return $null } $_) })
    if ($topOpens.Count -ne 1) { [void]$w3.Add(("{0} start-up opening(s) of the trace log outside a function, not 1" -f $topOpens.Count)) }
    $runOpens = @($logOpens | Where-Object { $topOpens -notcontains $_ })
    foreach ($c in $runOpens) {
        $pa = & $argOf $c 'Path'
        if (-not (& $mentions $pa @('Get-SqlStackGuiRunPath'))) { [void]$w3.Add(("line {0}: the trace log is opened at a path that is not the run folder's window.log" -f $c.Extent.StartLineNumber)) }
    }
    & $add 'W3-log-moves-to-run' 'the trace log is opened once at start-up (the one named exception, K6) and otherwise only at <run>\window.log, from Get-SqlStackGuiRunPath' $w3.ToArray() $logOpens.Count

    # W4: the stage table is read only by the command builder and the stage reader; the drawer's command box is written only from the builder.
    $w4 = New-Object System.Collections.ArrayList
    $tableCalls = @(& $cmdCalls 'Get-SqlStackGuiStageTable')
    foreach ($c in $tableCalls) {
        if (-not (& $insideAny $c @('Get-SqlStackGuiCommand', 'Get-SqlStackGuiRunState'))) { [void]$w4.Add(("line {0}: the stage table is read outside the command builder and the stage reader" -f $c.Extent.StartLineNumber)) }
    }
    if (-not (& $callsIn 'Get-SqlStackGuiCommand' 'Get-SqlStackGuiStageTable')) { [void]$w4.Add('Get-SqlStackGuiCommand does not read Get-SqlStackGuiStageTable') }
    $cmdBoxSets = @($productAssigns | Where-Object { ($_.Left -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$_.Left.Member.Extent.Text -eq 'Text') -and
                (& $varIs $_.Left.Expression 'txtCommand') })
    foreach ($a in $cmdBoxSets) {
        if (-not (& $inFn $a 'Update-SqlStackGuiDrawer')) { [void]$w4.Add(("line {0}: the drawer's command box is written outside Update-SqlStackGuiDrawer" -f $a.Extent.StartLineNumber)) }
    }
    if (($cmdBoxSets.Count -gt 0) -and (-not (& $callsIn 'Update-SqlStackGuiDrawer' 'Get-SqlStackGuiCommand'))) { [void]$w4.Add('Update-SqlStackGuiDrawer does not build its command through Get-SqlStackGuiCommand') }
    & $add 'W4-one-command-builder' 'the stage table is read only by Get-SqlStackGuiCommand and Get-SqlStackGuiRunState, and the drawer''s command box is written only by Update-SqlStackGuiDrawer from Get-SqlStackGuiCommand' $w4.ToArray() ($tableCalls.Count + $cmdBoxSets.Count)

    # W5: the clipboard is written only through the builder.
    $w5 = New-Object System.Collections.ArrayList
    $clip = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.TypeExpressionAst]) -and ([string]$n.TypeName.Name -match '(^|\.)Clipboard$') }, $true) | Where-Object { & $product $_ })
    foreach ($c in $clip) { if (-not (& $inFn $c 'Copy-SqlStackGuiCommand')) { [void]$w5.Add(("line {0}: the clipboard is used outside Copy-SqlStackGuiCommand" -f $c.Extent.StartLineNumber)) } }
    # WIDENED 2026-11-04 (gate F5): the clipboard COMMANDS too, not only the
    # Clipboard type. Planted in -SelfTest ('workbench plant: W5 sees ...').
    $clipCmds = @(@('Set-Clipboard', 'scb', 'clip', 'clip.exe') | ForEach-Object { & $cmdCalls $_ })
    foreach ($c in $clipCmds) { if (-not (& $inFn $c 'Copy-SqlStackGuiCommand')) { [void]$w5.Add(("line {0}: the clipboard is written outside Copy-SqlStackGuiCommand ({1})" -f $c.Extent.StartLineNumber, $c.GetCommandName())) } }
    $clip = @($clip) + @($clipCmds)
    if (-not $fnDef.ContainsKey('Copy-SqlStackGuiCommand')) { [void]$w5.Add('Copy-SqlStackGuiCommand is not in the syntax tree') }
    else {
        if (-not (& $callsIn 'Copy-SqlStackGuiCommand' 'Get-SqlStackGuiCommand')) { [void]$w5.Add('Copy-SqlStackGuiCommand does not take its text from Get-SqlStackGuiCommand') }
        $cpParams = @(@($fnDef['Copy-SqlStackGuiCommand'].FindAll({ param($n) $n -is [System.Management.Automation.Language.ParameterAst] }, $true)) | ForEach-Object { [string]$_.Name.VariablePath.UserPath })
        if ($cpParams -contains 'Text') { [void]$w5.Add('Copy-SqlStackGuiCommand takes a -Text parameter, so a caller could hand it any text') }
    }
    & $add 'W5-clipboard-through-builder' 'every clipboard write is inside Copy-SqlStackGuiCommand, which takes no text and copies only what Get-SqlStackGuiCommand built' $w5.ToArray() ($clip.Count + 1)

    # W6: TRIPWIRE, NOT THE GUARANTEE (W4/W5 are): a character match over product
    # string literals for the shape of a command line ('<x>.ps1 -Param' or '-PlanHash').
    $cmdShape = '(?i)(-PlanHash\b|\.ps1[''"]?\s+-[A-Za-z])'
    $cmdLits = @($ast.FindAll({ param($n) (($n -is [System.Management.Automation.Language.StringConstantExpressionAst]) -or ($n -is [System.Management.Automation.Language.ExpandableStringExpressionAst])) -and ([string]$n.Value -match $cmdShape) }, $true) |
            Where-Object { (& $product $_) -and (-not (& $insideAny $_ @('Get-SqlStackGuiStageTable', 'Get-SqlStackGuiCommand', 'Get-SqlStackGuiCompareBlock'))) })
    & $add 'W6-no-command-text-elsewhere (tripwire)' 'no product string literal outside the stage table and the builder is shaped like a command line (a character match over string literals, not a structural guarantee)' `
        @($cmdLits | ForEach-Object { "line {0}: {1}" -f $_.Extent.StartLineNumber, $_.Extent.Text }) @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.StringConstantExpressionAst] }, $true)).Count

    # W7: ONE stage reader. The per-stage readers are called only by Get-SqlStackGuiRunState.
    $w7 = New-Object System.Collections.ArrayList
    $readerNames = @('Get-SqlStackGuiPlanSet', 'Get-SqlStackGuiApplyState', 'Get-SqlStackGuiVerifyState', 'Read-SqlStackGuiSnapshot', 'Read-SqlStackGuiSpecFile')
    $readerCalls = @($ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ($readerNames -contains [string]$n.GetCommandName()) }, $true) | Where-Object { & $product $_ })
    foreach ($c in $readerCalls) {
        if (-not (& $inFn $c 'Get-SqlStackGuiRunState')) { [void]$w7.Add(("line {0}: {1} is called outside Get-SqlStackGuiRunState, so a stage could be judged by a second reader" -f $c.Extent.StartLineNumber, $c.GetCommandName())) }
    }
    foreach ($rn in $readerNames) { if (@($readerCalls | Where-Object { [string]$_.GetCommandName() -eq $rn }).Count -eq 0) { [void]$w7.Add(("{0} is never called by the stage reader" -f $rn)) } }
    & $add 'W7-one-stage-reader' 'every per-stage reader (plan set, apply, verify, snapshot, spec) is called only by Get-SqlStackGuiRunState, the ONE stage reader' $w7.ToArray() $readerCalls.Count

    # ---- I (2026-11-16, the Install screen): INV-5 and INV-6 ----
    # I1: a process is started by two functions and nothing else. Structural:
    # spawning commands, every .Start( member call, every use of the process
    # types (a type expression or a New-Object argument). WHAT IT DOES NOT
    # READ: the C# inside Initialize-SqlStackGuiWorkerHost's Add-Type, which is
    # a string to this parser; so the row also holds that Add-Type
    # -TypeDefinition appears only there and at the top-level DPI helper.
    $starterFns = @('Start-SqlStackGuiInstallWorker', 'Start-SqlStackGuiElevatedWindow')
    $spawnCmds = @('Start-Process', 'saps', 'Invoke-Item', 'ii', 'Start-Job', 'Invoke-Expression', 'iex', 'Invoke-WmiMethod', 'Invoke-CimMethod',
                   'cmd', 'cmd.exe', 'powershell', 'powershell.exe', 'pwsh', 'pwsh.exe', 'setup', 'setup.exe', 'msiexec', 'msiexec.exe', 'sc', 'sc.exe')
    $procTypeRe = '(^|\.)(Process|ProcessStartInfo|SqlStackGuiWorkerProcess)$'
    $i1 = New-Object System.Collections.ArrayList
    $startSites = @($ast.FindAll({ param($n)
                (($n -is [System.Management.Automation.Language.CommandAst]) -and ($spawnCmds -contains [string]$n.GetCommandName())) -or
                (($n -is [System.Management.Automation.Language.InvokeMemberExpressionAst]) -and ([string]$n.Member.Extent.Text -eq 'Start')) -or
                (($n -is [System.Management.Automation.Language.TypeExpressionAst]) -and ([string]$n.TypeName.Name -match $procTypeRe)) -or
                (($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'New-Object') -and
                    (@($n.CommandElements | Where-Object { ($_ -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$_.Value -match $procTypeRe) }).Count -ge 1)) }, $true) |
            Where-Object { & $product $_ })
    foreach ($s in $startSites) {
        if (-not (& $insideAny $s $starterFns)) { [void]$i1.Add(("line {0}: a process is started (or a process type is used) outside {1}: '{2}'" -f $s.Extent.StartLineNumber, ($starterFns -join ' and '), ([string]$s.Extent.Text).Split("`n")[0].Trim())) }
    }
    $fileLits = { param($node) @($node.FindAll({ param($m) ($m -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$m.Value -match '(?i)\.(ps1|exe|cmd|bat|msi)$') }, $true) | ForEach-Object { [string]$_.Value }) }
    foreach ($sf in $starterFns) { if (-not $fnDef.ContainsKey($sf)) { [void]$i1.Add(("{0} is not in the syntax tree" -f $sf)) } }
    if (-not $fnDef.ContainsKey('Get-SqlStackGuiWorkerPath')) { [void]$i1.Add('Get-SqlStackGuiWorkerPath is not in the syntax tree') }
    else {
        $wl = @(& $fileLits $fnDef['Get-SqlStackGuiWorkerPath'])
        if (($wl -join '|') -cne 'SqlStack-Install.ps1') { [void]$i1.Add(("Get-SqlStackGuiWorkerPath names [{0}], not exactly SqlStack-Install.ps1" -f ($wl -join ', '))) }
    }
    if ($fnDef.ContainsKey('Start-SqlStackGuiInstallWorker')) {
        if (-not (& $callsIn 'Start-SqlStackGuiInstallWorker' 'Get-SqlStackGuiWorkerPath')) { [void]$i1.Add('Start-SqlStackGuiInstallWorker does not take the worker from Get-SqlStackGuiWorkerPath') }
        $sl = @(& $fileLits $fnDef['Start-SqlStackGuiInstallWorker'] | Where-Object { $_ -cne 'powershell.exe' })
        if ($sl.Count -gt 0) { [void]$i1.Add(("Start-SqlStackGuiInstallWorker names a file of its own to start: {0}" -f ($sl -join ', '))) }
    }
    if ($fnDef.ContainsKey('Start-SqlStackGuiElevatedWindow')) {
        $el = @(& $fileLits $fnDef['Start-SqlStackGuiElevatedWindow'] | Where-Object { $_ -cne 'powershell.exe' })
        if ($el.Count -gt 0) { [void]$i1.Add(("Start-SqlStackGuiElevatedWindow names a file of its own to start: {0}" -f ($el -join ', '))) }
        if (@($fnDef['Start-SqlStackGuiElevatedWindow'].FindAll({ param($m) ($m -is [System.Management.Automation.Language.VariableExpressionAst]) -and ($m.VariablePath.UserPath -eq 'script:EntryScriptPath') }, $true)).Count -eq 0) {
            [void]$i1.Add('Start-SqlStackGuiElevatedWindow does not start $script:EntryScriptPath (this script)')
        }
    }
    $typeDefs = @(& $cmdCalls 'Add-Type' | Where-Object { @($_.CommandElements | Where-Object { ($_ -is [System.Management.Automation.Language.CommandParameterAst]) -and ($_.ParameterName -eq 'TypeDefinition') }).Count -ge 1 })
    foreach ($td in $typeDefs) {
        $tdFn = $null; for ($p = $td.Parent; $null -ne $p; $p = $p.Parent) { if ($p -is [System.Management.Automation.Language.FunctionDefinitionAst]) { $tdFn = $p; break } }
        if (($null -ne $tdFn) -and ([string]$tdFn.Name -ne 'Initialize-SqlStackGuiWorkerHost')) { [void]$i1.Add(("line {0}: compiled code (Add-Type -TypeDefinition) inside {1}; only Initialize-SqlStackGuiWorkerHost may hold it" -f $td.Extent.StartLineNumber, $tdFn.Name)) }
    }
    if (@($typeDefs | Where-Object { $tf = $false; for ($p = $_.Parent; $null -ne $p; $p = $p.Parent) { if ($p -is [System.Management.Automation.Language.FunctionDefinitionAst]) { $tf = $true; break } }; -not $tf }).Count -gt 1) {
        [void]$i1.Add('more than one top-level Add-Type -TypeDefinition (the DPI helper is the only one)')
    }
    $workerCalls = @(& $cmdCalls 'Start-SqlStackGuiInstallWorker')
    foreach ($c in $workerCalls) {
        if ($null -ne (& $argOf $c 'HarnessSetupExe')) { [void]$i1.Add(("line {0}: product code passes the test-only -HarnessSetupExe to the worker" -f $c.Extent.StartLineNumber)) }
    }
    & $add 'I1-process-starts' 'a process is started by exactly two functions: Start-SqlStackGuiInstallWorker, which starts only SqlStack-Install.ps1 from this script''s own folder (Get-SqlStackGuiWorkerPath), and Start-SqlStackGuiElevatedWindow, which starts only this script again as administrator; compiled code sits only in Initialize-SqlStackGuiWorkerHost and the DPI helper; no product call passes the test-only -HarnessSetupExe' $i1.ToArray() ($startSites.Count + $typeDefs.Count + $workerCalls.Count)

    # I2: a REAL install starts at one place, after the one decision.
    # WIDENED 2026-11-17 (the restart of Windows; the owner's ruling). Until
    # then the row read "every other start of it is the constant Preview
    # mode". The worker now has two more modes that change the machine, and
    # each has ONE home, held here: the constant Restart only inside a script
    # block handed to Invoke-SqlStackGuiWindowsRestart (which runs it only
    # after its one confirm) in Invoke-SqlStackGuiRestartNow, and the constant
    # ForgetResume only in Clear-SqlStackGuiResume. Install and a mode that is
    # not a constant are judged exactly as before.
    $i2 = New-Object System.Collections.ArrayList
    foreach ($c in $workerCalls) {
        $ma = & $argOf $c 'Mode'
        $isPreview = ($null -eq $ma) -or (($ma -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$ma.Value -ceq 'Preview'))
        if ($isPreview) { continue }
        $modeConst = $(if ($ma -is [System.Management.Automation.Language.StringConstantExpressionAst]) { [string]$ma.Value } else { '' })
        if ($modeConst -ceq 'Restart') {
            $inConfirmed = $false
            for ($p = $c.Parent; $null -ne $p; $p = $p.Parent) {
                if (($p -is [System.Management.Automation.Language.CommandAst]) -and ([string]$p.GetCommandName() -eq 'Invoke-SqlStackGuiWindowsRestart')) { $inConfirmed = $true; break }
            }
            if ((-not $inConfirmed) -or (-not (& $inFn $c 'Invoke-SqlStackGuiRestartNow'))) {
                [void]$i2.Add(("line {0}: the worker is started in mode Restart outside the script block Invoke-SqlStackGuiRestartNow hands to Invoke-SqlStackGuiWindowsRestart, so Windows could restart with no confirm" -f $c.Extent.StartLineNumber))
            }
        }
        elseif ($modeConst -ceq 'ForgetResume') {
            if (-not (& $inFn $c 'Clear-SqlStackGuiResume')) { [void]$i2.Add(("line {0}: the worker is started in mode ForgetResume outside Clear-SqlStackGuiResume" -f $c.Extent.StartLineNumber)) }
        }
        elseif (-not (& $inFn $c 'Invoke-SqlStackGuiInstallNow')) {
            [void]$i2.Add(("line {0}: the worker is started in a mode that is not the constant Preview, outside Invoke-SqlStackGuiInstallNow" -f $c.Extent.StartLineNumber))
        }
    }
    if ($workerCalls.Count -eq 0) { [void]$i2.Add('no product call of Start-SqlStackGuiInstallWorker: nothing was checked') }
    if (-not $fnDef.ContainsKey('Invoke-SqlStackGuiInstallNow')) { [void]$i2.Add('Invoke-SqlStackGuiInstallNow is not in the syntax tree') }
    elseif (-not (& $callsIn 'Invoke-SqlStackGuiInstallNow' 'Get-SqlStackGuiInstallAction')) { [void]$i2.Add('Invoke-SqlStackGuiInstallNow does not ask Get-SqlStackGuiInstallAction before it starts the worker') }
    & $add 'I2-install-one-place' 'the install worker is started for a real install at one place, Invoke-SqlStackGuiInstallNow, which asks Get-SqlStackGuiInstallAction first (elevated, a preview with no problem); to restart Windows at one place, inside the script block Invoke-SqlStackGuiRestartNow hands to Invoke-SqlStackGuiWindowsRestart, which runs it only after its one confirm; to remove the resume task only in Clear-SqlStackGuiResume; every other start of it is the constant Preview mode, which changes nothing' $i2.ToArray() $workerCalls.Count

    # V1 (gate F1, 2026-11-04): a control BORN HIDDEN that is later given text is
    # also made visible somewhere. The drawer note carried the elevation line and
    # the builder's "why no command" for a whole lane while it stayed hidden: an
    # empty -Subtitle makes New-SqlStackGuiCard hide its subtitle, and the drawer
    # only ever set .Text. Born hidden = a product '$x.Visible = $false', or
    # '$x = $card.Subtitle' where $card came from New-SqlStackGuiCard with no
    # -Subtitle or an empty one. Structural (assignments and a call's arguments).
    # It proves a showing assignment EXISTS ('$x.Visible = ' anything but the
    # constant $false), not that it runs on every path.
    $rightExpr = { param($a) $r = $a.Right; if ($r -is [System.Management.Automation.Language.CommandExpressionAst]) { return $r.Expression }; if (($r -is [System.Management.Automation.Language.PipelineAst]) -and ($r.PipelineElements.Count -eq 1) -and ($r.PipelineElements[0] -is [System.Management.Automation.Language.CommandExpressionAst])) { return $r.PipelineElements[0].Expression }; return $null }
    $emptySubCards = @{}
    foreach ($a in $productAssigns) {
        if ($a.Left -isnot [System.Management.Automation.Language.VariableExpressionAst]) { continue }
        if (($a.Right -isnot [System.Management.Automation.Language.PipelineAst]) -or ($a.Right.PipelineElements.Count -lt 1)) { continue }
        $cc = $a.Right.PipelineElements[0]
        if (($cc -isnot [System.Management.Automation.Language.CommandAst]) -or ([string]$cc.GetCommandName() -ne 'New-SqlStackGuiCard')) { continue }
        $sa = & $argOf $cc 'Subtitle'
        if (($null -eq $sa) -or (($sa -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$sa.Value -eq ''))) { $emptySubCards[[string]$a.Left.VariablePath.UserPath] = $a.Extent.StartLineNumber }
    }
    $bornHidden = [ordered]@{}
    foreach ($a in $productAssigns) {
        if (($a.Left -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$a.Left.Member.Extent.Text -eq 'Visible') -and
            ($a.Left.Expression -is [System.Management.Automation.Language.VariableExpressionAst]) -and ([string]$a.Right.Extent.Text -eq '$false')) {
            $vn = [string]$a.Left.Expression.VariablePath.UserPath
            if (-not $bornHidden.Contains($vn)) { $bornHidden[$vn] = ('Visible = $false at line {0}' -f $a.Extent.StartLineNumber) }
            continue
        }
        if ($a.Left -isnot [System.Management.Automation.Language.VariableExpressionAst]) { continue }
        $rx = & $rightExpr $a
        if (($rx -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$rx.Member.Extent.Text -eq 'Subtitle') -and
            ($rx.Expression -is [System.Management.Automation.Language.VariableExpressionAst]) -and $emptySubCards.ContainsKey([string]$rx.Expression.VariablePath.UserPath)) {
            $vn = [string]$a.Left.VariablePath.UserPath
            if (-not $bornHidden.Contains($vn)) { $bornHidden[$vn] = ('the empty subtitle of ${0} (line {1}), which New-SqlStackGuiCard hides' -f $rx.Expression.VariablePath.UserPath, $emptySubCards[[string]$rx.Expression.VariablePath.UserPath]) }
        }
    }
    $v1 = New-Object System.Collections.ArrayList
    $v1Checked = 0
    $memberSetsOn = { param([string]$Var, [string]$Member) @($productAssigns | Where-Object { ($_.Left -is [System.Management.Automation.Language.MemberExpressionAst]) -and ([string]$_.Left.Member.Extent.Text -eq $Member) -and (& $varIs $_.Left.Expression $Var) }) }
    foreach ($vn in @($bornHidden.Keys)) {
        $texts = @(& $memberSetsOn $vn 'Text')
        if ($texts.Count -eq 0) { continue }
        $v1Checked++
        $shows = @(& $memberSetsOn $vn 'Visible' | Where-Object { [string]$_.Right.Extent.Text -ne '$false' })
        if ($shows.Count -eq 0) {
            [void]$v1.Add(("`${0} is born hidden ({1}) and given text at line(s) {2}, but is never made visible: its text is never shown" -f $vn, $bornHidden[$vn], ((@($texts) | ForEach-Object { $_.Extent.StartLineNumber }) -join ', ')))
        }
    }
    & $add 'V1-hidden-text-shown' 'every control that is born hidden (Visible = $false, or a card subtitle given no text) and later given text is also made visible somewhere' $v1.ToArray() $v1Checked

    # Unrolled on purpose: a ',$rows' return wraps the array a second time under
    # the caller's @() (the shape defect this file's Update-HostFacts documents).
    return $rows.ToArray()
}

# ===========================================================================
# STRUCTURAL CENSUS of this file's own WinForms property literals.
#
# INVARIANT: every string literal assigned to a control property must be a
# member of that property's type when that type is an enum.
#
# PROVED 2026-09-17: $gridVols.BorderStyle = 'SingleLine' threw at form
# construction. DataGridView.BorderStyle is a BorderStyle (None, FixedSingle,
# Fixed3D); SingleLine is a DataGridViewCellBorderStyle. The form had never
# been constructed on this box, so nothing caught it - and one corrected line
# would not stop the next one.
#
# This enumerates from the SYNTAX TREE and resolves each property by
# REFLECTION, so it is the guarantee and not a tripwire: it reads structure,
# never characters, and a line-wrapped or re-spaced assignment is still seen.
# Its own ability to see the defect is proved by a specimen in -SelfTest.
# ===========================================================================
function Test-WinFormsPropertyLiteral {
    param([string]$ScriptPath)

    $findings = New-Object System.Collections.ArrayList
    $checked = 0
    $ast = [System.Management.Automation.Language.Parser]::ParseFile($ScriptPath, [ref]$null, [ref]$null)
    if ($null -eq $ast) {
        [void]$findings.Add("could not parse $ScriptPath")
        return [pscustomobject]@{ Checked = 0; Findings = $findings.ToArray() }
    }
    $assigns = @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.AssignmentStatementAst] }, $true))

    # Pass 1: variable -> the type its New-Object created.
    $types = @{}
    foreach ($a in $assigns) {
        if ($a.Left -isnot [System.Management.Automation.Language.VariableExpressionAst]) { continue }
        $cmd = $null
        if ($a.Right -is [System.Management.Automation.Language.PipelineAst] -and $a.Right.PipelineElements.Count -ge 1) {
            $cmd = $a.Right.PipelineElements[0]
        }
        if ($cmd -isnot [System.Management.Automation.Language.CommandAst]) { continue }
        $els = @($cmd.CommandElements)
        if ($els.Count -lt 2) { continue }
        if (([string]$els[0].Extent.Text) -ine 'New-Object') { continue }
        for ($i = 1; $i -lt $els.Count; $i++) {
            $e = $els[$i]
            if ($e -is [System.Management.Automation.Language.CommandParameterAst]) {
                if ($e.ParameterName -ine 'TypeName') { break }
                continue
            }
            if ($e -is [System.Management.Automation.Language.StringConstantExpressionAst]) {
                $types[$a.Left.VariablePath.UserPath] = $e.Value
            }
            break
        }
    }

    # Pass 1b: a TYPED parameter ([System.Windows.Forms.DataGridView]$Grid) is
    # a variable of that type too. Lane sqlstack-gui-glowup (stage 2) moved
    # control setup into shared look functions, and a literal moved there must
    # not move out of this census (the 2026-09-17 defect was exactly a grid's
    # BorderStyle literal). A name typed two ways is left unresolved.
    $paramTypes = @{}
    $ambiguous = @{}
    foreach ($pa in @($ast.FindAll({ param($n) $n -is [System.Management.Automation.Language.ParameterAst] }, $true))) {
        $tc = @($pa.Attributes | Where-Object { $_ -is [System.Management.Automation.Language.TypeConstraintAst] })
        if ($tc.Count -ne 1) { continue }
        $tn = [string]$tc[0].TypeName.FullName
        if ($tn -notmatch '^System\.Windows\.Forms\.') { continue }
        $pn = [string]$pa.Name.VariablePath.UserPath
        if ($paramTypes.ContainsKey($pn) -and ($paramTypes[$pn] -ne $tn)) { $ambiguous[$pn] = $true }
        $paramTypes[$pn] = $tn
    }
    foreach ($pn in @($paramTypes.Keys)) {
        if ((-not $ambiguous.ContainsKey($pn)) -and (-not $types.ContainsKey($pn))) { $types[$pn] = $paramTypes[$pn] }
    }

    # Pass 2: every  $var.Property = '<string literal>'.
    foreach ($a in $assigns) {
        if ($a.Left -isnot [System.Management.Automation.Language.MemberExpressionAst]) { continue }
        $tgt = $a.Left.Expression
        if ($tgt -isnot [System.Management.Automation.Language.VariableExpressionAst]) { continue }
        $vn = $tgt.VariablePath.UserPath
        if (-not $types.ContainsKey($vn)) { continue }
        if ($a.Left.Member -isnot [System.Management.Automation.Language.StringConstantExpressionAst]) { continue }
        $prop = $a.Left.Member.Value
        # The right-hand side of "$x.Prop = 'literal'" parses as a bare
        # CommandExpressionAst, NOT as a PipelineAst wrapping one. Accept both:
        # a matcher that only knew the wrapped shape checked nothing at all and
        # reported a clean census over zero sites.
        $lit = $null
        $rhs = $a.Right
        if ($rhs -is [System.Management.Automation.Language.PipelineAst] -and $rhs.PipelineElements.Count -eq 1) {
            $rhs = $rhs.PipelineElements[0]
        }
        if ($rhs -is [System.Management.Automation.Language.CommandExpressionAst] -and
            $rhs.Expression -is [System.Management.Automation.Language.StringConstantExpressionAst]) {
            $lit = $rhs.Expression.Value
        }
        if ($null -eq $lit) { continue }
        $t = $types[$vn] -as [type]
        if ($null -eq $t) {
            [void]$findings.Add(("{0}: type '{1}' did not resolve" -f $vn, $types[$vn]))
            continue
        }
        $checked++
        $pi = $t.GetProperty($prop)
        if ($null -eq $pi) {
            [void]$findings.Add(("{0}.{1}: no such property on {2}" -f $vn, $prop, $t.Name))
            continue
        }
        if ($pi.PropertyType.IsEnum) {
            # Parse, do not compare against the member NAMES: PowerShell's own
            # string-to-enum conversion is case-insensitive and understands the
            # comma form of a [Flags] enum, so $box.Anchor = 'Left,Right' is
            # valid although no member is called that. A census that measured
            # names instead of convertibility reported that correct line as a
            # defect - it was testing its own list, not the language's rule.
            $ok = $true
            try { [void][enum]::Parse($pi.PropertyType, $lit, $true) } catch { $ok = $false }
            if (-not $ok) {
                [void]$findings.Add(("{0}.{1} = '{2}': not assignable to {3}" -f $vn, $prop, $lit, $pi.PropertyType.Name))
            }
        }
    }
    return [pscustomobject]@{ Checked = $checked; Findings = $findings.ToArray() }
}

# ===========================================================================
# SELF-TEST. Headless: no form is created, no host is touched.
# ===========================================================================
if ($script:EntryArgs['SelfTest']) {
    $script:passes = 0; $script:fails = 0
    $script:PortBaseInUse = $script:EntryArgs['PortBase']
    function Assert-True {
        param([string]$Name, [bool]$Cond)
        if ($Cond) { Write-Host ("  PASS  {0}" -f $Name); $script:passes++ }
        else { Write-Host ("  FAIL  {0}" -f $Name) -ForegroundColor Red; $script:fails++ }
    }

    Write-Host "SqlStack (GUI) $($script:GuiVersion) -SelfTest"
    Write-Host ''
    Write-Host '-- engine shared with SqlStack-Collect --'
    Assert-True 'library dot-source defined Get-SqlStackPortPlan'   ($null -ne (Get-Command Get-SqlStackPortPlan -ErrorAction SilentlyContinue))
    Assert-True 'library dot-source defined Get-SqlStackMemoryPlan' ($null -ne (Get-Command Get-SqlStackMemoryPlan -ErrorAction SilentlyContinue))
    Assert-True 'library dot-source defined Get-OsReserveMb'        ($null -ne (Get-Command Get-OsReserveMb -ErrorAction SilentlyContinue))
    Assert-True 'library mode ran no collection'                    (-not (Test-Path variable:script:BundleDirCreated))
    # Lane L2f E2(a). The -AsLibrary load itself sets this process's elevation. This
    # self-test runs BEFORE this script's own `$script:IsElevated = Test-IsElevated`
    # (host facts, below), so what it sees is what the library load left.
    $l2fElev = Test-IsElevated
    Assert-True ('library load set $script:IsElevated to this process''s elevation (observed {0}; Test-IsElevated {1})' -f `
            $(if ($null -eq $script:IsElevated) { 'NULL' } else { $script:IsElevated }), $l2fElev) `
        (($null -ne $script:IsElevated) -and ($script:IsElevated -eq $l2fElev))

    Write-Host ''
    Write-Host '-- entry-point arguments survive the engine dot-source (D1) --'
    $guiAst = [System.Management.Automation.Language.Parser]::ParseFile($script:EntryScriptPath, [ref]$null, [ref]$null)
    $engAst = [System.Management.Automation.Language.Parser]::ParseFile($collectPath, [ref]$null, [ref]$null)
    $guiParams = @($guiAst.ParamBlock.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })
    $engParams = @($engAst.ParamBlock.Parameters | ForEach-Object { $_.Name.VariablePath.UserPath })
    $sharedNames = @($guiParams | Where-Object { $engParams -contains $_ })
    Assert-True 'entry args: this script declares parameters (haystack non-empty)'  ($guiParams.Count -ge 1)
    Assert-True 'entry args: the engine declares parameters (haystack non-empty)'   ($engParams.Count -ge 1)
    Assert-True 'entry args: the snapshot covers EVERY declared parameter'          (@($guiParams | Where-Object { -not $script:EntryArgs.ContainsKey($_) }).Count -eq 0)
    Assert-True 'entry args: a parameter name really does collide with the engine'  ($sharedNames.Count -ge 1)
    Assert-True 'entry args: -SelfTest is one of the colliding names'               ($sharedNames -contains 'SelfTest')
    Assert-True 'entry args: -SelfTest survived (this block is running at all)'     ([bool]$script:EntryArgs['SelfTest'])
    # Specimen control: the raw variable IS still clobbered by the dot-source.
    # If this ever goes red the hazard has changed shape - read the comment at
    # the dot-source before deleting the snapshot.
    Assert-True 'entry args: the raw $SelfTest was indeed rebound to the engine default' (-not $SelfTest)
    Assert-True 'entry args: -PortBase reached the code that uses it'               ($script:PortBaseInUse -eq $script:EntryArgs['PortBase'])

    Write-Host ''
    Write-Host '-- WinForms property literals, over this file''s syntax tree (D2) --'
    $wfLoaded = $true
    try {
        Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop
        Add-Type -AssemblyName System.Drawing -ErrorAction Stop
    } catch { $wfLoaded = $false }
    # A census that cannot resolve its types proves nothing, so this is a
    # failure and not a skip.
    Assert-True 'winforms: the assemblies the census reflects over are loaded' $wfLoaded
    if ($wfLoaded) {
        $specPath = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-winforms-specimen-' + [guid]::NewGuid().ToString('N') + '.ps1')
        $specimen = @(
            '$g = New-Object System.Windows.Forms.DataGridView',
            '$g.BorderStyle = ''SingleLine''',
            '$g.Dock = ''Fill'''
        ) -join [Environment]::NewLine
        [IO.File]::WriteAllText($specPath, $specimen, (New-Object System.Text.UTF8Encoding($false)))
        try {
            $spec = Test-WinFormsPropertyLiteral -ScriptPath $specPath
            Assert-True 'winforms: the census SEES the defect that shipped (specimen control)' (@($spec.Findings).Count -eq 1)
            Assert-True 'winforms: and passes the valid literal beside it'                     ($spec.Checked -eq 2)
        } finally { Remove-Item -LiteralPath $specPath -Force -ErrorAction SilentlyContinue }
        $live = Test-WinFormsPropertyLiteral -ScriptPath $script:EntryScriptPath
        Assert-True 'winforms: this file really assigns control literals (haystack non-empty)' ($live.Checked -ge 20)
        Assert-True 'winforms: every control property literal is valid for its own type'       (@($live.Findings).Count -eq 0)
        if (@($live.Findings).Count -gt 0) { $live.Findings | ForEach-Object { Write-Host ("        " + $_) -ForegroundColor Red } }
    }

    Write-Host ''
    Write-Host '-- GUI defect classes over this file''s syntax tree (lane sqlstack-gui-glowup, stage 1) --'
    # Specimen control first: the census must SEE the base's defects, or its
    # green on this file proves nothing. The specimen is the base's own header
    # lines (D3) with no -Server note (D6).
    $gsSpecPath = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-guistruct-specimen-' + [guid]::NewGuid().ToString('N') + '.ps1')
    $gsSpecimen = @(
        '$script:IsElevated = Test-IsElevated',
        '$elevText = if ($script:IsElevated) { ''elevated'' } else { ''NOT elevated - some probes will skip'' }'
    ) -join [Environment]::NewLine
    [IO.File]::WriteAllText($gsSpecPath, $gsSpecimen, (New-Object System.Text.UTF8Encoding($false)))
    try {
        $gsSpec = @(Test-SqlStackGuiStructure -ScriptPath $gsSpecPath)
        $gsSpecRed = @($gsSpec | Where-Object { @($_.Findings).Count -gt 0 } | ForEach-Object { $_.Id })
        Assert-True ("gui structure: the census SEES the base's defects in a specimen (red rows [{0}])" -f ($gsSpecRed -join ', ')) `
            ((@($gsSpecRed | Where-Object { $_ -like 'D3-*' }).Count -eq 2) -and ($gsSpecRed -contains 'D6-server-said'))
    } finally { Remove-Item -LiteralPath $gsSpecPath -Force -ErrorAction SilentlyContinue }
    $guiStruct = @(Test-SqlStackGuiStructure -ScriptPath $script:EntryScriptPath)
    Assert-True ('gui structure: the census returned its rows for this file ({0} row(s))' -f $guiStruct.Count) ($guiStruct.Count -ge 3)
    foreach ($gs in $guiStruct) {
        Assert-True ("gui structure {0}: {1} ({2} site(s) checked, {3} finding(s))" -f $gs.Id, $gs.Invariant, $gs.Checked, @($gs.Findings).Count) `
            ((@($gs.Findings).Count -eq 0) -and ($gs.Checked -ge 1))
        foreach ($fd in @($gs.Findings)) { Write-Host ('        ' + $fd) -ForegroundColor Red }
    }

    Write-Host ''
    Write-Host '-- header truth: elevation (D3) and -Server (D6) --'
    Assert-True 'elevation (D3): unelevated is stated, and no skip is claimed' ((Get-SqlStackGuiElevationText -IsElevated $false) -ceq 'not elevated')
    Assert-True 'elevation (D3): elevated is stated'                          ((Get-SqlStackGuiElevationText -IsElevated $true) -match '^elevated')
    foreach ($loc in @('localhost', '.', '(local)', '127.0.0.1', '', 'MSI', 'msi\NEW2022', 'tcp:localhost,1433', 'MSI.corp.example')) {
        Assert-True ("server (D6): '{0}' on host MSI is local, so the header adds nothing" -f $loc) ((Get-SqlStackGuiServerNote -Server $loc -ComputerName 'MSI') -eq '')
    }
    Assert-True 'server (D6): a remote host is said plainly' `
        ((Get-SqlStackGuiServerNote -Server 'SQLPROD01\INST2' -ComputerName 'MSI') -ceq "plans the local host only; -Server 'SQLPROD01\INST2' is not used")

    Write-Host ''
    Write-Host '-- legible at every scale, at the root; words, not colour alone (lane sqlstack-gui-glowup, stage 2) --'
    # Specimen control: the G rows must SEE the base's layout causes, or their
    # green on this file proves nothing. The specimen is the base's shape: a
    # Dpi form with no design DPI, a fixed-height panel, an unstyled grid and
    # an unstyled button.
    $gSpecPath = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-glowup-specimen-' + [guid]::NewGuid().ToString('N') + '.ps1')
    $gSpecimen = @(
        '$form = New-Object System.Windows.Forms.Form',
        '$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi',
        '$hdr = New-Object System.Windows.Forms.Panel',
        '$hdr.Height = 58',
        '$g = New-Object System.Windows.Forms.DataGridView',
        '$b = New-Object System.Windows.Forms.Button',
        '$form.Controls.AddRange(@($hdr, $g, $b))'
    ) -join [Environment]::NewLine
    [IO.File]::WriteAllText($gSpecPath, $gSpecimen, (New-Object System.Text.UTF8Encoding($false)))
    try {
        $gSpec = @(Test-SqlStackGuiStructure -ScriptPath $gSpecPath)
        $gSpecRed = @($gSpec | Where-Object { ($_.Id -like 'G*') -and (@($_.Findings).Count -gt 0) } | ForEach-Object { $_.Id })
        Assert-True ("layout (G): the census SEES the base's layout causes in a specimen (red rows [{0}])" -f ($gSpecRed -join ', ')) `
            ((@($gSpecRed) -join ',') -ceq 'G1-autoscale-at-root,G2-no-fixed-text-height,G3-grids-one-look,G4-buttons-one-look')
    } finally { Remove-Item -LiteralPath $gSpecPath -Force -ErrorAction SilentlyContinue }
    Assert-True 'layout (G): the four G rows ran on this file (green or red, above)' (@($guiStruct | Where-Object { $_.Id -like 'G*' }).Count -eq 4)

    $gb = ('{0} GB RAM' -f 31.5)
    $hf = @(Get-SqlStackGuiHeaderFacts -LogicalCores 22 -PhysicalMb 32255 -VolumeCount 1 -InstanceCount 4)
    Assert-True ("header facts: the build box reads '{0}'" -f ($hf -join ' | ')) (($hf -join '|') -ceq ('22 logical cores|' + $gb + '|1 lettered volume|4 SQL instances installed'))
    $hf = @(Get-SqlStackGuiHeaderFacts -LogicalCores 1 -PhysicalMb 1024 -VolumeCount 2 -InstanceCount 1)
    Assert-True ("header facts: singular and plural are right ('{0}')" -f ($hf -join ' | ')) (($hf -join '|') -ceq '1 logical core|1 GB RAM|2 lettered volumes|1 SQL instance installed')
    $hf = @(Get-SqlStackGuiHeaderFacts -LogicalCores 4 -PhysicalMb 8192 -VolumeCount 0 -InstanceCount 0)
    Assert-True ("header facts: zero is plural ('{0}')" -f ($hf -join ' | ')) ((($hf[2]) -ceq '0 lettered volumes') -and (($hf[3]) -ceq '0 SQL instances installed'))

    foreach ($cc in @(@(0, 1, '0 errors, 1 warning'), @(1, 0, '1 error, 0 warnings'), @(2, 3, '2 errors, 3 warnings'))) {
        $ct = Get-SqlStackGuiCountText -Errors $cc[0] -Warnings $cc[1]
        Assert-True ("status counts: {0} and {1} read '{2}'" -f $cc[0], $cc[1], $ct) ($ct -ceq $cc[2])
    }
    $st = Get-SqlStackGuiActionState -Errors 2 -NewRows 1 -HasFileSet $false -FileSetCurrent $false
    Assert-True ("actions: errors turn Generate off, and say so ('{0}')" -f $st.Reason) ((-not $st.GenerateEnabled) -and ($st.Reason -match '\b2 errors\b') -and ($st.Primary -eq 'Generate'))
    $st = Get-SqlStackGuiActionState -Errors 1 -NewRows 1 -HasFileSet $false -FileSetCurrent $false
    Assert-True ("actions: one error is singular ('{0}')" -f $st.Reason) ($st.Reason -match '\b1 error\.')
    $st = Get-SqlStackGuiActionState -Errors 0 -NewRows 0 -HasFileSet $false -FileSetCurrent $false
    Assert-True ("actions: no new instance turns Generate off, and says so ('{0}')" -f $st.Reason) ((-not $st.GenerateEnabled) -and ($st.Reason -match 'no new instance'))
    $st = Get-SqlStackGuiActionState -Errors 0 -NewRows 1 -HasFileSet $false -FileSetCurrent $false
    Assert-True 'actions: a clean plan with a new instance: Generate on, and it is the primary' ($st.GenerateEnabled -and ($st.Primary -eq 'Generate') -and ($st.Reason -eq ''))
    $st = Get-SqlStackGuiActionState -Errors 0 -NewRows 1 -HasFileSet $true -FileSetCurrent $true
    Assert-True 'actions: a current file set makes Save the primary' ($st.GenerateEnabled -and ($st.Primary -eq 'Save'))
    $st = Get-SqlStackGuiActionState -Errors 0 -NewRows 1 -HasFileSet $true -FileSetCurrent $false
    Assert-True ("actions: a stale file set hands the primary back to Generate, and says why ('{0}')" -f $st.Reason) (($st.Primary -eq 'Generate') -and ($st.Reason -match 'changed after Generate'))

    Write-Host ''
    Write-Host '-- Instances grid: TCP in words from the engine''s facts (D5) --'
    # The fixture rows are the SHAPES the engine returns on this box (the brief
    # critic's base read: MSSQLSERVER static 1433; NEW2022/OLD2017/AG2 with
    # Tcp\Enabled 0 and TcpDynamicPorts '0'), plus the two dynamic cases.
    $tw = {
        param($enabled, $port, $dyn, $state, $fixedPort, $mapPort)
        $map = @{}; if ($null -ne $mapPort) { $map['X'] = $mapPort }
        Get-SqlStackGuiTcpText -Name 'X' -FixedRow ([pscustomobject]@{ Name = 'X'; Port = $fixedPort }) -Map $map `
            -TcpRead ([pscustomobject]@{ Read = $true; Reason = ''; Row = [pscustomobject]@{ TcpEnabled = $enabled; IPAllTcpPort = $port; IPAllTcpDynamicPorts = $dyn; TcpDynamicPortsState = $state } })
    }
    $twOff = & $tw 0 '' '0' 'numeric' 'dynamic' $null
    Assert-True ("tcp words (D5): Enabled 0 reads 'TCP off', not a port (got '{0}')" -f $twOff.Text) ($twOff.Text -ceq 'TCP off')
    Assert-True 'tcp words (D5): the tooltip carries the raw registry values' ($twOff.Tip -match "Tcp\\Enabled = '0'" -and $twOff.Tip -match "TcpDynamicPorts = '0'")
    $twStatic = & $tw 1 '1433' '' 'empty-string' 1433 1433
    Assert-True ("tcp words (D5): a static port reads 'static 1433' (got '{0}')" -f $twStatic.Text) ($twStatic.Text -ceq 'static 1433')
    $twDyn = & $tw 1 '' '50644' 'numeric' 'dynamic' 50644
    Assert-True ("tcp words (D5): a recorded dynamic port reads 'dynamic 50644' (got '{0}')" -f $twDyn.Text) ($twDyn.Text -ceq 'dynamic 50644')
    $twNone = & $tw 1 '' '' 'empty-string' 'dynamic' $null
    Assert-True ("tcp words (D5): no static and no dynamic port reads 'dynamic (none assigned)' (got '{0}')" -f $twNone.Text) ($twNone.Text -ceq 'dynamic (none assigned)')
    $twAbsent = Get-SqlStackGuiTcpText -Name 'X' -FixedRow $null -Map @{} -TcpRead ([pscustomobject]@{ Read = $true; Row = $null; Reason = '' })
    Assert-True ("tcp words (D5): no Tcp key reads 'TCP not configured' (got '{0}')" -f $twAbsent.Text) ($twAbsent.Text -ceq 'TCP not configured')
    $twFail = Get-SqlStackGuiTcpText -Name 'X' -FixedRow $null -Map @{} -TcpRead ([pscustomobject]@{ Read = $false; Row = $null; Reason = 'SecurityException' })
    Assert-True ("tcp words (D5): a failed read says so and why, never a blank (got '{0}' / '{1}')" -f $twFail.Text, $twFail.Tip) ($twFail.Text -match '^unknown' -and $twFail.Tip -match 'SecurityException')
    $probeRegD5 = Get-ProbeRegistry
    $tcpProbeD5 = @($probeRegD5 | Where-Object { $_.Id -eq 'net-tcp-registry' })
    Assert-True ("tcp words (D5): the engine carries exactly one net-tcp-registry probe body for the grid to run ({0})" -f $tcpProbeD5.Count) `
        (($tcpProbeD5.Count -eq 1) -and ($tcpProbeD5[0].Script -is [scriptblock]))

    Write-Host ''
    Write-Host '-- suggested paths --'
    $sp = Get-SuggestedInstancePaths -InstanceName 'INST01' -DataDrive 'E' -LogDrive 'F' -TempDbDrive 'T' -BackupDrive 'G'
    Assert-True 'paths: data'    ($sp.Data   -eq 'E:\INST01\Data')
    Assert-True 'paths: log'     ($sp.Log    -eq 'F:\INST01\Log')
    Assert-True 'paths: tempdb'  ($sp.TempDb -eq 'T:\INST01\TempDB')
    Assert-True 'paths: backup'  ($sp.Backup -eq 'G:\INST01\Backup')
    $sp2 = Get-SuggestedInstancePaths -InstanceName 'INST01' -DataDrive 'e:'
    Assert-True 'paths: accepts "e:" form' ($sp2.Data -eq 'E:\INST01\Data')

    Write-Host ''
    Write-Host '-- path drive extraction --'
    Assert-True 'drive: from local path'  ((Get-PathDrive -Path 'E:\X\Y') -eq 'E')
    Assert-True 'drive: lowercase upped'  ((Get-PathDrive -Path 'e:\x') -eq 'E')
    Assert-True 'drive: UNC has none'     ((Get-PathDrive -Path '\\srv\share') -eq '')
    Assert-True 'drive: empty safe'       ((Get-PathDrive -Path '') -eq '')

    Write-Host ''
    Write-Host '-- tempdb and maxdop heuristics --'
    Assert-True 'tempdb files: 4 cores -> 4'   ((Get-TempDbFileCount -LogicalCores 4) -eq 4)
    Assert-True 'tempdb files: 8 cores -> 8'   ((Get-TempDbFileCount -LogicalCores 8) -eq 8)
    Assert-True 'tempdb files: 32 cores -> 8'  ((Get-TempDbFileCount -LogicalCores 32) -eq 8)
    Assert-True 'tempdb files: 0 cores -> 1'   ((Get-TempDbFileCount -LogicalCores 0) -eq 1)
    Assert-True 'maxdop: 8 cores 1 instance -> 8'  ((Get-SuggestedMaxDop -LogicalCores 8 -InstanceCount 1) -eq 8)
    Assert-True 'maxdop: 8 cores 2 instances -> 4' ((Get-SuggestedMaxDop -LogicalCores 8 -InstanceCount 2) -eq 4)
    Assert-True 'maxdop: 8 cores 3 instances -> 2' ((Get-SuggestedMaxDop -LogicalCores 8 -InstanceCount 3) -eq 2)
    Assert-True 'maxdop: 64 cores 1 instance capped at 8' ((Get-SuggestedMaxDop -LogicalCores 64 -InstanceCount 1) -eq 8)
    Assert-True 'maxdop: 2 cores 4 instances -> 1' ((Get-SuggestedMaxDop -LogicalCores 2 -InstanceCount 4) -eq 1)

    Write-Host ''
    Write-Host '-- drive advice --'
    $good = [pscustomobject]@{ DriveLetter='E'; SizeGB=500; FreeGB=400; AllocationUnitSize=65536; FileSystem='NTFS' }
    $bad  = [pscustomobject]@{ DriveLetter='C'; SizeGB=100; FreeGB=5;   AllocationUnitSize=4096;  FileSystem='NTFS' }
    Assert-True 'advice: clean volume has none'   ((Get-DriveAdvice -Volume $good -IntendedUse 'Data') -eq '')
    $adv = Get-DriveAdvice -Volume $bad -IntendedUse 'Data'
    Assert-True 'advice: flags system drive'      ($adv -match 'system drive')
    Assert-True 'advice: flags 4KB alloc unit'    ($adv -match '4KB')
    Assert-True 'advice: flags low free space'    ($adv -match 'free')
    Assert-True 'advice: alloc unit ignored for backup' ((Get-DriveAdvice -Volume $bad -IntendedUse 'Backup') -notmatch 'alloc')

    Write-Host ''
    Write-Host '-- tempdb sizing --'
    Assert-True 'tempdb size: 8 x 8192 + log' ((Get-PlannedTempDbSizeMb -FileCount 8 -FileSizeMb 8192) -eq 73728)

    Write-Host ''
    Write-Host '-- plan validation --'
    $vols = @(
        [pscustomobject]@{ DriveLetter='C'; SizeGB=300; FreeGB=120; AllocationUnitSize=4096;  FileSystem='NTFS' },
        [pscustomobject]@{ DriveLetter='E'; SizeGB=500; FreeGB=400; AllocationUnitSize=65536; FileSystem='NTFS' },
        [pscustomobject]@{ DriveLetter='F'; SizeGB=500; FreeGB=450; AllocationUnitSize=65536; FileSystem='NTFS' },
        [pscustomobject]@{ DriveLetter='T'; SizeGB=200; FreeGB=180; AllocationUnitSize=65536; FileSystem='NTFS' }
    )
    $mk = {
        param($name, $ord, $data, $log, $tmp)
        [pscustomobject]@{
            Name=$name; Ordinal=$ord; Port=$null; DacPort=$null
            DataPath=$data; LogPath=$log; TempDbPath=$tmp; BackupPath='F:\Backup'
            MaxMemoryMb=20000; MinMemoryMb=10000; MaxDop=4; CostThreshold=50
            TempDbFileCount=8; TempDbFileSizeMb=1024
        }
    }
    $okPlan = @((& $mk 'INST01' 1 'E:\INST01\Data' 'F:\INST01\Log' 'T:\INST01\TempDB'))
    $r = Test-SqlStackPlan -Plan $okPlan -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: clean plan has no ERROR' (@($r | Where-Object { $_.Severity -eq 'ERROR' }).Count -eq 0)

    $sameVol = @((& $mk 'INST01' 1 'E:\INST01\Data' 'E:\INST01\Log' 'T:\INST01\TempDB'))
    $r2 = Test-SqlStackPlan -Plan $sameVol -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: data+log same volume warns' (@($r2 | Where-Object { $_.Message -match 'Data and log' }).Count -eq 1)

    $onC = @((& $mk 'INST01' 1 'C:\INST01\Data' 'F:\INST01\Log' 'T:\INST01\TempDB'))
    $r3 = Test-SqlStackPlan -Plan $onC -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: system drive warns'  (@($r3 | Where-Object { $_.Message -match 'system drive' }).Count -ge 1)
    Assert-True 'validate: 4KB alloc warns'     (@($r3 | Where-Object { $_.Message -match '4KB' }).Count -ge 1)

    $missingVol = @((& $mk 'INST01' 1 'Z:\INST01\Data' 'F:\INST01\Log' 'T:\INST01\TempDB'))
    $r4 = Test-SqlStackPlan -Plan $missingVol -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: absent drive is an ERROR' (@($r4 | Where-Object { $_.Severity -eq 'ERROR' -and $_.Message -match 'does not exist' }).Count -eq 1)

    $tooBig = @((& $mk 'INST01' 1 'E:\D' 'F:\L' 'T:\T'))
    $tooBig[0].TempDbFileSizeMb = 40960   # 8 x 40GB + log = way past T:'s 180GB
    $r5 = Test-SqlStackPlan -Plan $tooBig -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: tempdb larger than volume is an ERROR' (@($r5 | Where-Object { $_.Severity -eq 'ERROR' -and $_.Message -match 'TempDB needs' }).Count -eq 1)

    $overMem = @((& $mk 'A' 1 'E:\D' 'F:\L' 'T:\T'), (& $mk 'B' 2 'E:\D2' 'F:\L2' 'T:\T2'))
    $overMem[0].MaxMemoryMb = 40000; $overMem[1].MaxMemoryMb = 40000
    $r6 = Test-SqlStackPlan -Plan $overMem -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: memory over-commit is an ERROR' (@($r6 | Where-Object { $_.Severity -eq 'ERROR' -and $_.Message -match 'over-commits' }).Count -eq 1)

    $noPath = @((& $mk 'INST01' 1 '' 'F:\L' 'T:\T'))
    $r7 = Test-SqlStackPlan -Plan $noPath -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: empty path is an ERROR' (@($r7 | Where-Object { $_.Severity -eq 'ERROR' -and $_.Message -match 'path is not set' }).Count -eq 1)

    $badName = @((& $mk '1BAD' 1 'E:\D' 'F:\L' 'T:\T'))
    $r8 = Test-SqlStackPlan -Plan $badName -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: bad instance name is an ERROR' (@($r8 | Where-Object { $_.Severity -eq 'ERROR' -and $_.Message -match 'Instance name' }).Count -eq 1)

    $dupPort = @((& $mk 'A' 1 'E:\D' 'F:\L' 'T:\T'), (& $mk 'B' 2 'E:\D2' 'F:\L2' 'T:\T2'))
    $dupPort[0].Port = 14331; $dupPort[1].Port = 14331
    $r9 = Test-SqlStackPlan -Plan $dupPort -Volumes $vols -PhysicalMb 65536
    Assert-True 'validate: duplicate port is an ERROR' (@($r9 | Where-Object { $_.Severity -eq 'ERROR' -and $_.Area -match '^port/' }).Count -ge 1)

    $r10 = Test-SqlStackPlan -Plan @() -Volumes $vols
    Assert-True 'validate: empty plan is INFO not a crash' ($r10.Count -eq 1 -and $r10[0].Severity -eq 'INFO')

    # I14 (lane sqlstack-L2i): THE DAC IS SQL'S DYNAMIC CHOICE, and the GUI shows it
    # rather than a port nobody sets. A plan row carrying the GUI's display text in
    # DacPort is validated without a crash or a port finding (the shared port planner
    # ignores DacPort), and a TCP port that is another row's +100 is no collision any
    # more. The row itself is read off THIS FILE'S SYNTAX TREE: 'DAC port' is built
    # -ReadOnly and not -Numeric, and Update-ComputedPlan assigns the display text.
    $dacRows = @((& $mk 'A' 1 'E:\D' 'F:\L' 'T:\T'), (& $mk 'B' 2 'E:\D2' 'F:\L2' 'T:\T2'))
    $dacRows[0].Port = 14331; $dacRows[1].Port = 14431
    $dacRows[0].DacPort = 'dynamic (SQL chooses at start-up)'; $dacRows[1].DacPort = 'dynamic (SQL chooses at start-up)'
    $r11 = Test-SqlStackPlan -Plan $dacRows -Volumes $vols -PhysicalMb 65536
    Assert-True ("validate (I14): a DacPort of display text is no port finding, and tcp 14431 beside tcp 14331 is no collision ({0} port finding(s))" -f `
            @($r11 | Where-Object { $_.Area -match '^port/' }).Count) (@($r11 | Where-Object { $_.Area -match '^port/' }).Count -eq 0)
    $dacAst = [System.Management.Automation.Language.Parser]::ParseFile($PSCommandPath, [ref]$null, [ref]$null)
    $dacRowCmd = @($dacAst.FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'Add-DetailRow') -and `
                    ([string]$n.Extent.Text -match "-Label\s+'DAC port'") }, $true))
    $dacRowParams = @(@($dacRowCmd | ForEach-Object { $_.CommandElements }) | Where-Object { $_ -is [System.Management.Automation.Language.CommandParameterAst] } | ForEach-Object { [string]$_.ParameterName })
    # Retargeted 2026-10-01 (lane sqlstack-gui-glowup): the write-back moved from
    # Update-ComputedPlan into the pure Invoke-SqlStackGuiPlanUpdate; same text.
    $dacUcp = @($dacAst.FindAll({ param($n) ($n -is [System.Management.Automation.Language.FunctionDefinitionAst]) -and ($n.Name -eq 'Invoke-SqlStackGuiPlanUpdate') }, $true))
    $dacText = @($dacUcp | ForEach-Object { $_.FindAll({ param($n) ($n -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$n.Value -eq 'dynamic (SQL chooses at start-up)') }, $true) })
    Assert-True ("gui (I14): the 'DAC port' row is display-only ({0} row(s), parameters [{1}]) and Invoke-SqlStackGuiPlanUpdate writes the display text ({2} literal(s))" -f `
            $dacRowCmd.Count, ($dacRowParams -join ','), $dacText.Count) `
        (($dacRowCmd.Count -eq 1) -and ($dacRowParams -contains 'ReadOnly') -and ($dacRowParams -notcontains 'Numeric') -and ($dacText.Count -eq 1))

    # I11 (lane sqlstack-L2i fix round 1, gate 2's unlisted twin): THE GUI'S ini
    # ADAPTER NAMES EXACTLY THE SCHEMA'S PATH KEYS. New-ConfigurationIni hands the
    # engine a spec-shaped instance whose 'paths' map is typed here by hand, so a
    # path key added to the schema (Get-SqlStackSpecPathKey) and not to this map
    # would reach the engine's ini emitter as an absent path. Read off THIS FILE'S
    # SYNTAX TREE, as the I14 row above is: every hashtable entry keyed 'paths' inside
    # New-ConfigurationIni, and the keys of the map it holds.
    $pkFn = @($dacAst.FindAll({ param($n) ($n -is [System.Management.Automation.Language.FunctionDefinitionAst]) -and ($n.Name -eq 'New-ConfigurationIni') }, $true))
    $pkPairs = @(@($pkFn | ForEach-Object { $_.FindAll({ param($n) $n -is [System.Management.Automation.Language.HashtableAst] }, $true) }) |
            ForEach-Object { foreach ($kv in @($_.KeyValuePairs)) {
                    if (($kv.Item1 -is [System.Management.Automation.Language.StringConstantExpressionAst]) -and ([string]$kv.Item1.Value -eq 'paths')) { $kv } } })
    $pkGuiKeys = @()
    if ($pkPairs.Count -eq 1) {
        $pkMap = @($pkPairs[0].Item2.FindAll({ param($n) $n -is [System.Management.Automation.Language.HashtableAst] }, $true))
        if ($pkMap.Count -ge 1) {
            $pkGuiKeys = @(@($pkMap[0].KeyValuePairs) | ForEach-Object {
                    $(if ($_.Item1 -is [System.Management.Automation.Language.StringConstantExpressionAst]) { [string]$_.Item1.Value } else { '<not a constant: ' + [string]$_.Item1.Extent.Text + '>' }) } | Sort-Object)
        }
    }
    $pkSchema = @(@(Get-SqlStackSpecPathKey) | Sort-Object)
    Assert-True ("gui (I11): New-ConfigurationIni's 'paths' map names exactly the schema's path keys ({0} function(s), {1} 'paths' entr(ies); GUI [{2}], schema [{3}])" -f `
            $pkFn.Count, $pkPairs.Count, ($pkGuiKeys -join ','), ($pkSchema -join ',')) `
        (($pkFn.Count -eq 1) -and ($pkPairs.Count -eq 1) -and ($pkSchema.Count -ge 1) -and (($pkGuiKeys -join ',') -ceq ($pkSchema -join ',')))

    Write-Host ''
    Write-Host '-- generated artifacts (review-only) --'
    # The ini now carries the HOST'S SQL Browser value (D2(ii)): the fixture passes
    # the reference host's value, Disabled.
    $ini = New-ConfigurationIni -Instance $okPlan[0] -SysAdmins @('DOM\SQL-DBA') -ObservedBrowser 'Disabled'
    # THE TWIN CHECK FROM THE CALLER'S SIDE. This function is now an adapter over
    # the engine's New-SqlStackConfigurationIni, so the thing worth asserting here
    # is that adapting a GUI plan row still produces the twin's key set minus the
    # two keys the plan removed - measured, frozen, and named in the fixture file.
    # A key lost in the ADAPTER (a GUI field this function forgets to map) shows up
    # here and nowhere else.
    $iniKeys = New-Object System.Collections.ArrayList
    foreach ($line in ($ini -split "`r?`n")) {
        $t = $line.Trim()
        if ($t.StartsWith(';') -or $t.StartsWith('[') -or ($t -eq '')) { continue }
        if ($t -match '^([A-Za-z0-9_]+)=') { [void]$iniKeys.Add($Matches[1]) }
    }
    $twinFile = Join-Path $PSScriptRoot 'tests\fixtures\spec\ini\gui-twin-keys.json'
    if (Test-Path -LiteralPath $twinFile) {
        $twinDoc = ConvertFrom-Json (Get-Content -LiteralPath $twinFile -Raw -Encoding UTF8)
        $want = @(@($twinDoc.keysWithServiceAccounts) | Where-Object { @('INSTANCEID', 'SECURITYMODE') -notcontains [string]$_ })
        $missing = @($want | Where-Object { @($iniKeys) -notcontains [string]$_ })
        $extra = @(@($iniKeys) | Where-Object { $want -notcontains [string]$_ })
        Assert-True ("ini: the GUI adapter renders the twin's measured key set minus INSTANCEID and SECURITYMODE ($(@($iniKeys).Count) of $($want.Count) key(s); missing [$($missing -join ',')] extra [$($extra -join ',')])") `
            (($missing.Count -eq 0) -and ($extra.Count -eq 0) -and (@($iniKeys).Count -eq 26))
    } else {
        Assert-True ('ini: the frozen twin key measurement is MISSING at ' + $twinFile) $false
    }
    Assert-True 'ini: the GUI adapter says the ini is Windows-authentication only' ($ini -match 'Windows-authentication only')
    Assert-True 'ini: names the instance'        ($ini -match 'INSTANCENAME="INST01"')
    Assert-True 'ini: carries data dir'          ($ini -match 'SQLUSERDBDIR="E:\\INST01\\Data"')
    Assert-True 'ini: carries tempdb file count' ($ini -match 'SQLTEMPDBFILECOUNT="8"')
    Assert-True 'ini: enables IFI'               ($ini -match 'SQLSVCINSTANTFILEINIT="True"')
    Assert-True 'ini: contains NO password keys' ($ini -notmatch '(?i)(SAPWD|SVCPASSWORD)\s*=')
    Assert-True 'ini: says review before running' ($ini -match 'REVIEW BEFORE RUNNING')
    Assert-True 'ini: notes static port is a separate step' ($ini -match 'StaticPortForIPAll 14331|StaticPortForIPAll')

    Assert-True 'ini (D2): BROWSERSVCSTARTUPTYPE is the observed host value, never an override' `
        (($ini -match 'BROWSERSVCSTARTUPTYPE="Disabled"') -and ($ini -notmatch 'explicit host.shared.browser override'))
    $iniUnknown = New-ConfigurationIni -Instance $okPlan[0] -PassThru
    Assert-True ("ini (D2): with no Browser value read, nothing is rendered for it and the ini says it is INCOMPLETE (Ok {0})" -f $iniUnknown.Ok) `
        ((-not $iniUnknown.Ok) -and ([string]$iniUnknown.Text -notmatch 'BROWSERSVCSTARTUPTYPE=') -and ([string]$iniUnknown.Text -match 'INCOMPLETE'))

    $sql = New-PostInstallSql -Instance $okPlan[0]
    Assert-True 'sql: sets max memory'      ($sql -match "max server memory \(MB\)', 20000")
    Assert-True 'sql: sets min memory'      ($sql -match "min server memory \(MB\)', 10000")
    Assert-True 'sql: sets maxdop'          ($sql -match "max degree of parallelism', 4")
    Assert-True 'sql: enables remote DAC'   ($sql -match "remote admin connections', 1")
    Assert-True 'sql: no DROP or DELETE'    ($sql -notmatch '(?i)\b(DROP|DELETE|TRUNCATE)\b')
    Assert-True 'sql: review banner'        ($sql -match 'REVIEW BEFORE RUNNING')

    $parser = $null
    if ($script:CommonLoaded) { try { $parser = New-ScriptDomParser -ToolRoot $PSScriptRoot } catch { $parser = $null } }
    if ($null -eq $parser) {
        Write-Host '  SKIP  T-SQL parse-gate (ScriptDom not loadable)'
    } else {
        $errs = $null
        [void]$parser.Parse((New-Object System.IO.StringReader($sql)), [ref]$errs)
        Assert-True 'sql: parse-gate clean' ($null -eq $errs -or $errs.Count -eq 0)
        if ($errs -and $errs.Count -gt 0) { Write-Host ("        " + $errs[0].Message) -ForegroundColor Red }
    }

    Write-Host ''
    Write-Host '-- fixed constraints in the plan computation (PLAN.md 4.4) --'
    # STRUCTURAL, over THIS FILE'S SYNTAX TREE, not over its characters: the
    # assertions below select AST nodes (FunctionDefinitionAst, CommandAst,
    # CommandParameterAst, ForEachStatementAst) and would survive any reformatting.
    #
    # RETARGETED 2026-10-01 (lane sqlstack-gui-glowup, D1/D4), INVARIANT UNCHANGED:
    # the planners are now called from ONE pure function,
    # Get-SqlStackGuiPlanComputation, and the write-back is the pure
    # Invoke-SqlStackGuiPlanUpdate (Update-ComputedPlan is a thin wrapper over it).
    # These rows read THOSE two functions: the planners still get -FixedInstances
    # and -KnownInstancePorts, no loop runs over the whole plan, and the Fixed
    # marker is read. And they are no longer the only guard: the write-back now
    # exists while this block runs, so the 'installed (D1):' rows below RUN it and
    # compare every fixed row before and after, which this tripwire could not.
    $selfAst = [System.Management.Automation.Language.Parser]::ParseFile($PSCommandPath, [ref]$null, [ref]$null)
    $ucp = @($selfAst.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and (@('Get-SqlStackGuiPlanComputation', 'Invoke-SqlStackGuiPlanUpdate') -contains $n.Name) }, $true))
    Assert-True 'fixed: Get-SqlStackGuiPlanComputation and Invoke-SqlStackGuiPlanUpdate are in the syntax tree' ($ucp.Count -eq 2)
    if ($ucp.Count -eq 2) {
        $cmds = @($ucp | ForEach-Object { $_.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true) })
        $paramNamesOf = {
            param($cmdName)
            $c = @($cmds | Where-Object { $_.GetCommandName() -eq $cmdName })
            if ($c.Count -eq 0) { return @() }
            @($c[0].CommandElements | Where-Object { $_ -is [System.Management.Automation.Language.CommandParameterAst] } | ForEach-Object { $_.ParameterName })
        }
        $memParams  = @(& $paramNamesOf 'Get-SqlStackMemoryPlan')
        $portParams = @(& $paramNamesOf 'Get-SqlStackPortPlan')
        Assert-True 'fixed: the memory planner is called with -FixedInstances'      ($memParams -contains 'FixedInstances')
        Assert-True 'fixed: the port planner is called with -FixedInstances'        ($portParams -contains 'FixedInstances')
        Assert-True 'fixed: the port planner is called with -KnownInstancePorts'    ($portParams -contains 'KnownInstancePorts')
        $loopVars = @($ucp | ForEach-Object { $_.FindAll({ param($n) $n -is [System.Management.Automation.Language.ForEachStatementAst] }, $true) } |
                      ForEach-Object { $_.Condition.Extent.Text })
        Assert-True 'fixed: nothing loops over the WHOLE plan any more'             ((@($loopVars | Where-Object { $_ -match '^(@\()?\$(script:)?Plan\)?$' }).Count) -eq 0)
        $fixedRefs = @($ucp | ForEach-Object { $_.FindAll({ param($n) $n -is [System.Management.Automation.Language.MemberExpressionAst] -and [string]$n.Member.Extent.Text -eq 'Fixed' }, $true) })
        Assert-True 'fixed: the function reads a row.Fixed marker at all'           ($fixedRefs.Count -ge 2)
    }
    # RETARGETED 2026-11-03 (lane sqlstack-workbench), PROPERTY UNCHANGED: the new
    # row's shape moved into the ONE factory New-SqlStackGuiPlanRow, which
    # New-PlanRowFromName (and the spec reader) now build through.
    $npr = @($selfAst.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'New-SqlStackGuiPlanRow' }, $true))
    $nprCaller = @($selfAst.FindAll({ param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -eq 'New-PlanRowFromName' }, $true))
    Assert-True 'fixed: New-PlanRowFromName is in the syntax tree and builds its row through New-SqlStackGuiPlanRow' `
        (($npr.Count -eq 1) -and ($nprCaller.Count -eq 1) -and (@($nprCaller[0].FindAll({ param($n) ($n -is [System.Management.Automation.Language.CommandAst]) -and ([string]$n.GetCommandName() -eq 'New-SqlStackGuiPlanRow') }, $true)).Count -eq 1))
    if ($npr.Count -eq 1) {
        $hts = @($npr[0].FindAll({ param($n) $n -is [System.Management.Automation.Language.HashtableAst] }, $true))
        $keys = @($hts | ForEach-Object { $_.KeyValuePairs } | ForEach-Object { $_.Item1.Extent.Text })
        Assert-True 'fixed: a new plan row declares a Fixed key'   ($keys -contains 'Fixed')
        Assert-True 'fixed: the row still declares IsDefault too (haystack check)' ($keys -contains 'IsDefault')
    }

    Write-Host ''
    Write-Host '-- installed instances are constraints, never claimants (D1); the arithmetic is the engine''s (D4) --'
    # Fixtures in the shapes the engine returns on this box: MSSQLSERVER static
    # 1433, NEW2022 TCP off (port map 'dynamic'). Nothing here reads the host.
    $invMs  = [pscustomobject]@{ Name = 'MSSQLSERVER'; InstanceId = 'MSSQL17.MSSQLSERVER'; IsDefault = $true }
    $invNew = [pscustomobject]@{ Name = 'NEW2022';     InstanceId = 'MSSQL16.NEW2022';     IsDefault = $false }
    $ownMs = @([pscustomobject]@{ Kind = 'SQLDataRoot'; Status = 'read'; Path = 'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL'; Reason = '' },
               [pscustomobject]@{ Kind = 'DefaultData'; Status = 'absent'; Path = ''; Reason = 'the key does not carry this value' },
               [pscustomobject]@{ Kind = 'BackupDirectory'; Status = 'read'; Path = 'C:\DB\MSSQL16.MSSQLSERVER\MSSQL\Backup'; Reason = '' })
    $fxMs  = New-PlanRowFromInstalled -Instance $invMs  -ObservedPort ([pscustomobject]@{ Name = 'MSSQLSERVER'; Port = 1433 }) -TcpText 'static 1433' -OwnedPathRows $ownMs -Ordinal 1
    $fxNew = New-PlanRowFromInstalled -Instance $invNew -ObservedPort ([pscustomobject]@{ Name = 'NEW2022'; Port = 'dynamic' }) -TcpText 'TCP off' -OwnedPathRows @() -Ordinal 2
    Assert-True 'installed (D1): an imported row is Fixed' ([bool]$fxMs.Fixed -and [bool]$fxNew.Fixed)
    Assert-True ("installed (D1): its port is the one read (1433), and a TCP-off instance reserves none ({0} / {1})" -f $fxMs.Port, $(if ($null -eq $fxNew.Port) { 'null' } else { $fxNew.Port })) `
        (($fxMs.Port -eq 1433) -and ($null -eq $fxNew.Port))
    Assert-True 'installed (D1): memory, MAXDOP and tempdb are NOT READ ($null), never 0 or a default' `
        (($null -eq $fxMs.MaxMemoryMb) -and ($null -eq $fxMs.MaxDop) -and ($null -eq $fxMs.TempDbFileCount))
    $fxFacts = (@($fxMs.Facts) -join ' | ')
    Assert-True 'installed (D1): the facts shown say what was read and what was not' `
        (($fxFacts -match 'Max server memory: NOT READ') -and ($fxFacts -match 'BackupDirectory: C:\\DB\\MSSQL16\.MSSQLSERVER\\MSSQL\\Backup \(registry\)') -and ($fxFacts -match 'DefaultData: not set in the registry') -and ($fxFacts -match 'TCP: static 1433'))
    $newRow = & $mk 'INST01' 3 'E:\INST01\Data' 'F:\INST01\Log' 'T:\INST01\TempDB'
    $newRow.MaxMemoryMb = 0; $newRow.MinMemoryMb = 0; $newRow.MaxDop = 0
    $newRow | Add-Member -NotePropertyName MemoryWeight -NotePropertyValue 1
    $newRow | Add-Member -NotePropertyName Fixed -NotePropertyValue $false
    $planD1 = @($fxMs, $fxNew, $newRow)
    $snapRow = { param($r) ($r | Select-Object Name, Ordinal, Port, DacPort, DataPath, LogPath, TempDbPath, BackupPath, MaxMemoryMb, MinMemoryMb, MaxDop, CostThreshold, TempDbFileCount, TempDbFileSizeMb, Fixed | ConvertTo-Json -Compress) }
    $fxBefore = (@($fxMs, $fxNew) | ForEach-Object { & $snapRow $_ }) -join ' || '
    $compD1 = Invoke-SqlStackGuiPlanUpdate -Plan $planD1 -PhysicalMb 32246 -LogicalCores 22 -PortBase 14330 -PortsInUse @(1433) -KnownInstancePorts @{ MSSQLSERVER = 1433 }
    $fxAfter = (@($fxMs, $fxNew) | ForEach-Object { & $snapRow $_ }) -join ' || '
    Assert-True 'installed (D1): the plan update changes NOTHING on an installed row (every field, before and after)' ($fxBefore -ceq $fxAfter)
    $pMs = @($compD1.Ports.Instances | Where-Object { $_.Name -eq 'MSSQLSERVER' })
    $pNew = @($compD1.Ports.Instances | Where-Object { $_.Name -eq 'NEW2022' })
    Assert-True ("installed (D1): the port planner holds MSSQLSERVER at 1433 as Fixed and reserves nothing for NEW2022 ({0} {1}; {2} {3})" -f $pMs[0].Status, $pMs[0].Port, $pNew[0].Status, $pNew[0].Port) `
        (($pMs.Count -eq 1) -and ($pMs[0].Status -eq 'Fixed') -and ([string]$pMs[0].Port -eq '1433') -and ($pNew.Count -eq 1) -and ($pNew[0].Status -eq 'Fixed') -and ([string]$pNew[0].Port -eq 'dynamic'))
    Assert-True ("installed (D1): only the NEW instance is planned: port 14330 + ordinal 3 = {0}, MAXDOP floor(22/3) = {1}" -f $newRow.Port, $newRow.MaxDop) `
        (([int]$newRow.Port -eq 14333) -and ([int]$newRow.MaxDop -eq 7) -and ([string]$newRow.DacPort -eq 'dynamic (SQL chooses at start-up)'))
    Assert-True ("installed (D1): with an installed instance's memory unread, the split is NOT COMPUTED and the new row keeps 0 ({0}, {1} MB)" -f $compD1.Memory.Status, $newRow.MaxMemoryMb) `
        (($compD1.Memory.Status -eq 'NotComputed') -and (-not $compD1.MemoryComputed) -and ([int]$newRow.MaxMemoryMb -eq 0))
    $vD1 = Test-SqlStackPlan -Plan $planD1 -Volumes $vols -PhysicalMb 32246 -PortsInUse @(1433) -KnownInstancePorts @{ MSSQLSERVER = 1433 } -InstalledNames @('MSSQLSERVER', 'NEW2022')
    $vD1Fixed = @($vD1 | Where-Object { $_.Area -match '/(MSSQLSERVER|NEW2022)$' })
    Assert-True ("installed (D1): the validator plans nothing for an installed row ({0} finding(s) name one)" -f $vD1Fixed.Count) ($vD1Fixed.Count -eq 0)
    Assert-True 'installed (D1): an unplanned max memory on the NEW row is an ERROR, so Generate stays off' `
        (@($vD1 | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -eq 'memory/INST01') -and ($_.Message -match 'Max memory is not set') }).Count -eq 1)
    Assert-True 'installed (D1): the over-commit check says it covers the new instance only' `
        (@($vD1 | Where-Object { ($_.Severity -eq 'WARN') -and ($_.Message -match 'covers the new instance\(s\) only') -and ($_.Message -match 'MSSQLSERVER, NEW2022') }).Count -eq 1)
    $clash = & $mk 'NEW2022' 3 'E:\X\Data' 'F:\X\Log' 'T:\X\TempDB'
    $vClash = Test-SqlStackPlan -Plan @($clash) -Volumes $vols -PhysicalMb 65536 -InstalledNames @('MSSQLSERVER', 'NEW2022')
    Assert-True 'installed (D1): a NEW instance may not take an installed name (Add, then rename, is the same path)' `
        (@($vClash | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Message -match 'already installed on this host') }).Count -eq 1)
    $fsD1 = @(Get-SqlStackGuiFileSet -Plan $planD1)
    $fsFixedHits = @($fsD1 | Where-Object { ([string]$_.Text -match 'INSTANCENAME="(MSSQLSERVER|NEW2022)"') -or ([string]$_.Text -match 'for the NEW instance (MSSQLSERVER|NEW2022)') })
    Assert-True ("installed (D1): the files are rendered for the NEW instance only ([{0}]; {1} mention an installed one)" -f (@($fsD1 | ForEach-Object { $_.Name }) -join ','), $fsFixedHits.Count) `
        (($fsD1.Count -eq 2) -and (@($fsD1 | Where-Object { $_.Instance -ne 'INST01' }).Count -eq 0) -and ($fsFixedHits.Count -eq 0))
    $fsOnlyFixed = @(Get-SqlStackGuiFileSet -Plan @($fxMs, $fxNew))
    Assert-True ("installed (D1): a plan of installed instances only renders NO file ({0})" -f $fsOnlyFixed.Count) ($fsOnlyFixed.Count -eq 0)

    # D4: the Arithmetic box shows the ENGINE's working, verbatim.
    $a4 = & $mk 'A' 1 'E:\A\Data' 'F:\A\Log' 'T:\A\TempDB'; $b4 = & $mk 'B' 2 'E:\B\Data' 'F:\B\Log' 'T:\B\TempDB'
    foreach ($r4 in @($a4, $b4)) { $r4.MaxMemoryMb = 0; $r4.MinMemoryMb = 0; $r4 | Add-Member -NotePropertyName MemoryWeight -NotePropertyValue 1; $r4 | Add-Member -NotePropertyName Fixed -NotePropertyValue $false }
    $compA4 = Invoke-SqlStackGuiPlanUpdate -Plan @($a4, $b4) -PhysicalMb 32246 -LogicalCores 22 -PortBase 14330 -InstalledNotInPlan @('MSSQLSERVER')
    $txtA4 = Format-SqlStackGuiArithmetic -Computation $compA4
    $engA4 = Get-SqlStackMemoryPlan -PhysicalMb 32246 -Instances @([pscustomobject]@{ Name = 'A'; MemoryWeight = 1 }, [pscustomobject]@{ Name = 'B'; MemoryWeight = 1 })
    $engA4Rows = @($engA4.Instances | Where-Object { -not $_.Fixed })
    Assert-True ("arithmetic (D4): the box carries the engine's own memory line verbatim ('{0}')" -f $engA4.Arithmetic) `
        (($compA4.Memory.Arithmetic -ceq $engA4.Arithmetic) -and $txtA4.Contains('engine: ' + $engA4.Arithmetic))
    Assert-True ("arithmetic (D4): each row holds the engine's split and says so (A {0} MB)" -f $a4.MaxMemoryMb) `
        (([int]$a4.MaxMemoryMb -eq [int]$engA4Rows[0].MaxMb) -and $txtA4.Contains(('A: max server memory in the plan row {0} MB = the split; min {1} MB = half of max' -f $engA4Rows[0].MaxMb, $engA4Rows[0].MinMb)))
    Assert-True 'arithmetic (D4): the port working is shown per new instance' `
        ($txtA4.Contains('A: port base 14330 + ordinal 1 = 14331') -and $txtA4.Contains('B: port base 14330 + ordinal 2 = 14332'))
    $a4.Port = 15000
    $txtTyped = Format-SqlStackGuiArithmetic -Computation (Get-SqlStackGuiPlanComputation -Plan @($a4, $b4) -PhysicalMb 32246 -LogicalCores 22 -PortBase 14330)
    Assert-True 'arithmetic (D4): a typed port is said to be typed, beside the allocation it replaced' `
        ($txtTyped.Contains('A: 15000, typed in the plan row (the allocation would be port base 14330 + ordinal 1 = 14331)'))
    Assert-True 'arithmetic (D4): the MAXDOP working is shown' ($txtA4.Contains('floor(22 logical cores / 2 instance(s) in the plan) = 11, capped at 8, at least 1: 8'))
    Assert-True 'arithmetic (D4): an installed instance left out of the plan is said, not silently ignored' ($txtA4 -match 'note: 1 installed instance\(s\) \(MSSQLSERVER\) are not in this plan')
    $txtD1 = Format-SqlStackGuiArithmetic -Computation $compD1
    Assert-True 'arithmetic (D4): a split that cannot be computed says why, in words' `
        (($txtD1 -match 'engine: not computed: the max server memory of the installed instance\(s\) MSSQLSERVER, NEW2022 was not read') -and ($txtD1 -match 'INST01: max server memory in the plan row 0 MB \(no split was computed: set it yourself\)'))
    $fxKnown = New-PlanRowFromInstalled -Instance $invMs -ObservedPort ([pscustomobject]@{ Name = 'MSSQLSERVER'; Port = 1433 }) -Ordinal 1
    $fxKnown.MaxMemoryMb = 3000
    $c4 = & $mk 'C' 2 'E:\C\Data' 'F:\C\Log' 'T:\C\TempDB'; $c4 | Add-Member -NotePropertyName MemoryWeight -NotePropertyValue 1; $c4 | Add-Member -NotePropertyName Fixed -NotePropertyValue $false
    $compK = Get-SqlStackGuiPlanComputation -Plan @($fxKnown, $c4) -PhysicalMb 32246 -LogicalCores 22 -PortBase 14330
    Assert-True ("arithmetic (D4): an installed instance whose memory IS known is subtracted by the engine as fixed ('{0}')" -f $compK.Memory.Arithmetic) `
        ($compK.MemoryComputed -and ($compK.Memory.Arithmetic -match 'fixed MSSQLSERVER=3000MB'))

    Write-Host ''
    Write-Host '-- the emitted files (D2) --'
    $brDisabled = ConvertTo-SqlStackGuiBrowser -Rows @([pscustomobject]@{ State = 'Stopped'; StartMode = 'Disabled'; StartName = 'NT AUTHORITY\LOCALSERVICE' }) -When '2026-10-01 07:00:00 +13:00'
    Assert-True ("browser (D2): the host's start mode maps through the engine's table and says so ('{0}' / {1})" -f $brDisabled.Value, $brDisabled.Source) `
        ($brDisabled.Ok -and ($brDisabled.Value -ceq 'Disabled') -and ($brDisabled.Source -match "start mode 'Disabled'") -and ($brDisabled.Source -match 'does not change it'))
    $brAbsent = ConvertTo-SqlStackGuiBrowser -Rows @()
    Assert-True ("browser (D2): no SQL Browser service means setup must not start one ('{0}')" -f $brAbsent.Value) ($brAbsent.Ok -and ($brAbsent.Value -ceq 'Disabled'))
    $brAuto = ConvertTo-SqlStackGuiBrowser -Rows @([pscustomobject]@{ StartMode = 'Auto' })
    Assert-True ("browser (D2): an automatic Browser stays automatic ('{0}')" -f $brAuto.Value) ($brAuto.Ok -and ($brAuto.Value -ceq 'Automatic'))
    $brBoot = ConvertTo-SqlStackGuiBrowser -Rows @([pscustomobject]@{ StartMode = 'Boot' })
    $brFail = ConvertTo-SqlStackGuiBrowser -Failed -Reason 'RPC unavailable'
    Assert-True 'browser (D2): an unmapped or unread start mode renders NOTHING, with the reason' `
        ((-not $brBoot.Ok) -and ($brBoot.Value -eq '') -and (-not $brFail.Ok) -and ($brFail.Source -match 'RPC unavailable'))
    $d2Row = & $mk 'INST01' 3 'E:\INST01\Data' 'F:\INST01\Log' 'T:\INST01\TempDB'
    $d2Row | Add-Member -NotePropertyName Fixed -NotePropertyValue $false
    $d2Row.Port = 14333
    $fsD2 = @(Get-SqlStackGuiFileSet -Plan @($fxMs, $fxNew, $d2Row) -Browser $brDisabled -HostName 'LAB01' -When '2026-10-01 07:00:00 +13:00')
    Assert-True ("files (D2): one ini and one script per NEW instance, named as the ini tells the operator ([{0}])" -f (@($fsD2 | ForEach-Object { $_.Name }) -join ', ')) `
        ((@($fsD2 | ForEach-Object { $_.Name }) -join ',') -ceq 'INST01-install.ini,INST01-post-install.sql')
    $iniD2 = [string]@($fsD2 | Where-Object { $_.Kind -eq 'ini' })[0].Text
    $sqlD2 = [string]@($fsD2 | Where-Object { $_.Kind -eq 'sql' })[0].Text
    # A content check of the engine's own run line against the file's name.
    $runName = $(if ($iniD2 -match '/ConfigurationFile=(\S+)') { $Matches[1] } else { '' })
    Assert-True ("files (D2): the ini's own run line names the file it is saved as ('{0}')" -f $runName) ($runName -ceq 'INST01-install.ini')
    Assert-True 'files (D2): the ini has ONE [OPTIONS] section (setup takes one instance per file)' (([regex]::Matches($iniD2, '(?m)^\[OPTIONS\]')).Count -eq 1)
    Assert-True 'files (D2): the ini says where its values came from: no spec, the GUI plan row, and the host''s SQL Browser read' `
        (($iniD2 -match '; Provenance: written by the SqlStack GUI') -and ($iniD2 -match 'There is no spec file and no plan hash') -and
         ($iniD2 -match "BROWSERSVCSTARTUPTYPE: this host's SQL Browser service start mode 'Disabled'") -and ($iniD2 -match 'BROWSERSVCSTARTUPTYPE="Disabled"') -and
         ($iniD2 -notmatch 'explicit host.shared.browser override'))
    Assert-True ("files (D2): the ini rendered clean (Ok {0}; problems [{1}])" -f @($fsD2 | Where-Object { $_.Kind -eq 'ini' })[0].Ok, (@(@($fsD2 | Where-Object { $_.Kind -eq 'ini' })[0].Problems) -join '; ')) `
        ([bool]@($fsD2 | Where-Object { $_.Kind -eq 'ini' })[0].Ok)
    # TRIPWIRE (characters): the settings the header lists, against the sp_configure calls in the body.
    $hdrList = $(if ($sqlD2 -match '(?m)^--   (.+)$') { @($Matches[1].Trim() -split '; ') } else { @() })
    $bodySet = @([regex]::Matches($sqlD2, "EXEC @rc = sys\.sp_configure '([^']+)'") | ForEach-Object { $_.Groups[1].Value })
    Assert-True ("sql (D2): the script sets exactly the settings its header lists (header [{0}]; body [{1}]) - a tripwire over its text" -f ($hdrList -join ', '), ($bodySet -join ', ')) `
        (($hdrList.Count -eq 6) -and (($hdrList -join '|') -ceq ($bodySet -join '|')))
    Assert-True 'sql (D2): no registry procedure, and the header says where the backup directory is set (tripwire)' `
        (($sqlD2 -notmatch '(?i)xp_(instance_)?reg') -and ($sqlD2 -match 'SQLBACKUPDIR in INST01-install\.ini'))
    Assert-True 'sql (D2): each statement says where its value came from' `
        (($sqlD2 -match "max server memory \(MB\)', 20000;\s+-- sets 20000: the plan row's Max memory MB") -and ($sqlD2 -match "remote admin connections', 1;\s+-- sets 1: this planner's default"))
    if ($null -ne $parser) {
        $errsD2 = $null
        [void]$parser.Parse((New-Object System.IO.StringReader($sqlD2)), [ref]$errsD2)
        Assert-True ("sql (D2): the per-instance script passes the T-SQL parse gate ({0} error(s))" -f @($errsD2).Count) ($null -eq $errsD2 -or $errsD2.Count -eq 0)
    } else { Write-Host '  SKIP  sql (D2): T-SQL parse-gate (ScriptDom not loadable), as the parse gate above' }
    $badName = & $mk '..\evil' 1 'E:\x' 'F:\x' 'T:\x'
    $refused = $false; try { [void](Get-SqlStackGuiFileSet -Plan @($badName)) } catch { $refused = $true }
    Assert-True 'files (D2): a name that is not an instance name is refused before a file name is built from it' $refused

    # (iv) the writer: one folder, named files only, and a yes before replacing anything.
    $wDir = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-gui-save-' + [guid]::NewGuid().ToString('N'))
    [void](New-Item -ItemType Directory -Path $wDir)
    try {
        $script:askedD2 = @()
        $w1 = Write-SqlStackGuiFileSet -Folder $wDir -FileSet $fsD2 -ConfirmOverwrite { param($e) $script:askedD2 = @($e); $true }
        Assert-True ("save (D2): a fresh folder gets exactly the set, and nobody is asked ([{0}])" -f (@($w1.Written) -join ', ')) `
            ((-not $w1.Cancelled) -and (@($w1.Written).Count -eq 2) -and (@($script:askedD2).Count -eq 0) -and
             ((@(Get-ChildItem -LiteralPath $wDir | ForEach-Object { $_.Name } | Sort-Object) -join ',') -ceq 'INST01-install.ini,INST01-post-install.sql'))
        $iniPath = Join-Path $wDir 'INST01-install.ini'
        [IO.File]::WriteAllText($iniPath, 'OPERATOR EDIT', (New-Object System.Text.UTF8Encoding($false)))
        $w2 = Write-SqlStackGuiFileSet -Folder $wDir -FileSet $fsD2 -ConfirmOverwrite { param($e) $script:askedD2 = @($e); $false }
        Assert-True ("save (D2): replacing existing files asks first, and a no writes NOTHING (asked about [{0}])" -f (@($script:askedD2) -join ', ')) `
            ($w2.Cancelled -and (@($w2.Written).Count -eq 0) -and ((@($script:askedD2) -join ',') -ceq 'INST01-install.ini,INST01-post-install.sql') -and ([IO.File]::ReadAllText($iniPath) -ceq 'OPERATOR EDIT'))
        $w3 = Write-SqlStackGuiFileSet -Folder $wDir -FileSet $fsD2 -ConfirmOverwrite { param($e) 'yes' }
        Assert-True 'save (D2): only a real $true replaces (a string answer writes nothing)' ($w3.Cancelled -and ([IO.File]::ReadAllText($iniPath) -ceq 'OPERATOR EDIT'))
        $w4 = Write-SqlStackGuiFileSet -Folder $wDir -FileSet $fsD2 -ConfirmOverwrite { param($e) $true }
        Assert-True 'save (D2): a yes replaces them, UTF-8 without a BOM' `
            ((-not $w4.Cancelled) -and ([IO.File]::ReadAllText($iniPath) -ceq $iniD2) -and ([IO.File]::ReadAllBytes($iniPath)[0] -ne 0xEF))
        $escaped = $false
        try { [void](Write-SqlStackGuiFileSet -Folder $wDir -FileSet @([pscustomobject]@{ Name = '..\INST01-install.ini'; Text = 'x' }) -ConfirmOverwrite { param($e) $true }) } catch { $escaped = $true }
        Assert-True 'save (D2): a name that would leave the folder is refused, and nothing is written' `
            ($escaped -and (-not (Test-Path -LiteralPath (Join-Path (Split-Path -Parent $wDir) 'INST01-install.ini'))))
    } finally { Remove-Item -LiteralPath $wDir -Recurse -Force -ErrorAction SilentlyContinue }
    $fpA = Get-SqlStackGuiPlanFingerprint -Plan @($fxMs, $d2Row)
    $d2Row.MaxDop = 3
    Assert-True 'save (D2): the plan fingerprint moves when a planned value changes, so Save refuses a stale set' ($fpA -cne (Get-SqlStackGuiPlanFingerprint -Plan @($fxMs, $d2Row)))
    # Specimen control first: the trap the helper exists for is real in this
    # PowerShell, or the three rows after it prove nothing.
    Assert-True 'save (generate first): specimen: @($null).Count is 1 here, so a bare count cannot tell "not generated" apart' (@($null).Count -eq 1)
    Assert-True 'save (generate first): no file set yet ($null) is "not generated", so Save says "Generate first."' (-not (Test-SqlStackGuiHasFileSet -FileSet $null))
    Assert-True 'save (generate first): an empty set is "not generated"' (-not (Test-SqlStackGuiHasFileSet -FileSet @()))
    Assert-True 'save (generate first): a generated set (two files, or one) is "generated"' ((Test-SqlStackGuiHasFileSet -FileSet $fsD2) -and (Test-SqlStackGuiHasFileSet -FileSet (@($fsD2)[0])))

    Write-Host ''
    Write-Host '-- SQL install media, READ through the engine''s own rule-7 readers (lane sqlstack-gui-media) --'
    # The fixtures are the engine's, not a second set: tests\fixtures\spec\media
    # is what rule 7's own loader tests run against, so this window and the rail
    # are proved against the SAME trees. Two of them are deliberately broken.
    $mediaRoot = Join-Path $PSScriptRoot 'tests\fixtures\spec\media'
    $m2022 = Read-SqlStackGuiMedia -MediaPath (Join-Path $mediaRoot '2022')
    $m2025 = Read-SqlStackGuiMedia -MediaPath (Join-Path $mediaRoot '2025')
    $m2017 = Read-SqlStackGuiMedia -MediaPath (Join-Path $mediaRoot '2017')
    Assert-True ("media: the three good trees read as their own version and baseline - 2017 {0}/{1}, 2022 {2}/{3}, 2025 {4}/{5}" -f `
            $m2017.Version, $m2017.Baseline, $m2022.Version, $m2022.Baseline, $m2025.Version, $m2025.Baseline) `
        ($m2017.Ok -and $m2022.Ok -and $m2025.Ok -and `
         ($m2017.Version -ceq '2017') -and ($m2022.Version -ceq '2022') -and ($m2025.Version -ceq '2025') -and `
         ($m2017.Baseline -ceq '14.0.1000.169') -and ($m2022.Baseline -ceq '16.0.1000.6') -and ($m2025.Baseline -ceq '17.0.1000.7'))
    # The VERSION is read back off the media, never from the folder's name: the
    # 2025 tree is read while sitting in a folder called '2025', so prove the
    # name is not what produced it by reading a tree whose name says nothing.
    $mCopy = Join-Path ([IO.Path]::GetTempPath()) ('ss-media-' + [Guid]::NewGuid().ToString('n'))
    try {
        Copy-Item -LiteralPath (Join-Path $mediaRoot '2022') -Destination $mCopy -Recurse
        $mAnon = Read-SqlStackGuiMedia -MediaPath $mCopy
        Assert-True ("media: the version comes from MediaInfo.xml and NOT from the folder name - a 2022 tree in a folder called '{0}' still reads {1}" -f `
                (Split-Path -Leaf $mCopy), $mAnon.Version) `
            ($mAnon.Ok -and ($mAnon.Version -ceq '2022') -and ($mAnon.Baseline -ceq '16.0.1000.6'))
    } finally { Remove-Item -LiteralPath $mCopy -Recurse -Force -ErrorAction SilentlyContinue }
    # The four ways it can fail, each said in its OWN words rather than 'invalid'.
    $mNoSetup = Read-SqlStackGuiMedia -MediaPath (Join-Path $mediaRoot 'no-setup')
    $mNoAttr  = Read-SqlStackGuiMedia -MediaPath (Join-Path $mediaRoot 'bad-noattr')
    $mEmpty   = Read-SqlStackGuiMedia -MediaPath ''
    $mGone    = Read-SqlStackGuiMedia -MediaPath (Join-Path $mediaRoot 'no-such-tree')
    Assert-True ("media: each failure is NAMED and they are four DIFFERENT sentences - no setup ('{0}'), no Value attribute ('{1}'), nothing chosen ('{2}'), folder absent ('{3}')" -f `
            $mNoSetup.Problem, $mNoAttr.Problem, $mEmpty.Problem, $mGone.Problem) `
        ((-not $mNoSetup.Ok) -and (-not $mNoAttr.Ok) -and (-not $mEmpty.Ok) -and (-not $mGone.Ok) -and `
         ([string]$mNoSetup.Problem -match 'setup\.exe') -and `
         ([string]$mNoAttr.Problem -match 'Value attribute') -and `
         ([string]$mEmpty.Problem -match 'no media folder') -and `
         ([string]$mGone.Problem -match 'does not exist') -and `
         (@(@($mNoSetup.Problem, $mNoAttr.Problem, $mEmpty.Problem, $mGone.Problem) | Sort-Object -Unique).Count -eq 4))
    Assert-True 'media: a failed read yields NO version and NO baseline, so nothing downstream can use a half-read tree' `
        (([string]$mNoSetup.Version -eq '') -and ([string]$mNoAttr.Version -eq '') -and ([string]$mNoAttr.Baseline -eq ''))

    Write-Host ''
    Write-Host '-- the generated spec: every value READ or PLANNED, none typed (lane sqlstack-gui-media) --'
    $spRow = & $mk 'INST01' 1 'E:\INST01\Data' 'F:\INST01\Log' 'T:\INST01\TempDB'
    $spRow | Add-Member -NotePropertyName MediaPath -NotePropertyValue (Join-Path $mediaRoot '2022')
    $spRow | Add-Member -NotePropertyName MediaVersion -NotePropertyValue '2022'
    $spRow | Add-Member -NotePropertyName MediaBaseline -NotePropertyValue '16.0.1000.6'
    $spRow | Add-Member -NotePropertyName MediaProblem -NotePropertyValue ''
    $spRow | Add-Member -NotePropertyName Fixed -NotePropertyValue $false
    $spRow.Port = 14331
    $spInstalled = @([pscustomobject]@{ Name = 'MSSQLSERVER' }, [pscustomobject]@{ Name = 'OLD2017' })
    $sp = New-SqlStackGuiSpec -Plan @($spRow) -Installed $spInstalled -HostName 'LAB01' -PortBase 14330 `
            -Edition 'Developer' -SysAdmin @('BUILTIN\Administrators', 'LAB01\someone')
    $spDoc = $null
    try { $spDoc = $sp.Text | ConvertFrom-Json } catch { $spDoc = $null }
    Assert-True ("spec: it is valid JSON, speaks the ENGINE's schema constant ('{0}'), and names {1} protected + {2} new instance(s)" -f `
            $(if ($spDoc) { [string]$spDoc.schema } else { '(unparseable)' }), $sp.ProtectedCount, $sp.InstanceCount) `
        ($sp.Ok -and ($null -ne $spDoc) -and ([string]$spDoc.schema -ceq $script:SqlStackSpecSchema) -and `
         ($sp.ProtectedCount -eq 2) -and ($sp.InstanceCount -eq 1))
    $spNew = @(@($spDoc.instances) | Where-Object { [string]$_.name -eq 'INST01' })
    $spProt = @(@($spDoc.instances) | Where-Object { $_.protected -eq $true })
    Assert-True ("spec: EVERY installed instance is carried as protected ([{0}]), because one the spec omits is one nothing protects" -f `
            ((@($spProt) | ForEach-Object { [string]$_.name }) -join ', ')) `
        ((@($spProt).Count -eq 2) -and `
         ((@($spProt) | ForEach-Object { [string]$_.name } | Sort-Object) -join ',') -ceq 'MSSQLSERVER,OLD2017')
    Assert-True ("spec: the new row's version is the one READ off its media ({0}) and its mediaPath is the folder that was browsed, not a name" -f `
            [string]@($spNew)[0].version) `
        ((@($spNew).Count -eq 1) -and ([string]@($spNew)[0].version -ceq '2022') -and `
         ([string]@($spNew)[0].mediaPath -ceq (Join-Path $mediaRoot '2022')) -and `
         ([string]@($spNew)[0].edition -ceq 'Developer'))
    Assert-True ("spec: host.name is the host it was generated on ('{0}') and the PLANNED port is an integer, not 'auto' ({1})" -f `
            [string]$spDoc.host.name, [string]@($spNew)[0].ports.tcp) `
        (([string]$spDoc.host.name -ceq 'LAB01') -and ([int]@($spNew)[0].ports.tcp -eq 14331) -and `
         ([int]$spDoc.host.portBase -eq 14330))
    # The refusals. A spec that cannot say what to install from is not written.
    $spNoMediaRow = & $mk 'INST02' 2 'E:\INST02\Data' 'F:\INST02\Log' 'T:\INST02\TempDB'
    $spNoMediaRow | Add-Member -NotePropertyName MediaPath -NotePropertyValue ''
    $spNoMediaRow | Add-Member -NotePropertyName MediaVersion -NotePropertyValue ''
    $spNoMediaRow | Add-Member -NotePropertyName MediaProblem -NotePropertyValue ''
    $spNoMediaRow | Add-Member -NotePropertyName Fixed -NotePropertyValue $false
    $spNo = New-SqlStackGuiSpec -Plan @($spNoMediaRow) -Installed $spInstalled -HostName 'LAB01' -Edition 'Developer'
    $spClash = & $mk 'OLD2017' 3 'E:\X\Data' 'F:\X\Log' 'T:\X\TempDB'
    $spClash | Add-Member -NotePropertyName MediaPath -NotePropertyValue (Join-Path $mediaRoot '2022')
    $spClash | Add-Member -NotePropertyName MediaVersion -NotePropertyValue '2022'
    $spClash | Add-Member -NotePropertyName MediaProblem -NotePropertyValue ''
    $spClash | Add-Member -NotePropertyName Fixed -NotePropertyValue $false
    $spCl = New-SqlStackGuiSpec -Plan @($spClash) -Installed $spInstalled -HostName 'LAB01' -Edition 'Developer'
    Assert-True ("spec: an instance with no media is REFUSED and named ('{0}'), and a new instance taking an INSTALLED name is refused too ('{1}')" -f `
            ((@($spNo.Problems) | Select-Object -First 1) -join ''), ((@($spCl.Problems) | Select-Object -First 1) -join '')) `
        ((-not $spNo.Ok) -and (@($spNo.Problems) -join ' ') -match 'INST02' -and `
         (-not $spCl.Ok) -and (@($spCl.Problems) -join ' ') -match 'OLD2017')
    $spAdmins = Get-SqlStackGuiSysAdmin
    Assert-True ("spec: the sysadmins are READ off this session, never typed - {0} entry(s), the local group among them" -f @($spAdmins).Count) `
        ((@($spAdmins).Count -ge 1) -and (@($spAdmins) -contains 'BUILTIN\Administrators'))

    Write-Host ''
    Write-Host '-- the per-instance endpoint: IP and port (RULED 2026-10-09) --'
    $epMk = {
        param($name, $ip, $port)
        [pscustomobject]@{ Name=$name; Ordinal=1; Port=$port; DacPort=$null; Ip=$ip; ListenAll=$false
            DataPath='E:\X\Data'; LogPath='F:\X\Log'; TempDbPath='T:\X\TempDB'; BackupPath='G:\X\Backup'
            MaxMemoryMb=4096; MinMemoryMb=1024; MaxDop=4; CostThreshold=50
            TempDbFileCount=8; TempDbFileSizeMb=1024; Fixed=$false }
    }
    # The ruled shape: five instances, five IPs, five ports. It must be silent.
    $epGood = @(
        (& $epMk 'BILLING'        '10.0.0.72' 1435), (& $epMk 'REPORT'  '10.0.0.74' 1436),
        (& $epMk 'CDRCOLLECTOR'   '10.0.0.76' 1437), (& $epMk 'PORTAL'  '10.0.0.78' 1438),
        (& $epMk 'ARCHIVE'        '10.0.0.80' 1439))
    $epGoodR = Test-SqlStackPlan -Plan $epGood -Volumes $vols -PhysicalMb 65536
    Assert-True ("endpoint: the ruled shape - 5 instances, 5 IPs, 5 ports - raises NOTHING about IPs or ports ({0} finding(s))" -f `
            @($epGoodR | Where-Object { $_.Area -match '^(endpoint|ip|port-shared)/' }).Count) `
        (@($epGoodR | Where-Object { $_.Area -match '^(endpoint|ip|port-shared)/' }).Count -eq 0)
    # The thing Adrian asked for: the SAME IP AND the SAME PORT is an ERROR.
    $epDup = @((& $epMk 'BILLING' '10.0.0.72' 1435), (& $epMk 'REPORT' '10.0.0.72' 1435))
    $epDupR = Test-SqlStackPlan -Plan $epDup -Volumes $vols -PhysicalMb 65536
    $epDupE = @($epDupR | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^endpoint/') })
    Assert-True ("endpoint: two instances on the SAME IP AND PORT is an ERROR naming both ('{0}')" -f (@($epDupE | ForEach-Object { $_.Message }) -join ' | ')) `
        ((@($epDupE).Count -eq 1) -and ([string]@($epDupE)[0].Message -match 'BILLING') -and ([string]@($epDupE)[0].Message -match 'REPORT'))
    # And ONE finding, not three: the pair check suppresses the two softer ones.
    Assert-True ("endpoint: one collision yields ONE finding, not an error plus two warnings ({0} IP/port warning(s))" -f `
            @($epDupR | Where-Object { $_.Area -match '^(ip|port-shared)/' }).Count) `
        (@($epDupR | Where-Object { $_.Area -match '^(ip|port-shared)/' }).Count -eq 0)
    # The two legal-but-off-pattern shapes are WARN, and they are NOT errors.
    $epSameIp = Test-SqlStackPlan -Plan @((& $epMk 'A' '10.0.0.72' 1435), (& $epMk 'B' '10.0.0.72' 1436)) -Volumes $vols -PhysicalMb 65536
    $epSamePort = Test-SqlStackPlan -Plan @((& $epMk 'A' '10.0.0.72' 1435), (& $epMk 'B' '10.0.0.74' 1435)) -Volumes $vols -PhysicalMb 65536
    Assert-True ("endpoint: same IP different ports, and same port different IPs, are WARN and never ERROR ({0} / {1})" -f `
            @($epSameIp | Where-Object { $_.Area -match '^ip/' }).Count, @($epSamePort | Where-Object { $_.Area -match '^port-shared/' }).Count) `
        ((@($epSameIp | Where-Object { ($_.Severity -eq 'WARN') -and ($_.Area -match '^ip/') }).Count -eq 1) -and `
         (@($epSameIp | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^(endpoint|ip)/') }).Count -eq 0) -and `
         (@($epSamePort | Where-Object { ($_.Severity -eq 'WARN') -and ($_.Area -match '^port-shared/') }).Count -eq 1) -and `
         (@($epSamePort | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^(endpoint|port-shared)/') }).Count -eq 0))
    Assert-True 'endpoint: the shared-port warning DISCLOSES the Kerberos caveat as believed-not-proved, rather than asserting it' `
        (([string]@($epSamePort | Where-Object { $_.Area -match '^port-shared/' })[0].Message -match 'Kerberos') -and `
         ([string]@($epSamePort | Where-Object { $_.Area -match '^port-shared/' })[0].Message -match 'BELIEVED'))
    # An INSTALLED instance is a constraint: planning onto its endpoint collides.
    $epFixed = (& $epMk 'OLD2017' '10.0.0.72' 1435); $epFixed.Fixed = $true
    $epVsFixed = Test-SqlStackPlan -Plan @($epFixed, (& $epMk 'NEWONE' '10.0.0.72' 1435)) -Volumes $vols -PhysicalMb 65536
    Assert-True ("endpoint: an INSTALLED instance's endpoint is a constraint, so planning onto it is an ERROR ({0})" -f `
            @($epVsFixed | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^endpoint/') }).Count) `
        (@($epVsFixed | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^endpoint/') }).Count -eq 1)
    $epBadIp = Test-SqlStackPlan -Plan @((& $epMk 'A' '10.0.0.999' 1435)) -Volumes $vols -PhysicalMb 65536
    Assert-True ("endpoint: a value that is not an IP address is refused before anything is bound to it ({0})" -f `
            (@($epBadIp | Where-Object { $_.Area -match '^ip/' } | ForEach-Object { $_.Message }) -join '')) `
        (@($epBadIp | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^ip/') }).Count -eq 1)
    # A row with no IP yet is simply not an endpoint: planning starts empty and
    # must not be red before the operator has typed anything.
    $epNoIp = Test-SqlStackPlan -Plan @((& $epMk 'A' '' 1435), (& $epMk 'B' '' 1436)) -Volumes $vols -PhysicalMb 65536
    Assert-True 'endpoint: rows with no IP yet raise nothing, so an empty plan is not red before anything is typed' `
        (@($epNoIp | Where-Object { $_.Area -match '^(endpoint|ip|port-shared)/' }).Count -eq 0)

    # Found by adversarial review 2026-10-17: the collision key was the RAW typed
    # string, so one address written two ways was two keys and the duplicate rule
    # - the one specifically asked for - passed with zero errors.
    $epDupSpell = Test-SqlStackPlan -Volumes $vols -PhysicalMb 65536 -Plan @(
        (& $epMk 'BILLING' '10.0.0.72' 1435), (& $epMk 'REPORT' '010.0.0.72' 1435))
    $epSpellErr = @($epDupSpell | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^(endpoint|ip)/') })
    Assert-True ("endpoint: one address written TWO WAYS is still one endpoint - a zero-padded spelling cannot smuggle a second instance onto it ({0} error(s))" -f @($epSpellErr).Count) `
        ((@($epSpellErr).Count -ge 1) -and `
         ((@($epSpellErr) | ForEach-Object { [string]$_.Message }) -join ' ') -match '(OCTAL|zero-padded)')
    # review(w1) (item M2, class comparison-key-not-canonical, V3 2026-11-03): the
    # port verdict and the endpoint verdict must read ONE key. Until 2026-11-03 the
    # port-split check keyed on the typed string, so two spellings of ONE IPv6
    # address looked like two IPs and the port Duplicate ERROR was suppressed.
    $epV6 = Test-SqlStackPlan -Volumes $vols -PhysicalMb 65536 -Plan @(
        (& $epMk 'BILLING' '2001:db8::5' 1435), (& $epMk 'REPORT' '2001:db8:0:0:0:0:0:5' 1435))
    Assert-True ("review(w1): '2001:db8::5' and '2001:db8:0:0:0:0:0:5' on one port raise the port Duplicate ERROR as well as the endpoint ERROR (port {0}, endpoint {1})" -f `
            @($epV6 | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^port/') }).Count, @($epV6 | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^endpoint/') }).Count) `
        ((@($epV6 | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^port/') }).Count -ge 1) -and (@($epV6 | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -match '^endpoint/') }).Count -eq 1))

    Write-Host ''
    Write-Host '-- the trace log: it records, it never throws, and it says whether it is safe to send --'
    # The log's ONE job on a machine nobody here can reach is to still exist when
    # something went wrong, so the properties tested are: it writes, it survives a
    # broken path, and its footer tells the operator whether to paste it.
    $lgDir = Join-Path ([IO.Path]::GetTempPath()) ('ss-log-' + [Guid]::NewGuid().ToString('n'))
    [void](New-Item -ItemType Directory -Path $lgDir -Force)
    try {
        $lgKeepFile = $script:LogFile; $lgKeepOn = $script:LogEnabled; $lgKeepN = $script:LogLines
        $script:LogFile = (Join-Path $lgDir 't.log'); $script:LogEnabled = $true; $script:LogLines = 0
        Write-SqlStackGuiLog 'MEDIA' 'a line with a stage'
        Write-SqlStackGuiLogError 'ERROR' 'a thing that failed' $(try { throw 'boom' } catch { $_ })
        $lgText = [IO.File]::ReadAllText($script:LogFile)
        $lgLines = @([IO.File]::ReadAllLines($script:LogFile))
        Assert-True ("log: it writes stamped, staged lines and an exception becomes SEVERAL lines with type, message and stack ({0} line(s))" -f @($lgLines).Count) `
            ((@($lgLines).Count -ge 5) -and `
             (@($lgLines)[0] -match '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}\s+MEDIA\s+a line with a stage$') -and `
             ($lgText -match 'FAILED: a thing that failed') -and ($lgText -match 'type   : ') -and `
             ($lgText -match 'message: boom') -and ($lgText -match 'stack  : '))
        $lgNoBom = [IO.File]::ReadAllBytes($script:LogFile)
        Assert-True 'log: UTF-8 with NO BOM, like every other file this window writes' `
            (-not (($lgNoBom.Length -ge 3) -and ($lgNoBom[0] -eq 0xEF) -and ($lgNoBom[1] -eq 0xBB) -and ($lgNoBom[2] -eq 0xBF)))
        # THE PROPERTY THAT MATTERS MOST: a log that throws would take the window
        # down with it, so an unwritable path must DISABLE the log, not raise.
        $script:LogFile = (Join-Path $lgDir "no-such-dir\nested\t.log")
        $lgThrew = $false
        try { Write-SqlStackGuiLog 'MEDIA' 'into a path that does not exist' } catch { $lgThrew = $true }
        Assert-True ('log: a write to an impossible path DISABLES the log and throws nothing (threw {0}, enabled now {1})' -f $lgThrew, $script:LogEnabled) `
            ((-not $lgThrew) -and (-not $script:LogEnabled))
        $lgOffCount = $script:LogLines
        Write-SqlStackGuiLog 'MEDIA' 'and a disabled log stays quiet'
        Assert-True 'log: once disabled it writes nothing further, rather than retrying on every line' ($script:LogLines -eq $lgOffCount)
        # The footer's verdict, over text the ENGINE's gate judges - not a second
        # copy of the rules. A clean trace and a dirty one must read differently.
        $lgClean = Test-ScrubGate -Text '2026-01-01 00:00:00.000  MEDIA   INST01: OK - SQL 2022, baseline 16.0.1000.6, from D:\SQL2022'
        $lgDirty = Test-ScrubGate -Text '2026-01-01 00:00:00.000  SPEC    sysadmins: CONTOSO\someone and someone@example.com via \\fileserver\share'
        Assert-True ("log: the footer's verdict comes from the engine's own scrub gate - a clean trace yields {0} finding(s), one carrying an account, an email and a UNC yields {1}" -f `
                @($lgClean).Count, @($lgDirty).Count) `
            ((@($lgClean).Count -eq 0) -and (@($lgDirty).Count -ge 3))
        $script:LogFile = $lgKeepFile; $script:LogEnabled = $lgKeepOn; $script:LogLines = $lgKeepN
    } finally { Remove-Item -LiteralPath $lgDir -Recurse -Force -ErrorAction SilentlyContinue }

    Write-Host ''
    Write-Host '-- workbench spine: run folder, stage reader, command builder, over REAL producer files (lane sqlstack-workbench) --'
    # The shapes are the real producers' (tests\fixtures\README-window.md): a real
    # unelevated dry run's transcripts and plans, and a real snapshot bundle. The
    # copies are RELOCATED (one path prefix rewritten, file times set to the real
    # ones) because the S1 rule matches a transcript to its spec by full path and
    # by time; no byte a reader judges is otherwise changed.
    $wbFx = Join-Path (Split-Path -Parent $script:EntryScriptPath) 'tests\fixtures\window'
    $wbTool = Split-Path -Parent $script:EntryScriptPath
    $wbTmp = Join-Path ([IO.Path]::GetTempPath()) ('ss-wb-' + [Guid]::NewGuid().ToString('n'))
    $wbUtf8Bom = New-Object System.Text.UTF8Encoding($true)
    $wbUtf8 = New-Object System.Text.UTF8Encoding($false)
    $wbCriticRun = 'C:\temp\lanes\sqlstack-ip-binding\critic-workbench\dry2\run'
    $wbCriticV9 = 'C:\temp\lanes\sqlstack-ip-binding\critic-workbench\dry2\v9'
    $wbCriticMedia = 'C:\GitHub\lanes\sqlstack-ip-binding-tools\SqlStack\tests\fixtures\spec\media\2022'
    $wbMedia = Join-Path $wbTool 'tests\fixtures\spec\media\2022'
    $wbHashes = @{ R1 = '745386ef124cdbfc9a7c24af4958c79e9f0a759a1ad8ea9906f497c2e811813b'; R2 = '345d56592db92e92071563c5037148e236367bfa68fc3972e299c9fb3693b422'
                   P1 = '5a038b3c94e85dd7d5d6950dcbd23e0c69346b2ffd03288516e026032726f9cd'; P2 = 'e5256e4d8421c993951c95e4c8bc456f3345f333c6fe0b2ab53460adcc7f24c3'
                   A1 = 'e813c5c46c6315e6f03e64a054dcfceaf58038cc3816b813abba5d20fcac0750' }
    $wbSpecUtc = [datetime]::Parse('2026-11-03T08:16:00.4842425Z').ToUniversalTime()
    $wbAbsUtc = [datetime]::Parse('2026-11-03T08:16:14.6889124Z').ToUniversalTime()
    # One relocated copy: <dir>\run\spec.json + spec-absent.json, <dir>\state\...
    $wbSeed = {
        param([string]$Dir)
        $run = Join-Path $Dir 'run'; $state = Join-Path $Dir 'state'
        [void](New-Item -ItemType Directory -Path (Join-Path $state 'console') -Force); [void](New-Item -ItemType Directory -Path $run -Force)
        foreach ($f in @(Get-ChildItem -LiteralPath (Join-Path $wbFx 'dry2\state') -File)) { [IO.File]::WriteAllBytes((Join-Path $state $f.Name), [IO.File]::ReadAllBytes($f.FullName)) }
        foreach ($f in @(Get-ChildItem -LiteralPath (Join-Path $wbFx 'dry2\state\console') -File)) {
            $t = [IO.File]::ReadAllText($f.FullName)
            [IO.File]::WriteAllText((Join-Path (Join-Path $state 'console') $f.Name), $t.Replace($wbCriticRun, $run), $wbUtf8Bom)
        }
        foreach ($sp in @('spec.json', 'spec-absent.json')) {
            $t = [IO.File]::ReadAllText((Join-Path (Join-Path $wbFx 'dry2') $sp))
            [IO.File]::WriteAllText((Join-Path $run $sp), $t.Replace($wbCriticMedia.Replace('\', '\\'), $wbMedia.Replace('\', '\\')), $wbUtf8)
        }
        [IO.File]::SetLastWriteTimeUtc((Join-Path $run 'spec.json'), $wbSpecUtc)
        [IO.File]::SetLastWriteTimeUtc((Join-Path $run 'spec-absent.json'), $wbAbsUtc)
        return [pscustomobject]@{ Run = $run; State = $state; Spec = (Join-Path $run 'spec.json'); Absent = (Join-Path $run 'spec-absent.json') }
    }
    $wbLab = @('MSSQLSERVER', 'LABA', 'LABB', 'LABC')
    try {
        # ---- the run-folder resolver (INV-1) ----
        $rp = Join-Path $wbTmp 'r p'
        $items = Get-SqlStackGuiRunItem
        $inside = @(@($items.Keys) | Where-Object { ([IO.Path]::GetDirectoryName((Get-SqlStackGuiRunPath -Root $rp -Item $_))) -eq [IO.Path]::GetFullPath($rp) })
        Assert-True ("run folder: every one of the {0} items resolves DIRECTLY inside the run folder ({1})" -f @($items.Keys).Count, (@($items.Keys) -join ', ')) ($inside.Count -eq @($items.Keys).Count)
        $refusals = @()
        foreach ($bad in @(@{ R = $rp; I = 'state' }, @{ R = $rp; I = '..\x' }, @{ R = 'C:\'; I = 'Spec' }, @{ R = ''; I = 'Spec' })) {
            $threw = $false; try { [void](Get-SqlStackGuiRunPath -Root $bad.R -Item $bad.I) } catch { $threw = $true }; $refusals += $threw
        }
        Assert-True ("run folder: an unknown item, a traversal, a drive root and no folder are each REFUSED (threw: {0})" -f ($refusals -join ',')) (@($refusals | Where-Object { -not $_ }).Count -eq 0)
        Assert-True ("run folder: the state folder is NOT in the run folder (K3): the default is the engine's one host-wide '{0}'" -f $script:SqlStackDefaultStatePath) `
            ((-not $items.Contains('State')) -and ([string]$script:SqlStackDefaultStatePath -eq 'C:\temp\SqlStack\state'))
        $wp = Write-SqlStackGuiRunFile -Root $rp -Item 'Spec' -Text '{ "x": 1 }'
        $wb = [IO.File]::ReadAllBytes($wp)
        Assert-True ("run folder: the writer creates the folder and writes spec.json there, UTF-8 with no BOM ({0})" -f $wp) `
            (($wp -eq (Join-Path ([IO.Path]::GetFullPath($rp)) 'spec.json')) -and ($wb[0] -ne 0xEF) -and ([IO.File]::ReadAllText($wp) -eq '{ "x": 1 }'))
        $exp = Initialize-SqlStackGuiRunFolder -Root $rp -Item 'Export'
        Assert-True 'run folder: the export folder is created inside the run folder, never elsewhere' ($exp -eq (Join-Path ([IO.Path]::GetFullPath($rp)) 'export'))
        $dflt = Get-SqlStackGuiDefaultRunFolder -HostName 'LAB01' -Now ([datetime]'2026-11-03 21:05')
        Assert-True ("run folder: the default is C:\temp\SqlStack\runs\<HOST>-<yyyyMMdd-HHmm> ('{0}')" -f $dflt) ($dflt -ceq 'C:\temp\SqlStack\runs\LAB01-20261103-2105')

        # ---- S1: the plan set, by the transcript rule (K1, K2) ----
        $s1 = & $wbSeed (Join-Path $wbTmp 's1')
        $ps = Get-SqlStackGuiPlanSet -StatePath $s1.State -SpecPath $s1.Spec
        Assert-True ("S1 (K1): the CURRENT plan of spec.json is the newest dry run after its save, e5256e4d..., PlanOk, its bytes hashing to its name ({0} {1} {2})" -f $ps.Status, $(if ($ps.Current) { $ps.Current.Hash.Substring(0, 12) } else { '-' }), $(if ($ps.Current) { $ps.Current.HashOk } else { '-' })) `
            (($ps.Status -eq 'Done') -and ($ps.Current.Hash -ceq $wbHashes.P2) -and $ps.Current.HashOk -and ($ps.Current.Status -ceq 'PlanOk'))
        $supH = @(@($ps.Superseded) | ForEach-Object { $_.Hash } | Sort-Object)
        Assert-True ("S1 (K1): the three older plans of the SAME spec are SUPERSEDED, never 'conflicting' ({0})" -f ((@($supH) | ForEach-Object { $_.Substring(0, 8) }) -join ',')) `
            ((($supH -join ',') -ceq ((@($wbHashes.R2, $wbHashes.P1, $wbHashes.R1) | Sort-Object) -join ',')) -and (-not ((@($ps.Detail) -join ' ') -match 'conflict')))
        Assert-True ("S1 (K3): the uninstall spec's plan in the same state folder is not this spec's plan, and no plan is an orphan ({0} orphan(s))" -f @($ps.Orphans).Count) `
            ((@($ps.Superseded | Where-Object { $_.Hash -eq $wbHashes.A1 }).Count -eq 0) -and (@($ps.Orphans).Count -eq 0))
        $psA = Get-SqlStackGuiPlanSet -StatePath $s1.State -SpecPath $s1.Absent
        Assert-True ("S1: spec-absent.json's current plan is its own, e813c5c4... ({0})" -f $(if ($psA.Current) { $psA.Current.Hash.Substring(0, 12) } else { $psA.Words })) `
            (($psA.Status -eq 'Done') -and ($psA.Current.Hash -ceq $wbHashes.A1))
        # Stale: saved again after every dry run.
        [IO.File]::SetLastWriteTimeUtc($s1.Spec, [datetime]::UtcNow)
        $psS = Get-SqlStackGuiPlanSet -StatePath $s1.State -SpecPath $s1.Spec
        Assert-True ("S1: a spec saved AFTER its last dry run has no current plan: Stale, in words ('{0}')" -f $psS.Words) (($psS.Status -eq 'Stale') -and ($null -eq $psS.Current) -and ($psS.Words -match 'Run the dry run again'))
        [IO.File]::SetLastWriteTimeUtc($s1.Spec, $wbSpecUtc)
        # K2: the newest run refused and WROTE a plan.
        $s2 = & $wbSeed (Join-Path $wbTmp 's2')
        foreach ($n in @('plan-20261103T081558148Z.log', 'plan-20261103T081601535Z.log')) { Remove-Item -LiteralPath (Join-Path (Join-Path $s2.State 'console') $n) -Force }
        [IO.File]::SetLastWriteTimeUtc($s2.Spec, [datetime]::Parse('2026-11-03T08:15:40Z').ToUniversalTime())
        $psR = Get-SqlStackGuiPlanSet -StatePath $s2.State -SpecPath $s2.Spec
        Assert-True ("S1 (K2): a REFUSED dry run writes a plan, and that current plan is stage 3 FAILED with its blocked patch action ({0}; {1})" -f $psR.Status, ((@($psR.Detail) | Where-Object { $_ -match '^blocked' }) -join ' | ')) `
            (($psR.Status -eq 'Failed') -and ($psR.Current.Hash -ceq $wbHashes.R2) -and ($psR.Current.Status -ceq 'Refused') -and
             (@($psR.Detail | Where-Object { $_ -match '^blocked: Patch SQLSTACK1 - patch package not found' }).Count -eq 1))
        # A dry run still running: its transcript has no EXIT line yet.
        $s3 = & $wbSeed (Join-Path $wbTmp 's3')
        $runLog = Join-Path (Join-Path $s3.State 'console') 'plan-20261103T081601535Z.log'
        $cut = [IO.File]::ReadAllText($runLog)
        [IO.File]::WriteAllText($runLog, $cut.Substring(0, $cut.IndexOf('-- instances')), $wbUtf8Bom)
        $psRun = Get-SqlStackGuiPlanSet -StatePath $s3.State -SpecPath $s3.Spec
        Assert-True ("S1: a dry run whose transcript has no EXIT line is Running, and offers nothing ('{0}')" -f $psRun.Words) (($psRun.Status -eq 'Running') -and ($null -eq $psRun.Current))
        # A rejected run writes NO plan, and its transcript has no SPEC line (the real v9 shape).
        $v9 = Join-Path $wbTmp 'v9'
        [void](New-Item -ItemType Directory -Path (Join-Path $v9 'state\console') -Force)
        [IO.File]::WriteAllText((Join-Path $v9 'state\console\plan-20261103T081619293Z.log'), ([IO.File]::ReadAllText((Join-Path $wbFx 'dry2-v9\state\console\plan-20261103T081619293Z.log'))).Replace($wbCriticV9, $v9), $wbUtf8Bom)
        [IO.File]::WriteAllBytes((Join-Path $v9 'spec.json'), [IO.File]::ReadAllBytes((Join-Path $wbFx 'dry2-v9\spec.json')))
        [IO.File]::SetLastWriteTimeUtc((Join-Path $v9 'spec.json'), [datetime]::Parse('2026-11-03T08:16:18.1432971Z').ToUniversalTime())
        $psRej = Get-SqlStackGuiPlanSet -StatePath (Join-Path $v9 'state') -SpecPath (Join-Path $v9 'spec.json')
        Assert-True ("S1 (K2): a REJECTED dry run (exit 4, no plan, no SPEC line) is matched by its command line and is Failed with its refusal ('{0}')" -f ((@($psRej.Detail)) -join ' | ')) `
            (($psRej.Status -eq 'Failed') -and ($psRej.Words -match 'wrote no plan: EXIT 4') -and (@($psRej.Detail | Where-Object { $_ -match 'r15-host-name' }).Count -ge 1))
        # A plan whose bytes do not hash to its name is a refusal, never offered.
        $s4 = & $wbSeed (Join-Path $wbTmp 's4')
        $pp = Join-Path $s4.State ('plan-{0}.json' -f $wbHashes.P2)
        [IO.File]::AppendAllText($pp, ' ', $wbUtf8)
        $psM = Get-SqlStackGuiPlanSet -StatePath $s4.State -SpecPath $s4.Spec
        Assert-True ("S1: a plan whose BYTES do not hash to its name is REFUSED ('{0}')" -f $psM.Words) (($psM.Status -eq 'Failed') -and (-not $psM.Current.HashOk) -and ($psM.Words -match 'does not hash to its own name'))
        Remove-Item -LiteralPath $pp -Force
        $psGone = Get-SqlStackGuiPlanSet -StatePath $s4.State -SpecPath $s4.Spec
        Assert-True ("S1: a transcript naming a plan file that is gone is Failed ('{0}')" -f $psGone.Words) (($psGone.Status -eq 'Failed') -and ($psGone.Words -match 'is not in the state folder'))
        # A hand-copied plan no transcript names: listed, never offered.
        $s5 = & $wbSeed (Join-Path $wbTmp 's5')
        [IO.File]::WriteAllText((Join-Path $s5.State ('plan-{0}.json' -f ('0' * 64))), '{}', $wbUtf8)
        $psO = Get-SqlStackGuiPlanSet -StatePath $s5.State -SpecPath $s5.Spec
        Assert-True ("S1: a plan NO transcript names is listed as not this run's and never offered ({0})" -f (@($psO.Orphans) -join ',')) `
            (((@($psO.Orphans) -join ',') -ceq ('plan-{0}.json' -f ('0' * 64))) -and ($psO.Current.Hash -ceq $wbHashes.P2))
        $psNone = Get-SqlStackGuiPlanSet -StatePath (Join-Path $wbTmp 'no-state') -SpecPath $s5.Spec
        $psNoSpec = Get-SqlStackGuiPlanSet -StatePath $s5.State -SpecPath (Join-Path $wbTmp 'none\spec.json')
        Assert-True ("S1: no state folder, and no spec saved, are each NotStarted in words ('{0}' / '{1}')" -f $psNone.Words, $psNoSpec.Words) `
            (($psNone.Status -eq 'NotStarted') -and ($psNoSpec.Status -eq 'NotStarted') -and ($psNoSpec.Words -match 'not saved yet'))

        # ---- S2: the apply state (K8), from the producer's own print and journal shapes ----
        $s6 = & $wbSeed (Join-Path $wbTmp 's6')
        $h = $wbHashes.P2
        $con = Join-Path $s6.State 'console'
        $mkApply = {
            param([string]$Stamp, [string]$Outcome, $Exit, [string[]]$Problems = @())
            $l = New-Object System.Collections.ArrayList
            [void]$l.Add(('CONSOLE: this run''s console is saved to {0}' -f (Join-Path $con ('apply-' + $Stamp + '.log'))))
            [void]$l.Add(('SqlStack-Apply 0.1.0 - APPLY of plan {0}.' -f $h))
            [void]$l.Add('')
            if (@($Problems).Count -gt 0) { [void]$l.Add(('PROBLEMS ({0}):' -f @($Problems).Count)); foreach ($p in $Problems) { [void]$l.Add('  - ' + $p) }; [void]$l.Add('') }
            if ($Outcome) { [void]$l.Add('OUTCOME: ' + $Outcome) }
            if ($null -ne $Exit) { [void]$l.Add(('EXIT: {0}' -f $Exit)) }
            [IO.File]::WriteAllText((Join-Path $con ('apply-' + $Stamp + '.log')), ($l -join "`r`n"), $wbUtf8Bom)
        }
        $jl = Join-Path $s6.State ('journal-{0}.jsonl' -f $h.Substring(0, 12))
        $jrec = { param([string]$State) ('{"schema":"sqlstack-journal-v1","ts":"2026-11-03T09:00:00Z","host":"LAB01","planHash":"' + $h + '","state":"' + $State + '","phase":"before","iniPath":"x.ini","instance":"SQLSTACK1"}') }
        $ap0 = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True ("S2: no transcript and no journal: not started ('{0}')" -f $ap0.Words) ($ap0.Status -eq 'NotStarted')
        & $mkApply '20261103T090000000Z' '' $null
        $apR = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True 'S2: an apply whose transcript has no EXIT line is Running' ($apR.Status -eq 'Running')
        Remove-Item -LiteralPath (Join-Path $con 'apply-20261103T090000000Z.log') -Force
        [IO.File]::WriteAllText($jl, ((& $jrec 'intent-install') + "`n"), $wbUtf8)
        & $mkApply '20261103T090100000Z' 'ActionFailed' 8 @('SQLSTACK1: setup exited 1603')
        $apU = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True ("S2: an install intent with no outcome outranks the exit code: 'read RUNBOOK 4b' ('{0}')" -f $apU.Words) (($apU.Status -eq 'Attention') -and ($apU.Words -match 'RUNBOOK 4b'))
        [IO.File]::WriteAllText($jl, ((& $jrec 'intent-install') + "`n" + (& $jrec 'done-reboot-pending') + "`n"), $wbUtf8)
        & $mkApply '20261103T090200000Z' 'AppliedRebootPending' 6
        $ap6 = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True ("S2: exit 6 is applied with a restart pending, and the SAME command resumes ('{0}')" -f $ap6.Words) (($ap6.Status -eq 'Attention') -and ($ap6.Words -match 'SAME command'))
        [IO.File]::WriteAllText($jl, ((& $jrec 'intent-install') + "`n" + (& $jrec 'done-reboot-pending') + "`n" + (& $jrec 'created') + "`n"), $wbUtf8)
        & $mkApply '20261103T091500000Z' 'Applied' 0
        $apOk = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True ("S2: a resume - several transcripts for one hash - is decided by the NEWEST: exit 0 is applied ('{0}')" -f $apOk.Words) (($apOk.Status -eq 'Done') -and ($apOk.Words -match '^Applied'))
        & $mkApply '20261103T092000000Z' 'ActionFailed' 8 @('SQLSTACK1: setup exited 1603')
        $ap8 = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True ("S2: exit 8 is STOP, with the transcript's problem line ('{0}')" -f $ap8.Words) (($ap8.Status -eq 'Failed') -and ($ap8.Words -match 'STOP') -and (@($ap8.Detail | Where-Object { $_ -match '1603' }).Count -eq 1))
        & $mkApply '20261103T093000000Z' 'HashMismatch' 10
        $ap10 = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True ("S2: exit 10 (and 4, 5, 7, 9) is refused BEFORE anything ran ('{0}')" -f $ap10.Words) (($ap10.Status -eq 'Failed') -and ($ap10.Words -match 'before anything ran'))
        [IO.File]::AppendAllText($jl, "{not json`n", $wbUtf8)
        $apBad = Get-SqlStackGuiApplyState -StatePath $s6.State -Hash $h
        Assert-True 'S2: a journal line that does not parse is SHOWN as a problem (the engine''s reader), never dropped' (@($apBad.Detail | Where-Object { $_ -match '^journal problem: line 4' }).Count -eq 1)

        # ---- S5: the verify state (K9) ----
        $mkVerify = {
            param([string]$Stamp, [string]$Outcome, [int]$Exit)
            [IO.File]::WriteAllText((Join-Path $con ('verify-' + $Stamp + '.log')), (@(('SqlStack-Apply 0.1.0 - VERIFY of plan {0}. Nothing is written to any instance.' -f $h), '', ('OUTCOME: ' + $Outcome), ('EXIT: {0}' -f $Exit)) -join "`r`n"), $wbUtf8Bom)
        }
        $vrep = Join-Path $s6.State ('verify-{0}.md' -f $h)
        $vfWords = @()
        foreach ($v in @(@('20261103T100000000Z', 'VerifyDrift', 11, 'Attention'), @('20261103T100100000Z', 'VerifyDisagrees', 12, 'Failed'), @('20261103T100200000Z', 'VerifyUnproved', 13, 'Attention'), @('20261103T100300000Z', 'Verified', 0, 'Done'))) {
            & $mkVerify $v[0] $v[1] $v[2]
            [IO.File]::WriteAllText($vrep, '# verify', $wbUtf8)
            $vs = Get-SqlStackGuiVerifyState -StatePath $s6.State -Hash $h
            $vfWords += ('{0}->{1}' -f $v[2], $vs.Status)
            if ($vs.Status -ne $v[3]) { $vfWords += 'WRONG' }
            if (($v[2] -eq 11) -and ($vs.Words -notmatch 'not a failure')) { $vfWords += 'DRIFT-CALLED-FAILURE' }
        }
        Assert-True ("S5 (K9): each verify exit reads as its own state, and drift is never called a failure ({0})" -f ($vfWords -join ', ')) (-not (($vfWords -join ',') -match 'WRONG|DRIFT'))
        [IO.File]::WriteAllText((Join-Path $con 'verify-20261103T100400000Z.log'), (@(('SqlStack-Apply 0.1.0 - VERIFY of plan {0}. Nothing is written to any instance.' -f $h), '', 'PROBLEMS (1):', ("  - plan {0} is unfinished on this host: resume it (powershell -NoProfile -File SqlStack-Apply.ps1 -Spec 'x' -Apply -PlanHash {0} -StatePath 'y')." -f $h), '', 'OUTCOME: VerifyDrift', 'EXIT: 11') -join "`r`n"), $wbUtf8Bom)
        $vsUf = Get-SqlStackGuiVerifyState -StatePath $s6.State -Hash $h
        Assert-True ("S5 (28h): an exit 11 that names an unfinished plan says so and does not call it mere drift ('{0}')" -f $vsUf.Words) `
            (($vsUf.Status -eq 'Attention') -and ($vsUf.Words -match 'UNFINISHED') -and ($vsUf.Words -notmatch 'not a failure') -and (@($vsUf.Detail | Where-Object { $_ -match 'is unfinished on this host' }).Count -eq 1))
        # S5 (28h-13), fix round 3 (N-5): an exit 13 naming an unfinished plan says UNFINISHED, stays Attention, and
        # does not say 'nothing disagreed'. S5 (28i): an exit 11 naming a journal that does not read cleanly says UNFINISHED.
        [IO.File]::WriteAllText((Join-Path $con 'verify-20261103T100500000Z.log'), (@(('SqlStack-Apply 0.1.0 - VERIFY of plan {0}. Nothing is written to any instance.' -f $h), '', 'PROBLEMS (2):', '  - 1 of 1 oracle(s) could not answer at least one half, so this verify is UNPROVED rather than verified', ("  - plan {0} is unfinished on this host: resume it (powershell -NoProfile -File SqlStack-Apply.ps1 -Spec 'x' -Apply -PlanHash {0} -StatePath 'y')." -f $h), '', 'OUTCOME: VerifyUnproved', 'EXIT: 13') -join "`r`n"), $wbUtf8Bom)
        $vsU13 = Get-SqlStackGuiVerifyState -StatePath $s6.State -Hash $h
        Assert-True ("S5 (28h-13): an exit 13 that names an unfinished plan says so, stays Attention, and does not say nothing disagreed ('{0}')" -f $vsU13.Words) `
            (($vsU13.Status -eq 'Attention') -and ($vsU13.Words -match 'UNFINISHED') -and ($vsU13.Words -match 'exit 13') -and ($vsU13.Words -notmatch 'nothing disagreed') -and ($vsU13.Words -match 'never the same as verified'))
        [IO.File]::WriteAllText((Join-Path $con 'verify-20261103T100600000Z.log'), (@(('SqlStack-Apply 0.1.0 - VERIFY of plan {0}. Nothing is written to any instance.' -f $h), '', 'PROBLEMS (1):', ("  - plan {0} is unfinished on this host: its journal y\journal-{1}.jsonl does not read cleanly (line 8 of y\journal-{1}.jsonl does not parse as JSON: x), so how far this plan got is unknown." -f $h, $h.Substring(0, 12)), '', 'OUTCOME: VerifyDrift', 'EXIT: 11') -join "`r`n"), $wbUtf8Bom)
        $vsTorn = Get-SqlStackGuiVerifyState -StatePath $s6.State -Hash $h
        Assert-True ("S5 (28i): an exit 11 that names an unfinished plan whose journal does not read cleanly says UNFINISHED, not mere drift ('{0}')" -f $vsTorn.Words) `
            (($vsTorn.Status -eq 'Attention') -and ($vsTorn.Words -match 'UNFINISHED') -and ($vsTorn.Words -notmatch 'not a failure'))
        & $mkVerify '20261103T110000000Z' 'SpecRejected' 4
        [IO.File]::SetLastWriteTimeUtc($vrep, [datetime]::Parse('2026-11-03T10:03:00Z').ToUniversalTime())
        $vsOld = Get-SqlStackGuiVerifyState -StatePath $s6.State -Hash $h
        Assert-True ("S5 (K9): a report older than the newest verify run is said to be from an earlier run ('{0}')" -f ((@($vsOld.Detail)) -join ' | ')) `
            (($vsOld.Status -eq 'Failed') -and (@($vsOld.Detail | Where-Object { $_ -match 'from an earlier run' }).Count -eq 1))

        # ---- S4 (folder part): the snapshot bundle ----
        $snapFx = Join-Path $wbFx 'snapA'
        $sa = Read-SqlStackGuiSnapshot -Folder $snapFx
        Assert-True ("S4: the real snapshot is read: newest bundle, intact, host token HOST1 ('{0}')" -f $sa.Words) `
            (($sa.Status -eq 'Done') -and ($sa.BundleName -ceq 'SqlStack-Diag-HOST1-2026-11-03T08-17-12-614Z') -and ($sa.HostToken -ceq 'HOST1') -and ($sa.CollectedUtc -ceq '2026-11-03T08:17:12.614Z'))
        $sb = Join-Path $wbTmp 'snapB'
        [void](New-Item -ItemType Directory -Path (Join-Path $sb 'SqlStack-Diag-HOST1-2026-11-03T09-00-00-000Z') -Force)
        $man = [IO.File]::ReadAllText((Join-Path $snapFx 'SqlStack-Diag-HOST1-2026-11-03T08-17-12-614Z\manifest.json'))
        [IO.File]::WriteAllText((Join-Path $sb 'SqlStack-Diag-HOST1-2026-11-03T09-00-00-000Z\manifest.json'), ($man -replace '"intact":\s*true', '"intact": false' -replace '2026-11-03T08:17:12.614Z', '2026-11-03T09:00:00.000Z'), $wbUtf8)
        [void](New-Item -ItemType Directory -Path (Join-Path $sb 'SqlStack-Diag-HOST1-2026-11-03T08-00-00-000Z') -Force)
        [IO.File]::WriteAllText((Join-Path $sb 'SqlStack-Diag-HOST1-2026-11-03T08-00-00-000Z\manifest.json'), $man, $wbUtf8)
        [void](New-Item -ItemType Directory -Path (Join-Path $sb 'SqlStack-Diag-HOST1-2026-11-03T09-30-00-000Z') -Force)
        $sbr = Read-SqlStackGuiSnapshot -Folder $sb
        Assert-True ("S4: several bundles: the NEWEST by collectedUtc decides and is said; NOT intact is Failed; a bundle with no manifest did not finish ('{0}' | {1})" -f $sbr.Words, ((@($sbr.Detail)) -join ' | ')) `
            (($sbr.Status -eq 'Failed') -and ($sbr.CollectedUtc -ceq '2026-11-03T09:00:00.000Z') -and (@($sbr.Detail | Where-Object { $_ -match 'did not finish' }).Count -eq 1) -and (@($sbr.Detail | Where-Object { $_ -match '^2 bundles here' }).Count -eq 1))
        Assert-True 'S4: no snapshot folder is not started' ((Read-SqlStackGuiSnapshot -Folder (Join-Path $wbTmp 'nope')).Status -eq 'NotStarted')

        # ---- the ONE stage reader and the ONE command builder over a seeded run ----
        $s7 = & $wbSeed (Join-Path $wbTmp 's7')
        $rs = Get-SqlStackGuiRunState -Root $s7.Run -StatePath $s7.State -InstalledInstance $wbLab -HostName 'LAB01'
        $rsLine = (@($rs.Stages) | ForEach-Object { '{0}={1}' -f $_.Id, $_.Status }) -join ' '
        Assert-True ("stage reader: nine stages in the stage table's order, each a status in words ({0})" -f $rsLine) `
            ((@($rs.Stages).Count -eq 9) -and ((@($rs.Stages) | ForEach-Object { $_.Id }) -join ',') -eq '1,2,3,4,5,6,7,8,9' -and (@($rs.Stages | Where-Object { -not $_.Words }).Count -eq 0))
        Assert-True ("stage reader: the hand-seeded LAB01 spec is accepted when the host is LAB01; stage 3 is done with e5256e4d; stages 4 and 7 wait for their runs ({0})" -f $rsLine) `
            (($rs.Stages[0].Status -eq 'Done') -and ($rs.Stages[2].Status -eq 'Done') -and ($rs.Stages[3].Status -eq 'NotStarted') -and ($rs.Stages[4].Status -eq 'Blocked') -and ($rs.Stages[5].Status -eq 'Done') -and ($rs.Stages[6].Status -eq 'NotStarted'))
        $want4 = ('powershell -NoProfile -ExecutionPolicy Bypass -File {0} -Spec {1} -StatePath {2} -Apply -PlanHash {3}' -f (Join-Path $wbTool 'SqlStack-Apply.ps1'), $s7.Spec, $s7.State, $wbHashes.P2)
        $c4 = Get-SqlStackGuiCommand -Stage 4 -State $rs -ToolDir $wbTool
        Assert-True ("command (INV-2, K12): stage 4 is the full line with -Spec and -StatePath and the READ hash: '{0}'" -f $c4.Text) ($c4.Ok -and ($c4.Text -ceq $want4) -and $c4.Elevated)
        Assert-True 'command (K16): stages 4 and 7 carry the pending-reboot snippet; stage 3 does not' `
            (($c4.Snippet -match 'PendingFileRenameOperations') -and ((Get-SqlStackGuiCommand -Stage 7 -State $rs -ToolDir $wbTool).Snippet -match 'RebootRequired') -and (-not (Get-SqlStackGuiCommand -Stage 3 -State $rs -ToolDir $wbTool).Snippet))
        $rb = [IO.File]::ReadAllText((Join-Path $wbTool 'RUNBOOK-live-tier-A.md'))
        Assert-True 'command (K16): every line of the snippet is RUNBOOK step 4''s, verbatim' (@((Get-SqlStackGuiRebootSnippet) -split "`r`n" | Where-Object { -not $rb.Contains($_) }).Count -eq 0)
        $c3 = Get-SqlStackGuiCommand -Stage 3 -State $rs -ToolDir $wbTool
        $c7 = Get-SqlStackGuiCommand -Stage 7 -State $rs -ToolDir $wbTool
        $c2 = Get-SqlStackGuiCommand -Stage 2 -State $rs -ToolDir $wbTool
        Assert-True ("command: stage 3 is the dry run of spec.json, stage 7 the uninstall of spec-absent.json with ITS hash, stage 2 the collector into snapshot-A ('{0}' | '{1}' | '{2}')" -f $c3.Text, $c7.Text, $c2.Text) `
            (($c3.Text -ceq ('powershell -NoProfile -ExecutionPolicy Bypass -File {0} -Spec {1} -StatePath {2}' -f (Join-Path $wbTool 'SqlStack-Apply.ps1'), $s7.Spec, $s7.State)) -and
             ($c7.Text -ceq ('powershell -NoProfile -ExecutionPolicy Bypass -File {0} -Spec {1} -StatePath {2} -Apply -PlanHash {3}' -f (Join-Path $wbTool 'SqlStack-Apply.ps1'), $s7.Absent, $s7.State, $wbHashes.A1)) -and
             ($c2.Text -ceq ('powershell -NoProfile -ExecutionPolicy Bypass -File {0} -OutDir {1} -NoZip' -f (Join-Path $wbTool 'SqlStack-Collect.ps1'), (Join-Path $s7.Run 'snapshot-A'))) -and (-not $c2.Elevated))
        $c5 = Get-SqlStackGuiCommand -Stage 5 -State $rs -ToolDir $wbTool
        Assert-True ("command: stage 5 is NOT offered before the apply has finished, and says why ('{0}')" -f $c5.Reason) ((-not $c5.Ok) -and ($c5.Reason -match 'stage 4') -and (-not $c5.Text))
        # K13: the same spec read on a host that is not LAB01 fails stage 1 (r15), and stage 4 is still the read hash.
        $rsMsi = Get-SqlStackGuiRunState -Root $s7.Run -StatePath $s7.State -InstalledInstance $wbLab -HostName 'NOTLAB01'
        $c3m = Get-SqlStackGuiCommand -Stage 3 -State $rsMsi -ToolDir $wbTool
        Assert-True ("stage reader (K13): on another host the LAB01 spec fails stage 1 by r15, no dry-run command is offered, and stage 4 still copies the read hash ('{0}')" -f (@($rsMsi.Stages[0].Detail) -join ' | ')) `
            (($rsMsi.Stages[0].Status -eq 'Failed') -and (@($rsMsi.Stages[0].Detail | Where-Object { $_ -match 'r15-host-name' }).Count -ge 1) -and (-not $c3m.Ok) -and ((Get-SqlStackGuiCommand -Stage 4 -State $rsMsi -ToolDir $wbTool).Text -ceq $want4))
        # Applied -> verify is offered with the SAME hash.
        $s7con = Join-Path $s7.State 'console'
        [IO.File]::WriteAllText((Join-Path $s7con 'apply-20261103T090000000Z.log'), (@(('SqlStack-Apply 0.1.0 - APPLY of plan {0}.' -f $wbHashes.P2), 'OUTCOME: Applied', 'EXIT: 0') -join "`r`n"), $wbUtf8Bom)
        $rsAp = Get-SqlStackGuiRunState -Root $s7.Run -StatePath $s7.State -InstalledInstance $wbLab -HostName 'LAB01'
        $c5b = Get-SqlStackGuiCommand -Stage 5 -State $rsAp -ToolDir $wbTool
        Assert-True ("command: once applied, stage 5 verifies the SAME plan ('{0}')" -f $c5b.Text) ($c5b.Ok -and ($c5b.Text -ceq ($want4 -replace '-Apply -PlanHash', '-Verify -PlanHash')))
        # No current plan -> no hash command, in words.
        [IO.File]::SetLastWriteTimeUtc($s7.Spec, [datetime]::UtcNow)
        $rsSt = Get-SqlStackGuiRunState -Root $s7.Run -StatePath $s7.State -InstalledInstance $wbLab -HostName 'LAB01'
        $c4s = Get-SqlStackGuiCommand -Stage 4 -State $rsSt -ToolDir $wbTool
        Assert-True ("command (INV-2): a stale spec has NO current plan, so stage 4 offers no command and no hash ('{0}'); the earlier apply is said, not offered ('{1}')" -f $c4s.Reason, $rsSt.Stages[3].Words) `
            ((-not $c4s.Ok) -and (-not $c4s.Text) -and ($rsSt.Stages[3].Status -eq 'Stale'))
        # K4: no throwaway -> stages 6 and 7 are greyed, in words.
        $nt = Get-Content -LiteralPath $s7.Spec -Raw | ConvertFrom-Json
        foreach ($i in @($nt.instances)) { if ($i.PSObject.Properties['throwaway']) { $i.PSObject.Properties.Remove('throwaway') } }
        [IO.File]::WriteAllText($s7.Spec, ($nt | ConvertTo-Json -Depth 12), $wbUtf8)
        $rsNt = Get-SqlStackGuiRunState -Root $s7.Run -StatePath $s7.State -InstalledInstance $wbLab -HostName 'LAB01'
        $c6n = Get-SqlStackGuiCommand -Stage 6 -State $rsNt -ToolDir $wbTool
        Assert-True ("stage reader (K4): with no throwaway instance stages 6 and 7 are Blocked, saying SPEC 6.3.2 leg 1, and no uninstall command is offered ('{0}')" -f $rsNt.Stages[5].Words) `
            (($rsNt.Stages[5].Status -eq 'Blocked') -and ($rsNt.Stages[6].Status -eq 'Blocked') -and ($rsNt.Stages[5].Words -match '6\.3\.2') -and (-not $c6n.Ok))
        # Gate F8 (2026-11-04): the reboot check goes WITH a command. A stage with no
        # command (stale stage 4, blocked stage 7) carries no snippet, so the drawer
        # shows no orphan "# BEFORE it" and Copy reboot check is off.
        $c7n = Get-SqlStackGuiCommand -Stage 7 -State $rsNt -ToolDir $wbTool
        Assert-True ("command (F8): a greyed stage 4 or 7 carries NO reboot snippet ('{0}' | '{1}'), while the offered stage 4 does (above)" -f $c4s.Reason, $c7n.Reason) `
            ((-not $c4s.Ok) -and (-not $c4s.Snippet) -and (-not $c7n.Ok) -and (-not $c7n.Snippet) -and [bool]$c4.Snippet)
        # Quoting: a run folder with a space.
        $sq = & $wbSeed (Join-Path $wbTmp 'with space')
        $rsQ = Get-SqlStackGuiRunState -Root $sq.Run -StatePath $sq.State -InstalledInstance $wbLab -HostName 'LAB01'
        $cq = Get-SqlStackGuiCommand -Stage 4 -State $rsQ -ToolDir $wbTool
        Assert-True ("command: a path with a space is single-quoted, so the line pastes as one argument ('{0}')" -f $cq.Text) ($cq.Ok -and ($cq.Text -match ("-Spec '" + [regex]::Escape($sq.Spec) + "' -StatePath '")))
        $c1 = Get-SqlStackGuiCommand -Stage 1 -State $rs -ToolDir $wbTool
        $c9 = Get-SqlStackGuiCommand -Stage 9 -State $rs -ToolDir $wbTool
        Assert-True ("command: stages 1 and 9 have nothing to run, and say so ('{0}' | '{1}')" -f $c1.Reason, $c9.Reason) ((-not $c1.Ok) -and (-not $c9.Ok) -and $c1.Reason -and $c9.Reason)
        Assert-True ("stage reader (K14): tidy-up lists the UNREDACTED observed files for this run's plans and deletes nothing ({0} line(s))" -f @($rs.Stages[8].Detail).Count) `
            ((@($rs.Stages[8].Detail | Where-Object { $_ -match ('observed-' + $wbHashes.P2 + '\.json') }).Count -eq 1) -and ($rs.Stages[8].Detail[0] -match 'UNREDACTED'))
        $cpNo = Copy-SqlStackGuiCommand -Stage 1 -State $rs -ToolDir $wbTool
        Assert-True ("command: Copy for a stage with no command copies NOTHING and says why ('{0}')" -f $cpNo.Reason) ((-not $cpNo.Ok) -and (-not $cpNo.Text))

        # ---- the redaction map and the compare block (K15) ----
        $mapDir = Join-Path $wbTmp 'maps'
        [void](New-Item -ItemType Directory -Path $mapDir -Force)
        $bName = 'SqlStack-Diag-HOST1-2026-11-03T08-17-12-614Z'
        $mapDoc = [ordered]@{ HOST1 = [ordered]@{ class = 'HOST'; value = 'LABHOST' }; INST2 = [ordered]@{ class = 'INST'; value = 'LABA' }; INST4 = [ordered]@{ class = 'INST'; value = 'LABC' }; INST6 = [ordered]@{ class = 'INST'; value = 'SQLSTACK1' } }
        [IO.File]::WriteAllText((Join-Path $mapDir ($bName + '.map.json')), ($mapDoc | ConvertTo-Json -Depth 4), $wbUtf8)
        $mOk = Read-SqlStackGuiRedactionMap -BundleName $bName -HostToken 'HOST1' -MapRoot $mapDir -ComputerName 'LABHOST'
        $mOther = Read-SqlStackGuiRedactionMap -BundleName $bName -HostToken 'HOST1' -MapRoot $mapDir -ComputerName 'ELSEWHERE'
        $mNone = Read-SqlStackGuiRedactionMap -BundleName 'SqlStack-Diag-HOST1-none' -HostToken 'HOST1' -MapRoot $mapDir -ComputerName 'LABHOST'
        Assert-True ("map: read only when its host value is THIS computer; another host's map and a missing map are refused in words ('{0}' | '{1}')" -f $mOther.Reason, $mNone.Reason) `
            ($mOk.Ok -and ([string]$mOk.Map['INST2'].Value -ceq 'LABA') -and (-not $mOther.Ok) -and ($mOther.Reason -match 'another host') -and (-not $mNone.Ok) -and ($mNone.Reason -match 'not visible'))
    } finally { Remove-Item -LiteralPath $wbTmp -Recurse -Force -ErrorAction SilentlyContinue }

    Write-Host ''
    Write-Host '-- workbench plan: one row shape, features and sysadmins from ONE source, IP and throwaway in the spec, the spec read back (S3) --'
    $w2Media = Join-Path (Split-Path -Parent $script:EntryScriptPath) 'tests\fixtures\spec\media\2022'
    $w2Row = {
        param([string]$Name, [string]$Ip = '', [bool]$ListenAll = $false, [bool]$Throwaway = $false, [string]$Features = 'SQLENGINE')
        $r = New-SqlStackGuiPlanRow -Name $Name -Ordinal 1 -Port 14331 -DataPath ('E:\{0}\Data' -f $Name) -LogPath ('F:\{0}\Log' -f $Name) -TempDbPath ('T:\{0}\TempDB' -f $Name) -BackupPath ('G:\{0}\Backup' -f $Name) `
                -MaxMemoryMb 4096 -MaxDop 4 -TempDbFileCount 4 -Ip $Ip -ListenAll $ListenAll -MediaPath $w2Media -MediaVersion '2022' -Features $Features -Throwaway $Throwaway
        return $r
    }
    $w2Def = New-SqlStackGuiPlanRow -Name 'INST01'
    Assert-True ("row shape: a new row defaults to features SQLENGINE, throwaway OFF (K4, ruled by Adrian), no IP, not Fixed ({0}/{1}/'{2}'/{3})" -f $w2Def.Features, $w2Def.Throwaway, $w2Def.Ip, $w2Def.Fixed) `
        (($w2Def.Features -ceq 'SQLENGINE') -and (-not $w2Def.Throwaway) -and ($w2Def.Ip -eq '') -and (-not $w2Def.ListenAll) -and (-not $w2Def.Fixed))
    $w2Admins = [string[]]@('BUILTIN\Administrators', 'LAB01\someone')
    $w2Inst = @([pscustomobject]@{ Name = 'MSSQLSERVER' }, [pscustomobject]@{ Name = 'LABA' })
    foreach ($fv in @('SQLENGINE', 'SQLENGINE,FULLTEXT')) {
        $rowF = & $w2Row 'INST01' -Features $fv
        $specF = New-SqlStackGuiSpec -Plan @($rowF) -Installed $w2Inst -HostName 'LAB01' -PortBase 14330 -Edition 'Developer' -SysAdmin $w2Admins
        $docF = $specF.Text | ConvertFrom-Json
        $newF = @($docF.instances | Where-Object { $_.name -eq 'INST01' })[0]
        $iniF = @(Get-SqlStackGuiFileSet -Plan @($rowF) -HostName 'LAB01' -SysAdmin $w2Admins | Where-Object { $_.Kind -eq 'ini' })[0].Text
        $iniFeat = $(if ($iniF -match '(?m)^FEATURES="?([^"\r\n]+)"?') { $Matches[1] } else { '' })
        $iniAdm = $(if ($iniF -match '(?m)^SQLSYSADMINACCOUNTS=(.+)$') { $Matches[1] } else { '' })
        Assert-True ("finding 6: features '{0}' reach the spec ({1}) and the .ini ({2}) from ONE source, and so do the sysadmins ({3})" -f $fv, (@($newF.features) -join ','), $iniFeat, $iniAdm) `
            (((@($newF.features) -join ',') -ceq $fv) -and ($iniFeat -ceq $fv) -and (@($newF.sysadmins | Where-Object { $iniAdm -notmatch [regex]::Escape([string]$_) }).Count -eq 0) -and (@($newF.sysadmins).Count -eq 2))
    }
    $specT = New-SqlStackGuiSpec -Plan @((& $w2Row 'INST01' -Throwaway $true), (& $w2Row 'INST02')) -Installed $w2Inst -HostName 'LAB01' -PortBase 14330 -Edition 'Developer' -SysAdmin $w2Admins
    $docT = $specT.Text | ConvertFrom-Json
    $absT = New-SqlStackGuiSpec -Plan @((& $w2Row 'INST01' -Throwaway $true), (& $w2Row 'INST02')) -Installed $w2Inst -HostName 'LAB01' -PortBase 14330 -Edition 'Developer' -SysAdmin $w2Admins -AbsentThrowaway
    $docA = $absT.Text | ConvertFrom-Json
    $tw1 = @($docT.instances | Where-Object { $_.name -eq 'INST01' })[0]; $tw2 = @($docT.instances | Where-Object { $_.name -eq 'INST02' })[0]
    Assert-True ("throwaway (finding 6, K4): a ticked row is written throwaway:true, an unticked one carries no throwaway key ({0} / {1})" -f $tw1.throwaway, [bool]$tw2.PSObject.Properties['throwaway']) `
        (($tw1.throwaway -eq $true) -and (-not $tw2.PSObject.Properties['throwaway']))
    Assert-True ("spec-absent: the uninstall copy marks ONLY the throwaway instance absent and keeps the rest ({0})" -f ((@($docA.instances) | ForEach-Object { '{0}={1}' -f $_.name, $(if ($_.state) { $_.state } else { 'protected' }) }) -join ', ')) `
        ($absT.Ok -and ($absT.AbsentCount -eq 1) -and ([string](@($docA.instances | Where-Object { $_.name -eq 'INST01' })[0].state) -ceq 'absent') -and ([string](@($docA.instances | Where-Object { $_.name -eq 'INST02' })[0].state) -ceq 'present'))
    $specIp = New-SqlStackGuiSpec -Plan @((& $w2Row 'INST01' -Ip '2001:db8:0:0:0:0:0:5'), (& $w2Row 'INST02' -ListenAll $true)) -Installed $w2Inst -HostName 'LAB01' -PortBase 14330 -Edition 'Developer' -SysAdmin $w2Admins
    $docIp = $specIp.Text | ConvertFrom-Json
    $ip1 = @($docIp.instances | Where-Object { $_.name -eq 'INST01' })[0]; $ip2 = @($docIp.instances | Where-Object { $_.name -eq 'INST02' })[0]
    Assert-True ("IP (finding 6, INV-4): a bound IP is written CANONICAL with listenAll false ('{0}', {1}); Listen All alone is written with no ip ({2}, ip key {3})" -f $ip1.ip, $ip1.listenAll, $ip2.listenAll, [bool]$ip2.PSObject.Properties['ip']) `
        ($specIp.Ok -and ([string]$ip1.ip -ceq '2001:db8::5') -and ($ip1.listenAll -eq $false) -and ($ip2.listenAll -eq $true) -and (-not $ip2.PSObject.Properties['ip']))
    $specBadIp = New-SqlStackGuiSpec -Plan @((& $w2Row 'INST01' -Ip '010.0.0.5')) -Installed $w2Inst -HostName 'LAB01' -Edition 'Developer' -SysAdmin $w2Admins
    $specR17 = New-SqlStackGuiSpec -Plan @((& $w2Row 'INST01' -Ip '10.0.0.5' -ListenAll $true)) -Installed $w2Inst -HostName 'LAB01' -Edition 'Developer' -SysAdmin $w2Admins
    Assert-True ("IP: a refused spelling, and an IP with Listen All (r17), are spec PROBLEMS, never written ('{0}' | '{1}')" -f (@($specBadIp.Problems)[0]), (@($specR17.Problems)[0])) `
        ((-not $specBadIp.Ok) -and ((@($specBadIp.Problems) -join ' ') -match 'zero-padded') -and (-not $specR17.Ok) -and ((@($specR17.Problems) -join ' ') -match 'r17'))
    $vMed = Test-SqlStackPlan -Plan @((New-SqlStackGuiPlanRow -Name 'INST01' -Port 14331 -DataPath 'E:\I\Data' -LogPath 'F:\I\Log' -TempDbPath 'T:\I\TempDB' -BackupPath 'G:\I\Backup' -MaxMemoryMb 4096 -TempDbFileCount 4)) -Volumes $vols -PhysicalMb 65536
    $vMedR = Test-SqlStackPlan -Plan @((New-SqlStackGuiPlanRow -Name 'INST01' -Port 14331 -DataPath 'E:\I\Data' -LogPath 'F:\I\Log' -TempDbPath 'T:\I\TempDB' -BackupPath 'G:\I\Backup' -MaxMemoryMb 4096 -TempDbFileCount 4)) -Volumes $vols -PhysicalMb 65536 -RequireMedia
    Assert-True ("validation (finding 2): with -RequireMedia an instance with no media read is an ERROR in Validation ({0}); without it, none ({1})" -f @($vMedR | Where-Object { $_.Area -match '^media/' }).Count, @($vMed | Where-Object { $_.Area -match '^media/' }).Count) `
        ((@($vMedR | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -eq 'media/INST01') }).Count -eq 1) -and (@($vMed | Where-Object { $_.Area -match '^media/' }).Count -eq 0))
    $vR17 = Test-SqlStackPlan -Plan @((& $w2Row 'INST01' -Ip '10.0.0.5' -ListenAll $true)) -Volumes $vols -PhysicalMb 65536
    Assert-True 'validation: an IP together with Listen All is an ERROR naming rule r17' (@($vR17 | Where-Object { ($_.Severity -eq 'ERROR') -and ($_.Area -eq 'ip/INST01') -and ($_.Message -match 'r17') }).Count -eq 1)
    # S3: a spec this window wrote reads back EDITABLE; a hand-written one opens read-only naming its differences.
    $rtDoc = $specT.Text | ConvertFrom-Json
    $rtImp = ConvertFrom-SqlStackGuiSpec -Doc $rtDoc
    $rt = Test-SqlStackGuiSpecRoundTrip -Doc $rtDoc -Import $rtImp -Installed $w2Inst -HostName 'LAB01'
    Assert-True ("S3: a spec this window wrote round-trips: read back and written again it is the SAME document ({0} difference(s): {1})" -f @($rt.Differences).Count, ((@($rt.Differences) | Select-Object -First 3) -join '; ')) `
        ($rt.Same -and (@($rtImp.Rows).Count -eq 2) -and ($rtImp.Edition -ceq 'Developer') -and ((@($rtImp.SysAdmin) -join ',') -ceq ($w2Admins -join ',')) -and ($rtImp.PortBase -eq 14330))
    $rtOther = Test-SqlStackGuiSpecRoundTrip -Doc $rtDoc -Import $rtImp -Installed $w2Inst -HostName 'ELSEWHERE'
    Assert-True ("S3: the same spec read on ANOTHER host is not editable, and the difference is NAMED ({0})" -f ((@($rtOther.Differences)) -join '; ')) `
        ((-not $rtOther.Same) -and (@($rtOther.Differences) -contains '$.host.name'))
    $hwDoc = [IO.File]::ReadAllText((Join-Path (Split-Path -Parent $script:EntryScriptPath) 'tests\fixtures\window\dry2\spec.json')) | ConvertFrom-Json
    $hwImp = ConvertFrom-SqlStackGuiSpec -Doc $hwDoc
    $hwRt = Test-SqlStackGuiSpecRoundTrip -Doc $hwDoc -Import $hwImp -Installed @('MSSQLSERVER', 'LABA', 'LABB', 'LABC' | ForEach-Object { [pscustomobject]@{ Name = $_ } }) -HostName 'LAB01'
    Assert-True ("S3: the critic's hand-written spec is NOT silently taken in: its rows are read ({0}) and every value the window does not model is named ({1} difference(s), e.g. {2})" -f `
            @($hwImp.Rows).Count, @($hwRt.Differences).Count, ((@($hwRt.Differences) | Select-Object -First 3) -join '; ')) `
        ((@($hwImp.Rows).Count -eq 1) -and (-not $hwRt.Same) -and (@($hwRt.Differences | Where-Object { $_ -notmatch '^(\$|cannot be rewritten)' }).Count -eq 0))
    Assert-True 'json compare: equal documents have no difference; a changed value is named by its path' `
        ((@(Compare-SqlStackGuiJson -A ('{"a":{"b":[1,2]}}' | ConvertFrom-Json) -B ('{"a":{"b":[1,2]}}' | ConvertFrom-Json)).Count -eq 0) -and
         ((@(Compare-SqlStackGuiJson -A ('{"a":{"b":[1,2]}}' | ConvertFrom-Json) -B ('{"a":{"b":[1,3]}}' | ConvertFrom-Json)) -join ',') -ceq '$.a.b[1]'))
    # The actions, in words.
    $saOk = Get-SqlStackGuiSpecActionState -Errors 0 -NewRows 1 -ReadOnly $false
    $saRo = Get-SqlStackGuiSpecActionState -Errors 0 -NewRows 1 -ReadOnly $true
    $saEr = Get-SqlStackGuiSpecActionState -Errors 2 -NewRows 1 -ReadOnly $false
    $saNo = Get-SqlStackGuiSpecActionState -Errors 0 -NewRows 0 -ReadOnly $false
    $saPb = Get-SqlStackGuiSpecActionState -Errors 0 -NewRows 1 -ReadOnly $false -SpecProblems @('INST01: no SQL install media folder has been chosen')
    Assert-True ("Save spec (findings 1, 10): on only for a clean plan; every off state says why ('{0}' | '{1}' | '{2}' | '{3}')" -f $saRo.Reason, $saEr.Reason, $saNo.Reason, $saPb.Reason) `
        ($saOk.Enabled -and (-not $saRo.Enabled) -and ($saRo.Reason -match 'READ ONLY') -and (-not $saEr.Enabled) -and ($saEr.Reason -match '2 errors') -and (-not $saNo.Enabled) -and (-not $saPb.Enabled) -and ($saPb.Reason -match 'media'))
    # S6: the host IP list (critic K10).
    $ipRows = @(Get-SqlStackGuiHostIpRows -Rows @(
        [pscustomobject]@{ Ip = '127.0.0.1'; Interface = 'Loopback'; Family = 'InterNetwork'; IsLoopback = $true; IsLinkLocal = $false },
        [pscustomobject]@{ Ip = 'fe80::1%4'; Interface = 'Ethernet'; Family = 'InterNetworkV6'; IsLoopback = $false; IsLinkLocal = $true },
        [pscustomobject]@{ Ip = '169.254.10.1'; Interface = 'Wi-Fi 2'; Family = 'InterNetwork'; IsLoopback = $false; IsLinkLocal = $true },
        [pscustomobject]@{ Ip = '10.0.0.70'; Interface = 'Ethernet'; Family = 'InterNetwork'; IsLoopback = $false; IsLinkLocal = $false; PrefixOrigin = 'Manual' }))
    $ipFail = @(Get-SqlStackGuiHostIpRows -Rows @([pscustomobject]@{ Ip = ''; Interface = ''; Family = ''; IsLoopback = $false; IsLinkLocal = $false; ReadFailed = 'the local address list could not be read: boom' }))
    Assert-True ("host IPs (S6): loopback and link-local are LABELLED, not hidden ({0}); a failed read says 'could not read', never 'no addresses' ('{1}')" -f ((@($ipRows) | ForEach-Object { $_.Kind }) -join ','), $ipFail[0].Address) `
        ((((@($ipRows) | ForEach-Object { $_.Kind }) -join ',') -ceq 'loopback,link-local,link-local,IPv4') -and ($ipFail[0].Address -ceq 'could not read') -and ($ipFail[0].Kind -match 'boom'))
    # K15 (lane sqlstack-live-blockers): the DHCP label, from the reader's PrefixOrigin.
    $ipDh = @(Get-SqlStackGuiHostIpRows -Rows @(
        [pscustomobject]@{ Ip = '192.168.244.1'; Interface = 'VMware Network Adapter VMnet1'; Family = 'InterNetwork'; IsLoopback = $false; IsLinkLocal = $false; PrefixOrigin = 'Dhcp' },
        [pscustomobject]@{ Ip = '10.0.0.71'; Interface = 'Ethernet'; Family = 'InterNetwork'; IsLoopback = $false; IsLinkLocal = $false; PrefixOrigin = 'unknown' },
        [pscustomobject]@{ Ip = '10.0.0.72'; Interface = 'Ethernet'; Family = 'InterNetwork'; IsLoopback = $false; IsLinkLocal = $false },
        [pscustomobject]@{ Ip = '10.0.0.73'; Interface = 'Ethernet'; Family = 'InterNetwork'; IsLoopback = $false; IsLinkLocal = $false; PrefixOrigin = 'Manual' }))
    Assert-True ("host IPs (K15): a DHCP address is labelled DHCP and an unread origin says so, before any dry run ({0})" -f ((@($ipDh) | ForEach-Object { $_.Kind }) -join ',')) `
        (((@($ipDh) | ForEach-Object { $_.Kind }) -join ',') -ceq 'IPv4 (DHCP),IPv4 (DHCP state unknown),IPv4 (DHCP state unknown),IPv4')
    # Finding 14: a free share is judged unrounded.
    $vLow = [pscustomobject]@{ DriveLetter = 'C'; SizeGB = 1881.5; FreeGB = 185.1; AllocationUnitSize = 65536; FileSystem = 'NTFS' }
    Assert-True ("finding 14: 185.1 of 1881.5 GB free is '{0}' and the advice calls it low ('{1}')" -f (Get-SqlStackGuiFreeText -Percent (100.0 * 185.1 / 1881.5)), (Get-DriveAdvice -Volume $vLow)) `
        (((Get-SqlStackGuiFreeText -Percent (100.0 * 185.1 / 1881.5)) -ceq '9.8%') -and ((Get-DriveAdvice -Volume $vLow) -match 'only 9\.8% free') -and ((Get-SqlStackGuiFreeText -Percent 42.4) -ceq '42%'))
    $words = @('NotStarted', 'Running', 'Done', 'Attention', 'Failed', 'Stale', 'Blocked') | ForEach-Object { (Get-SqlStackGuiStatusWord -Status $_).Word }
    Assert-True ("rail: every stage status is a WORD ({0})" -f ($words -join ', ')) ((@($words | Sort-Object -Unique).Count -eq 7) -and (@($words | Where-Object { -not $_ }).Count -eq 0))

    Write-Host ''
    Write-Host '-- workbench memory and compare: snapshot A''s ceilings (K7) and the in-process compare (K15), over the REAL bundle --'
    $w3Tmp = Join-Path ([IO.Path]::GetTempPath()) ('ss-wb3-' + [Guid]::NewGuid().ToString('n'))
    try {
        $w3Fx = Join-Path (Split-Path -Parent $script:EntryScriptPath) 'tests\fixtures\window\snapA'
        $w3B = 'SqlStack-Diag-HOST1-2026-11-03T08-17-12-614Z'
        $w3Snap = [pscustomobject]@{ Status = 'Done'; Bundle = (Join-Path $w3Fx $w3B); BundleName = $w3B; HostToken = 'HOST1'; CollectedUtc = '2026-11-03T08:17:12.614Z' }
        $w3Maps = Join-Path $w3Tmp 'maps'
        [void](New-Item -ItemType Directory -Path $w3Maps -Force)
        # A FICTIONAL map of the collector's shape: the real one holds real values and was not copied.
        $w3Map = [ordered]@{ HOST1 = [ordered]@{ class = 'HOST'; value = 'LABHOST' }; INST2 = [ordered]@{ class = 'INST'; value = 'NEW2022' }
                             INST4 = [ordered]@{ class = 'INST'; value = 'OLD2017' }; INST6 = [ordered]@{ class = 'INST'; value = 'AG2' } }
        [IO.File]::WriteAllText((Join-Path $w3Maps ($w3B + '.map.json')), ($w3Map | ConvertTo-Json -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
        $w3Names = @('MSSQLSERVER', 'NEW2022', 'OLD2017', 'AG2')
        $mc = Read-SqlStackGuiMemoryCeiling -Snapshot $w3Snap -Installed $w3Names -MapRoot $w3Maps -ComputerName 'LABHOST'
        $mcLine = (@($mc.Rows) | ForEach-Object { '{0}={1}' -f $_.Name, $(if ($null -ne $_.Mb) { $_.Mb } else { 'null' }) }) -join ' '
        Assert-True ("K7: the real snapshot's ceilings, the default instance by its literal name and the named ones through the map ({0})" -f $mcLine) `
            ($mc.Ok -and ($mcLine -ceq 'MSSQLSERVER=1024 NEW2022=1800 OLD2017=1048 AG2=null'))
        $ag2 = @($mc.Rows | Where-Object { $_.Name -eq 'AG2' })[0]
        Assert-True ("K7: the instance whose probe was skipped has NO ceiling - not 0 - and says why, from probes.jsonl ('{0}')" -f $ag2.Words) `
            (($null -eq $ag2.Mb) -and ($ag2.Words -match 'SkippedNotApplicable') -and ($ag2.Words -match 'not reachable'))
        $mcOther = Read-SqlStackGuiMemoryCeiling -Snapshot $w3Snap -Installed $w3Names -MapRoot $w3Maps -ComputerName 'ELSEWHERE'
        $mcNoMap = Read-SqlStackGuiMemoryCeiling -Snapshot $w3Snap -Installed $w3Names -MapRoot (Join-Path $w3Tmp 'nomaps') -ComputerName 'LABHOST'
        # Gate F2 (2026-11-04), brief S4: the DEFAULT instance too. Its file needs no
        # token, but a bundle this window cannot tie to this host is not this host's
        # number: no map, or another host's map, means NO instance is matched.
        $msOther = @($mcOther.Rows | Where-Object { $_.Name -eq 'MSSQLSERVER' })[0]; $msNoMap = @($mcNoMap.Rows | Where-Object { $_.Name -eq 'MSSQLSERVER' })[0]
        Assert-True ("K7 (S4, gate F2): another host's map, or no visible map, matches NO instance, the default one included ('{0}' | '{1}' | MSSQLSERVER: '{2}' | '{3}')" -f `
                @($mcOther.Rows | Where-Object { $_.Name -eq 'NEW2022' })[0].Words, @($mcNoMap.Rows | Where-Object { $_.Name -eq 'NEW2022' })[0].Words, $msOther.Words, $msNoMap.Words) `
            ((@($mcOther.Rows | Where-Object { $null -ne $_.Mb }).Count -eq 0) -and (@($mcOther.Rows | Where-Object { $_.Name -eq 'NEW2022' })[0].Words -match 'another host') -and
             (@($mcNoMap.Rows | Where-Object { $null -ne $_.Mb }).Count -eq 0) -and ($msOther.Words -match '^cannot be matched to this host''s instances') -and ($msNoMap.Words -match '^cannot be matched to this host''s instances'))
        # ... and the typed planning ceiling is then the fallback for it (S4).
        $msRow = @([pscustomobject]@{ Name = 'MSSQLSERVER'; Fixed = $true; MaxMemoryMb = $null; TypedCeilingMb = 3072; Facts = [string[]]@('Max server memory: NOT READ.') })
        Set-SqlStackGuiInstalledCeiling -Plan $msRow -Ceilings $mcOther
        Assert-True ("K7 (S4, gate F2): with another host's map the default instance takes the TYPED ceiling, not the bundle's 1024 ('{0}')" -f $msRow[0].Facts[0]) `
            (($msRow[0].MaxMemoryMb -eq 3072) -and ($msRow[0].CeilingSource -eq 'typed') -and ($msRow[0].Facts[0] -match 'cannot be matched'))
        # The SQL default and a zero, in a copy of the real bundle.
        $w3Copy = Join-Path $w3Tmp ('c\' + $w3B)
        [void](New-Item -ItemType Directory -Path (Join-Path $w3Copy 'probes') -Force)
        foreach ($f in @('manifest.json', 'probes.jsonl')) { [IO.File]::WriteAllBytes((Join-Path $w3Copy $f), [IO.File]::ReadAllBytes((Join-Path (Join-Path $w3Fx $w3B) $f))) }
        $cfg = [IO.File]::ReadAllText((Join-Path (Join-Path $w3Fx $w3B) 'probes\sql-configurations.INST2.json'))
        [IO.File]::WriteAllText((Join-Path $w3Copy 'probes\sql-configurations.INST2.json'), ($cfg -replace '("name":\s*"max server memory \(MB\)",\s*"value_in_use":\s*)1800', '${1}2147483647'), (New-Object System.Text.UTF8Encoding($false)))
        $cfg4 = [IO.File]::ReadAllText((Join-Path (Join-Path $w3Fx $w3B) 'probes\sql-configurations.INST4.json'))
        [IO.File]::WriteAllText((Join-Path $w3Copy 'probes\sql-configurations.INST4.json'), ($cfg4 -replace '("name":\s*"max server memory \(MB\)",\s*"value_in_use":\s*)1048', '${1}0'), (New-Object System.Text.UTF8Encoding($false)))
        $w3SnapC = [pscustomobject]@{ Status = 'Done'; Bundle = $w3Copy; BundleName = $w3B; HostToken = 'HOST1'; CollectedUtc = '2026-11-03T08:17:12.614Z' }
        $mcC = Read-SqlStackGuiMemoryCeiling -Snapshot $w3SnapC -Installed $w3Names -MapRoot $w3Maps -ComputerName 'LABHOST'
        $u2 = @($mcC.Rows | Where-Object { $_.Name -eq 'NEW2022' })[0]; $z4 = @($mcC.Rows | Where-Object { $_.Name -eq 'OLD2017' })[0]
        Assert-True ("K7: 2147483647 reads 'unlimited (SQL default)', and a 0 is NOT a ceiling ('{0}' | '{1}')" -f $u2.Words, $z4.Words) `
            ($u2.Unlimited -and ($u2.Words -match '^unlimited \(SQL default\)') -and ($null -eq $z4.Mb) -and ($z4.Words -match 'not a ceiling'))
        # The installed rows take the ceilings; a typed one is the fallback; unread stays unread.
        $fxRows = @($w3Names | ForEach-Object { [pscustomobject]@{ Name = $_; Fixed = $true; MaxMemoryMb = $null; Facts = [string[]]@('Max server memory: NOT READ.') } })
        $fxRows[3] | Add-Member -NotePropertyName TypedCeilingMb -NotePropertyValue 2048
        Set-SqlStackGuiInstalledCeiling -Plan $fxRows -Ceilings $mc
        Assert-True ("finding 5 (K7): installed rows carry snapshot A's ceiling, and a TYPED planning ceiling only where none was read ({0})" -f ((@($fxRows) | ForEach-Object { '{0}={1}/{2}' -f $_.Name, $_.MaxMemoryMb, $_.CeilingSource }) -join ' ')) `
            (($fxRows[0].MaxMemoryMb -eq 1024) -and ($fxRows[1].MaxMemoryMb -eq 1800) -and ($fxRows[3].MaxMemoryMb -eq 2048) -and ($fxRows[3].CeilingSource -eq 'typed') -and ($fxRows[0].Facts[0] -match 'snapshot A') -and ($fxRows[3].Facts[0] -match 'TYPED'))
        $fxRows[3].TypedCeilingMb = 0
        Set-SqlStackGuiInstalledCeiling -Plan $fxRows -Ceilings $mc
        Assert-True 'finding 5: with neither, the ceiling stays NOT READ ($null), never 0' (($null -eq $fxRows[3].MaxMemoryMb) -and ($fxRows[3].Facts[0] -match 'NOT READ'))
        # The split now runs over read ceilings, and an UNLIMITED installed instance is a warning, as the engine plans it.
        $nw = New-SqlStackGuiPlanRow -Name 'INST01' -Port 14331 -DataPath 'E:\I\Data' -LogPath 'F:\I\Log' -TempDbPath 'T:\I\TempDB' -BackupPath 'G:\I\Backup' -MaxMemoryMb 4096 -TempDbFileCount 4
        $cmpRead = Get-SqlStackGuiPlanComputation -Plan @($fxRows[0], $fxRows[1], $fxRows[2], $nw) -PhysicalMb 32246
        Assert-True ("finding 5: with every installed ceiling read, the memory split IS computed (status {0})" -f $cmpRead.Memory.Status) $cmpRead.MemoryComputed
        $unl = [pscustomobject]@{ Name = 'LABB'; Fixed = $true; MaxMemoryMb = 2147483647; Port = $null; Facts = @() }
        $vU = Test-SqlStackPlan -Plan @($unl, $nw) -Volumes $vols -PhysicalMb 65536
        Assert-True ("K7: an installed instance at the SQL default (unlimited) is a WARN naming it, not an over-commit ERROR ({0})" -f ((@($vU | Where-Object { $_.Area -eq 'memory' }) | ForEach-Object { $_.Severity + ': ' + $_.Message }) -join ' | ')) `
            ((@($vU | Where-Object { ($_.Area -eq 'memory') -and ($_.Severity -eq 'ERROR') }).Count -eq 0) -and (@($vU | Where-Object { ($_.Area -eq 'memory') -and ($_.Severity -eq 'WARN') -and ($_.Message -match 'LABB') -and ($_.Message -match 'unlimited') }).Count -eq 1))

        # K15: the in-process compare over the real bundle against a byte-copy of itself.
        $w3Run = Join-Path $w3Tmp 'run'
        foreach ($leaf in @('snapshot-A', 'snapshot-B')) {
            $dst = Join-Path $w3Run ($leaf + '\' + $w3B)
            [void](New-Item -ItemType Directory -Path (Join-Path $dst 'probes') -Force)
            foreach ($f in @(Get-ChildItem -LiteralPath (Join-Path $w3Fx $w3B) -Recurse -File)) {
                $rel = $f.FullName.Substring((Join-Path $w3Fx $w3B).Length).TrimStart('\')
                [IO.File]::WriteAllBytes((Join-Path $dst $rel), [IO.File]::ReadAllBytes($f.FullName))
            }
        }
        $cmpState = [pscustomobject]@{ Root = $w3Run; StatePath = (Join-Path $w3Tmp 'state')
            Spec = [pscustomobject]@{ Throwaway = [string[]]@('AG2') }
            SnapshotA = (Read-SqlStackGuiSnapshot -Folder (Join-Path $w3Run 'snapshot-A')); SnapshotB = (Read-SqlStackGuiSnapshot -Folder (Join-Path $w3Run 'snapshot-B')) }
        # The compare reads the map with THIS computer's name, so the map now names this computer as its host.
        $w3Map['HOST1'] = [ordered]@{ class = 'HOST'; value = $env:COMPUTERNAME }
        [IO.File]::WriteAllText((Join-Path $w3Maps ($w3B + '.map.json')), ($w3Map | ConvertTo-Json -Depth 4), (New-Object System.Text.UTF8Encoding($false)))
        $blk = Get-SqlStackGuiCompareBlock -State $cmpState -ToolDir (Split-Path -Parent $script:EntryScriptPath) -MapRoot $w3Maps
        Assert-True ("K15: with snapshot B's map the compare block excludes the throwaway's TOKEN, read from that map ({0}); with no map there is NO block, and it says why ('{1}')" -f $blk.Token, (Get-SqlStackGuiCompareBlock -State $cmpState -MapRoot (Join-Path $w3Tmp 'nomaps')).Reason) `
            (($blk.Token -ceq 'INST6') -and ($blk.Text -match "-ExcludeInstance 'INST6'") -and ($blk.Text -match [regex]::Escape((Join-Path $w3Run ('snapshot-B\' + $w3B)))) -and (-not (Get-SqlStackGuiCompareBlock -State $cmpState -MapRoot (Join-Path $w3Tmp 'nomaps')).Text))
        $cmp = Invoke-SqlStackGuiCompare -State $cmpState -MapRoot $w3Maps
        Assert-True ("K15: the window runs the ENGINE's Compare-SqlStackSnapshot in-process and puts OK first, then EMPTY ('{0}' | '{1}' | {2})" -f @($cmp.Lines)[0], @($cmp.Lines)[1], $cmp.Headline) `
            ($cmp.Ran -and (@($cmp.Lines)[0] -match '^OK=True') -and (@($cmp.Lines)[1] -match '^EMPTY=True') -and ($cmp.Result.Ok -eq $true))
    } finally { Remove-Item -LiteralPath $w3Tmp -Recurse -Force -ErrorAction SilentlyContinue }

    Write-Host ''
    Write-Host '-- workbench invariants: the censuses see their defects (specimen), and INV-1 holds by the ENGINE''s own writer census --'
    $wSpecPath = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-workbench-specimen-' + [guid]::NewGuid().ToString('N') + '.ps1')
    $wSpecimen = @(
        'function Save-Thing { [IO.File]::WriteAllText(''C:\x\spec.json'', ''{}'') }',
        'Write-SqlStackGuiFileSet -Folder ''C:\elsewhere'' -FileSet @() -ConfirmOverwrite { $true }',
        'function Move-Log { Open-SqlStackGuiLog -Path ''C:\x\window.log'' }',
        '$t = Get-SqlStackGuiStageTable',
        'function Copy-It { [System.Windows.Forms.Clipboard]::SetText(''x'') }',
        '$s = ''SqlStack-Apply.ps1 -Spec x -Apply -PlanHash 00''',
        '$p = Get-SqlStackGuiPlanSet -StatePath x -SpecPath y'
    ) -join [Environment]::NewLine
    [IO.File]::WriteAllText($wSpecPath, $wSpecimen, (New-Object System.Text.UTF8Encoding($false)))
    try {
        $wSpec = @(Test-SqlStackGuiStructure -ScriptPath $wSpecPath)
        $wRed = @($wSpec | Where-Object { ($_.Id -like 'W*') -and (@($_.Findings).Count -gt 0) } | ForEach-Object { $_.Id })
        Assert-True ("workbench (W): the census SEES each defect in a specimen (red rows [{0}])" -f ($wRed -join ', ')) `
            ((@($wRed) -join ',') -ceq 'W1-writes-through-run-folder,W2-writers-resolve-here,W3-log-moves-to-run,W4-one-command-builder,W5-clipboard-through-builder,W6-no-command-text-elsewhere (tripwire),W7-one-stage-reader')
    } finally { Remove-Item -LiteralPath $wSpecPath -Force -ErrorAction SilentlyContinue }
    Assert-True 'workbench (W): the seven W rows ran on this file (green or red, above)' (@($guiStruct | Where-Object { $_.Id -like 'W*' }).Count -eq 7)
    # Gate F5, F6, F1 (2026-11-04): ONE PLANT PER SPECIMEN, each a sink or a shape
    # the census once missed. The row must go red with ITS OWN finding (matched by
    # the finding's words), because a bare specimen turns most rows red for an
    # unrelated reason ("not in the syntax tree", "nothing was checked").
    $wPlants = @(
        @('W1 sees [IO.File]::OpenWrite (F5)', 'W1-writes-through-run-folder', 'a file write outside', 'function Save-It { [IO.File]::OpenWrite(''C:\x\a.txt'').Dispose() }'),
        @('W1 sees an image .Save (F5)', 'W1-writes-through-run-folder', 'a file write outside', 'function Shot-It { $bm = New-Object System.Drawing.Bitmap(1, 1); $bm.Save(''C:\x\a.png'') }'),
        @('W1 sees [IO.File]::Open (F5 class)', 'W1-writes-through-run-folder', 'a file write outside', 'function Open-It { [IO.File]::Open(''C:\x\a.txt'', ''Create'').Dispose() }'),
        @('W1 sees a zip writer (F5 class)', 'W1-writes-through-run-folder', 'a file write outside', 'function Zip-It { [IO.Compression.ZipFile]::CreateFromDirectory(''C:\x'', ''C:\y.zip'') }'),
        @('W1 sees Compress-Archive (F5 class)', 'W1-writes-through-run-folder', 'a file write outside', 'function Zip-It { Compress-Archive -Path ''C:\x'' -DestinationPath ''C:\y.zip'' }'),
        @('W5 sees Set-Clipboard (F5)', 'W5-clipboard-through-builder', 'the clipboard is (used|written) outside', 'function Copy-It { Set-Clipboard -Value ''x'' }'),
        @('W5 sees clip.exe (F5 class)', 'W5-clipboard-through-builder', 'the clipboard is (used|written) outside', 'function Copy-It { ''x'' | clip.exe }'),
        @('W2 sees Write-SqlStackGuiRunFile -Root elsewhere (F6)', 'W2-writers-resolve-here', '-Root is not the open run folder', 'function Tidy-It { $p = Write-SqlStackGuiRunFile -Root ''C:\Windows\Temp'' -Item ''TidyUp'' -Text ''x'' }'),
        @('W2 sees Initialize-SqlStackGuiRunFolder -Root elsewhere (F6 class)', 'W2-writers-resolve-here', '-Root is not the open run folder', 'function Make-It { $d = Initialize-SqlStackGuiRunFolder -Root $env:TEMP -Item ''Export'' }'),
        @('W2 sees the open run folder re-pointed (F6 class)', 'W2-writers-resolve-here', 'WbRoot is assigned outside', 'function Move-It { $script:WbRoot = ''C:\Windows\Temp'' }'),
        @('I1 sees Start-Process (2026-11-16)', 'I1-process-starts', 'a process is started', 'function Run-It { Start-Process notepad.exe }'),
        @('I1 sees [Diagnostics.Process]::Start', 'I1-process-starts', 'a process is started', 'function Run-It { [System.Diagnostics.Process]::Start(''x.exe'') }'),
        @('I1 sees a .Start() on anything', 'I1-process-starts', 'a process is started', 'function Run-It { $p = Get-Thing; $p.Start() }'),
        @('I1 sees compiled code outside the worker host', 'I1-process-starts', 'compiled code', 'function Hide-It { Add-Type -TypeDefinition ''public class X {}'' }'),
        @('I1 sees the test-only harness switch in product code', 'I1-process-starts', 'test-only -HarnessSetupExe', 'function Fake-It { $w = Start-SqlStackGuiInstallWorker -RunFolder ''C:\r'' -HarnessSetupExe ''C:\x.exe'' }'),
        @('I2 sees a real install started elsewhere', 'I2-install-one-place', 'not the constant Preview', 'function Go-It { $w = Start-SqlStackGuiInstallWorker -RunFolder ''C:\r'' -Mode ''Install'' }'),
        @('I2 sees a mode that is not a constant', 'I2-install-one-place', 'not the constant Preview', 'function Go-It { $w = Start-SqlStackGuiInstallWorker -RunFolder ''C:\r'' -Mode $m }'),
        @('I2 sees a restart of Windows started with no confirm (2026-11-17)', 'I2-install-one-place', 'in mode Restart outside', 'function Invoke-SqlStackGuiRestartNow { $w = Start-SqlStackGuiInstallWorker -RunFolder ''C:\r'' -Mode ''Restart'' }'),
        @('I2 sees the resume task removed elsewhere (2026-11-17)', 'I2-install-one-place', 'in mode ForgetResume outside', 'function Tidy-It { $w = Start-SqlStackGuiInstallWorker -RunFolder ''C:\r'' -Mode ''ForgetResume'' }'),
        @('D3 sees a branch on elevation', 'D3-elevation-two-readers', 'something other than an argument', 'if ($script:IsElevated) { $x = 1 }'),
        @('V1 sees a hidden card subtitle given text (F1)', 'V1-hidden-text-shown', 'never made visible', ('$cd = New-SqlStackGuiCard -Title ''x'' -Subtitle ''''' + [Environment]::NewLine + '$note = $cd.Subtitle' + [Environment]::NewLine + 'function Set-It { $note.Text = ''Run it elevated'' }')),
        @('V1 sees a Visible = $false label given text (F1 class)', 'V1-hidden-text-shown', 'never made visible', ('$lb = New-Object System.Windows.Forms.Label' + [Environment]::NewLine + '$lb.Visible = $false' + [Environment]::NewLine + 'function Set-It { $lb.Text = ''why'' }'))
    )
    foreach ($pl in $wPlants) {
        $plPath = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-workbench-plant-' + [guid]::NewGuid().ToString('N') + '.ps1')
        [IO.File]::WriteAllText($plPath, [string]$pl[3], (New-Object System.Text.UTF8Encoding($false)))
        try {
            $plRow = @(Test-SqlStackGuiStructure -ScriptPath $plPath | Where-Object { $_.Id -eq $pl[1] }) | Select-Object -First 1
            $plHit = @(@($(if ($plRow) { $plRow.Findings } else { @() })) | Where-Object { $_ -match $pl[2] })
            Assert-True ("workbench plant: {0}: row {1} goes red with its own finding ('{2}')" -f $pl[0], $pl[1], $(if ($plHit.Count) { $plHit[0] } else { 'NOT SEEN; findings: ' + (@($(if ($plRow) { $plRow.Findings } else { @() })) -join ' | ') })) ($plHit.Count -ge 1)
        } finally { Remove-Item -LiteralPath $plPath -Force -ErrorAction SilentlyContinue }
    }
    # The same plants as the gate's, in a COPY of THIS file: the copy is green
    # before the plant (checked above, as the file itself), and the plant turns
    # exactly its row red. Anchors are code this file must keep.
    $selfText = [IO.File]::ReadAllText($script:EntryScriptPath)
    $railAnchor = ('function ' + 'Update-SqlStackGuiRail {')   # built, so this line is not a second copy of the anchor
    $railNl = $(if ($selfText.Contains("`r`n")) { "`r`n" } else { "`n" })
    $realPlants = @(
        @('OpenWrite', 'W1-writes-through-run-folder', ($railAnchor + $railNl + "    [IO.File]::OpenWrite('C:\temp\gate-plant.txt').Dispose()")),
        @('Bitmap.Save', 'W1-writes-through-run-folder', ($railAnchor + $railNl + "    `$bm = New-Object System.Drawing.Bitmap(1,1); `$bm.Save('C:\temp\gate-plant.png')")),
        @('Set-Clipboard', 'W5-clipboard-through-builder', ($railAnchor + $railNl + "    Set-Clipboard -Value 'typed'")),
        @('Write-SqlStackGuiRunFile -Root C:\Windows\Temp', 'W2-writers-resolve-here', ($railAnchor + $railNl + "    `$p = Write-SqlStackGuiRunFile -Root 'C:\Windows\Temp' -Item 'TidyUp' -Text 'x'")),
        @('Start-Process', 'I1-process-starts', ($railAnchor + $railNl + "    Start-Process notepad.exe")),
        @('a real install started from the rail', 'I2-install-one-place', ($railAnchor + $railNl + "    `$w = Start-SqlStackGuiInstallWorker -RunFolder `$script:WbRoot -Mode 'Install'")),
        @('a restart of Windows started from the rail', 'I2-install-one-place', ($railAnchor + $railNl + "    `$w = Start-SqlStackGuiInstallWorker -RunFolder `$script:WbRoot -Mode 'Restart'")),
        @('a branch on elevation', 'D3-elevation-two-readers', ($railAnchor + $railNl + "    if (`$script:IsElevated) { return }"))
    )
    Assert-True 'workbench plant: the anchor for the in-file plants is in this file exactly once' (([regex]::Matches($selfText, [regex]::Escape($railAnchor))).Count -eq 1)
    foreach ($pl in $realPlants) {
        $plPath = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack-workbench-realplant-' + [guid]::NewGuid().ToString('N') + '.ps1')
        [IO.File]::WriteAllText($plPath, $selfText.Replace($railAnchor, [string]$pl[2]), (New-Object System.Text.UTF8Encoding($false)))
        try {
            $plRed = @(Test-SqlStackGuiStructure -ScriptPath $plPath | Where-Object { @($_.Findings).Count -gt 0 } | ForEach-Object { $_.Id })
            Assert-True ("workbench plant in a copy of this file: {0} turns exactly {1} red (red rows [{2}])" -f $pl[0], $pl[1], ($plRed -join ', ')) ((@($plRed) -join ',') -ceq $pl[1])
        } finally { Remove-Item -LiteralPath $plPath -Force -ErrorAction SilentlyContinue }
    }
    # K5(a): the ENGINE's writer census, over THIS file. Specimen first: it must see a spawn.
    $wcSpec = Get-SqlStackWriterCensus -Source @(@{ Label = 'specimen'; Text = 'function Run-It { Start-Process powershell -ArgumentList ''-File x.ps1'' }' })
    Assert-True ("writer census (INV-1): the engine's census SEES a spawned process in a specimen ({0} offender(s))" -f @($wcSpec.Offenders).Count) (@($wcSpec.Offenders).Count -ge 1)
    $wc = Get-SqlStackWriterCensus -Source @(@{ Label = 'SqlStack.ps1'; Path = $script:EntryScriptPath })
    # REWORDED 2026-11-16 (the Install screen), CONDITION UNCHANGED: 0 offenders.
    # The old words said "NO writer, spawner or SQL client". This file now starts
    # two processes (INV-5), through .NET calls this census of COMMANDS does not
    # read; those two starts are held by 'gui structure I1-process-starts', above.
    Assert-True ("writer census (INV-1, INV-5): SqlStack.ps1 holds NO writer cmdlet, NO spawning command and NO SQL client; its two process starts are row I1's ({0} command(s), {1} function(s), {2} offender(s), {3} problem(s){4})" -f `
            $wc.CommandsScanned, $wc.FunctionsScanned, @($wc.Offenders).Count, @($wc.Problems).Count, $(if (@($wc.Offenders).Count) { ' -- ' + (@($wc.Offenders | ForEach-Object { [string]$_ }) -join ' | ') } else { '' })) `
        ((@($wc.Offenders).Count -eq 0) -and (@($wc.Problems).Count -eq 0) -and ($wc.CommandsScanned -ge 1000))
    # K10 / INV-4: the engine's local-address reader only READS. Its syntax tree calls
    # New-Object and NIC enumeration members, and assigns no script, global or env variable.
    # Since fix round 1 (F1) the per-card judgement is Get-SqlStackCardDhcpState: the
    # reader may call it and nothing else, and its body is held to the SAME lists.
    $ipFn = @($engAst.FindAll({ param($n) ($n -is [System.Management.Automation.Language.FunctionDefinitionAst]) -and (@('Get-SqlStackLocalIpAddress', 'Get-SqlStackCardDhcpState') -ccontains $n.Name) }, $true))
    $ipCmds = @($ipFn | ForEach-Object { $_.FindAll({ param($n) $n -is [System.Management.Automation.Language.CommandAst] }, $true) } | ForEach-Object { [string]$_.GetCommandName() } | Sort-Object -Unique)
    $ipMembers = @($ipFn | ForEach-Object { $_.FindAll({ param($n) $n -is [System.Management.Automation.Language.InvokeMemberExpressionAst] }, $true) } | ForEach-Object { [string]$_.Member.Extent.Text } | Sort-Object -Unique)
    $ipScoped = @($ipFn | ForEach-Object { $_.FindAll({ param($n) ($n -is [System.Management.Automation.Language.AssignmentStatementAst]) -and ($n.Left -is [System.Management.Automation.Language.VariableExpressionAst]) -and ($n.Left.VariablePath.UserPath -match '^(?i)(script|global|env):') }, $true) })
    Assert-True ("host IPs (INV-4, K10): Get-SqlStackLocalIpAddress and Get-SqlStackCardDhcpState only read - commands [{0}], members [{1}], {2} script/global/env assignment(s)" -f ($ipCmds -join ','), ($ipMembers -join ','), $ipScoped.Count) `
        (($ipFn.Count -eq 2) -and (@($ipCmds | Where-Object { @('New-Object', 'Get-SqlStackCardDhcpState') -cnotcontains $_ }).Count -eq 0) -and
         (@($ipMembers | Where-Object { @('GetAllNetworkInterfaces', 'GetIPProperties', 'GetIPv4Properties', 'ToString', 'IsLoopback', 'StartsWith', 'Add', 'ContainsKey') -notcontains $_ }).Count -eq 0) -and ($ipScoped.Count -eq 0))

    Write-Host ''
    Write-Host '-- the workbench gate''s findings (2026-11-04): words the operator reads, and the README''s bytes --'
    # F7: the -STA hint only when the thread is NOT STA. (On the base this row is red
    # because the words were inline and always carried the hint; the helper is new.)
    $crSta = try { Get-SqlStackGuiCopyRefusal -Message 'boom' -Apartment 'STA' } catch { '' }
    $crMta = try { Get-SqlStackGuiCopyRefusal -Message 'boom' -Apartment 'MTA' } catch { '' }
    Assert-True ("copy refusal (F7): an STA window is not told to start with -STA ('{0}'); an MTA one is ('{1}')" -f $crSta, $crMta) `
        ($crSta -and ($crSta -notmatch '-STA') -and ($crSta -match 'boom') -and ($crMta -match '-STA') -and ($crMta -match 'boom'))
    # F9: Save spec's status line uses the stage reader's word for an earlier dry run.
    # TRIPWIRE, NOT THE GUARANTEE: a character match over the Save spec handler's literals.
    $f9Ast = [System.Management.Automation.Language.Parser]::ParseFile($script:EntryScriptPath, [ref]$null, [ref]$null)
    $f9Click = @($f9Ast.FindAll({ param($n) ($n -is [System.Management.Automation.Language.InvokeMemberExpressionAst]) -and ([string]$n.Expression.Extent.Text -eq '$btnSpec') -and ([string]$n.Member.Extent.Text -eq 'Add_Click') }, $true))
    $f9Lits = @($f9Click | ForEach-Object { $_.FindAll({ param($n) $n -is [System.Management.Automation.Language.StringConstantExpressionAst] }, $true) } | ForEach-Object { [string]$_.Value })
    Assert-True ("save spec (F9, tripwire): the status line calls an earlier dry run 'stale', the stage reader's word, never 'superseded' ({0} handler(s))" -f $f9Click.Count) `
        (($f9Click.Count -eq 1) -and (@($f9Lits | Where-Object { $_ -match '(?i)superseded' }).Count -eq 0) -and (@($f9Lits | Where-Object { $_ -match '\bstale\b' }).Count -ge 1))
    # F10: the memory WARN says where an installed ceiling CAN come from: snapshot A.
    $f10Fixed = [pscustomobject]@{ Name = 'LABA'; Fixed = $true; MaxMemoryMb = $null; Port = $null; Facts = @() }
    $f10New = New-SqlStackGuiPlanRow -Name 'INST01' -Port 14331 -DataPath 'E:\I\Data' -LogPath 'F:\I\Log' -TempDbPath 'T:\I\TempDB' -BackupPath 'G:\I\Backup' -MaxMemoryMb 4096 -TempDbFileCount 4
    # Assigned bare first: Test-SqlStackPlan returns with a comma (the engine's wrap census).
    $f10All = Test-SqlStackPlan -Plan @($f10Fixed, $f10New) -Volumes $vols -PhysicalMb 65536
    $f10 = @($f10All | Where-Object { ($_.Area -eq 'memory') -and ($_.Severity -eq 'WARN') -and ($_.Message -match 'LABA') })
    $f10Arith = (Get-SqlStackGuiPlanComputation -Plan @($f10Fixed, $f10New) -PhysicalMb 65536).Memory.Arithmetic
    Assert-True ("memory (F10): an unread installed ceiling names snapshot A as its source, in the WARN and the arithmetic ('{0}' | '{1}')" -f (@($f10 | ForEach-Object { $_.Message }) -join ' | '), $f10Arith) `
        (($f10.Count -eq 1) -and ($f10[0].Message -match 'snapshot A') -and ([string]$f10Arith -match 'snapshot A'))
    # F13: with a read-only spec open, the counts say they are this window's own check.
    $ctRo = try { Get-SqlStackGuiCountText -Errors 5 -Warnings 0 -ReadOnly } catch { '' }
    Assert-True ("status (F13): a read-only spec's counts say whose check they are ('{0}'); an editable one's are unchanged ('{1}')" -f $ctRo, (Get-SqlStackGuiCountText -Errors 5 -Warnings 0)) `
        (($ctRo -match '^5 errors, 0 warnings') -and ($ctRo -match 'read-only') -and ((Get-SqlStackGuiCountText -Errors 5 -Warnings 0) -ceq '5 errors, 0 warnings'))
    # F3: the operator docs hold no control byte but LF, and CR only before LF (a
    # BYTE scan: a '\t' or '\r' typed into a path became a TAB and a CR once).
    foreach ($doc in @('README.md', 'tests\fixtures\README-window.md')) {
        $dp = Join-Path (Split-Path -Parent $script:EntryScriptPath) $doc
        $db = [IO.File]::ReadAllBytes($dp)
        $bad = New-Object System.Collections.ArrayList
        for ($k = 0; $k -lt $db.Length; $k++) {
            $b = $db[$k]
            if (($b -lt 32) -and ($b -ne 10) -and (($b -ne 13) -or ($k + 1 -ge $db.Length) -or ($db[$k + 1] -ne 10))) { [void]$bad.Add(('byte {0} at offset {1}' -f $b, $k)) }
        }
        Assert-True ("docs (F3): {0} holds no TAB, lone CR or other control byte ({1} byte(s) scanned{2})" -f $doc, $db.Length, $(if ($bad.Count) { ': ' + (@($bad) -join ', ') } else { '' })) ($bad.Count -eq 0)
    }
    # F4: the README claims no PROVED clipboard copy; the copy is said to be untested.
    # TRIPWIRE, NOT THE GUARANTEE: a character match over the README's sentences.
    $rmText = [IO.File]::ReadAllText((Join-Path (Split-Path -Parent $script:EntryScriptPath) 'README.md'))
    $rmProvedCopy = @([regex]::Matches($rmText, '\*\*We proved\*\*[^.\r\n]*') | ForEach-Object { $_.Value } | Where-Object { $_ -match '(?i)\bcop(y|ies|ied)\b' })
    Assert-True ("docs (F4, tripwire): the README claims no proved clipboard copy and says the copy is untested ({0} proved-copy line(s))" -f $rmProvedCopy.Count) `
        (($rmProvedCopy.Count -eq 0) -and ($rmText -match '(?i)clipboard[^\r\n]*untested|untested[^\r\n]*clipboard'))

    Write-Host ''
    Write-Host '-- accounts and authentication (2026-11-16): typed on the plan row, saved with the secrets the loader demands, read back, and in the ini --'
    $acV = Resolve-SqlStackGuiAccount -Text $script:SqlStackGuiVirtualWords
    $acB = Resolve-SqlStackGuiAccount -Text ''
    $acD = Resolve-SqlStackGuiAccount -Text ' CONTOSO\svc-sqla '
    $acG = Resolve-SqlStackGuiAccount -Text 'CONTOSO\gmsa-sql$'
    Assert-True ("account: the built-in words and a blank are 'virtual' ({0}/{1}); DOMAIN\name is a domain account that needs a password ('{2}', {3}); a name ending in `$ is a group managed account that needs none ({4}, {5})" -f $acV.Value, $acB.Value, $acD.Value, $acD.NeedsPassword, $acG.Kind, $acG.NeedsPassword) `
        (($acV.Value -ceq 'virtual') -and ($acB.Value -ceq 'virtual') -and $acD.Ok -and ($acD.Value -ceq 'CONTOSO\svc-sqla') -and ($acD.Kind -ceq 'domain') -and $acD.NeedsPassword -and $acG.Ok -and ($acG.Kind -ceq 'gmsa') -and (-not $acG.NeedsPassword))
    $acBad = @(@('svc-sqla', 'a\b\c', 'CONTOSO\x"y', 'someone@contoso.com', 'CONTOSO\') | ForEach-Object { Resolve-SqlStackGuiAccount -Text $_ })
    Assert-True ("account: a name with no domain, two backslashes, a double quote, a UPN and an empty name are each refused in plain words ('{0}')" -f [string]$acBad[0].Problem) `
        ((@($acBad | Where-Object { $_.Ok }).Count -eq 0) -and (@($acBad | Where-Object { -not $_.Problem }).Count -eq 0) -and ([string]$acBad[0].Problem -match 'DOMAIN\\name'))
    $acNote = Get-SqlStackGuiAccountNote -Engine 'CONTOSO\svc-sqla' -Agent ''
    $acNoteBad = Get-SqlStackGuiAccountNote -Engine 'svc' -Agent ''
    Assert-True ("account: the line under the boxes says each account in plain words ('{0}'), and says when one is not usable ('{1}')" -f $acNote.Text, $acNoteBad.Text) `
        ($acNote.Ok -and ($acNote.Text -match 'Engine: domain account') -and ($acNote.Text -match 'Agent: built-in') -and (-not $acNoteBad.Ok) -and ($acNoteBad.Text -match 'not usable yet'))
    # The plan of the brief: A mixed mode with a domain engine account and an
    # address; B Windows only on built-in accounts; C a group managed account.
    $p2Row = {
        param([string]$Name, [int]$Port, [string]$Ip, [string]$Eng, [string]$Auth)
        New-SqlStackGuiPlanRow -Name $Name -Ordinal 1 -Port $Port -DataPath ('E:\{0}\Data' -f $Name) -LogPath ('F:\{0}\Log' -f $Name) -TempDbPath ('T:\{0}\TempDB' -f $Name) -BackupPath ('G:\{0}\Backup' -f $Name) `
            -MaxMemoryMb 4096 -MaxDop 4 -TempDbFileCount 4 -Ip $Ip -MediaPath $w2Media -MediaVersion '2022' -EngineAccount $Eng -Authentication $Auth
    }
    $p2Plan = @((& $p2Row 'A' 14341 '10.20.30.41' 'CONTOSO\svc-sqla' $script:SqlStackGuiAuthMixed), (& $p2Row 'B' 14342 '' $script:SqlStackGuiVirtualWords $script:SqlStackGuiAuthWindows), (& $p2Row 'C' 14343 '' 'CONTOSO\gmsa-sql$' $script:SqlStackGuiAuthWindows))
    $p2Spec = New-SqlStackGuiSpec -Plan $p2Plan -Installed $w2Inst -HostName 'LAB01' -PortBase 14330 -Edition 'Developer' -SysAdmin $w2Admins
    $p2Doc = $p2Spec.Text | ConvertFrom-Json
    $p2A = @($p2Doc.instances | Where-Object { $_.name -eq 'A' })[0]; $p2B = @($p2Doc.instances | Where-Object { $_.name -eq 'B' })[0]; $p2C = @($p2Doc.instances | Where-Object { $_.name -eq 'C' })[0]
    $p2Secrets = @($p2Doc.secrets.PSObject.Properties | ForEach-Object { '{0}={1}' -f $_.Name, $_.Value.ref })
    Assert-True ("spec: A is saved mixed with engine '{0}', B windows on virtual accounts, C with engine '{1}'; the secrets are exactly [{2}], each a name to ask for, never a value" -f $p2A.serviceAccounts.engine, $p2C.serviceAccounts.engine, ($p2Secrets -join ', ')) `
        ($p2Spec.Ok -and ([string]$p2A.securityMode -ceq 'mixed') -and ([string]$p2A.serviceAccounts.engine -ceq 'CONTOSO\svc-sqla') -and ([string]$p2A.serviceAccounts.agent -ceq 'virtual') -and ([string]$p2A.ip -ceq '10.20.30.41') -and ([int]$p2A.ports.tcp -eq 14341) -and
         ([string]$p2B.securityMode -ceq 'windows') -and ([string]$p2B.serviceAccounts.engine -ceq 'virtual') -and ([int]$p2B.ports.tcp -eq 14342) -and ([string]$p2C.serviceAccounts.engine -ceq 'CONTOSO\gmsa-sql$') -and
         (($p2Secrets -join ',') -ceq 'sa=prompt,svc-A-engine=prompt,svc-C-engine=prompt'))
    $p2Imp = ConvertFrom-SqlStackGuiSpec -Doc $p2Doc
    $p2Rt = Test-SqlStackGuiSpecRoundTrip -Doc $p2Doc -Import $p2Imp -Installed $w2Inst -HostName 'LAB01'
    $p2Back = @($p2Imp.Rows | ForEach-Object { '{0}:{1}/{2}/{3}' -f $_.Name, $_.EngineAccount, $_.AgentAccount, $_.Authentication })
    Assert-True ("round trip: the saved spec loads back into the same rows [{0}] and writes back unchanged ({1} difference(s); {2} import problem(s))" -f ($p2Back -join ' | '), @($p2Rt.Differences).Count, @($p2Imp.Problems).Count) `
        ($p2Rt.Same -and (@($p2Imp.Problems).Count -eq 0) -and
         (($p2Back -join '|') -ceq ('A:CONTOSO\svc-sqla/{0}/{1}|B:{0}/{0}/{2}|C:CONTOSO\gmsa-sql$/{0}/{2}' -f $script:SqlStackGuiVirtualWords, $script:SqlStackGuiAuthMixed, $script:SqlStackGuiAuthWindows)))
    $p2Tmp = Join-Path ([IO.Path]::GetTempPath()) ('sqlstack install loop ' + [guid]::NewGuid().ToString('N'))
    [void](New-Item -ItemType Directory -Path $p2Tmp -Force)
    try {
        $ilRun = Join-Path $p2Tmp 'run 1'
        [void](Initialize-SqlStackGuiRunFolder -Root $ilRun)
        $ilSpecPath = Write-SqlStackGuiRunFile -Root $ilRun -Item 'Spec' -Text $p2Spec.Text
        $p2Load = Read-SqlStackGuiSpecFile -Path $ilSpecPath -InstalledInstance @('MSSQLSERVER', 'LABA') -HostName 'LAB01'
        Assert-True ("loader: the ENGINE's Test-SqlStackSpec accepts the saved spec, secrets and all ({0} error(s){1})" -f @($p2Load.Errors).Count, $(if (@($p2Load.Errors).Count) { ': ' + (@($p2Load.Errors) -join ' | ') } else { '' })) ($p2Load.Ok -and (@($p2Load.Errors).Count -eq 0))
        $p2Browser = [pscustomobject]@{ Ok = $true; Value = 'Disabled'; Source = 'a test value' }
        $p2Set = @(Get-SqlStackGuiFileSet -Plan $p2Plan -Browser $p2Browser -HostName 'LAB01' -SysAdmin $w2Admins)
        $p2Ini = @{}; foreach ($f in @($p2Set | Where-Object { $_.Kind -eq 'ini' })) { $p2Ini[$f.Instance] = [string]$f.Text }
        $iniKey = { param([string]$Text, [string]$Key) if ($Text -match ('(?m)^' + $Key + '="?([^"\r\n]*)"?\s*$')) { $Matches[1] } else { '(absent)' } }
        Assert-True ("ini: A carries engine '{0}', agent '{1}' and SECURITYMODE {2}; B '{3}' and SECURITYMODE {4}; C '{5}'; every file is complete and none holds a password key" -f (& $iniKey $p2Ini['A'] 'SQLSVCACCOUNT'), (& $iniKey $p2Ini['A'] 'AGTSVCACCOUNT'), (& $iniKey $p2Ini['A'] 'SECURITYMODE'), (& $iniKey $p2Ini['B'] 'SQLSVCACCOUNT'), (& $iniKey $p2Ini['B'] 'SECURITYMODE'), (& $iniKey $p2Ini['C'] 'SQLSVCACCOUNT')) `
            (((& $iniKey $p2Ini['A'] 'SQLSVCACCOUNT') -ceq 'CONTOSO\svc-sqla') -and ((& $iniKey $p2Ini['A'] 'AGTSVCACCOUNT') -ceq 'NT Service\SQLAgent$A') -and ((& $iniKey $p2Ini['A'] 'SECURITYMODE') -ceq 'SQL') -and
             ((& $iniKey $p2Ini['B'] 'SQLSVCACCOUNT') -ceq 'NT Service\MSSQL$B') -and ((& $iniKey $p2Ini['B'] 'SECURITYMODE') -ceq '(absent)') -and ((& $iniKey $p2Ini['C'] 'SQLSVCACCOUNT') -ceq 'CONTOSO\gmsa-sql$') -and
             (@($p2Set | Where-Object { -not $_.Ok }).Count -eq 0) -and (@($p2Set | Where-Object { $_.Text -match '(?im)^\s*(SAPWD|SQLSVCPASSWORD|AGTSVCPASSWORD)\s*=' }).Count -eq 0))
        $p2BadRow = & $p2Row 'D' 14344 '' 'svc-with-no-domain' $script:SqlStackGuiAuthWindows
        $p2BadSpec = New-SqlStackGuiSpec -Plan @($p2BadRow) -Installed $w2Inst -HostName 'LAB01' -Edition 'Developer' -SysAdmin $w2Admins
        $p2BadIni = @(Get-SqlStackGuiFileSet -Plan @($p2BadRow) -Browser $p2Browser -HostName 'LAB01' -SysAdmin $w2Admins | Where-Object { $_.Kind -eq 'ini' })[0]
        Assert-True ("account: one that cannot be used is a spec PROBLEM ('{0}') and its ini is marked INCOMPLETE, never written as the built-in account" -f (@($p2BadSpec.Problems)[0])) `
            ((-not $p2BadSpec.Ok) -and ((@($p2BadSpec.Problems) -join ' ') -match 'engine account cannot be used') -and (-not $p2BadIni.Ok) -and ($p2BadIni.Text.StartsWith('; INCOMPLETE')))
        Assert-True 'save: the plan fingerprint moves when an account or the authentication changes' `
            (((Get-SqlStackGuiPlanFingerprint -Plan @((& $p2Row 'A' 14341 '' 'CONTOSO\x' $script:SqlStackGuiAuthWindows))) -cne (Get-SqlStackGuiPlanFingerprint -Plan @((& $p2Row 'A' 14341 '' 'CONTOSO\y' $script:SqlStackGuiAuthWindows)))) -and
             ((Get-SqlStackGuiPlanFingerprint -Plan @((& $p2Row 'A' 14341 '' 'CONTOSO\x' $script:SqlStackGuiAuthWindows))) -cne (Get-SqlStackGuiPlanFingerprint -Plan @((& $p2Row 'A' 14341 '' 'CONTOSO\x' $script:SqlStackGuiAuthMixed)))))

        Write-Host ''
        Write-Host '-- install loop: the Install screen''s own launch function, headless, on that plan, with a stand-in for setup (INV-5, INV-6, INV-7) --'
        $ilExport = Initialize-SqlStackGuiRunFolder -Root $ilRun -Item 'Export'
        $ilEnc = New-Object System.Text.UTF8Encoding($false)
        [IO.File]::WriteAllText((Join-Path $ilExport 'OLD1-install.ini'), 'left from an earlier plan', $ilEnc)
        [IO.File]::WriteAllText((Join-Path $ilExport 'notes.txt'), 'not a planner file', $ilEnc)
        $ilW = Write-SqlStackGuiFileSet -Folder $ilExport -FileSet $p2Set -ConfirmOverwrite { $true } -RemoveOthers
        Assert-True ("export: with -RemoveOthers the folder holds exactly this plan: {0} written, [{1}] from an earlier plan removed, a file that is not the planner's kept ({2})" -f @($ilW.Written).Count, (@($ilW.Removed) -join ', '), [IO.File]::Exists((Join-Path $ilExport 'notes.txt'))) `
            ((@($ilW.Written).Count -eq 6) -and ((@($ilW.Removed) -join ',') -ceq 'OLD1-install.ini') -and [IO.File]::Exists((Join-Path $ilExport 'notes.txt')) -and (@([IO.Directory]::GetFiles($ilExport, '*-install.ini')).Count -eq 3))
        $ilChoice0 = Read-SqlStackGuiInstallChoice -Root $ilRun
        # An updates folder (one .exe in it, a space in its name) for A; none for B and C.
        $ilUpd = Join-Path $p2Tmp 'updates 2022'
        [void](New-Item -ItemType Directory -Path $ilUpd -Force)
        [IO.File]::WriteAllText((Join-Path $ilUpd 'SQLServer2022-KB0000000-x64.exe'), 'not a real package', $ilEnc)
        $p2Plan[0].UpdatesPath = $ilUpd
        $p2Plan[1].UpdatesPath = (Join-Path $p2Tmp 'no such folder')
        $ilUpdFind = @(Get-SqlStackGuiUpdatesFinding -Plan $p2Plan)
        $ilUpdEmpty = Test-SqlStackGuiUpdatesFolder -Path $ilExport
        Assert-True ("updates: a folder with an .exe reads '{0}' with no warning; none reads '{1}'; a missing folder and one with no .exe are each ONE warning in words, never an error ({2} finding(s): '{3}'; '{4}')" -f (Test-SqlStackGuiUpdatesFolder -Path $ilUpd).Text, (Test-SqlStackGuiUpdatesFolder -Path '').Text, $ilUpdFind.Count, $(if ($ilUpdFind.Count) { $ilUpdFind[0].Message } else { '' }), $ilUpdEmpty.Warning) `
            (((Test-SqlStackGuiUpdatesFolder -Path $ilUpd).Text -ceq ('updates from ' + $ilUpd)) -and (-not (Test-SqlStackGuiUpdatesFolder -Path $ilUpd).Warning) -and ((Test-SqlStackGuiUpdatesFolder -Path '  ').Text -ceq 'no updates applied') -and
             ($ilUpdFind.Count -eq 1) -and ([string]$ilUpdFind[0].Severity -ceq 'WARN') -and ([string]$ilUpdFind[0].Message -match '^B: the updates folder does not exist') -and ($ilUpdEmpty.Warning -match 'holds no \.exe'))
        $p2Plan[1].UpdatesPath = ''
        $ilUpdMap = Get-SqlStackGuiUpdatesMap -Plan $p2Plan
        [void](Write-SqlStackGuiRunFile -Root $ilRun -Item 'Install' -Text (ConvertTo-Json ([ordered]@{ host = 'LAB01'; interfaceAlias = 'Ethernet 2'; prefixLength = 26; updates = $ilUpdMap }) -Depth 4))
        $ilChoice1 = Read-SqlStackGuiInstallChoice -Root $ilRun
        Assert-True ("updates: the folders are saved in install.json, not in the spec, and read back (map [{0}]; read back [{1}])" -f (@($ilUpdMap.Keys) -join ','), (@($ilChoice1.Updates.Keys) -join ',')) `
            (((@($ilUpdMap.Keys) -join ',') -ceq 'A') -and (@($ilChoice1.Updates.Keys).Count -eq 1) -and ([string]$ilChoice1.Updates['A'] -ceq $ilUpd) -and (-not ($p2Spec.Text -match 'updates')))
        Assert-True ("install choice: none saved reads as none ({0}, prefix {1}); the saved network card and prefix length read back ('{2}', {3}, host {4}, files {5})" -f $ilChoice0.Exists, $ilChoice0.PrefixLength, $ilChoice1.InterfaceAlias, $ilChoice1.PrefixLength, $ilChoice1.HostName, $ilChoice1.HasFiles) `
            ((-not $ilChoice0.Exists) -and ($ilChoice0.PrefixLength -eq 24) -and $ilChoice0.HasFiles -and $ilChoice1.Exists -and ($ilChoice1.InterfaceAlias -ceq 'Ethernet 2') -and ($ilChoice1.PrefixLength -eq 26) -and ($ilChoice1.HostName -ceq 'LAB01'))
        # 2026-11-23: the "Install anyway" tick box is saved in install.json and read back.
        [void](Write-SqlStackGuiRunFile -Root $ilRun -Item 'Install' -Text (ConvertTo-Json ([ordered]@{ host = 'LAB01'; interfaceAlias = 'Ethernet 2'; prefixLength = 26; ignorePendingRestart = $true; updates = $ilUpdMap }) -Depth 4))
        $ilChoice2 = Read-SqlStackGuiInstallChoice -Root $ilRun
        Assert-True ("pending restart: the tick box choice reads back from install.json ({0}); a file without it reads as unticked ({1})" -f $ilChoice2.IgnorePendingRestart, $ilChoice1.IgnorePendingRestart) `
            (($ilChoice2.IgnorePendingRestart -eq $true) -and ($ilChoice1.IgnorePendingRestart -eq $false) -and ([string]$ilChoice2.Updates['A'] -ceq $ilUpd))
        # The stand-in for setup.exe: it appends each argument it was started
        # with, as UTF-16 hex, to the file ARGV_OUT names, and exits 0.
        $ilExe = Join-Path $p2Tmp 'standin-setup.exe'
        Add-Type -OutputType ConsoleApplication -OutputAssembly $ilExe -TypeDefinition @'
using System; using System.IO; using System.Text;
public static class SqlStackGuiStandInSetup { public static int Main(string[] a) {
  var sb = new StringBuilder();
  foreach (var s in a) { foreach (char c in s) sb.Append(((int)c).ToString("X4")); sb.Append("\r\n"); }
  File.AppendAllText(Environment.GetEnvironmentVariable("ARGV_OUT"), sb.ToString()); return 0; } }
'@
        $ilArgv = Join-Path $p2Tmp 'argv-out.txt'
        $env:ARGV_OUT = $ilArgv
        $ilHex = { param([string]$s) (@($s.ToCharArray() | ForEach-Object { ([int]$_).ToString('X4') }) -join '') }
        $ilCard = [string]@([System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() | Where-Object { [string]$_.NetworkInterfaceType -eq 'Loopback' } | ForEach-Object { $_.Name })[0]
        # ---- the preview ----
        $ilPm = New-SqlStackGuiInstallModel
        $ilPw = Start-SqlStackGuiInstallWorker -RunFolder $ilRun -Mode 'Preview' -InterfaceAlias $ilCard -PrefixLength 24 -HarnessSetupExe $ilExe
        $ilPdone = Wait-SqlStackGuiWorker -Worker $ilPw -Model $ilPm -TimeoutSec 120
        $ilPw.Dispose()
        $ilRows = @(Get-SqlStackGuiInstallRows -Model $ilPm)
        $ilKinds = @($ilPm.Instances['A'].Steps | ForEach-Object { $_.Kind })
        Assert-True ("install loop: the preview (a hidden child, exit {0}) lists [{1}], each '{2}'; A will get [{3}]; the address {4} needs a network card; {5}; the stand-in was not started" -f $ilPm.ExitCode, (@($ilPm.Order) -join ', '), $ilRows[0].Word, ($ilKinds -join ', '), (@($ilPm.Addresses | ForEach-Object { $_.Ip }) -join ','), (Get-SqlStackGuiInstallNeedsText -Model $ilPm)) `
            ($ilPdone -and ($ilPm.ExitCode -eq 0) -and ((@($ilPm.Order) -join ',') -ceq 'A,B,C') -and (@($ilPm.Problems).Count -eq 0) -and (($ilKinds -join ',') -ceq 'address,install,edition,bind,sql,restart,check') -and
             ((@($ilPm.Addresses | ForEach-Object { $_.Ip }) -join ',') -ceq '10.20.30.41') -and ((@($ilPm.Needs | ForEach-Object { $_.Key }) -join '|') -ceq '#sa|CONTOSO\svc-sqla') -and (@($ilRows | Where-Object { $_.Word -ne 'will be installed' }).Count -eq 0) -and (-not [IO.File]::Exists($ilArgv)))
        $ilStepA = [string]@($ilPm.Instances['A'].Steps | Where-Object { $_.Kind -eq 'install' })[0].Text
        $ilStepB = [string]@($ilPm.Instances['B'].Steps | Where-Object { $_.Kind -eq 'install' })[0].Text
        Assert-True ("updates: the preview line for A reads 'updates from <folder>' and for B 'no updates applied' ('{0}')" -f $ilStepB) `
            ($ilStepA.Contains('updates from ' + $ilUpd) -and (-not $ilStepA.Contains('WARNING')) -and $ilStepB.Contains('no updates applied'))
        # 2026-11-23: the tick box reaches the worker as -IgnorePendingRestart, and setup's command line as /SKIPRULES.
        $ilIm = New-SqlStackGuiInstallModel
        $ilIw = Start-SqlStackGuiInstallWorker -RunFolder $ilRun -Mode 'Preview' -InterfaceAlias $ilCard -PrefixLength 24 -HarnessSetupExe $ilExe -IgnorePendingRestart $true
        $ilIdone = Wait-SqlStackGuiWorker -Worker $ilIw -Model $ilIm -TimeoutSec 120
        $ilIw.Dispose()
        $ilSkipOn = @($ilIm.Lines | Where-Object { ([string]$_).Contains('/SKIPRULES="RebootRequiredCheck"') }).Count
        $ilSkipOff = @($ilPm.Lines | Where-Object { ([string]$_).Contains('SKIPRULES') }).Count
        $ilAddr = [string]@($ilPm.Instances['A'].Steps | Where-Object { $_.Kind -eq 'address' })[0].Text
        Assert-True ("pending restart: ticked, every setup command line of the preview carries /SKIPRULES ({0} line(s)); unticked none ({1}); the address step starts with WARNING ('{2}')" -f $ilSkipOn, $ilSkipOff, $ilAddr) `
            ($ilIdone -and ($ilIm.ExitCode -eq 0) -and ($ilSkipOn -eq 3) -and ($ilSkipOff -eq 0) -and $ilAddr.StartsWith('WARNING: adds 10.20.30.41/24 to card') -and $ilAddr.EndsWith('On a client server add it by hand first.'))
        $ilActU = Get-SqlStackGuiInstallAction -IsElevated $false -Model $ilPm
        $ilActE = Get-SqlStackGuiInstallAction -IsElevated $true -Model $ilPm
        $ilActR = Get-SqlStackGuiInstallAction -IsElevated $true -Model $ilPm -Running $true
        $ilActS = Get-SqlStackGuiInstallAction -IsElevated $true -Model $ilPm -SaveProblem 'the plan has 2 errors'
        $ilActN = Get-SqlStackGuiInstallAction -IsElevated $true -Model (New-SqlStackGuiInstallModel)
        Assert-True ("install action (INV-6): not elevated = '{0}' ({1}); elevated = '{2}' ({3}); running, a plan that cannot be saved and no preview are each Off with the reason ({4}/{5}/{6})" -f $ilActU.Text, $ilActU.Kind, $ilActE.Text, $ilActE.Kind, $ilActR.Kind, $ilActS.Kind, $ilActN.Kind) `
            (($ilActU.Kind -ceq 'Elevate') -and ($ilActU.Text -ceq 'Restart as administrator to install') -and ($ilActE.Kind -ceq 'Install') -and ($ilActE.Text -ceq 'Install now') -and ($ilActR.Kind -ceq 'Off') -and ($ilActS.Kind -ceq 'Off') -and ($ilActS.Reason -match '2 errors') -and ($ilActN.Kind -ceq 'Off'))
        # ---- the install: passwords over standard input, state lines back ----
        $ilPwSa = 'sa pass word 1!'
        $ilPwSvc = 'ends in a backslash\'
        $ilSecrets = [ordered]@{ '#sa' = $ilPwSa; 'CONTOSO\svc-sqla' = $ilPwSvc }
        $ilM = New-SqlStackGuiInstallModel
        $ilWk = Start-SqlStackGuiInstallWorker -RunFolder $ilRun -Mode 'Install' -InterfaceAlias $ilCard -PrefixLength 24 -HarnessSetupExe $ilExe
        Send-SqlStackGuiWorkerSecrets -Worker $ilWk -Secrets $ilSecrets
        $ilDone = Wait-SqlStackGuiWorker -Worker $ilWk -Model $ilM -TimeoutSec 180
        $ilWk.Dispose()
        $ilGot = @(); if ([IO.File]::Exists($ilArgv)) { $ilGot = @([IO.File]::ReadAllLines($ilArgv)) }
        Assert-True ("install loop (INV-7): both passwords, one with spaces and one ending in a backslash, reached the stand-in byte for byte as /SAPWD and /SQLSVCPASSWORD ({0} argument(s) received)" -f $ilGot.Count) `
            ($ilDone -and ($ilGot -ccontains (& $ilHex ('/SAPWD=' + $ilPwSa))) -and ($ilGot -ccontains (& $ilHex ('/SQLSVCPASSWORD=' + $ilPwSvc))))
        Assert-True ("install loop: the state lines arrive in order [{0}]" -f (@($ilM.Trail) -join ' > ')) `
            ((@($ilM.Trail) -join '>') -ceq 'A:waiting>B:waiting>C:waiting>A:adding address>A:installing>A:failed')
        $ilOut = Get-SqlStackGuiInstallOutcome -Model $ilM -RunFolder $ilRun
        $ilRes = @($ilOut.Rows | ForEach-Object { '{0}={1}' -f $_.Name, $_.Result })
        Assert-True ("install loop: setup answered 0 for an instance that does not exist, and the result is a clear FAILURE, not done (exit {0}; {1}; next: '{2}')" -f $ilM.ExitCode, ($ilRes -join ' | '), $ilOut.Next) `
            (($ilM.ExitCode -eq 2) -and ($ilOut.Kind -ceq 'Failed') -and ([string]$ilOut.Rows[0].Result -match '^FAILED: setup returned 0 but A is not registered as installed') -and ([string]$ilOut.Rows[1].Result -ceq 'not run') -and ([string]$ilOut.Rows[2].Result -ceq 'not run') -and
             ($ilOut.Next -match '^Failed: ') -and ($ilOut.Next -match 'Summary\.txt') -and (@($ilOut.Rows | Where-Object { $_.Result -match '^done' }).Count -eq 0))
        $ilB64 = { param([string]$s) [Convert]::ToBase64String([Text.Encoding]::Unicode.GetBytes($s)) }
        $ilNeedles = @($ilPwSa, $ilPwSvc, (& $ilB64 $ilPwSa), (& $ilB64 $ilPwSvc))
        $ilLeaks = New-Object System.Collections.ArrayList
        foreach ($l in @($ilM.Lines)) { foreach ($nd in $ilNeedles) { if (([string]$l).Contains($nd)) { [void]$ilLeaks.Add('a worker line') } } }
        $ilFiles = @(Get-ChildItem -LiteralPath $ilRun -Recurse -File)
        foreach ($f in $ilFiles) {
            $fb = [IO.File]::ReadAllBytes($f.FullName)
            foreach ($nd in $ilNeedles) { foreach ($e in @([Text.Encoding]::UTF8, [Text.Encoding]::Unicode)) { if ($e.GetString($fb).Contains($nd)) { [void]$ilLeaks.Add($f.Name) } } }
        }
        $ilLogs = @($ilFiles | Where-Object { $_.Name -like 'install-log-*.txt' })
        Assert-True ("install loop (INV-7): no password, plain or base64, is in any of the {0} line(s) the worker sent (state lines and log lines) or in any of the {1} file(s) under the run folder, its own log included ({2} log; {3} hit(s))" -f @($ilM.Lines).Count, $ilFiles.Count, $ilLogs.Count, $ilLeaks.Count) `
            (($ilLeaks.Count -eq 0) -and ($ilLogs.Count -eq 1) -and (@($ilM.Lines).Count -ge 10) -and ([string]$ilM.LogPath -ceq $ilLogs[0].FullName))
        Assert-True 'updates: the stand-in received /UPDATEENABLED=True and /UPDATESOURCE=<the folder>, and the first run was quiet (/Q, the first ini)' `
            (($ilGot -ccontains (& $ilHex '/UPDATEENABLED=True')) -and ($ilGot -ccontains (& $ilHex ('/UPDATESOURCE=' + $ilUpd))) -and ($ilGot -ccontains (& $ilHex '/Q')) -and ($ilGot -ccontains (& $ilHex ('/ConfigurationFile=' + (Join-Path $ilExport 'A-install.ini')))))
        # ---- every password is optional: sa left blank = setup's own window for A ----
        Remove-Item -LiteralPath $ilArgv -Force -ErrorAction SilentlyContinue
        $ilTyped = Select-SqlStackGuiTypedSecrets -Secrets ([ordered]@{ '#sa' = ''; 'CONTOSO\svc-sqla' = $ilPwSvc })
        $ilM2 = New-SqlStackGuiInstallModel
        $ilWk2 = Start-SqlStackGuiInstallWorker -RunFolder $ilRun -Mode 'Install' -InterfaceAlias $ilCard -PrefixLength 24 -HarnessSetupExe $ilExe
        Send-SqlStackGuiWorkerSecrets -Worker $ilWk2 -Secrets $ilTyped
        $ilDone2 = Wait-SqlStackGuiWorker -Worker $ilWk2 -Model $ilM2 -TimeoutSec 180
        $ilWk2.Dispose()
        $ilGot2 = @(); if ([IO.File]::Exists($ilArgv)) { $ilGot2 = @([IO.File]::ReadAllLines($ilArgv)) }
        $ilWinIni = Join-Path $ilExport 'A-install-window.ini'
        Assert-True ("optional passwords: sa left blank is not sent ([{0}] sent); the stand-in got NO /SAPWD and no /Q, ran on A-install-window.ini (QUIET off), still got the typed service password, and A's state read '{1}'" -f (@($ilTyped.Keys) -join ','), (@($ilM2.Trail | Where-Object { $_ -match 'setup window' }) -join '')) `
            ($ilDone2 -and ((@($ilTyped.Keys) -join ',') -ceq 'CONTOSO\svc-sqla') -and (@($ilGot2 | Where-Object { $_.StartsWith((& $ilHex '/SAPWD')) }).Count -eq 0) -and ($ilGot2 -cnotcontains (& $ilHex '/Q')) -and
             ($ilGot2 -ccontains (& $ilHex ('/ConfigurationFile=' + $ilWinIni))) -and ($ilGot2 -ccontains (& $ilHex ('/SQLSVCPASSWORD=' + $ilPwSvc))) -and
             (@($ilM2.Trail) -ccontains 'A:waiting for you in the SQL Server setup window') -and ([IO.File]::ReadAllText($ilWinIni) -match '(?m)^QUIET="False"') -and ([IO.File]::ReadAllText((Join-Path $ilExport 'A-install.ini')) -match '(?m)^QUIET="True"'))
        # ---- the restart of Windows: the worker's restart mode under the TEST HARNESS (nothing is registered, nothing restarts) ----
        $ilRm = New-SqlStackGuiInstallModel
        $ilRw = Start-SqlStackGuiInstallWorker -RunFolder $ilRun -Mode 'Restart' -ResumeArguments '-NoProfile -File "C:\a b\SqlStack.ps1" -OpenInstall' -HarnessSetupExe $ilExe
        $ilRw.CloseInput()
        $ilRdone = Wait-SqlStackGuiWorker -Worker $ilRw -Model $ilRm -TimeoutSec 120
        $ilRw.Dispose()
        Assert-True ("restart: the worker's restart mode, started by the window's one launch function under the test harness, ends {0} and says no task was registered and Windows was not restarted ('{1}')" -f $ilRm.ExitCode, $ilRm.EndText) `
            ($ilRdone -and ($ilRm.ExitCode -eq 0) -and (@($ilRm.Lines | Where-Object { $_ -match 'TEST HARNESS: no task is registered' }).Count -eq 1) -and (@($ilRm.Lines | Where-Object { $_ -match 'TEST HARNESS: Windows is NOT restarted' }).Count -eq 1) -and ($ilRm.EndText -match 'SqlStack opens again'))
    } finally {
        Remove-Item Env:\ARGV_OUT -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $p2Tmp -Recurse -Force -ErrorAction SilentlyContinue
    }
    # The outcome, from lines alone (no process): reboot, done, and a worker
    # that ended 0 without every instance done.
    $ocM = { param([string[]]$Lines, [int]$Code) $m = New-SqlStackGuiInstallModel; foreach ($l in $Lines) { Update-SqlStackGuiInstallModel -Model $m -Line $l }; $m.Finished = $true; $m.ExitCode = $Code; $m }
    $ocReboot = Get-SqlStackGuiInstallOutcome -RunFolder 'C:\temp\run 1' -Model (& $ocM @("@@INSTANCE`tA`tnew", "@@INSTANCE`tB`tnew", "@@STATE`tA`twaiting", "@@STATE`tB`twaiting", "@@STATE`tA`tinstalling", "@@STATE`tA`treboot needed`tsetup asked", "@@END`t3`tsetup asked for a restart") 3)
    $ocDone = Get-SqlStackGuiInstallOutcome -Model (& $ocM @("@@INSTANCE`tA`tnew", "@@STATE`tA`tinstalling", "@@STATE`tA`tdone`tlogin OK", "@@END`t0`tdone") 0)
    $ocHalf = Get-SqlStackGuiInstallOutcome -Model (& $ocM @("@@INSTANCE`tA`tnew", "@@INSTANCE`tB`tnew", "@@STATE`tA`tdone", "@@STATE`tB`tinstalling", "@@END`t0`tdone") 0)
    Assert-True ("outcome: reboot needed says to restart Windows, open the same run folder and press Install again ('{0}'); done is done; exit 0 with an instance not done is a failure ({1}/{2}/{3})" -f $ocReboot.Next, $ocReboot.Kind, $ocDone.Kind, $ocHalf.Kind) `
        (($ocReboot.Kind -ceq 'Reboot') -and ($ocReboot.Next -match 'restart Windows') -and ($ocReboot.Next -match [regex]::Escape('C:\temp\run 1')) -and ($ocReboot.Next -match 'press Install again') -and ([string]$ocReboot.Rows[1].Result -ceq 'not run') -and
         ($ocDone.Kind -ceq 'Done') -and ($ocDone.Next -match '^Done\.') -and ($ocHalf.Kind -ceq 'Failed') -and ([string]$ocHalf.Rows[1].Result -ceq 'stopped while installing'))
    # The restart of Windows, with fakes: the confirm names the machine, and
    # the worker runs ONLY after a yes. Nothing is registered, nothing restarts.
    $rsLog = New-Object System.Collections.ArrayList
    $rsOk = { param($r) [void]$rsLog.Add('worker:' + $r); $m = New-SqlStackGuiInstallModel; $m.Finished = $true; $m.ExitCode = 0; $m }
    $rsBad = { param($r) [void]$rsLog.Add('worker:' + $r); $m = New-SqlStackGuiInstallModel; Update-SqlStackGuiInstallModel -Model $m -Line "@@END`t2`tthe task could not be registered"; $m.Finished = $true; $m.ExitCode = 2; $m }
    $rsNo = Invoke-SqlStackGuiWindowsRestart -MachineName 'LAB01' -Resume $true -Confirm { param($q) [void]$rsLog.Add('asked:' + $q); $false } -RunWorker $rsOk
    $rsAsked = [string]$rsLog[0]; $rsAfterNo = $rsLog.Count; $rsLog.Clear()
    $rsYes = Invoke-SqlStackGuiWindowsRestart -MachineName 'LAB01' -Resume $true -Confirm { param($q) [void]$rsLog.Add('asked'); $true } -RunWorker $rsOk
    $rsOrder = ($rsLog -join ','); $rsLog.Clear()
    $rsPlain = Invoke-SqlStackGuiWindowsRestart -MachineName 'LAB01' -Resume $false -Confirm { param($q) $true } -RunWorker $rsOk
    $rsFail = Invoke-SqlStackGuiWindowsRestart -MachineName 'LAB01' -Resume $true -Confirm { param($q) $true } -RunWorker $rsBad
    $rsThrow = Invoke-SqlStackGuiWindowsRestart -MachineName 'LAB01' -Resume $true -Confirm { param($q) $true } -RunWorker { param($r) throw 'no worker' }
    Assert-True ("restart: ONE confirm that names the machine; a no starts nothing ({0}: '{1}'); a yes runs the worker after the question [{2}]; a worker that fails or cannot start is said ({3}: '{4}' / {5})" -f $rsNo.Kind, $rsNo.Text, $rsOrder, $rsFail.Kind, $rsFail.Text, $rsThrow.Kind) `
        (($rsNo.Kind -ceq 'Declined') -and ($rsAfterNo -eq 1) -and ($rsAsked -match 'Restart Windows on LAB01 now\?') -and ($rsAsked -match 'none is stored') -and ($rsOrder -ceq 'asked,worker:True') -and ($rsYes.Kind -ceq 'Restarting') -and ($rsYes.Text -match 'opens again') -and
         ($rsPlain.Kind -ceq 'Restarting') -and ($rsPlain.Text -ceq 'Windows is restarting.') -and ($rsFail.Kind -ceq 'Failed') -and ($rsFail.Text -match 'the task could not be registered') -and ($rsThrow.Kind -ceq 'Failed') -and ($rsThrow.Text -match 'no worker'))
    $pdM = New-SqlStackGuiInstallModel
    Update-SqlStackGuiInstallModel -Model $pdM -Line "@@PENDING`tWindows Update, pending file renames"
    Assert-True ("restart: the worker's pending-restart line reaches the model ('{0}'), and a preview without one leaves it empty" -f $pdM.Pending) (($pdM.Pending -ceq 'Windows Update, pending file renames') -and ((New-SqlStackGuiInstallModel).Pending -ceq ''))
    # 2026-11-23 (the real-path review): the pending line, the new end states, a crash, elevation from a network drive, the language mode.
    $pdOff = Get-SqlStackGuiPendingText -Pending 'Windows Update' -Ignore $false
    $pdOn = Get-SqlStackGuiPendingText -Pending 'Windows Update' -Ignore $true
    Assert-True ("pending restart: unticked the first line says setup will very likely refuse ('{0}'); ticked it says setup ignores it; none pending is empty" -f $pdOff) `
        ($pdOff.EndsWith('Setup will very likely refuse to start until Windows is restarted.') -and $pdOn.EndsWith('Setup will be told to ignore it.') -and ((Get-SqlStackGuiPendingText -Pending '' -Ignore $true) -eq ''))
    $ocAtt = Get-SqlStackGuiInstallOutcome -Model (& $ocM @("@@INSTANCE`tA`tnew", "@@INSTANCE`tB`tattention", "@@STATE`tA`tdone`tlogin OK", "@@STATE`tB`tneeds attention`tsetup failed last time (exit 1)", "@@END`t2`tB needs attention: setup failed last time (exit 1)") 2)
    $ocChk = Get-SqlStackGuiInstallOutcome -Model (& $ocM @("@@INSTANCE`tA`tnew", "@@STATE`tA`tinstalled, check failed`tSQL Server is installed. The login test over 127.0.0.1,14341 did not answer.", "@@END`t4`ta connection check failed for A") 4)
    $ocNoEnd = Get-SqlStackGuiInstallOutcome -Model (& $ocM @("@@INSTANCE`tA`tnew", "@@STATE`tA`tinstalling") 1)
    $ocTrap = Get-SqlStackGuiInstallOutcome -Model (& $ocM @("@@INSTANCE`tA`tnew", "@@END`t2`tunexpected error, the run stopped part way: boom") 2)
    $ocAll = @($ocAtt, $ocChk, $ocNoEnd, $ocTrap)
    Assert-True ("outcome: needs attention ('{0}') and installed, check failed ('{1}') are never Done and never say every instance is installed; no END line, or the trap's END, reads 'stopped part way' ('{2}'), never 'nothing was changed'" -f $ocAtt.Rows[1].Result, $ocChk.Rows[0].Result, $ocNoEnd.Next) `
        ((@($ocAll | Where-Object { $_.Kind -ceq 'Done' }).Count -eq 0) -and (@($ocAll | Where-Object { $_.Next -match 'Every instance is installed' }).Count -eq 0) -and
         ([string]$ocAtt.Rows[1].Result).StartsWith('NEEDS ATTENTION') -and ([string]$ocChk.Rows[0].Result).StartsWith('installed, check failed: SQL Server is installed') -and
         $ocNoEnd.Next.StartsWith('The run stopped part way. Something may already be changed: read the log before pressing Install again.') -and $ocTrap.Next.StartsWith('The run stopped part way.') -and
         (@($ocAll | Where-Object { $_.Next -match '(?i)nothing was changed' }).Count -eq 0) -and ((Get-SqlStackGuiInstallStateWord -State 'needs attention').Color -ceq 'Error') -and ((Get-SqlStackGuiInstallStateWord -State 'installed, check failed').Word -ceq 'installed, check failed'))
    $npFake = { param($r) if ($r -eq 'Z:\') { 'Network' } else { 'Fixed' } }
    Assert-True 'elevation: a UNC path and a mapped (Network) drive are network paths; a local fixed drive is not' `
        ((Test-SqlStackGuiNetworkPath -Path '\\srv\share\SqlStack' -DriveType $npFake) -and (Test-SqlStackGuiNetworkPath -Path 'Z:\SqlStack\run 1' -DriveType $npFake) -and (-not (Test-SqlStackGuiNetworkPath -Path 'C:\temp\SqlStack' -DriveType $npFake)) -and (-not (Test-SqlStackGuiNetworkPath -Path '' -DriveType $npFake)))
    Assert-True ("language mode: FullLanguage runs; ConstrainedLanguage stops with one message ('{0}')" -f (Get-SqlStackGuiLanguageStop -Mode 'ConstrainedLanguage')) `
        (((Get-SqlStackGuiLanguageStop -Mode 'FullLanguage') -eq '') -and ((Get-SqlStackGuiLanguageStop -Mode 'ConstrainedLanguage') -match '^SqlStack cannot run on this machine: PowerShell runs in ConstrainedLanguage'))
    $elArgs = Get-SqlStackGuiElevatedArguments -ScriptPath 'C:\Sql Stack app\SqlStack\SqlStack.ps1' -RunFolder 'C:\temp\SqlStack\runs\LAB01-1\' -Advanced $true
    Assert-True ("elevated restart: this script, quoted when its path has a space, the same run folder, straight onto Install ('{0}')" -f $elArgs) `
        ($elArgs -ceq '-NoProfile -ExecutionPolicy Bypass -STA -File "C:\Sql Stack app\SqlStack\SqlStack.ps1" -RunFolder C:\temp\SqlStack\runs\LAB01-1 -OpenInstall -Advanced')
    $slLine = ConvertTo-SqlStackGuiSecretLine -Key '#sa' -Password ('p w' + [char]0x00E9 + '\')
    $slParts = @($slLine -split ' ')
    Assert-True ("secret line (INV-7): two base64 fields of plain ASCII that decode to the name and the password exactly ({0} field(s))" -f $slParts.Count) `
        (($slParts.Count -eq 2) -and ($slLine -cmatch '^[A-Za-z0-9+/= ]+$') -and ([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($slParts[0])) -ceq '#sa') -and ([Text.Encoding]::Unicode.GetString([Convert]::FromBase64String($slParts[1])) -ceq ('p w' + [char]0x00E9 + '\')))
    Assert-True ("password: empty, a double quote and a control character are each refused in plain words; spaces and a trailing backslash are fine ('{0}')" -f (Get-SqlStackGuiPasswordProblem -Text 'a"b')) `
        ((Get-SqlStackGuiPasswordProblem -Text '') -and (Get-SqlStackGuiPasswordProblem -Text 'a"b') -and (Get-SqlStackGuiPasswordProblem -Text ('a' + [char]9 + 'b')) -and (-not (Get-SqlStackGuiPasswordProblem -Text 'a b\')))
    Assert-True ("process argument: plain stays bare, a space is quoted, a trailing backslash inside quotes is doubled, a double quote is refused ({0} | {1} | {2})" -f (ConvertTo-SqlStackGuiProcessArg 'C:\a\b.ps1'), (ConvertTo-SqlStackGuiProcessArg 'Ethernet 2'), (ConvertTo-SqlStackGuiProcessArg 'C:\a b\')) `
        (((ConvertTo-SqlStackGuiProcessArg 'C:\a\b.ps1') -ceq 'C:\a\b.ps1') -and ((ConvertTo-SqlStackGuiProcessArg 'Ethernet 2') -ceq '"Ethernet 2"') -and ((ConvertTo-SqlStackGuiProcessArg 'C:\a b\') -ceq '"C:\a b\\"') -and ($(try { [void](ConvertTo-SqlStackGuiProcessArg 'a"b'); $false } catch { $true })))

    Write-Host ''
    Write-Host '-- shared data fixtures (the ONE body, in the engine; this script is a CALLER) --'
    # Invariant, and it is a SET: every entry point that dot-sources the engine
    # runs THE SAME fixture body, and that body exists in exactly one file. The
    # engine's -SelfTest enumerates the entry points from the code and goes red
    # for any one of them that does not make this call, so the rule cannot be
    # satisfied by a list. Running them from HERE also proves the dot-source
    # really handed this process the loader, observed, plan and hash surface -
    # a claim no assertion in the engine's own process can make for this one.
    $guiFx = Invoke-SqlStackDataFixtures -Assert { param($fxName, $fxCond) Assert-True -Name $fxName -Cond $fxCond }
    Assert-True ("data fixtures: own counters {0} passed / {1} failed / {2} skipped" -f `
            $guiFx.Passed, $guiFx.Failed, $guiFx.Skipped) ($guiFx.Failed -eq 0)

    Write-Host ''
    Write-Host ("RESULT: {0} passed, {1} failed" -f $script:passes, $script:fails)
    if ($script:fails -gt 0) { exit 1 }
    exit 0
}

# ===========================================================================
# ===========================================================================
#  GUI
# ===========================================================================
# ===========================================================================

# DPI. WinForms under PS 5.1 is not DPI aware by default, which makes every
# control blurry and mis-sized on a 4K display. SetProcessDPIAware must be
# called BEFORE the first form is created.
if (-not ('SqlStackDpi' -as [type])) {
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class SqlStackDpi {
    [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
}
'@ -ErrorAction SilentlyContinue
}
try { [void][SqlStackDpi]::SetProcessDPIAware() } catch { }

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

# From the snapshot taken before the engine dot-source, not from $PortBase.
$script:PortBaseInUse = $script:EntryArgs['PortBase']

# ---- host facts, gathered once ----
$script:IsElevated = Test-IsElevated
$script:Volumes = @()
$script:PhysicalMb = 0
$script:LogicalCores = 0
$script:ExcludedRanges = @()
$script:PortsInUse = @()
$script:Instances = @()
$script:Plan = New-Object System.Collections.ArrayList
# The generated file set: $null until Generate runs, exactly as before these
# two lines existed (the Save handler's own tests are unchanged). Set here, at
# the top level, because a FUNCTION now reads them (Update-SqlStackGuiActions)
# and the engine's library-scope census requires a function's script
# variables to be assigned where a load can see them.
$script:LastFileSet = $null
$script:LastFileSetFingerprint = $null

function Update-HostFacts {
    $cs = Get-CimInstance -ClassName Win32_ComputerSystem
    $script:PhysicalMb = [int][math]::Round($cs.TotalPhysicalMemory/1MB)
    $script:LogicalCores = [int]$cs.NumberOfLogicalProcessors

    $vols = $null
    try {
        $vols = Get-Volume -ErrorAction Stop | Where-Object { $_.DriveLetter } | ForEach-Object {
            [pscustomobject]@{
                DriveLetter = [string]$_.DriveLetter
                Label       = [string]$_.FileSystemLabel
                FileSystem  = [string]$_.FileSystem
                SizeGB      = [math]::Round($_.Size/1GB,1)
                FreeGB      = [math]::Round($_.SizeRemaining/1GB,1)
                AllocationUnitSize = [int]$_.AllocationUnitSize
            } }
    } catch {
        $vols = Get-CimInstance -ClassName Win32_Volume | Where-Object { $_.DriveLetter } | ForEach-Object {
            [pscustomobject]@{
                DriveLetter = ([string]$_.DriveLetter).TrimEnd(':')
                Label       = [string]$_.Label
                FileSystem  = [string]$_.FileSystem
                SizeGB      = [math]::Round($_.Capacity/1GB,1)
                FreeGB      = [math]::Round($_.FreeSpace/1GB,1)
                AllocationUnitSize = [int]$_.BlockSize
            } }
    }
    $script:Volumes = @($vols | Sort-Object DriveLetter)

    # [object[]], NOT @(): both of these functions return ',$array', so @() wraps
    # the array a SECOND time and the result is a ONE-element array holding it -
    # .Count reads 1 however many rows came back and foreach iterates once over
    # the whole array (PROVED 2026-09-17, C1-C4 of fix-round2/probe-shape.log).
    # $script:Instances is read by .Count at the two status labels and by foreach
    # in the two import loops, so the wrap was live, not cosmetic.
    $script:ExcludedRanges = [object[]](ConvertFrom-NetshExcludedPortRange -Lines (netsh int ipv4 show excludedportrange protocol=tcp))
    $script:PortsInUse = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | ForEach-Object { [int]$_.LocalPort } | Sort-Object -Unique)
    $script:Instances = [object[]](Get-SqlInstanceInventory)
    # The SECOND real call site for KnownInstancePorts (the collector body is the
    # first). Built from the same registry rule via the same shared function, so
    # the idempotency carve-out and the fixed-port pin cannot drift apart.
    $portMap = Get-KnownInstancePortMap -Instances $script:Instances
    $script:KnownInstancePorts = $portMap.Map
    $script:ObservedInstancePorts = $portMap.Fixed

    # D5 (lane sqlstack-gui-glowup): the Instances grid shows TCP from the
    # ENGINE's facts, never from a registry read of this window's own. The port
    # is the port map above (the object the planner gets); the protocol switch,
    # which the map does not carry, comes from the engine's own
    # net-tcp-registry probe body, run here read-only per instance.
    $script:TcpReads = @{}
    $probeReg = Get-ProbeRegistry
    $tcpProbe = @($probeReg | Where-Object { $_.Id -eq 'net-tcp-registry' })
    foreach ($i in $script:Instances) {
        $st = [pscustomobject]@{ Read = $false; Row = $null; Reason = '' }
        if ($tcpProbe.Count -ne 1) { $st.Reason = ('the engine has {0} net-tcp-registry probe(s), not 1' -f $tcpProbe.Count) }
        else {
            try {
                $got = @(& $tcpProbe[0].Script ([pscustomobject]@{ Instance = $i }))
                $st.Read = $true
                if ($got.Count -ge 1) { $st.Row = $got[0] }
            } catch { $st.Reason = ('{0}: {1}' -f $_.Exception.GetType().Name, $_.Exception.Message) }
        }
        $script:TcpReads[[string]$i.Name] = $st
    }

    # D2(ii) (lane sqlstack-gui-glowup): SQL Browser is SHARED host state. The
    # ini keeps its CURRENT start mode, so running setup never changes it by
    # default: read here through the engine's own inst-browser-service probe
    # body (read-only) and mapped by the engine's SPEC.md 4.2 table.
    $when = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz')
    $bProbe = @($probeReg | Where-Object { $_.Id -eq 'inst-browser-service' })
    if ($bProbe.Count -ne 1) {
        $script:BrowserRead = ConvertTo-SqlStackGuiBrowser -Failed -Reason ('the engine has {0} inst-browser-service probe(s), not 1' -f $bProbe.Count) -When $when
    } else {
        try { $script:BrowserRead = ConvertTo-SqlStackGuiBrowser -Rows @(& $bProbe[0].Script $null) -When $when }
        catch { $script:BrowserRead = ConvertTo-SqlStackGuiBrowser -Failed -Reason ('{0}: {1}' -f $_.Exception.GetType().Name, $_.Exception.Message) -When $when }
    }

    # INV-4 / S6: this host's addresses, from the ENGINE's one local-address
    # reader, which only reads ('host IPs (INV-4, K10):' in -SelfTest). A failed
    # read is its own sentinel row, shown as 'could not read'.
    $script:HostIps = @(Get-SqlStackLocalIpAddress)
}

function New-PlanRowFromName {
    # A NEW instance with this host's suggested folders, through the ONE row
    # shape (New-SqlStackGuiPlanRow, which says what every field means).
    param([string]$Name, [int]$Ordinal)
    $paths = Get-SuggestedInstancePaths -InstanceName $Name `
        -DataDrive $script:DefaultDataDrive -LogDrive $script:DefaultLogDrive `
        -TempDbDrive $script:DefaultTempDrive -BackupDrive $script:DefaultBackupDrive
    return (New-SqlStackGuiPlanRow -Name $Name -Ordinal $Ordinal -DataPath $paths.Data -LogPath $paths.Log -TempDbPath $paths.TempDb -BackupPath $paths.Backup `
                -TempDbFileCount (Get-TempDbFileCount -LogicalCores $script:LogicalCores) -TempDbFileSizeMb 1024)
}

function Update-ComputedPlan {
    # Recompute ports and memory across the whole plan, then push into CLAIMANT
    # rows. A row with Fixed = $true is an instance that ALREADY EXISTS on the
    # host (built by New-PlanRowFromInstalled): a CONSTRAINT, never a claimant,
    # never written back. The logic is the pure Invoke-SqlStackGuiPlanUpdate
    # (lane sqlstack-gui-glowup, D1/D4), which -SelfTest runs at runtime; this
    # wrapper hands it the host facts and KEEPS the computation for the Plan
    # tab's Arithmetic box instead of discarding it.
    $inPlan = @($script:Plan | ForEach-Object { [string]$_.Name })
    $notIn = [string[]]@(@($script:Instances) | Where-Object { $inPlan -notcontains [string]$_.Name } | ForEach-Object { [string]$_.Name })
    $script:Computation = Invoke-SqlStackGuiPlanUpdate -Plan $script:Plan.ToArray() -PhysicalMb $script:PhysicalMb -LogicalCores $script:LogicalCores `
        -PortBase $script:PortBaseInUse -ExcludedRanges $script:ExcludedRanges -PortsInUse $script:PortsInUse `
        -KnownInstancePorts $(if ($script:KnownInstancePorts) { $script:KnownInstancePorts } else { @{} }) -InstalledNotInPlan $notIn
}

# ---- pick sensible default drives: biggest free volumes that are not C: ----
function Set-DefaultDrives {
    $cand = @($script:Volumes | Where-Object { $_.DriveLetter -ne 'C' } | Sort-Object FreeGB -Descending)
    $fallback = if ($script:Volumes.Count -gt 0) { $script:Volumes[0].DriveLetter } else { 'C' }
    $pick = { param($i) if ($cand.Count -gt $i) { $cand[$i].DriveLetter } elseif ($cand.Count -gt 0) { $cand[0].DriveLetter } else { $fallback } }
    $script:DefaultDataDrive   = (& $pick 0)
    $script:DefaultLogDrive    = (& $pick 1)
    $script:DefaultTempDrive   = (& $pick 2)
    $script:DefaultBackupDrive = (& $pick 3)
}

Update-HostFacts
Set-DefaultDrives

# ---- the workbench's run folder and state folder (lane sqlstack-workbench) ----
# From the ENTRY-ARGS snapshot, never the raw parameters (the engine dot-source
# can rebind a shared name). The state folder is the engine's ONE host-wide
# folder unless -StatePath names another (critic K3).
$script:WbToolDir = $PSScriptRoot
$script:WbStatePath = $(if ([string]::IsNullOrWhiteSpace([string]$script:EntryArgs['StatePath'])) { [string]$script:SqlStackDefaultStatePath } else { [IO.Path]::GetFullPath([string]$script:EntryArgs['StatePath']).TrimEnd('\') })
$script:WbRoot = $(if ([string]::IsNullOrWhiteSpace([string]$script:EntryArgs['RunFolder'])) { Get-SqlStackGuiDefaultRunFolder -HostName $env:COMPUTERNAME -Now (Get-Date) } else { [IO.Path]::GetFullPath([string]$script:EntryArgs['RunFolder']).TrimEnd('\') })
# K6: the trace log follows the run folder unless the operator named one (or 'none').
$script:WbLogFollowsRun = ([string]::IsNullOrWhiteSpace([string]$script:EntryArgs['LogPath']) -and $script:LogEnabled)
$script:WbMapRoot = ''
$script:WbSysAdmin = Get-SqlStackGuiSysAdmin
$script:WbReadOnly = $false
$script:WbReadOnlyReason = ''
$script:WbState = $null
$script:WbSelectedStage = 1
$script:WbRailUpdating = $false
$script:WbCompareText = ''
$script:WbCeilings = $null
$script:Loading = $false
# ---- the Install screen (2026-11-16) ----
# -Advanced: the older stages and the paste-a-command drawer. Without it the
# rail is Host, Plan, Install.
$script:WbAdvanced = [bool]$script:EntryArgs['Advanced']
$script:InstallModel = New-SqlStackGuiInstallModel   # what the grid shows: the last preview, or the run
$script:InstallPreview = $script:InstallModel         # the last PREVIEW: what the Install button is decided from
$script:InstallSave = $null                          # the last Save-SqlStackGuiPlanFiles result
$script:InstallWorker = $null                        # the running worker, while an install runs
$script:InstallRunning = $false
$script:InstallOutcome = $null                       # the last finished install's Get-SqlStackGuiInstallOutcome
$script:InstallUiLoading = $false
$script:InstallNicLoaded = $false                    # the Install screen has loaded the network cards into its controls
$script:InstallRebootLater = $false                  # "Continue later" was pressed after a reboot-needed result
$script:AccountNote = $null

# ===========================================================================
# The look (lane sqlstack-gui-glowup, stage 2): a calm Windows 11 palette, and
# a layout that is legible at every display scale.
#
# SCALING, AT THE ROOT. The form declares the DPI its pixel constants were
# written for ONCE, AFTER every control is in its tree: AutoScaleDimensions
# 96x96 first, then AutoScaleMode Dpi, so WinForms scales every constant in ONE
# pass, by (display DPI / 96). Both orders and both timings matter, and both
# were PROVED on this box on 2026-10-01: declared before the tree is built,
# the pass is left pending and every child ResumeLayout re-runs it on
# controls that re-arm their own scaling (each number box's margin and
# minimum width were scaled nine times: a 120px box became 4,617px); with the
# mode set first, the mode's own pass runs at factor 1, uses up every
# control's pending scaling, and the design DPI then scales nothing. Until
# 2026-10-01 the form set AutoScaleMode Dpi WITHOUT AutoScaleDimensions, so no
# constant ever scaled (the form stayed 1180x800 at 144 DPI) while every font
# grew: the host facts ran past a 58px header and grid headers that needed
# 25px got 19 (the lane's brief critic PROVED 56 clipped controls at 150%).
# Text-bearing controls get NO constant pixel height: labels and buttons
# AutoSize, table rows are AutoSize or Percent, grid headers and rows size
# from their fonts. Pixels needed AFTER the scaling pass (cell paddings, tab
# padding) come from ConvertTo-SqlStackGuiPx, which reads a FONT's height,
# and a font's height already follows the DPI.
# Guarded by rows G1-G4 of Test-SqlStackGuiStructure in -SelfTest; measured
# at runtime by the lane's census harness at 100/150/200%.
# ===========================================================================
function New-SqlStackGuiColor { param([int]$Rgb) return [System.Drawing.Color]::FromArgb(255, (($Rgb -shr 16) -band 255), (($Rgb -shr 8) -band 255), ($Rgb -band 255)) }
$script:Ui = @{
    Window       = (New-SqlStackGuiColor 0xF3F3F3)
    Card         = (New-SqlStackGuiColor 0xFFFFFF)
    Border       = (New-SqlStackGuiColor 0xE5E5E5)
    Text         = (New-SqlStackGuiColor 0x1B1B1B)
    Secondary    = (New-SqlStackGuiColor 0x5F5F5F)
    Accent       = (New-SqlStackGuiColor 0x0067C0)
    AccentHover  = (New-SqlStackGuiColor 0x1975C5)
    AccentDown   = (New-SqlStackGuiColor 0x005BA8)
    ButtonBorder = (New-SqlStackGuiColor 0xD1D1D1)
    ButtonHover  = (New-SqlStackGuiColor 0xF6F6F6)
    ButtonDown   = (New-SqlStackGuiColor 0xF0F0F0)
    Disabled     = (New-SqlStackGuiColor 0xF5F5F5)
    DisabledText = (New-SqlStackGuiColor 0x9E9E9E)
    Chip         = (New-SqlStackGuiColor 0xF3F3F3)
    Selection    = (New-SqlStackGuiColor 0xE5F1FB)
    AltRow       = (New-SqlStackGuiColor 0xFAFAFA)
    Error        = (New-SqlStackGuiColor 0xC42B1C)
    Warning      = (New-SqlStackGuiColor 0x9D5D00)
    WarningBack  = (New-SqlStackGuiColor 0xFFF4CE)
    Info         = (New-SqlStackGuiColor 0x005FB8)
    Ok           = (New-SqlStackGuiColor 0x0F7B0F)
}

function Get-SqlStackGuiInstalledFamily {
    # The first of -Names that is installed. GDI+ silently substitutes another
    # face for a missing family, so the name is checked, never assumed.
    param([string[]]$Names)
    $have = @((New-Object System.Drawing.Text.InstalledFontCollection).Families | ForEach-Object { $_.Name })
    foreach ($n in $Names) { if ($have -contains $n) { return $n } }
    return $null
}
$semiFamily = Get-SqlStackGuiInstalledFamily -Names @('Segoe UI Semibold')
$monoFamily = Get-SqlStackGuiInstalledFamily -Names @('Cascadia Mono', 'Consolas')
if (-not $monoFamily) { $monoFamily = 'Courier New' }
$newSemibold = {
    param([single]$Pt)
    if ($semiFamily) { return (New-Object System.Drawing.Font($semiFamily, $Pt)) }
    return (New-Object System.Drawing.Font('Segoe UI', $Pt, [System.Drawing.FontStyle]::Bold))
}
$script:UiFont = @{
    Body    = (New-Object System.Drawing.Font('Segoe UI', 9))
    Strong  = (& $newSemibold 9)
    Section = (& $newSemibold 10.5)
    Host    = (& $newSemibold 16)
    Mono    = (New-Object System.Drawing.Font($monoFamily, 9))
}

function ConvertTo-SqlStackGuiPx {
    # Logical pixels (written for 96 DPI) to device pixels, read from the body
    # font's height (16 px at 96 DPI), which already follows the DPI. Only for
    # pixels the form's own scaling pass does not reach: grid cell paddings,
    # the tab strip's padding.
    param([double]$Logical)
    return [int][Math]::Max(1, [Math]::Round($Logical * $script:UiFont.Body.Height / 16.0))
}

$script:Tips = New-Object System.Windows.Forms.ToolTip
$script:Tips.AutoPopDelay = 20000
$script:ButtonRole = @{}

$script:PaintCardBorder = {
    param($s, $e)
    try {
        $pen = New-Object System.Drawing.Pen($script:Ui.Border)
        $e.Graphics.DrawRectangle($pen, 0, 0, $s.ClientSize.Width - 1, $s.ClientSize.Height - 1)
        $pen.Dispose()
    } catch { }
}

function Add-SqlStackGuiCardRow {
    # One row of a card: AutoSize (-Fit) for text and buttons, else the card's
    # remaining height (Percent 100) for a grid, list or text view.
    param($Card, [System.Windows.Forms.Control]$Control, [switch]$Fit)
    $t = $Card.Card
    $r = $t.RowCount
    $t.RowCount = $r + 1
    if ($Fit) { [void]$t.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize))) }
    else { [void]$t.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, 100))) }
    $t.Controls.Add($Control, 0, $r)
}

function New-SqlStackGuiCard {
    <#
      A content card: white, a 1px border, padding, a section title and a
      secondary line. Title and subtitle are AutoSize labels anchored left and
      right in a table column, so they WRAP to the card's width instead of
      clipping. -FitHeight: the card is as tall as its rows.
    #>
    param([string]$Title, [string]$Subtitle = '', [switch]$FitHeight)
    $cardPanel = New-Object System.Windows.Forms.TableLayoutPanel
    $cardPanel.Dock = 'Fill'
    $cardPanel.BackColor = $script:Ui.Card
    $cardPanel.Padding = New-Object System.Windows.Forms.Padding(14, 10, 14, 12)
    $cardPanel.Margin = New-Object System.Windows.Forms.Padding(0)
    $cardPanel.ColumnCount = 1
    [void]$cardPanel.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, 100)))
    if ($FitHeight) { $cardPanel.AutoSize = $true; $cardPanel.AutoSizeMode = 'GrowAndShrink' }
    $cardPanel.Add_Paint($script:PaintCardBorder)
    $cardPanel.Add_Resize({ $this.Invalidate() })
    $cardTitle = New-Object System.Windows.Forms.Label
    $cardTitle.AutoSize = $true
    $cardTitle.Anchor = 'Left,Right'
    $cardTitle.UseMnemonic = $false
    $cardTitle.Font = $script:UiFont.Section
    $cardTitle.ForeColor = $script:Ui.Text
    $cardTitle.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 2)
    $cardTitle.Text = $Title
    $cardSub = New-Object System.Windows.Forms.Label
    $cardSub.AutoSize = $true
    $cardSub.Anchor = 'Left,Right'
    $cardSub.UseMnemonic = $false
    $cardSub.ForeColor = $script:Ui.Secondary
    $cardSub.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 8)
    $cardSub.Text = $Subtitle
    $cardSub.Visible = [bool]$Subtitle
    $card = [pscustomobject]@{ Card = $cardPanel; Title = $cardTitle; Subtitle = $cardSub }
    Add-SqlStackGuiCardRow -Card $card -Control $cardTitle -Fit
    Add-SqlStackGuiCardRow -Card $card -Control $cardSub -Fit
    return $card
}

function New-SqlStackGuiChip {
    # A fact in the header card: words on a quiet chip, never colour alone.
    param([string]$Text, [string]$Tip = '')
    $chip = New-Object System.Windows.Forms.Label
    $chip.AutoSize = $true
    $chip.UseMnemonic = $false
    $chip.Text = $Text
    $chip.Padding = New-Object System.Windows.Forms.Padding(8, 3, 8, 3)
    $chip.Margin = New-Object System.Windows.Forms.Padding(0, 0, 6, 4)
    $chip.BackColor = $script:Ui.Chip
    $chip.ForeColor = $script:Ui.Text
    if ($Tip) { $script:Tips.SetToolTip($chip, $Tip) }
    return $chip
}

function Set-SqlStackGuiFlowHeight {
    <#
      A wrapping flow (the header's chips, a row of buttons) is as tall as its
      contents wrapped at its CURRENT width. It is not AutoSize because a table
      measures an AutoSize flow at a width it has not given it yet: on this box
      the header chips were measured one per line and then centred in the tall
      row. So the flow measures itself, at its real width, whenever it lays out.
    #>
    param([System.Windows.Forms.FlowLayoutPanel]$Flow)
    if ($Flow.ClientSize.Width -le 0) { return }
    $h = $Flow.GetPreferredSize((New-Object System.Drawing.Size($Flow.ClientSize.Width, 0))).Height
    if (($h -gt 0) -and ($Flow.Height -ne $h)) {
        $Flow.Height = $h
        # The table holding it measured the row with the OLD height; lay it out
        # again so a flow that wrapped after a resize is not cut off (MEASURED by
        # the lane sqlstack-workbench harness at the window's minimum size).
        if ($Flow.Parent) { $Flow.Parent.PerformLayout() }
    }
}

function New-SqlStackGuiFlow {
    # A left-to-right flow that WRAPS rather than clips, for a card row.
    $flow = New-Object System.Windows.Forms.FlowLayoutPanel
    $flow.WrapContents = $true
    $flow.Dock = 'Fill'
    $flow.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
    $flow.BackColor = $script:Ui.Card
    $flow.Add_Layout({ Set-SqlStackGuiFlowHeight -Flow $this })
    return $flow
}

function Set-SqlStackGuiButtonColors {
    # Colours only, so it is safe to call at any time (Enabled changes call it).
    # Disabled is VISIBLY disabled; the one primary action is accent-filled.
    param([System.Windows.Forms.Button]$Button)
    $fa = $Button.FlatAppearance
    if (-not $Button.Enabled) {
        $Button.BackColor = $script:Ui.Disabled; $Button.ForeColor = $script:Ui.DisabledText; $fa.BorderColor = $script:Ui.Border
        $fa.MouseOverBackColor = $script:Ui.Disabled; $fa.MouseDownBackColor = $script:Ui.Disabled
    } elseif ($script:ButtonRole[$Button] -eq 'primary') {
        $Button.BackColor = $script:Ui.Accent; $Button.ForeColor = [System.Drawing.Color]::White; $fa.BorderColor = $script:Ui.Accent
        $fa.MouseOverBackColor = $script:Ui.AccentHover; $fa.MouseDownBackColor = $script:Ui.AccentDown
    } else {
        $Button.BackColor = $script:Ui.Card; $Button.ForeColor = $script:Ui.Text; $fa.BorderColor = $script:Ui.ButtonBorder
        $fa.MouseOverBackColor = $script:Ui.ButtonHover; $fa.MouseDownBackColor = $script:Ui.ButtonDown
    }
}

function Initialize-SqlStackGuiButton {
    <#
      EVERY button in this window goes through here ('G4-buttons-one-look' in
      Test-SqlStackGuiStructure): flat, sized from its text (no constant pixel
      height), coloured by its role. Call it before the form declares its
      design DPI (the end of this file): its padding and minimum width are
      logical pixels that the one scaling pass scales.
    #>
    param([System.Windows.Forms.Button]$Button, [switch]$Primary)
    $Button.FlatStyle = 'Flat'
    $Button.UseVisualStyleBackColor = $false
    $Button.AutoSize = $true
    $Button.AutoSizeMode = 'GrowAndShrink'
    $Button.MinimumSize = New-Object System.Drawing.Size(76, 0)
    $Button.Padding = New-Object System.Windows.Forms.Padding(8, 2, 8, 2)
    $Button.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
    $Button.FlatAppearance.BorderSize = 1
    $script:ButtonRole[$Button] = $(if ($Primary) { 'primary' } else { 'secondary' })
    $Button.Add_EnabledChanged({ Set-SqlStackGuiButtonColors -Button $this })
    Set-SqlStackGuiButtonColors -Button $Button
}

function Set-SqlStackGuiGridLook {
    <#
      EVERY grid in this window goes through here ('G3-grids-one-look' in
      Test-SqlStackGuiStructure): header height and row height FROM THEIR FONTS
      (never a pixel constant), no row headers, full-row select, horizontal
      lines only, alternating rows, and the grid's own tooltip with the full
      text wherever a cell still ends in an ellipsis.
      DataGridView.BorderStyle is a BorderStyle (None, FixedSingle, Fixed3D);
      'SingleLine' belongs to DataGridViewCellBorderStyle and threw at form
      construction on 2026-09-17. Literals here are still checked by the
      'winforms:' census in -SelfTest: it reads this function's TYPED -Grid.
    #>
    param([System.Windows.Forms.DataGridView]$Grid)
    $padX = ConvertTo-SqlStackGuiPx 6
    $padY = ConvertTo-SqlStackGuiPx 3
    $Grid.BorderStyle = 'None'
    $Grid.BackgroundColor = $script:Ui.Card
    $Grid.ReadOnly = $true
    $Grid.AllowUserToAddRows = $false
    $Grid.AllowUserToDeleteRows = $false
    $Grid.AllowUserToResizeRows = $false
    $Grid.RowHeadersVisible = $false
    $Grid.SelectionMode = 'FullRowSelect'
    $Grid.MultiSelect = $false
    $Grid.CellBorderStyle = 'SingleHorizontal'
    $Grid.GridColor = $script:Ui.Border
    $Grid.EnableHeadersVisualStyles = $false
    $Grid.ColumnHeadersBorderStyle = 'None'
    $Grid.ColumnHeadersHeightSizeMode = 'AutoSize'
    $Grid.AutoSizeRowsMode = 'AllCells'
    $Grid.ShowCellToolTips = $true
    $hs = $Grid.ColumnHeadersDefaultCellStyle
    $hs.BackColor = $script:Ui.Window; $hs.ForeColor = $script:Ui.Text
    $hs.SelectionBackColor = $script:Ui.Window; $hs.SelectionForeColor = $script:Ui.Text
    $hs.Font = $script:UiFont.Strong
    $hs.Padding = New-Object System.Windows.Forms.Padding($padX, $padY, $padX, $padY)
    $hs.WrapMode = [System.Windows.Forms.DataGridViewTriState]::True
    $ds = $Grid.DefaultCellStyle
    $ds.BackColor = $script:Ui.Card; $ds.ForeColor = $script:Ui.Text
    $ds.SelectionBackColor = $script:Ui.Selection; $ds.SelectionForeColor = $script:Ui.Text
    $ds.Padding = New-Object System.Windows.Forms.Padding($padX, $padY, $padX, $padY)
    $Grid.AlternatingRowsDefaultCellStyle.BackColor = $script:Ui.AltRow
}

function Add-SqlStackGuiGridColumn {
    # A column sized to its content; -Fill takes the width left over, and
    # Update-SqlStackGuiFillColumns keeps it from shrinking below its text.
    param([System.Windows.Forms.DataGridView]$Grid, [string]$Name, [string]$Tip = '', [switch]$Fill, [switch]$Wrap)
    $gc = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $gc.Name = $Name
    $gc.HeaderText = $Name
    if ($Tip) { $gc.ToolTipText = $Tip }
    if ($Fill) { $gc.AutoSizeMode = 'Fill' } else { $gc.AutoSizeMode = 'AllCells' }
    if ($Wrap) { $gc.DefaultCellStyle.WrapMode = [System.Windows.Forms.DataGridViewTriState]::True }
    [void]$Grid.Columns.Add($gc)
    return $gc
}

function Update-SqlStackGuiFillColumns {
    # A Fill column never shrinks below its header or its widest unwrapped
    # cell, measured by the grid itself: past that the grid scrolls sideways
    # rather than cut text. A wrapping column keeps only its header's width.
    param([System.Windows.Forms.DataGridView]$Grid)
    foreach ($gc in @($Grid.Columns)) {
        if ($gc.AutoSizeMode -ne [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill) { continue }
        $mode = $(if ($gc.DefaultCellStyle.WrapMode -eq [System.Windows.Forms.DataGridViewTriState]::True) { 'ColumnHeader' } else { 'AllCells' })
        $w = $gc.GetPreferredWidth([System.Windows.Forms.DataGridViewAutoSizeColumnMode]$mode, $true)
        if ($w -gt 2) { $gc.MinimumWidth = [Math]::Min($w, 4000) }
    }
}

function Set-SqlStackGuiCellColor {
    # A grid cell's colour, which only REPEATS the words beside it, and the SAME
    # colour when the row is selected (Gemini finding 8: the selected row lost it).
    param([System.Windows.Forms.DataGridViewCell]$Cell, [System.Drawing.Color]$Color)
    $Cell.Style.ForeColor = $Color
    $Cell.Style.SelectionForeColor = $Color
}

function Set-SqlStackGuiGridHeightToRows {
    <#
      A grid as tall as its header plus its rows (at least -MinRows, at most
      -MaxRows; past that it scrolls), so one volume is not a large empty box.
      Every pixel is read from the grid's own laid-out header and rows.
    #>
    param([System.Windows.Forms.DataGridView]$Grid, [int]$MinRows = 1, [int]$MaxRows = 6)
    $h = $Grid.ColumnHeadersHeight
    $n = $Grid.Rows.Count
    $take = [Math]::Min($n, $MaxRows)
    for ($i = 0; $i -lt $take; $i++) { $h += $Grid.Rows[$i].Height }
    if ($take -lt $MinRows) {
        $one = $(if ($n -gt 0) { $Grid.Rows[0].Height } else { $Grid.Font.Height + 2 * (ConvertTo-SqlStackGuiPx 4) })
        $h += ($MinRows - $take) * $one
    }
    $colsW = 0
    foreach ($gc in @($Grid.Columns)) { if ($gc.Visible) { $colsW += [Math]::Max($gc.Width, $gc.MinimumWidth) } }
    if ($colsW -gt $Grid.ClientSize.Width) { $h += [System.Windows.Forms.SystemInformation]::HorizontalScrollBarHeight }
    $h += 2
    if ($Grid.Height -ne $h) { $Grid.Height = $h }
}

function New-SqlStackGuiTabPage {
    param([string]$Text)
    $page = New-Object System.Windows.Forms.TabPage
    $page.Text = $Text
    $page.UseVisualStyleBackColor = $false
    $page.BackColor = $script:Ui.Window
    $page.Padding = New-Object System.Windows.Forms.Padding(10)
    return $page
}

$script:DrawTab = {
    param($s, $e)
    try {
        $r = $e.Bounds
        $sel = ($e.Index -eq $s.SelectedIndex)
        $bg = New-Object System.Drawing.SolidBrush($(if ($sel) { $script:Ui.Card } else { $script:Ui.Window }))
        $e.Graphics.FillRectangle($bg, $r); $bg.Dispose()
        $flags = [System.Windows.Forms.TextFormatFlags]'HorizontalCenter, VerticalCenter, SingleLine, NoPrefix, NoPadding'
        [System.Windows.Forms.TextRenderer]::DrawText($e.Graphics, $s.TabPages[$e.Index].Text, $s.Font, $r, $(if ($sel) { $script:Ui.Text } else { $script:Ui.Secondary }), $flags)
        if ($sel) {
            $bar = [Math]::Max(2, [int][Math]::Round($s.Font.Height / 8.0))
            $ab = New-Object System.Drawing.SolidBrush($script:Ui.Accent)
            $e.Graphics.FillRectangle($ab, ($r.X + 2 * $bar), ($r.Bottom - $bar), [Math]::Max(1, $r.Width - 4 * $bar), $bar); $ab.Dispose()
        }
    } catch { }
}

function Set-SqlStackGuiTabLook {
    <#
      Owner-drawn tabs: the selected tab is white with an accent bar under its
      caption, the others sit on the window colour in the secondary colour.
      The native control still MEASURES every caption (a tab's width follows
      its text plus this padding), so a caption never clips; the draw handler
      only paints, and a failure in it leaves the tab blank rather than stop
      the window.
    #>
    param([System.Windows.Forms.TabControl]$Tabs)
    $Tabs.DrawMode = 'OwnerDrawFixed'
    $Tabs.Padding = New-Object System.Drawing.Point((ConvertTo-SqlStackGuiPx 16), (ConvertTo-SqlStackGuiPx 6))
    $Tabs.Add_DrawItem($script:DrawTab)
}

function New-SqlStackGuiTable {
    # A layout table: -Columns / -Rows are size specs, 'auto' or a percent.
    param([string[]]$Columns, [string[]]$Rows)
    $tbl = New-Object System.Windows.Forms.TableLayoutPanel
    $tbl.Dock = 'Fill'
    $tbl.Margin = New-Object System.Windows.Forms.Padding(0)
    $tbl.BackColor = $script:Ui.Window
    $tbl.ColumnCount = $Columns.Count
    $tbl.RowCount = $Rows.Count
    foreach ($c in $Columns) {
        if ($c -eq 'auto') { [void]$tbl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize))) }
        else { [void]$tbl.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, [single]$c))) }
    }
    foreach ($r in $Rows) {
        if ($r -eq 'auto') { [void]$tbl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize))) }
        else { [void]$tbl.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::Percent, [single]$r))) }
    }
    return $tbl
}

# ===========================================================================
# Form: THE WORKBENCH (lane sqlstack-workbench, 2026-11-03)
#
# One window for the whole journey: a header (the host and the run folder), a
# left RAIL of stages, a CENTRE that shows the selected stage, and a DRAWER on
# the right with the exact command to run next and a preview of the stage's
# file. The window runs none of the stages (INV-1; the Install screen alone
# starts the install worker, INV-5): every stage's state comes from the ONE
# stage reader (Get-SqlStackGuiRunState, INV-3) and every command from the ONE
# builder (Get-SqlStackGuiCommand, INV-2).
# ===========================================================================
$form = New-Object System.Windows.Forms.Form
# G1: every pixel constant below is LOGICAL (96 DPI). The design DPI is
# declared at the end of this file, after the last control is added.
$form.Text = "SqlStack $($script:GuiVersion) - stacked SQL Server workbench"
$form.Size = New-Object System.Drawing.Size(1440, 900)
$form.MinimumSize = New-Object System.Drawing.Size(1180, 760)
$form.StartPosition = 'CenterScreen'
$form.Font = $script:UiFont.Body
$form.BackColor = $script:Ui.Window
$form.ForeColor = $script:Ui.Text

$root = New-SqlStackGuiTable -Columns @('100') -Rows @('auto', '100')
$root.Padding = New-Object System.Windows.Forms.Padding(12, 12, 12, 8)

# ---- header card: the host, its facts as chips that WRAP, elevation, and the run folder ----
$hdrCard = New-SqlStackGuiCard -Title $env:COMPUTERNAME -FitHeight
$hdr = $hdrCard.Card
$hdr.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$lblHost = $hdrCard.Title
$lblHost.Font = $script:UiFont.Host
$flpFacts = New-SqlStackGuiFlow
# D3: elevation is STATED, never followed by a skip nobody makes. D6: a
# -Server naming another host is said, from the entry-args snapshot.
$elevText = Get-SqlStackGuiElevationText -IsElevated $script:IsElevated
$serverNote = Get-SqlStackGuiServerNote -Server $script:EntryArgs['Server']
$factTips = @(
    'Logical processors, as Windows reports them for this host.',
    'Physical memory, as Windows reports it for this host.',
    'Volumes with a drive letter, listed on the Host view.',
    'Instances named in the registry under Instance Names\SQL. They are loaded into the plan as locked rows.')
$facts = @(Get-SqlStackGuiHeaderFacts -LogicalCores $script:LogicalCores -PhysicalMb $script:PhysicalMb -VolumeCount $script:Volumes.Count -InstanceCount $script:Instances.Count)
for ($i = 0; $i -lt $facts.Count; $i++) { $flpFacts.Controls.Add((New-SqlStackGuiChip -Text $facts[$i] -Tip $factTips[$i])) }
$flpFacts.Controls.Add((New-SqlStackGuiChip -Text $elevText -Tip 'Whether this window runs as administrator. Reading, planning and saving need no elevation. Install does: its button starts this window again as administrator.'))
Add-SqlStackGuiCardRow -Card $hdrCard -Control $flpFacts -Fit
if ($serverNote) {
    $lblServer = New-Object System.Windows.Forms.Label
    $lblServer.AutoSize = $true
    $lblServer.Anchor = 'Left,Right'
    $lblServer.UseMnemonic = $false
    $lblServer.BackColor = $script:Ui.WarningBack
    $lblServer.ForeColor = $script:Ui.Warning
    $lblServer.Padding = New-Object System.Windows.Forms.Padding(8, 4, 8, 4)
    $lblServer.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 0)
    $lblServer.Text = ('Warning: this window ' + $serverNote + '.')
    Add-SqlStackGuiCardRow -Card $hdrCard -Control $lblServer -Fit
}
$lblRunFolder = New-Object System.Windows.Forms.Label
$lblRunFolder.Name = 'lblRunFolder'
$lblRunFolder.AutoSize = $true
$lblRunFolder.Anchor = 'Left,Right'
$lblRunFolder.UseMnemonic = $false
$lblRunFolder.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
$lblRunFolder.Text = 'Run folder: (none yet)'
Add-SqlStackGuiCardRow -Card $hdrCard -Control $lblRunFolder -Fit
$flpRun = New-SqlStackGuiFlow
$btnOpenRun = New-Object System.Windows.Forms.Button
$btnOpenRun.Text = 'Open run folder...'
Initialize-SqlStackGuiButton -Button $btnOpenRun
$script:Tips.SetToolTip($btnOpenRun, 'Open another run folder. Its spec.json is loaded back into the plan.')
$btnNewRun = New-Object System.Windows.Forms.Button
$btnNewRun.Text = 'New run folder'
Initialize-SqlStackGuiButton -Button $btnNewRun
$script:Tips.SetToolTip($btnNewRun, 'Start a new run folder for this plan, named after this host and the time.')
$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = 'Refresh'
Initialize-SqlStackGuiButton -Button $btnRefresh
$script:Tips.SetToolTip($btnRefresh, 'Read the run folder and the state folder again, and redraw every stage from what is there.')
$flpRun.Controls.AddRange(@($btnOpenRun, $btnNewRun, $btnRefresh))
Add-SqlStackGuiCardRow -Card $hdrCard -Control $flpRun -Fit

# ---- status strip ----
$status = New-Object System.Windows.Forms.StatusStrip
$status.Font = $script:UiFont.Body
$status.SizingGrip = $false
$status.BackColor = $script:Ui.Window
# A severity marker (its colour repeats the words beside it), the counts in
# words, then the message.
$statusMarker = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusMarker.Text = [string][char]0x25CF
$statusMarker.ForeColor = $script:Ui.Secondary
$statusMarker.ToolTipText = 'Red: the plan has an error. Amber: warnings only. Green: neither. Grey: no new instance is planned yet. The counts beside it say so in words.'
$statusCounts = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusCounts.Margin = New-Object System.Windows.Forms.Padding(0, 3, 14, 2)
$statusLabel = New-Object System.Windows.Forms.ToolStripStatusLabel
$statusLabel.Spring = $true
$statusLabel.TextAlign = 'MiddleLeft'
$statusLabel.Text = 'Ready. Nothing on this host changes until you press Install now and confirm.'
[void]$status.Items.Add($statusMarker)
[void]$status.Items.Add($statusCounts)
[void]$status.Items.Add($statusLabel)

# Rail | centre, and with -Advanced the drawer beside them.
$bodyColumns = $(if ($script:WbAdvanced) { @('17', '54', '29') } else { @('17', '83') })
$body = New-SqlStackGuiTable -Columns $bodyColumns -Rows @('100')

# ===========================================================================
# THE RAIL: Host, Plan, Install; with -Advanced also the older stages, each
# with its status in words
# ===========================================================================
$cardRail = New-SqlStackGuiCard -Title $(if ($script:WbAdvanced) { 'Stages' } else { 'Steps' }) -Subtitle $(if ($script:WbAdvanced) { 'Read from the files in the run folder. Select one.' } else { 'Look at the host, plan the new instances, then install them.' })
$cardRail.Card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
$gridStages = New-Object System.Windows.Forms.DataGridView
$gridStages.Name = 'gridStages'
Set-SqlStackGuiGridLook -Grid $gridStages
$gridStages.Dock = 'Fill'
Add-SqlStackGuiCardRow -Card $cardRail -Control $gridStages

# ===========================================================================
# THE CENTRE: one view at a time (Host, Plan, or a stage)
# ===========================================================================
$centre = New-Object System.Windows.Forms.Panel
$centre.Dock = 'Fill'
$centre.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 0)
$centre.BackColor = $script:Ui.Window

# ---- the Host view: volumes, installed instances, this host's addresses (read only) ----
$viewHost = New-SqlStackGuiTable -Columns @('100') -Rows @('auto', '50', '50')
$viewHost.Name = 'viewHost'
$cardVols = New-SqlStackGuiCard -Title 'Volumes' -Subtitle 'Volumes with a drive letter, read once when this window opened. Select one here, then press Use selected volume beside a folder in the plan.' -FitHeight
$cardVols.Card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$lblVols = $cardVols.Title
$gridVols = New-Object System.Windows.Forms.DataGridView
Set-SqlStackGuiGridLook -Grid $gridVols
$gridVols.Anchor = 'Top,Left,Right'
Add-SqlStackGuiCardRow -Card $cardVols -Control $gridVols -Fit
# The Volumes grid is as tall as its rows, re-measured whenever a font, a
# header, a row or the width (a sideways scrollbar) changes.
$gridVols.Add_ColumnHeadersHeightChanged({ Set-SqlStackGuiGridHeightToRows -Grid $gridVols })
$gridVols.Add_RowHeightChanged({ Set-SqlStackGuiGridHeightToRows -Grid $gridVols })
$gridVols.Add_ColumnWidthChanged({ Set-SqlStackGuiGridHeightToRows -Grid $gridVols })
$gridVols.Add_Resize({ Set-SqlStackGuiGridHeightToRows -Grid $gridVols })

function Update-VolumeGrid {
    $gridVols.Rows.Clear()
    $gridVols.Columns.Clear()
    $volTips = @{
        'FS'     = 'File system.'
        'Free %' = 'Free space as a share of the volume: red below 10% (Notes says so too), amber below 25%, green otherwise. Hover a cell for it in words.'
        'Alloc'  = 'Allocation unit (cluster) size. 64K is recommended for SQL Server data, log and TempDB volumes; another size is amber and named in Notes.'
        'Notes'  = 'What is worth knowing about the volume before placing SQL Server files on it.'
    }
    foreach ($n in @('Drive', 'Label', 'FS', 'Total GB', 'Free GB', 'Free %', 'Alloc', 'Notes')) {
        [void](Add-SqlStackGuiGridColumn -Grid $gridVols -Name $n -Tip ([string]$volTips[$n]) -Fill:($n -eq 'Notes'))
    }
    foreach ($v in $script:Volumes) {
        # The share is judged UNROUNDED (Gemini finding 14: 185.1 of 1881.5 GB is
        # 9.84%, which rounded to '10%' and so was never called low).
        $raw = $(if ($v.SizeGB -gt 0) { 100.0 * $v.FreeGB / $v.SizeGB } else { 0.0 })
        $pctText = Get-SqlStackGuiFreeText -Percent $raw
        $alloc = if ($v.AllocationUnitSize -gt 0) { ('{0}K' -f [int]($v.AllocationUnitSize/1KB)) } else { '?' }
        $notes = Get-DriveAdvice -Volume $v
        $idx = $gridVols.Rows.Add(@(
            ($v.DriveLetter + ':'), $v.Label, $v.FileSystem,
            $v.SizeGB, $v.FreeGB, $pctText, $alloc, $notes))
        $row = $gridVols.Rows[$idx]
        # Colour is always paired with words: the tooltip, and Notes below 10%.
        # The SELECTION colour repeats it (finding 8: a selected row lost its colour).
        $pc = $row.Cells['Free %']
        if ($raw -lt 10) { Set-SqlStackGuiCellColor -Cell $pc -Color $script:Ui.Error; $pc.ToolTipText = ('{0} free: low (below 10%).' -f $pctText) }
        elseif ($raw -lt 25) { Set-SqlStackGuiCellColor -Cell $pc -Color $script:Ui.Warning; $pc.ToolTipText = ('{0} free: getting low (below 25%).' -f $pctText) }
        else { Set-SqlStackGuiCellColor -Cell $pc -Color $script:Ui.Ok; $pc.ToolTipText = ('{0} free: enough (25% or more).' -f $pctText) }
        if ($v.AllocationUnitSize -and $v.AllocationUnitSize -ne $script:SqlRecommendedAllocUnit) {
            Set-SqlStackGuiCellColor -Cell $row.Cells['Alloc'] -Color $script:Ui.Warning
            $row.Cells['Alloc'].ToolTipText = ('{0}, not the 64K recommended for SQL Server data, log and TempDB.' -f $alloc)
        }
        if ($notes) { Set-SqlStackGuiCellColor -Cell $row.Cells['Notes'] -Color $script:Ui.Warning }
    }
    Update-SqlStackGuiFillColumns -Grid $gridVols
    Set-SqlStackGuiGridHeightToRows -Grid $gridVols
}

$cardInst = New-SqlStackGuiCard -Title 'SQL Server instances already installed on this host' -Subtitle 'Read from the registry through the engine''s own functions. They are in the plan as locked rows. This window opens no SQL connection.'
$cardInst.Card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$lblInst = $cardInst.Title
$gridInst = New-Object System.Windows.Forms.DataGridView
Set-SqlStackGuiGridLook -Grid $gridInst
$gridInst.Dock = 'Fill'
Add-SqlStackGuiCardRow -Card $cardInst -Control $gridInst

function Update-InstanceGrid {
    $gridInst.Rows.Clear(); $gridInst.Columns.Clear()
    # D5 (lane sqlstack-gui-glowup): ONE source. TCP comes from the engine's
    # facts gathered in Update-HostFacts ($script:ObservedInstancePorts and
    # $script:KnownInstancePorts from Get-KnownInstancePortMap, the switch from
    # the engine's net-tcp-registry probe), IN WORDS, with the raw values in the
    # tooltip. This function reads no host state: 'D5-grid-one-source' in
    # Test-SqlStackGuiStructure goes red if it does.
    $instTips = @{
        'Instance ID' = 'The ID the registry names for the instance under Instance Names\SQL (for example MSSQL16.NEW2022).'
        'Default'     = 'True for the default instance (MSSQLSERVER), which clients reach by the host name alone.'
        'TCP'         = ("How the instance takes TCP connections, read from its registry through the engine. " +
                         "'TCP off': the TCP/IP protocol is disabled. 'static N': a static port. 'dynamic N': no static port; SQL took N at its last start. " +
                         "'dynamic (none assigned)': no static port and none recorded. Hover a cell for the raw values.")
    }
    foreach ($n in @('Instance', 'Instance ID', 'Default', 'TCP')) {
        [void](Add-SqlStackGuiGridColumn -Grid $gridInst -Name $n -Tip ([string]$instTips[$n]) -Fill:($n -eq 'TCP'))
    }
    foreach ($i in $script:Instances) {
        $nm = [string]$i.Name
        $fixedRow = @($script:ObservedInstancePorts | Where-Object { [string]$_.Name -eq $nm }) | Select-Object -First 1
        $tcpRead = $(if ($script:TcpReads -and $script:TcpReads.ContainsKey($nm)) { $script:TcpReads[$nm] } else { $null })
        $tcp = Get-SqlStackGuiTcpText -Name $nm -FixedRow $fixedRow -Map $script:KnownInstancePorts -TcpRead $tcpRead
        $idx = $gridInst.Rows.Add(@($nm, $i.InstanceId, $i.IsDefault, $tcp.Text))
        $gridInst.Rows[$idx].Cells['TCP'].ToolTipText = $tcp.Tip
    }
    Update-SqlStackGuiFillColumns -Grid $gridInst
}

# INV-4: this host's addresses are SHOWN, read-only, from the engine's reader
# (Get-SqlStackLocalIpAddress, proved read-only by 'host IPs (INV-4, K10):' in -SelfTest).
$cardIps = New-SqlStackGuiCard -Title 'This host''s IP addresses (read only)' -Subtitle 'Every address on every adapter, including adapters that are down, from the engine''s local-address reader. Planning never changes an address. Install adds a planned address this host does not have yet, to the network card you choose there, after you confirm.'
$gridIps = New-Object System.Windows.Forms.DataGridView
$gridIps.Name = 'gridIps'
Set-SqlStackGuiGridLook -Grid $gridIps
$gridIps.Dock = 'Fill'
Add-SqlStackGuiCardRow -Card $cardIps -Control $gridIps

function Update-HostIpGrid {
    $gridIps.Rows.Clear(); $gridIps.Columns.Clear()
    foreach ($n in @('Address', 'Kind', 'Adapter')) { [void](Add-SqlStackGuiGridColumn -Grid $gridIps -Name $n -Fill:($n -eq 'Adapter')) }
    foreach ($r in @(Get-SqlStackGuiHostIpRows -Rows $script:HostIps)) { [void]$gridIps.Rows.Add(@($r.Address, $r.Kind, $r.Adapter)) }
    Update-SqlStackGuiFillColumns -Grid $gridIps
}

$viewHost.Controls.Add($cardVols.Card, 0, 0)
$viewHost.Controls.Add($cardInst.Card, 0, 1)
$viewHost.Controls.Add($cardIps.Card, 0, 2)

# ---- the Plan view: stage 1 ----
$viewPlan = New-SqlStackGuiTable -Columns @('30', '70') -Rows @('auto', '55', '45')
$viewPlan.Name = 'viewPlan'
$planTopWords = $(if ($script:WbAdvanced) {
        'The installed instances are loaded as locked rows. Save spec writes spec.json into the run folder: that is the file the dry run reads. ' +
        'The .ini and .sql are a second, UNGUARDED route: no SqlStack rail protects a run of them. Install runs them through the install worker, which changes only the instances this plan names.'
    } else {
        'The instances already installed are listed as locked rows. Add each new instance and fill in its details. Save plan keeps the plan in the run folder; then open Install.'
    })
$cardPlanTop = New-SqlStackGuiCard -Title 'Plan the new instances' -Subtitle $planTopWords -FitHeight
$cardPlanTop.Card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$lblReadOnly = New-Object System.Windows.Forms.Label
$lblReadOnly.Name = 'lblReadOnly'
$lblReadOnly.AutoSize = $true
$lblReadOnly.Anchor = 'Left,Right'
$lblReadOnly.UseMnemonic = $false
$lblReadOnly.BackColor = $script:Ui.WarningBack
$lblReadOnly.ForeColor = $script:Ui.Warning
$lblReadOnly.Padding = New-Object System.Windows.Forms.Padding(8, 4, 8, 4)
$lblReadOnly.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
$lblReadOnly.Visible = $false
Add-SqlStackGuiCardRow -Card $cardPlanTop -Control $lblReadOnly -Fit
$revTop = New-SqlStackGuiFlow
$btnAdd = New-Object System.Windows.Forms.Button
$btnAdd.Text = 'Add new instance'
Initialize-SqlStackGuiButton -Button $btnAdd
$script:Tips.SetToolTip($btnAdd, 'Add a NEW instance to the plan.')
$btnRemove = New-Object System.Windows.Forms.Button
$btnRemove.Text = 'Remove'
Initialize-SqlStackGuiButton -Button $btnRemove
$script:Tips.SetToolTip($btnRemove, 'Take the selected NEW instance out of the plan. Installed instances cannot be removed. Nothing on the host changes.')
# Edition is the ONE value that is neither read nor planned: MediaInfo.xml does
# not carry it (MEASURED 2026-10-08 over the 2017/2022/2025 fixtures), so it is
# an operator DECISION and this window asks rather than infers.
$lblEdition = New-Object System.Windows.Forms.Label
$lblEdition.Text = 'Edition'; $lblEdition.AutoSize = $true; $lblEdition.Anchor = 'Left'
$lblEdition.Margin = New-Object System.Windows.Forms.Padding(12, 6, 6, 0)
$cboEdition = New-Object System.Windows.Forms.ComboBox
$cboEdition.Name = 'cboEdition'
$cboEdition.DropDownStyle = 'DropDownList'
$cboEdition.MinimumSize = New-Object System.Drawing.Size(130, 0)
$cboEdition.Margin = New-Object System.Windows.Forms.Padding(0, 2, 12, 0)
[void]$cboEdition.Items.AddRange(@('Developer', 'Standard', 'Enterprise', 'Express', 'Web'))
$cboEdition.SelectedIndex = 0
$script:Tips.SetToolTip($cboEdition, 'The edition to install. The media does not state one, so this is your choice and the spec records it.')
# Finding 1: the SPEC is the main path, so Save spec is the ONE primary action.
$btnSpec = New-Object System.Windows.Forms.Button
$btnSpec.Text = $(if ($script:WbAdvanced) { 'Save spec' } else { 'Save plan' })
Initialize-SqlStackGuiButton -Button $btnSpec -Primary
$script:Tips.SetToolTip($btnSpec, 'Write spec.json (and, for a throwaway instance, spec-absent.json) into the run folder. Every value is read off this host or planned from it. Nothing is run.')
# Preview and Export show and write the .ini/.sql by hand: they need the
# drawer, so they are on the screen only with -Advanced. The Install screen
# writes the same files itself, with no dialog.
$btnGen = New-Object System.Windows.Forms.Button
$btnGen.Text = 'Preview .ini/.sql'
Initialize-SqlStackGuiButton -Button $btnGen
$btnGen.Visible = $script:WbAdvanced
$btnSave = New-Object System.Windows.Forms.Button
$btnSave.Text = 'Export .ini/.sql (unguarded)'
Initialize-SqlStackGuiButton -Button $btnSave
$btnSave.Visible = $script:WbAdvanced
$script:Tips.SetToolTip($btnSave, 'Write the previewed .ini and .sql into the run folder''s export folder. They run by hand only, with none of SqlStack''s rails. Nothing is run.')
$lblGenReason = New-Object System.Windows.Forms.Label
$lblGenReason.AutoSize = $true
$lblGenReason.Anchor = 'Left'
$lblGenReason.UseMnemonic = $false
$lblGenReason.ForeColor = $script:Ui.Secondary
$lblGenReason.Margin = New-Object System.Windows.Forms.Padding(4, 6, 0, 0)
$revTop.Controls.AddRange(@($btnAdd, $btnRemove, $lblEdition, $cboEdition, $btnSpec, $btnGen, $btnSave, $lblGenReason))
Add-SqlStackGuiCardRow -Card $cardPlanTop -Control $revTop -Fit

# -- left: the instance list (installed rows first, locked) --
$cardPlanInst = New-SqlStackGuiCard -Title 'Instances' -Subtitle 'Installed ones are locked constraints. New ones are planned.'
$cardPlanInst.Card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 10, 10)
$lstPlan = New-Object System.Windows.Forms.ListBox
$lstPlan.Name = 'lstPlan'
$lstPlan.Dock = 'Fill'
$lstPlan.IntegralHeight = $false
$lstPlan.HorizontalScrollbar = $true
$lstPlan.BorderStyle = 'None'
$lstPlan.Font = $script:UiFont.Mono
Add-SqlStackGuiCardRow -Card $cardPlanInst -Control $lstPlan

# -- right: the detail editor --
$cardDetail = New-SqlStackGuiCard -Title 'Selected instance' -Subtitle 'Select an instance in the list.'
$cardDetail.Card.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
$lblDetailTitle = $cardDetail.Title
$lblDetailNote = $cardDetail.Subtitle
# The editor is as tall as its rows, at the top of a panel that SCROLLS when
# the card is shorter than that (a small window).
$detailBody = New-Object System.Windows.Forms.Panel
$detailBody.Dock = 'Fill'
$detailBody.AutoScroll = $true
$detailBody.Margin = New-Object System.Windows.Forms.Padding(0)
$detailBody.BackColor = $script:Ui.Card
$detail = New-Object System.Windows.Forms.TableLayoutPanel
# NOT docked: a docked table is forced to the panel's width and squeezes its
# fields under their minimums (MEASURED by the lane's harness: the folder boxes
# ran under their Browse buttons). It is AutoSize, at least as wide as the
# panel (Set-SqlStackGuiDetailWidth), and the panel scrolls when it is wider.
$detail.Location = New-Object System.Drawing.Point(0, 0)
$detail.AutoSize = $true
$detail.AutoSizeMode = 'GrowAndShrink'
$detail.BackColor = $script:Ui.Card
$detail.ColumnCount = 6
# label | value | label | value | Browse | Use selected volume: paired fields
# share rows, and a folder row spans the three middle columns.
foreach ($cs in @('auto', 'auto', 'auto', '100', 'auto', 'auto')) {
    if ($cs -eq 'auto') { [void]$detail.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::AutoSize))) }
    else { [void]$detail.ColumnStyles.Add((New-Object System.Windows.Forms.ColumnStyle([System.Windows.Forms.SizeType]::Percent, [single]$cs))) }
}

$script:DetailControls = @{}

function Add-DetailTableRow {
    # Grow the detail table to hold row -Row; every row is AutoSize.
    param([int]$Row)
    while ($detail.RowCount -le $Row) {
        $detail.RowCount = $detail.RowCount + 1
        [void]$detail.RowStyles.Add((New-Object System.Windows.Forms.RowStyle([System.Windows.Forms.SizeType]::AutoSize)))
    }
}

function Add-DetailRow {
    # One labelled value at (-Row, -Col 0 or 2). A field in column 2 spans to
    # the table's right edge. -Check is a box to tick; -Choices a fixed list.
    # -Editable with -Choices: a list you can also TYPE into (an account name).
    param([string]$Label, [string]$Key, [int]$Row, [int]$Col = 0, [switch]$Numeric, [switch]$ReadOnly, [switch]$Check, [string[]]$Choices = @(), [switch]$Editable)
    Add-DetailTableRow -Row $Row
    $lab = New-Object System.Windows.Forms.Label
    $lab.Text = $Label; $lab.Anchor = 'Left'; $lab.AutoSize = $true
    $lab.Margin = New-Object System.Windows.Forms.Padding($(if ($Col -gt 0) { 18 } else { 0 }), 3, 8, 3)
    $detail.Controls.Add($lab, $Col, $Row)

    if ($Numeric) {
        $box = New-Object System.Windows.Forms.NumericUpDown
        $box.Minimum = 0; $box.Maximum = 2147483647; $box.Anchor = 'Left'
        # A MINIMUM, not only a width: the table may not squeeze a number box
        # below it, and the form's scaling pass scales it (a width a table has
        # already squeezed would be scaled from the squeezed value).
        $box.MinimumSize = New-Object System.Drawing.Size(120, 0)
        $box.Width = 120
    } elseif ($Check) {
        # Each kind has its OWN variable: the 'winforms:' census types a variable by
        # the New-Object that creates it, so one name across kinds would be judged
        # as the last kind.
        $chkBox = New-Object System.Windows.Forms.CheckBox
        $chkBox.AutoSize = $true; $chkBox.Anchor = 'Left'; $chkBox.Text = ''
        $box = $chkBox
    } elseif (@($Choices).Count -gt 0) {
        $cboBox = New-Object System.Windows.Forms.ComboBox
        $cboBox.DropDownStyle = 'DropDownList'; $cboBox.Anchor = 'Left'
        $cboBox.MinimumSize = New-Object System.Drawing.Size(170, 0)
        if ($Editable) {
            $cboBox.DropDownStyle = 'DropDown'; $cboBox.Anchor = 'Left,Right'
            $cboBox.MinimumSize = New-Object System.Drawing.Size(260, 0)
        }
        [void]$cboBox.Items.AddRange([object[]]@($Choices))
        $box = $cboBox
    } else {
        $box = New-Object System.Windows.Forms.TextBox
        $box.Anchor = 'Left,Right'
        $box.MinimumSize = New-Object System.Drawing.Size(170, 0)
        if ($ReadOnly) { $box.ReadOnly = $true }
    }
    $box.Name = $Key
    $detail.Controls.Add($box, $Col + 1, $Row)
    if ($Col -gt 0) { $detail.SetColumnSpan($box, 3) }
    $script:DetailControls[$Key] = $box
    return $box
}

function Add-DetailNote {
    # A line of words under a field, spanning the value columns. Display only:
    # NOT in $script:DetailControls, so it is never saved onto a plan row.
    param([int]$Row, [string]$Text)
    Add-DetailTableRow -Row $Row
    $n = New-Object System.Windows.Forms.Label
    $n.AutoSize = $true; $n.Anchor = 'Left,Right'; $n.UseMnemonic = $false
    $n.ForeColor = $script:Ui.Secondary
    $n.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
    $n.Text = $Text
    $detail.Controls.Add($n, 1, $Row)
    $detail.SetColumnSpan($n, 5)
}

function Add-DetailPathRow {
    # A folder: its box spans the middle columns, then Browse and Use selected volume.
    param([string]$Label, [string]$Key, [int]$Row)
    $box = Add-DetailRow -Label $Label -Key $Key -Row $Row -Col 0
    $detail.SetColumnSpan($box, 3)

    $b = New-Object System.Windows.Forms.Button
    $b.Text = 'Browse...'; $b.Anchor = 'Left'
    Initialize-SqlStackGuiButton -Button $b
    $b.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
    $b.Margin = New-Object System.Windows.Forms.Padding(8, 2, 0, 2)
    $script:Tips.SetToolTip($b, 'Choose the folder.')
    $b.Tag = $Key
    $b.Add_Click({
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = "Choose the folder for $($this.Tag)"
        $dlg.ShowNewFolderButton = $true
        $cur = $script:DetailControls[$this.Tag].Text
        if ($cur -and (Test-Path $cur -ErrorAction SilentlyContinue)) { $dlg.SelectedPath = $cur }
        if ($dlg.ShowDialog() -eq 'OK') {
            $script:DetailControls[$this.Tag].Text = $dlg.SelectedPath
            Save-DetailToPlan; Update-Validation
        }
    })
    $detail.Controls.Add($b, 4, $Row)

    $u = New-Object System.Windows.Forms.Button
    $u.Text = 'Use selected volume'; $u.Anchor = 'Left'
    Initialize-SqlStackGuiButton -Button $u
    $u.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
    $u.Margin = New-Object System.Windows.Forms.Padding(8, 2, 0, 2)
    $script:Tips.SetToolTip($u, 'Put this folder on the volume selected in the Host view''s Volumes list.')
    $u.Tag = $Key
    $u.Add_Click({
        if ($gridVols.SelectedRows.Count -eq 0) { $statusLabel.Text = 'Select a volume in the Host view first.'; return }
        $drive = ([string]$gridVols.SelectedRows[0].Cells['Drive'].Value).TrimEnd(':')
        $sel = $lstPlan.SelectedIndex
        if ($sel -lt 0) { return }
        $inst = $script:Plan[$sel].Name
        $leaf = switch ($this.Tag) { 'DataPath' {'Data'} 'LogPath' {'Log'} 'TempDbPath' {'TempDB'} 'BackupPath' {'Backup'} default {'Data'} }
        $script:DetailControls[$this.Tag].Text = ('{0}:\{1}\{2}' -f $drive, $inst, $leaf)
        Save-DetailToPlan; Update-Validation
    })
    $detail.Controls.Add($u, 5, $Row)
}

function Update-SqlStackGuiMediaStatus {
    # Re-read the SELECTED row's media and show what the engine said, in words.
    # Called after a browse, after the box is left and after the selection
    # changes. A READ only.
    $i = $lstPlan.SelectedIndex
    if ($i -lt 0 -or $i -ge $script:Plan.Count) { $script:MediaStatus.Text = ''; return }
    $p = $script:Plan[$i]
    if ($p.Fixed) { $script:MediaStatus.Text = ''; return }
    $r = Read-SqlStackGuiMedia -MediaPath ([string]$p.MediaPath)
    $p.MediaVersion  = [string]$r.Version
    $p.MediaBaseline = [string]$r.Baseline
    $p.MediaProblem  = [string]$r.Problem
    # The media read is the single most likely thing to go wrong on a machine
    # nobody here can see, so BOTH outcomes are logged, with the folder.
    if ($r.Ok) {
        Write-SqlStackGuiLog 'MEDIA' ('{0}: OK - SQL {1}, baseline {2}, from {3}' -f $p.Name, $r.Version, $r.Baseline, $p.MediaPath)
    } else {
        Write-SqlStackGuiLog 'MEDIA' ('{0}: NOT USABLE - {1} (folder: {2})' -f $p.Name, $r.Problem, $p.MediaPath)
    }
    if ($r.Ok) {
        $script:MediaStatus.Text = ('Read off the media: SQL Server {0}, BaselineVersion {1}. {2} is present.' -f `
                                    $r.Version, $r.Baseline, (Get-SqlStackSetupExePath))
        $script:MediaStatus.ForeColor = $script:Ui.Ok
    } else {
        $script:MediaStatus.Text = ('Not usable yet: {0}' -f $r.Problem)
        $script:MediaStatus.ForeColor = $script:Ui.Error
    }
}

function Add-DetailMediaRow {
    # The SQL install media folder, and under it what was READ off that folder.
    # FIRST in the editor (finding 2: it sat below the fold at 100% and 150%), and
    # Browse only: media is wherever the ISO was extracted, not a planned volume.
    param([string]$Label, [string]$Key, [int]$Row)
    $box = Add-DetailRow -Label $Label -Key $Key -Row $Row -Col 0
    $detail.SetColumnSpan($box, 3)
    $script:Tips.SetToolTip($box, 'The extracted SQL Server media for THIS instance: the folder holding setup.exe and MediaInfo.xml.')

    $b = New-Object System.Windows.Forms.Button
    $b.Text = 'Browse...'; $b.Anchor = 'Left'
    Initialize-SqlStackGuiButton -Button $b
    $b.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
    $b.Margin = New-Object System.Windows.Forms.Padding(8, 2, 0, 2)
    $script:Tips.SetToolTip($b, 'Choose the SQL Server install media folder. It is only read.')
    $b.Tag = $Key
    $b.Add_Click({
        $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
        $dlg.Description = 'Choose the SQL Server install media folder (the one holding setup.exe)'
        # FALSE, deliberately: media is an existing tree that is READ. Offering to
        # create a folder here would offer to make an empty one that cannot work.
        $dlg.ShowNewFolderButton = $false
        $cur = $script:DetailControls[$this.Tag].Text
        if ($cur -and (Test-Path $cur -ErrorAction SilentlyContinue)) { $dlg.SelectedPath = $cur }
        if ($dlg.ShowDialog() -eq 'OK') {
            $script:DetailControls[$this.Tag].Text = $dlg.SelectedPath
            Save-DetailToPlan
            Update-SqlStackGuiMediaStatus
            Update-Validation
        }
    })
    $detail.Controls.Add($b, 4, $Row)

    # The read-back, on its own row, spanning the table. It is NOT registered in
    # $script:DetailControls: that hashtable is the load/save map and every key in
    # it is written straight back onto the plan row, so a display-only box there
    # would be saved over the thing it displays.
    $lab = New-Object System.Windows.Forms.Label
    $lab.Text = 'Read off the media'; $lab.Anchor = 'Left'; $lab.AutoSize = $true
    $lab.Margin = New-Object System.Windows.Forms.Padding(0, 3, 8, 3)
    Add-DetailTableRow -Row ($Row + 1)
    $detail.Controls.Add($lab, 0, ($Row + 1))
    $script:MediaStatus = New-Object System.Windows.Forms.Label
    $script:MediaStatus.Anchor = 'Left,Right'; $script:MediaStatus.AutoSize = $true
    $script:MediaStatus.Margin = New-Object System.Windows.Forms.Padding(0, 3, 0, 3)
    $script:MediaStatus.Text = ''
    $detail.Controls.Add($script:MediaStatus, 1, ($Row + 1))
    $detail.SetColumnSpan($script:MediaStatus, 5)
}

# Rows 0-1: the media, FIRST (finding 2), then the instance's identity and role.
Add-DetailMediaRow -Label 'SQL install media' -Key 'MediaPath' -Row 0
[void](Add-DetailRow -Label 'Instance name'  -Key 'Name'             -Row 2 -Col 0)
[void](Add-DetailRow -Label 'Features'       -Key 'Features'         -Row 2 -Col 2 -Choices @('SQLENGINE', 'SQLENGINE,FULLTEXT'))
[void](Add-DetailRow -Label 'Throwaway'      -Key 'Throwaway'        -Row 3 -Col 0 -Check)
[void](Add-DetailRow -Label 'Listen All'     -Key 'ListenAll'        -Row 3 -Col 2 -Check)
# K4 (RULED by Adrian 2026-11-03): OFF by default; it means only "SqlStack may
# uninstall it later" (SPEC 6.3.2 leg 1).
Add-DetailNote -Row 4 -Text $(if ($script:WbAdvanced) { 'Throwaway means SqlStack may uninstall this instance later (SPEC 6.3.2). With it off, stages 6 and 7, the uninstall, cannot be planned and are greyed.' }
                              else { 'Throwaway marks an instance SqlStack may uninstall later. Leave it off for an instance you mean to keep.' })
[void](Add-DetailRow -Label 'Bind IP'        -Key 'Ip'               -Row 5 -Col 0)
$detail.SetColumnSpan($script:DetailControls['Ip'], 3)
# INV-4: planned into the spec and checked by loader rules r16 and r17. The
# install worker binds it (and adds the address first when this host lacks it).
Add-DetailNote -Row 6 -Text $(if ($script:WbAdvanced) { 'SqlStack records the IP and Listen All in the spec, and the loader checks them (rules r16 and r17). The network binding step (slice 4) is wired: a plan for an instance already on this host binds its address, and first adds that address to the network adapter when the adapter does not have it. -Apply restarts that instance only inside a maintenance window the spec names, and only after you type its name. Its first live run has not happened. The Host view lists this host''s addresses.' }
                              else { 'Leave Bind IP empty to listen on every address this host has. An address this host does not have yet is added by Install, to the network card you choose there. The Host screen lists this host''s addresses.' })
# Rows 7-11 (2026-11-16): who the two services run as, and how people sign in.
$cboEngine = Add-DetailRow -Label 'Engine account' -Key 'EngineAccount' -Row 7 -Col 0 -Choices @($script:SqlStackGuiVirtualWords) -Editable
$detail.SetColumnSpan($cboEngine, 3)
$script:Tips.SetToolTip($cboEngine, 'The account the SQL Server service runs as. Keep the built-in one, or type DOMAIN\name. A name ending in $ is a group managed account.')
$cboAgent = Add-DetailRow -Label 'Agent account' -Key 'AgentAccount' -Row 8 -Col 0 -Choices @($script:SqlStackGuiVirtualWords) -Editable
$detail.SetColumnSpan($cboAgent, 3)
$script:Tips.SetToolTip($cboAgent, 'The account the SQL Server Agent service runs as. Keep the built-in one, or type DOMAIN\name. A name ending in $ is a group managed account.')
# What the two boxes mean, in plain words, AS YOU TYPE. Display only: not in
# $script:DetailControls, so it is never saved onto a plan row.
Add-DetailTableRow -Row 9
$script:AccountNote = New-Object System.Windows.Forms.Label
$script:AccountNote.AutoSize = $true; $script:AccountNote.Anchor = 'Left,Right'; $script:AccountNote.UseMnemonic = $false
$script:AccountNote.ForeColor = $script:Ui.Secondary
$script:AccountNote.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 6)
$detail.Controls.Add($script:AccountNote, 1, 9)
$detail.SetColumnSpan($script:AccountNote, 5)
[void](Add-DetailRow -Label 'Authentication' -Key 'Authentication'   -Row 10 -Col 0 -Choices @($script:SqlStackGuiAuthWindows, $script:SqlStackGuiAuthMixed))
Add-DetailNote -Row 11 -Text 'Mixed mode also allows SQL logins; Install then asks for the sa password. No password is ever saved in the plan.'
[void](Add-DetailRow -Label 'TCP port'       -Key 'Port'             -Row 12 -Col 0 -Numeric)
[void](Add-DetailRow -Label 'Max memory MB'  -Key 'MaxMemoryMb'      -Row 12 -Col 2 -Numeric)
[void](Add-DetailRow -Label 'Min memory MB'  -Key 'MinMemoryMb'      -Row 13 -Col 0 -Numeric)
[void](Add-DetailRow -Label 'MAXDOP'         -Key 'MaxDop'           -Row 13 -Col 2 -Numeric)
[void](Add-DetailRow -Label 'Cost threshold' -Key 'CostThreshold'    -Row 14 -Col 0 -Numeric)
[void](Add-DetailRow -Label 'TempDB files'   -Key 'TempDbFileCount'  -Row 14 -Col 2 -Numeric)
[void](Add-DetailRow -Label 'TempDB MB each' -Key 'TempDbFileSizeMb' -Row 15 -Col 0 -Numeric)
# DISPLAY-ONLY (lane sqlstack-L2i, I14): no step sets a DAC port, so SQL chooses it at
# start-up and there is nothing here for an operator to type.
[void](Add-DetailRow -Label 'DAC port'       -Key 'DacPort'          -Row 15 -Col 2 -ReadOnly)
Add-DetailPathRow -Label 'Data folder'   -Key 'DataPath'   -Row 16
Add-DetailPathRow -Label 'Log folder'    -Key 'LogPath'    -Row 17
Add-DetailPathRow -Label 'TempDB folder' -Key 'TempDbPath' -Row 18
Add-DetailPathRow -Label 'Backup folder' -Key 'BackupPath' -Row 19
# Rows 20-21 (2026-11-17): the optional updates folder. Browse only, like the
# media: it is an existing folder that setup READS.
$txtUpdates = Add-DetailRow -Label 'Updates folder' -Key 'UpdatesPath' -Row 20 -Col 0
$detail.SetColumnSpan($txtUpdates, 3)
$script:Tips.SetToolTip($txtUpdates, 'Optional: a folder holding SQL Server update packages (.exe) for this instance''s version.')
$btnUpdates = New-Object System.Windows.Forms.Button
$btnUpdates.Text = 'Browse...'; $btnUpdates.Anchor = 'Left'
Initialize-SqlStackGuiButton -Button $btnUpdates
$btnUpdates.Padding = New-Object System.Windows.Forms.Padding(6, 0, 6, 0)
$btnUpdates.Margin = New-Object System.Windows.Forms.Padding(8, 2, 0, 2)
$script:Tips.SetToolTip($btnUpdates, 'Choose the folder that holds the update packages. It is only read.')
$btnUpdates.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Choose the folder that holds the SQL Server update packages (.exe)'
    $dlg.ShowNewFolderButton = $false
    $cur = $script:DetailControls['UpdatesPath'].Text
    if ($cur -and (Test-Path $cur -ErrorAction SilentlyContinue)) { $dlg.SelectedPath = $cur }
    if ($dlg.ShowDialog() -eq 'OK') {
        $script:DetailControls['UpdatesPath'].Text = $dlg.SelectedPath
        Save-DetailToPlan; Update-Validation
    }
})
$detail.Controls.Add($btnUpdates, 4, 20)
Add-DetailNote -Row 21 -Text 'Optional. With a folder here, setup applies the newest update package it finds there for this version during the install. Leave it empty and no update is applied; setup never goes to the internet.'

# D1: an installed (Fixed) row is shown READ-ONLY, as the facts that were read
# about it, in place of the editor: nothing about it can be typed or planned.
$txtFixed = New-Object System.Windows.Forms.TextBox
$txtFixed.Name = 'txtFixed'
$txtFixed.Multiline = $true; $txtFixed.ReadOnly = $true; $txtFixed.Dock = 'Fill'; $txtFixed.Visible = $false
$txtFixed.ScrollBars = 'Vertical'; $txtFixed.BorderStyle = 'None'; $txtFixed.BackColor = $script:Ui.AltRow
# Finding 3: with no editable row selected the editor is HIDDEN and this says
# why, rather than offering fields whose edits would go nowhere.
$lblEmpty = New-Object System.Windows.Forms.Label
$lblEmpty.Name = 'lblEmpty'
$lblEmpty.AutoSize = $true
$lblEmpty.Dock = 'Top'
$lblEmpty.UseMnemonic = $false
$lblEmpty.ForeColor = $script:Ui.Secondary
$lblEmpty.Padding = New-Object System.Windows.Forms.Padding(0, 6, 0, 6)
$lblEmpty.Text = 'No new instance is selected. Press Add new instance, or select one in the list. Select an installed instance to read what was read about it.'
# K7 fallback: a planning ceiling for an installed instance whose max server
# memory snapshot A did not give. Used ONLY for the memory split; never written
# to the instance, and not in $script:DetailControls (the new-row editor's map).
$pnlCeiling = New-SqlStackGuiFlow
$pnlCeiling.Dock = 'Top'
$pnlCeiling.BackColor = $script:Ui.Card
$lblCeiling = New-Object System.Windows.Forms.Label
$lblCeiling.AutoSize = $true; $lblCeiling.UseMnemonic = $false
$lblCeiling.Margin = New-Object System.Windows.Forms.Padding(0, 6, 8, 6)
$lblCeiling.Text = 'Planning ceiling MB (typed; for the memory split only, never written to the instance)'
$numCeiling = New-Object System.Windows.Forms.NumericUpDown
$numCeiling.Name = 'TypedCeilingMb'
$numCeiling.Minimum = 0; $numCeiling.Maximum = 2147483647
$numCeiling.MinimumSize = New-Object System.Drawing.Size(120, 0)
$numCeiling.Width = 120
$pnlCeiling.Controls.AddRange(@($lblCeiling, $numCeiling))
$pnlCeiling.Visible = $false
$detailBody.Controls.AddRange(@($txtFixed, $detail, $lblEmpty, $pnlCeiling))
function Set-SqlStackGuiDetailWidth {
    # The editor's floor is the panel's own width, read at run time (no pixel constant).
    $w = $detailBody.ClientSize.Width
    if (($w -gt 0) -and ($detail.MinimumSize.Width -ne $w)) { $detail.MinimumSize = New-Object System.Drawing.Size($w, 0) }
}
$detailBody.Add_Resize({ Set-SqlStackGuiDetailWidth })
Add-SqlStackGuiCardRow -Card $cardDetail -Control $detailBody

# -- bottom: validation (every finding in words) and the arithmetic --
$planBottom = New-SqlStackGuiTable -Columns @('100') -Rows @('100')
$cardVal = New-SqlStackGuiCard -Title 'Validation' -Subtitle $(if ($script:WbAdvanced) { 'Every finding, with its severity in words. An error keeps Save spec off until it is fixed. The engine''s arithmetic is in the drawer''s Arithmetic tab.' }
                                                                else { 'Every finding, with its severity in words. An error keeps Save plan and Install off until it is fixed.' })
$cardVal.Card.Margin = New-Object System.Windows.Forms.Padding(0)
$gridVal = New-Object System.Windows.Forms.DataGridView
$gridVal.Name = 'gridVal'
Set-SqlStackGuiGridLook -Grid $gridVal
$gridVal.Dock = 'Fill'
Add-SqlStackGuiCardRow -Card $cardVal -Control $gridVal

# D4: the arithmetic the file header promises, from the engine's own planners.
# It WRAPS (finding 7: unwrapped, every installed-instance line was cut off), and
# it has its own drawer tab, so it is never squeezed beside Validation.
$txtArith = New-Object System.Windows.Forms.TextBox
$txtArith.Name = 'txtArith'
$txtArith.Multiline = $true; $txtArith.ReadOnly = $true; $txtArith.Dock = 'Fill'; $txtArith.ScrollBars = 'Vertical'; $txtArith.WordWrap = $true
$txtArith.BorderStyle = 'None'; $txtArith.BackColor = $script:Ui.Card
$txtArith.Font = $script:UiFont.Mono

$planBottom.Controls.Add($cardVal.Card, 0, 0)
$viewPlan.Controls.Add($cardPlanTop.Card, 0, 0)
$viewPlan.SetColumnSpan($cardPlanTop.Card, 2)
$viewPlan.Controls.Add($cardPlanInst.Card, 0, 1)
$viewPlan.Controls.Add($cardDetail.Card, 1, 1)
$viewPlan.Controls.Add($planBottom, 0, 2)
$viewPlan.SetColumnSpan($planBottom, 2)

# ---- the stage view: stages 2-9 ----
$cardStage = New-SqlStackGuiCard -Title 'Stage' -Subtitle ''
$cardStage.Card.Name = 'viewStage'
$lblStageTitle = $cardStage.Title
$lblStageWords = $cardStage.Subtitle
$flpStage = New-SqlStackGuiFlow
$btnCompare = New-Object System.Windows.Forms.Button
$btnCompare.Text = 'Compare snapshots now'
Initialize-SqlStackGuiButton -Button $btnCompare
$script:Tips.SetToolTip($btnCompare, 'Run the engine''s Compare-SqlStackSnapshot here, over the two bundles. It only reads them.')
$btnTidy = New-Object System.Windows.Forms.Button
$btnTidy.Text = 'Mark tidy-up done'
Initialize-SqlStackGuiButton -Button $btnTidy
$script:Tips.SetToolTip($btnTidy, 'Record in the run folder that you removed what this stage lists. The window itself deletes nothing.')
$flpStage.Controls.AddRange(@($btnCompare, $btnTidy))
Add-SqlStackGuiCardRow -Card $cardStage -Control $flpStage -Fit
$txtStage = New-Object System.Windows.Forms.TextBox
$txtStage.Name = 'txtStage'
$txtStage.Multiline = $true; $txtStage.ReadOnly = $true; $txtStage.Dock = 'Fill'; $txtStage.ScrollBars = 'Vertical'; $txtStage.WordWrap = $true
$txtStage.BorderStyle = 'None'; $txtStage.BackColor = $script:Ui.Card
Add-SqlStackGuiCardRow -Card $cardStage -Control $txtStage
$viewStage = $cardStage.Card

# ---- the Install view (2026-11-16): the preview, the one button, the states, the log ----
$cardInstall = New-SqlStackGuiCard -Title 'Install' -Subtitle 'Opening this screen saves the plan and its setup files into the run folder, then lists what Install will do. Nothing on this host changes until you press Install now and confirm.'
$cardInstall.Card.Name = 'viewInstall'
# The FIRST line of the preview, shown only when Windows has a restart pending
# (the worker's preview said so). Installing anyway stays possible.
$flpPending = New-SqlStackGuiFlow
$lblPending = New-Object System.Windows.Forms.Label
$lblPending.Name = 'lblPending'
$lblPending.AutoSize = $true; $lblPending.UseMnemonic = $false
$lblPending.ForeColor = $script:Ui.Warning
$lblPending.Margin = New-Object System.Windows.Forms.Padding(0, 6, 10, 0)
$btnRestartNow = New-Object System.Windows.Forms.Button
$btnRestartNow.Name = 'btnRestartNow'
$btnRestartNow.Text = 'Restart Windows now'
Initialize-SqlStackGuiButton -Button $btnRestartNow
$script:Tips.SetToolTip($btnRestartNow, 'Restart Windows after one confirm. Nothing is installed and nothing is left behind.')
$chkIgnorePending = New-Object System.Windows.Forms.CheckBox
$chkIgnorePending.Name = 'chkIgnorePending'
$chkIgnorePending.Text = 'Install anyway (tell setup to ignore the pending restart)'
$chkIgnorePending.AutoSize = $true; $chkIgnorePending.UseMnemonic = $false
$chkIgnorePending.Margin = New-Object System.Windows.Forms.Padding(0, 6, 10, 0)
$script:Tips.SetToolTip($chkIgnorePending, 'Setup checks for a pending restart and refuses to start. Ticked, setup is told to ignore that check. The choice is saved in the run folder.')
$flpPending.Controls.AddRange(@($lblPending, $btnRestartNow, $chkIgnorePending))
$flpPending.Visible = $false
Add-SqlStackGuiCardRow -Card $cardInstall -Control $flpPending -Fit
$flpInstall = New-SqlStackGuiFlow
$btnInstall = New-Object System.Windows.Forms.Button
$btnInstall.Name = 'btnInstall'
$btnInstall.Text = 'Install now'
Initialize-SqlStackGuiButton -Button $btnInstall -Primary
$btnInstallCheck = New-Object System.Windows.Forms.Button
$btnInstallCheck.Text = 'Check again'
Initialize-SqlStackGuiButton -Button $btnInstallCheck
$script:Tips.SetToolTip($btnInstallCheck, 'Save the plan again and list again what Install will do. Nothing on this host changes.')
$flpInstall.Controls.AddRange(@($btnInstall, $btnInstallCheck))
Add-SqlStackGuiCardRow -Card $cardInstall -Control $flpInstall -Fit
$lblInstallWhy = New-Object System.Windows.Forms.Label
$lblInstallWhy.Name = 'lblInstallWhy'
$lblInstallWhy.AutoSize = $true; $lblInstallWhy.Anchor = 'Left,Right'; $lblInstallWhy.UseMnemonic = $false
$lblInstallWhy.ForeColor = $script:Ui.Secondary
$lblInstallWhy.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 4)
Add-SqlStackGuiCardRow -Card $cardInstall -Control $lblInstallWhy -Fit
# Shown only when the plan binds an address this host does not have yet.
$flpNic = New-SqlStackGuiFlow
$lblNic = New-Object System.Windows.Forms.Label
$lblNic.Text = 'Network card for the new address'; $lblNic.AutoSize = $true; $lblNic.UseMnemonic = $false
$lblNic.Margin = New-Object System.Windows.Forms.Padding(0, 6, 6, 0)
$cboNic = New-Object System.Windows.Forms.ComboBox
$cboNic.Name = 'cboNic'
$cboNic.DropDownStyle = 'DropDownList'
$cboNic.MinimumSize = New-Object System.Drawing.Size(260, 0)
$cboNic.Margin = New-Object System.Windows.Forms.Padding(0, 2, 14, 0)
$script:Tips.SetToolTip($cboNic, 'The network cards of this machine that are up. Install adds the planned address to the one you choose.')
$lblPrefix = New-Object System.Windows.Forms.Label
$lblPrefix.Text = 'Prefix length'; $lblPrefix.AutoSize = $true; $lblPrefix.UseMnemonic = $false
$lblPrefix.Margin = New-Object System.Windows.Forms.Padding(0, 6, 6, 0)
$numPrefix = New-Object System.Windows.Forms.NumericUpDown
$numPrefix.Name = 'numPrefix'
$numPrefix.Minimum = 1; $numPrefix.Maximum = 128; $numPrefix.Value = 24
$numPrefix.MinimumSize = New-Object System.Drawing.Size(70, 0)
$script:Tips.SetToolTip($numPrefix, 'The subnet prefix length of the new address: 24 is a 255.255.255.0 mask.')
$flpNic.Controls.AddRange(@($lblNic, $cboNic, $lblPrefix, $numPrefix))
$flpNic.Visible = $false
Add-SqlStackGuiCardRow -Card $cardInstall -Control $flpNic -Fit
$lblInstallNeeds = New-Object System.Windows.Forms.Label
$lblInstallNeeds.Name = 'lblInstallNeeds'
$lblInstallNeeds.AutoSize = $true; $lblInstallNeeds.Anchor = 'Left,Right'; $lblInstallNeeds.UseMnemonic = $false
$lblInstallNeeds.Margin = New-Object System.Windows.Forms.Padding(0, 4, 0, 6)
Add-SqlStackGuiCardRow -Card $cardInstall -Control $lblInstallNeeds -Fit
$gridInstall = New-Object System.Windows.Forms.DataGridView
$gridInstall.Name = 'gridInstall'
Set-SqlStackGuiGridLook -Grid $gridInstall
$gridInstall.Dock = 'Fill'
Add-SqlStackGuiCardRow -Card $cardInstall -Control $gridInstall
$lblInstallResult = New-Object System.Windows.Forms.Label
$lblInstallResult.Name = 'lblInstallResult'
$lblInstallResult.AutoSize = $true; $lblInstallResult.Anchor = 'Left,Right'; $lblInstallResult.UseMnemonic = $false
$lblInstallResult.Font = $script:UiFont.Strong
$lblInstallResult.Margin = New-Object System.Windows.Forms.Padding(0, 8, 0, 6)
Add-SqlStackGuiCardRow -Card $cardInstall -Control $lblInstallResult -Fit
# Shown only after an install that ended "reboot needed".
$flpReboot = New-SqlStackGuiFlow
$btnRestartContinue = New-Object System.Windows.Forms.Button
$btnRestartContinue.Name = 'btnRestartContinue'
$btnRestartContinue.Text = 'Restart Windows now and continue'
Initialize-SqlStackGuiButton -Button $btnRestartContinue -Primary
$script:Tips.SetToolTip($btnRestartContinue, 'After one confirm: Windows restarts, and SqlStack opens again on this run folder when you sign in. It asks for the passwords again; none is stored.')
$btnContinueLater = New-Object System.Windows.Forms.Button
$btnContinueLater.Name = 'btnContinueLater'
$btnContinueLater.Text = 'Continue later'
Initialize-SqlStackGuiButton -Button $btnContinueLater
$script:Tips.SetToolTip($btnContinueLater, 'Leave it here. Nothing is left behind: restart Windows when it suits you, open this run folder again and press Install.')
$flpReboot.Controls.AddRange(@($btnRestartContinue, $btnContinueLater))
$flpReboot.Visible = $false
Add-SqlStackGuiCardRow -Card $cardInstall -Control $flpReboot -Fit
$txtInstallLog = New-Object System.Windows.Forms.TextBox
$txtInstallLog.Name = 'txtInstallLog'
$txtInstallLog.Multiline = $true; $txtInstallLog.ReadOnly = $true; $txtInstallLog.Dock = 'Fill'; $txtInstallLog.ScrollBars = 'Both'; $txtInstallLog.WordWrap = $false
$txtInstallLog.BorderStyle = 'None'; $txtInstallLog.BackColor = $script:Ui.AltRow
$txtInstallLog.Font = $script:UiFont.Mono
Add-SqlStackGuiCardRow -Card $cardInstall -Control $txtInstallLog
$viewInstall = $cardInstall.Card

$centre.Controls.AddRange(@($viewHost, $viewPlan, $viewStage, $viewInstall))
# The centre has a FLOOR, in lines of its own font (so it follows the display
# scale), and SCROLLS below it: at the window's minimum size the views would
# otherwise squeeze a grid shorter than one of its rows (MEASURED by the lane's
# harness at 150%). AutoScrollMinSize grows the area the docked views fill.
$centre.AutoScroll = $true
function Set-SqlStackGuiCentreFloor { $centre.AutoScrollMinSize = New-Object System.Drawing.Size(0, ($centre.Font.Height * 46)) }
$centre.Add_FontChanged({ Set-SqlStackGuiCentreFloor })

# ===========================================================================
# THE DRAWER: the exact command to run next (from the ONE builder), and the
# stage's file
# ===========================================================================
$cardDrawer = New-SqlStackGuiCard -Title 'Next step' -Subtitle ''
$lblDrawerTitle = $cardDrawer.Title
$lblDrawerNote = $cardDrawer.Subtitle
$txtCommand = New-Object System.Windows.Forms.TextBox
$txtCommand.Name = 'txtCommand'
$txtCommand.Multiline = $true; $txtCommand.ReadOnly = $true; $txtCommand.Dock = 'Fill'; $txtCommand.ScrollBars = 'Vertical'; $txtCommand.WordWrap = $true
$txtCommand.BorderStyle = 'None'; $txtCommand.BackColor = $script:Ui.AltRow
$txtCommand.Font = $script:UiFont.Mono
Add-SqlStackGuiCardRow -Card $cardDrawer -Control $txtCommand
$flpDrawer = New-SqlStackGuiFlow
$btnCopy = New-Object System.Windows.Forms.Button
$btnCopy.Text = 'Copy command'
Initialize-SqlStackGuiButton -Button $btnCopy -Primary
$btnCopySnippet = New-Object System.Windows.Forms.Button
$btnCopySnippet.Text = 'Copy reboot check'
Initialize-SqlStackGuiButton -Button $btnCopySnippet
$btnCopyCompare = New-Object System.Windows.Forms.Button
$btnCopyCompare.Text = 'Copy compare block'
Initialize-SqlStackGuiButton -Button $btnCopyCompare
$flpDrawer.Controls.AddRange(@($btnCopy, $btnCopySnippet, $btnCopyCompare))
Add-SqlStackGuiCardRow -Card $cardDrawer -Control $flpDrawer -Fit
$lblPreview = New-Object System.Windows.Forms.Label
$lblPreview.Name = 'lblPreview'
$lblPreview.AutoSize = $true; $lblPreview.Anchor = 'Left,Right'; $lblPreview.UseMnemonic = $false
$lblPreview.Font = $script:UiFont.Strong
$lblPreview.Margin = New-Object System.Windows.Forms.Padding(0, 10, 0, 4)
$lblPreview.Text = 'Preview'
Add-SqlStackGuiCardRow -Card $cardDrawer -Control $lblPreview -Fit
$revTabs = New-Object System.Windows.Forms.TabControl
$revTabs.Dock = 'Fill'
$revTabs.Margin = New-Object System.Windows.Forms.Padding(0)
Set-SqlStackGuiTabLook -Tabs $revTabs
$txtPreview = New-Object System.Windows.Forms.TextBox
$txtPreview.Name = 'txtPreview'
$txtPreview.Multiline = $true; $txtPreview.ScrollBars = 'Both'; $txtPreview.WordWrap = $false; $txtPreview.BorderStyle = 'None'
$txtPreview.Font = $script:UiFont.Mono; $txtPreview.Dock = 'Fill'; $txtPreview.ReadOnly = $true; $txtPreview.BackColor = $script:Ui.Card
$txtIni = New-Object System.Windows.Forms.TextBox
$txtIni.Name = 'txtIni'
$txtIni.Multiline = $true; $txtIni.ScrollBars = 'Both'; $txtIni.WordWrap = $false; $txtIni.BorderStyle = 'None'
$txtIni.Font = $script:UiFont.Mono; $txtIni.Dock = 'Fill'; $txtIni.ReadOnly = $true; $txtIni.BackColor = $script:Ui.Card
$txtSql = New-Object System.Windows.Forms.TextBox
$txtSql.Name = 'txtSql'
$txtSql.Multiline = $true; $txtSql.ScrollBars = 'Both'; $txtSql.WordWrap = $false; $txtSql.BorderStyle = 'None'
$txtSql.Font = $script:UiFont.Mono; $txtSql.Dock = 'Fill'; $txtSql.ReadOnly = $true; $txtSql.BackColor = $script:Ui.Card
$tpPreview = New-Object System.Windows.Forms.TabPage; $tpPreview.Text = 'File'; $tpPreview.Controls.Add($txtPreview)
$tpArith = New-Object System.Windows.Forms.TabPage; $tpArith.Text = 'Arithmetic'; $tpArith.Controls.Add($txtArith)
# D2(i): one file of each kind PER NEW INSTANCE, each under its own separator line.
$tpIni = New-Object System.Windows.Forms.TabPage; $tpIni.Text = '.ini (unguarded)'; $tpIni.Controls.Add($txtIni)
$tpSql = New-Object System.Windows.Forms.TabPage; $tpSql.Text = '.sql (unguarded)'; $tpSql.Controls.Add($txtSql)
$revTabs.TabPages.AddRange(@($tpPreview, $tpArith, $tpIni, $tpSql))
Add-SqlStackGuiCardRow -Card $cardDrawer -Control $revTabs

$body.Controls.Add($cardRail.Card, 0, 0)
$body.Controls.Add($centre, 1, 0)
# The drawer (the command to paste, the file previews) only with -Advanced.
if ($script:WbAdvanced) { $body.Controls.Add($cardDrawer.Card, 2, 0) }
$root.Controls.Add($hdr, 0, 0)
$root.Controls.Add($body, 0, 1)
$form.Controls.AddRange(@($root, $status))

# ===========================================================================
# Behaviour
# ===========================================================================
function Update-PlanList {
    $sel = $lstPlan.SelectedIndex
    $lstPlan.Items.Clear()
    foreach ($p in $script:Plan) {
        $lstPlan.Items.Add(("{0,-16} {1,6}  {2}" -f $p.Name, $(if ($p.Port) { $p.Port } else { '-' }), $(if ($p.Fixed) { 'locked' } else { 'new' }))) | Out-Null
    }
    if ($sel -ge 0 -and $sel -lt $lstPlan.Items.Count) { $lstPlan.SelectedIndex = $sel }
    elseif ($lstPlan.Items.Count -gt 0) { $lstPlan.SelectedIndex = $lstPlan.Items.Count - 1 }
}

function Load-PlanToDetail {
    $i = $lstPlan.SelectedIndex
    $none = ($i -lt 0 -or $i -ge $script:Plan.Count)
    $p = $(if ($none) { $null } else { $script:Plan[$i] })
    # Finding 4: an installed row can never be removed from the plan.
    $btnRemove.Enabled = ((-not $none) -and (-not $p.Fixed) -and (-not $script:WbReadOnly))
    if ($none) {
        # Finding 3: no row, no editor.
        $detail.Visible = $false; $txtFixed.Visible = $false; $lblEmpty.Visible = $true
        $lblDetailTitle.Text = 'Selected instance'
        $lblDetailNote.Text = 'Nothing is selected.'
        return
    }
    $lblEmpty.Visible = $false
    # D1: an installed row shows its facts, read-only; the editor is hidden.
    $detail.Visible = (-not $p.Fixed)
    $txtFixed.Visible = [bool]$p.Fixed
    $lblDetailTitle.Text = $(if ($p.Fixed) { ('{0}: installed, locked' -f $p.Name) } else { ('{0}: new' -f $p.Name) })
    $lblDetailNote.Text = $(if ($p.Fixed) { 'The facts read about it, and what could not be read. Nothing here can be changed, and no file is written for it.' }
                            elseif ($script:WbReadOnly) { 'Read only: this run folder''s spec could not be loaded for editing (the banner above says why).' }
                            else { 'The planned values. Change any of them, and Validation checks the plan again.' })
    $lblDetailNote.Visible = $true
    $pnlCeiling.Visible = ([bool]$p.Fixed -and ([string]$p.CeilingSource -ne 'snapshot'))
    if ($p.Fixed) {
        $script:Loading = $true
        $numCeiling.Value = [Math]::Max(0, [int]$p.TypedCeilingMb)
        $script:Loading = $false
        $txtFixed.Text = (@($p.Facts) -join "`r`n"); return
    }
    $detail.Enabled = (-not $script:WbReadOnly)
    $script:Loading = $true
    foreach ($k in $script:DetailControls.Keys) {
        $c = $script:DetailControls[$k]
        $v = $p.$k
        if ($c -is [System.Windows.Forms.NumericUpDown]) {
            $n = 0; if ($v) { $n = [int]$v }
            if ($n -lt $c.Minimum) { $n = [int]$c.Minimum }
            if ($n -gt $c.Maximum) { $n = [int]$c.Maximum }
            $c.Value = $n
        } elseif ($c -is [System.Windows.Forms.CheckBox]) { $c.Checked = [bool]$v }
        elseif (($c -is [System.Windows.Forms.ComboBox]) -and ([string]$c.DropDownStyle -eq 'DropDown')) { $c.Text = $(if ([string]::IsNullOrWhiteSpace([string]$v)) { [string]$c.Items[0] } else { [string]$v }) }
        elseif ($c -is [System.Windows.Forms.ComboBox]) { $c.SelectedIndex = [Math]::Max(0, $c.Items.IndexOf([string]$v)) }
        else { $c.Text = [string]$v }
    }
    $script:Loading = $false
    Update-SqlStackGuiAccountNote
    # After $script:Loading is cleared, so the read-back reflects the row now
    # shown rather than the one that was shown when this call started.
    Update-SqlStackGuiMediaStatus
}

function Save-DetailToPlan {
    if ($script:Loading) { return }
    if ($script:WbReadOnly) { return }
    $i = $lstPlan.SelectedIndex
    if ($i -lt 0 -or $i -ge $script:Plan.Count) { return }
    $p = $script:Plan[$i]
    # D1: the editor never writes an installed (Fixed) row.
    if ($p.Fixed) { return }
    foreach ($k in $script:DetailControls.Keys) {
        $c = $script:DetailControls[$k]
        if ($c -is [System.Windows.Forms.NumericUpDown]) { $p.$k = [int]$c.Value }
        elseif ($c -is [System.Windows.Forms.CheckBox]) { $p.$k = [bool]$c.Checked }
        elseif (($c -is [System.Windows.Forms.ComboBox]) -and ([string]$c.DropDownStyle -eq 'DropDown')) { $p.$k = [string]$c.Text }
        elseif ($c -is [System.Windows.Forms.ComboBox]) { $p.$k = [string]$c.SelectedItem }
        else { $p.$k = [string]$c.Text }
    }
}

function Update-SqlStackGuiAccountNote {
    # The line under the two account boxes, as you type (Get-SqlStackGuiAccountNote).
    $n = Get-SqlStackGuiAccountNote -Engine ([string]$script:DetailControls['EngineAccount'].Text) -Agent ([string]$script:DetailControls['AgentAccount'].Text)
    $script:AccountNote.Text = $n.Text
    $script:AccountNote.ForeColor = $(if ($n.Ok) { $script:Ui.Secondary } else { $script:Ui.Error })
}

function Get-SqlStackGuiCurrentSpec {
    # The spec Save spec would write NOW, from the plan rows (the preview and the
    # writer both call this, so what is previewed is what is saved). -Absent:
    # the uninstall copy, the throwaway instances marked absent.
    param([switch]$Absent)
    return (New-SqlStackGuiSpec -Plan $script:Plan.ToArray() -Installed @($script:Instances) `
                -HostName $env:COMPUTERNAME -PortBase $script:PortBaseInUse `
                -Edition ([string]$cboEdition.SelectedItem) -SysAdmin $script:WbSysAdmin -Browser $script:BrowserRead -AbsentThrowaway:$Absent)
}

function Update-SqlStackGuiActions {
    # The Plan view's actions. Save spec (the primary): no error, a NEW instance,
    # not read-only, and the spec writer has no problem. Preview .ini/.sql keeps
    # Generate's rule (Get-SqlStackGuiActionState). Export only once the preview
    # matches the plan as it is now. Each off state says why, in words.
    param([int]$Errors, [int]$NewRows)
    $has = Test-SqlStackGuiHasFileSet -FileSet $script:LastFileSet
    $cur = $has -and ((Get-SqlStackGuiPlanFingerprint -Plan $script:Plan.ToArray()) -eq $script:LastFileSetFingerprint)
    $state = Get-SqlStackGuiActionState -Errors $Errors -NewRows $NewRows -HasFileSet $has -FileSetCurrent $cur
    $specNow = Get-SqlStackGuiCurrentSpec
    $sa = Get-SqlStackGuiSpecActionState -Errors $Errors -NewRows $NewRows -ReadOnly ([bool]$script:WbReadOnly) -SpecProblems @($specNow.Problems)
    $btnSpec.Enabled = $sa.Enabled
    $btnGen.Enabled = ($state.GenerateEnabled -and (-not $script:WbReadOnly))
    $btnSave.Enabled = ($has -and $cur)
    $btnAdd.Enabled = (-not $script:WbReadOnly)
    $lblGenReason.Text = $(if (-not $sa.Enabled) { $sa.Reason } elseif ($has -and (-not $cur) -and $script:WbAdvanced) { 'The plan changed after the .ini/.sql preview: preview again before Export.' } else { $sa.Reason })
    # Without -Advanced the button reads Save plan, so its reason does too.
    if (-not $script:WbAdvanced) { $lblGenReason.Text = ([string]$lblGenReason.Text -creplace 'Save spec', 'Save plan') }
    $script:Tips.SetToolTip($btnGen, $(if ($btnGen.Enabled) { 'Show the .ini and .sql for the NEW instances in the drawer. Nothing is run, and nothing is written until you Export.' } else { $state.Reason }))
}

function Update-Validation {
    # The Validation grid's columns are made here, after the form's scaling
    # pass: they size from their content, with no pixel constant to scale.
    if ($gridVal.Columns.Count -eq 0) {
        [void](Add-SqlStackGuiGridColumn -Grid $gridVal -Name 'Severity' -Tip 'ERROR keeps Save spec off until it is fixed. WARN and INFO are for a human to weigh.')
        [void](Add-SqlStackGuiGridColumn -Grid $gridVal -Name 'Area')
        [void](Add-SqlStackGuiGridColumn -Grid $gridVal -Name 'Finding' -Fill -Wrap)
    }
    $gridVal.Rows.Clear()
    # D4: the validator gets the same -KnownInstancePorts the planners get, and
    # the installed names; the Arithmetic box shows the engine's working for the
    # rows as they are now (the same computation the validator runs).
    $kip = $(if ($script:KnownInstancePorts) { $script:KnownInstancePorts } else { @{} })
    $installedNames = [string[]]@(@($script:Instances) | ForEach-Object { [string]$_.Name })
    $findings = Test-SqlStackPlan -Plan $script:Plan.ToArray() -Volumes $script:Volumes `
                    -ExcludedRanges $script:ExcludedRanges -PortsInUse $script:PortsInUse `
                    -PhysicalMb $script:PhysicalMb -KnownInstancePorts $kip -InstalledNames $installedNames -RequireMedia
    # The updates folders are the window's own (not the engine's plan): a
    # folder that is missing or holds no .exe is a WARN row, never an error.
    $findings = @($findings) + @(Get-SqlStackGuiUpdatesFinding -Plan $script:Plan.ToArray())
    $inPlan = @($script:Plan | ForEach-Object { [string]$_.Name })
    $notIn = [string[]]@($installedNames | Where-Object { $inPlan -notcontains $_ })
    $shown = Get-SqlStackGuiPlanComputation -Plan $script:Plan.ToArray() -PhysicalMb $script:PhysicalMb -LogicalCores $script:LogicalCores `
                -PortBase $script:PortBaseInUse -ExcludedRanges $script:ExcludedRanges -PortsInUse $script:PortsInUse `
                -KnownInstancePorts $kip -InstalledNotInPlan $notIn
    $txtArith.Text = Format-SqlStackGuiArithmetic -Computation $shown
    $errors = 0; $warns = 0
    foreach ($f in $findings) {
        # The severity is a WORD in its own column; its colour only repeats it,
        # and the selection keeps it (finding 8).
        $vi = $gridVal.Rows.Add(@([string]$f.Severity, [string]$f.Area, [string]$f.Message))
        $sevCell = $gridVal.Rows[$vi].Cells['Severity']
        switch ($f.Severity) {
            'ERROR' { Set-SqlStackGuiCellColor -Cell $sevCell -Color $script:Ui.Error; $errors++ }
            'WARN'  { Set-SqlStackGuiCellColor -Cell $sevCell -Color $script:Ui.Warning; $warns++ }
            default { Set-SqlStackGuiCellColor -Cell $sevCell -Color $script:Ui.Info }
        }
    }
    Update-SqlStackGuiFillColumns -Grid $gridVal
    $newRows = @($script:Plan | Where-Object { -not $_.Fixed }).Count
    $statusCounts.Text = Get-SqlStackGuiCountText -Errors $errors -Warnings $warns -ReadOnly:([bool]$script:WbReadOnly)
    # Finding 13: grey, not green, while no new instance is planned.
    $statusMarker.ForeColor = $(if ($errors -gt 0) { $script:Ui.Error } elseif ($newRows -eq 0) { $script:Ui.Secondary } elseif ($warns -gt 0) { $script:Ui.Warning } else { $script:Ui.Ok })
    $script:ValidationCounts = @{ Errors = $errors; Warnings = $warns }
    # D1: there is something to save only when a NEW instance is planned.
    Update-SqlStackGuiActions -Errors $errors -NewRows $newRows
    if ($script:WbSelectedStage -eq 1) { Update-SqlStackGuiDrawer }
}

function Show-SqlStackGuiFile {
    # Read-only navigation inside the drawer's .ini / .sql tabs. Nothing is
    # run, written or changed.
    param([string]$Name)
    if ($null -eq $script:LastFileSet) { return }
    $f = @($script:LastFileSet | Where-Object { $_.Name -eq $Name }) | Select-Object -First 1
    if (-not $f) { return }
    $isIni = ($f.Kind -eq 'ini')
    $view = $(if ($isIni) { $txtIni } else { $txtSql })
    $revTabs.SelectedTab = $(if ($isIni) { $tpIni } else { $tpSql })
    $mark = $(if ($isIni) { ('; ======== file {0} ========' -f $f.Name) } else { ('-- ======== file {0} ========' -f $f.Name) })
    $at = $view.Text.IndexOf($mark)
    if ($at -ge 0) { $view.SelectionStart = $at; $view.SelectionLength = 0; $view.ScrollToCaret() }
}

function Add-SqlStackGuiInstalledRows {
    # Finding 4 + D1: EVERY installed instance joins the plan automatically, as a
    # FIXED row built from what was read about it: a locked constraint, never a
    # claimant, never removed and never rendered. Replaces 'Import existing'.
    # Census: 'D1-import-builds-fixed'.
    $added = 0
    foreach ($inst in $script:Instances) {
        if (@($script:Plan | Where-Object { $_.Name -eq $inst.Name }).Count -gt 0) { continue }
        $nm = [string]$inst.Name
        $obs = @($script:ObservedInstancePorts | Where-Object { [string]$_.Name -eq $nm }) | Select-Object -First 1
        $tcpRead = $(if ($script:TcpReads -and $script:TcpReads.ContainsKey($nm)) { $script:TcpReads[$nm] } else { $null })
        $tcp = Get-SqlStackGuiTcpText -Name $nm -FixedRow $obs -Map $script:KnownInstancePorts -TcpRead $tcpRead
        $owned = @()
        try { $owned = @(Get-SqlStackInstanceOwnedPathRows -InstanceId ([string]$inst.InstanceId)) }
        catch { $owned = @([pscustomobject]@{ Kind = 'DefaultData'; Status = 'could-not-read'; Path = ''; Reason = $_.Exception.Message }) }
        $row = New-PlanRowFromInstalled -Instance $inst -ObservedPort $obs -TcpText $tcp.Text -OwnedPathRows $owned -Ordinal ($script:Plan.Count + 1)
        $script:Plan.Insert($added, $row)
        $added++
    }
    $o = 0; foreach ($p in $script:Plan) { $o++; $p.Ordinal = $o }
    return $added
}

# ---- the run folder, the stage reader, the rail, the centre and the drawer ----
function Set-SqlStackGuiRunFolder {
    # Open (create) a run folder, move the trace log into it (K6) unless the
    # operator named a -LogPath, and load its spec.json back into the plan (S3).
    param([Parameter(Mandatory)][string]$Root)
    $full = Initialize-SqlStackGuiRunFolder -Root $Root
    $script:WbRoot = $full
    if ($script:WbLogFollowsRun) {
        Write-SqlStackGuiLog 'RUN' ('the trace log moves to the run folder: ' + (Get-SqlStackGuiRunPath -Root $full -Item 'WindowLog'))
        [void](Open-SqlStackGuiLog -Path (Get-SqlStackGuiRunPath -Root $full -Item 'WindowLog'))
    }
    Write-SqlStackGuiLog 'RUN' ('run folder: ' + $full + '; state folder: ' + $script:WbStatePath)
    $lblRunFolder.Text = (('Run folder: {0}' -f $full) + "`r`n" + ('State folder (one for the whole host, shared by every run): {0}' -f $script:WbStatePath))
    Update-SqlStackGuiRunState
    Import-SqlStackGuiRunSpec
}

function Import-SqlStackGuiRunSpec {
    # S3: the run folder's spec.json, as the ONE stage reader read it, back into
    # the plan. A spec this window can write back unchanged is EDITABLE; anything
    # else (invalid JSON, a loader error, a key or value this window does not
    # model, another host) is shown READ-ONLY and the banner names why. Nothing is
    # ever silently dropped.
    $sp = $script:WbState.Spec
    $script:WbReadOnly = $false; $script:WbReadOnlyReason = ''
    # Update-Validation too: the status counts name a read-only spec (gate F13), and
    # a run folder with no spec must not keep the last folder's words.
    if (-not $sp.Exists) { Update-SqlStackGuiReadOnly; Update-Validation; return }
    $why = New-Object System.Collections.ArrayList
    if (-not $sp.ParseOk) { [void]$why.Add(('spec.json cannot be read: {0}' -f $sp.Problem)) }
    else {
        $imp = ConvertFrom-SqlStackGuiSpec -Doc $sp.Doc
        $rt = Test-SqlStackGuiSpecRoundTrip -Doc $sp.Doc -Import $imp -Installed @($script:Instances) -HostName $env:COMPUTERNAME -Browser $script:BrowserRead
        # Replace the NEW rows with the file's; installed rows stay as read.
        $keep = @($script:Plan | Where-Object { $_.Fixed })
        $script:Plan.Clear()
        foreach ($r in $keep) { [void]$script:Plan.Add($r) }
        # The updates folders are not in the spec: they come back from install.json.
        $impUpdates = (Read-SqlStackGuiInstallChoice -Root $script:WbRoot).Updates
        foreach ($r in @($imp.Rows)) { $r.Ordinal = $script:Plan.Count + 1; if ($impUpdates.ContainsKey([string]$r.Name)) { $r.UpdatesPath = [string]$impUpdates[[string]$r.Name] }; [void]$script:Plan.Add($r) }
        if ($imp.Edition -and ($cboEdition.Items.IndexOf($imp.Edition) -ge 0)) { $cboEdition.SelectedItem = $imp.Edition }
        if (@($imp.SysAdmin).Count -gt 0) { $script:WbSysAdmin = [string[]]@($imp.SysAdmin) }
        foreach ($x in @($imp.Problems)) { [void]$why.Add($x) }
        if (-not $rt.Same) { [void]$why.Add(('this window cannot write it back unchanged; it differs at: {0}' -f ((@($rt.Differences) | Select-Object -First 8) -join '; '))) }
        if (-not $sp.Ok) { foreach ($e in @($sp.Errors)) { [void]$why.Add(('the loader rejects it: ' + $e)) } }
        foreach ($p in @($script:Plan | Where-Object { -not $_.Fixed })) { $m = Read-SqlStackGuiMedia -MediaPath ([string]$p.MediaPath); $p.MediaBaseline = [string]$m.Baseline; $p.MediaProblem = [string]$m.Problem }
    }
    if ($why.Count -gt 0) {
        $script:WbReadOnly = $true
        $script:WbReadOnlyReason = ('READ ONLY: ' + ((@($why)) -join "`r`n"))
    }
    Write-SqlStackGuiLog 'SPEC' ('loaded spec.json from the run folder: read-only={0}; {1}' -f $script:WbReadOnly, $script:WbReadOnlyReason)
    # NO Update-ComputedPlan here: its write-back would replace the loaded
    # max memory with the split's, and the file would no longer round-trip.
    Update-PlanList; Load-PlanToDetail
    Update-SqlStackGuiReadOnly
    Update-Validation
}

function Update-SqlStackGuiReadOnly {
    # The banner names the FIRST reason and how many more there are; every reason
    # is in its tooltip and in the trace log, so none is dropped and the banner
    # does not squeeze the plan (MEASURED: a hand-written spec gave eleven).
    $lines = @(([string]$script:WbReadOnlyReason) -split "`r`n" | Where-Object { $_ })
    $lblReadOnly.Visible = [bool]$script:WbReadOnly
    $lblReadOnly.Text = $(if ($lines.Count -le 1) { [string]$script:WbReadOnlyReason } else { ('{0}  (and {1} more reason(s): hover here to read them all)' -f $lines[0], ($lines.Count - 1)) })
    $script:Tips.SetToolTip($lblReadOnly, ([string]$script:WbReadOnlyReason))
}

function Update-SqlStackGuiRunState {
    # INV-3: THE ONE call of the ONE stage reader. Everything the rail, the
    # centre and the drawer show about a stage comes from what this returns.
    $names = [string[]]@(@($script:Instances) | ForEach-Object { [string]$_.Name })
    $script:WbState = Get-SqlStackGuiRunState -Root $script:WbRoot -StatePath $script:WbStatePath -InstalledInstance $names -HostName $env:COMPUTERNAME
    # K7: the installed rows' max server memory, from snapshot A when it is here.
    $script:WbCeilings = Read-SqlStackGuiMemoryCeiling -Snapshot $script:WbState.SnapshotA -Installed $names -MapRoot $script:WbMapRoot
    Set-SqlStackGuiInstalledCeiling -Plan $script:Plan.ToArray() -Ceilings $script:WbCeilings
    Update-SqlStackGuiRail
}

function Update-SqlStackGuiRail {
    if ($gridStages.Columns.Count -eq 0) {
        [void](Add-SqlStackGuiGridColumn -Grid $gridStages -Name 'Stage' -Fill -Wrap)
        [void](Add-SqlStackGuiGridColumn -Grid $gridStages -Name 'Status' -Tip 'Read from the files in the run folder and the state folder: not started, running, done, check it, FAILED, stale (the spec changed after it), or greyed (it cannot happen yet).')
    }
    # Each row's Tag is the view it opens: 0 Host, 1 Plan, 10 Install, 2-9 a
    # stage. Without -Advanced the rail is Host, Plan, Install; with it the
    # older stages follow, unchanged.
    $script:WbRailUpdating = $true
    $gridStages.Rows.Clear()
    $ri = $gridStages.Rows.Add(@($(if ($script:WbAdvanced) { 'Host (read only)' } else { 'Host' }), 'read'))
    $gridStages.Rows[$ri].Tag = 0
    foreach ($s in @($script:WbState.Stages)) {
        if ((-not $script:WbAdvanced) -and ($s.Id -ne 1)) { continue }
        $w = Get-SqlStackGuiStatusWord -Status $s.Status
        $ri = $gridStages.Rows.Add(@($(if ($script:WbAdvanced) { ('{0}  {1}{2}' -f $s.Id, $s.Name, $(if ($s.Elevated) { ' (elevated)' } else { '' })) } else { [string]$s.Name }), $w.Word))
        $gridStages.Rows[$ri].Tag = [int]$s.Id
        Set-SqlStackGuiCellColor -Cell $gridStages.Rows[$ri].Cells['Status'] -Color $script:Ui[$w.Color]
        $gridStages.Rows[$ri].Cells['Status'].ToolTipText = [string]$s.Words
        if ($s.Id -eq 1) {
            # Install sits straight after Plan.
            $ri = $gridStages.Rows.Add(@('Install', ''))
            $gridStages.Rows[$ri].Tag = 10
        }
    }
    Update-SqlStackGuiInstallRailWord
    Update-SqlStackGuiFillColumns -Grid $gridStages
    foreach ($row in @($gridStages.Rows)) { if ([int]$row.Tag -eq [int]$script:WbSelectedStage) { $gridStages.CurrentCell = $row.Cells[0]; break } }
    $script:WbRailUpdating = $false
}

function Update-SqlStackGuiInstallRailWord {
    # The Install row's status, in place (the rail is not rebuilt): from the
    # last finished install, else the running one, else the preview.
    $word = 'not opened'; $color = 'Secondary'; $tip = 'Select Install to save the plan and see what it will do.'
    if ($script:InstallRunning) { $word = 'running'; $color = 'Info'; $tip = 'Install is running.' }
    elseif ($script:InstallOutcome) {
        switch ([string]$script:InstallOutcome.Kind) {
            'Done'   { $word = 'done'; $color = 'Ok' }
            'Reboot' { $word = 'reboot needed'; $color = 'Warning' }
            'NotRun' { $word = 'not run'; $color = 'Warning' }
            default  { $word = 'FAILED'; $color = 'Error' }
        }
        $tip = [string]$script:InstallOutcome.Next
    } elseif ($script:InstallSave) {
        $act = Get-SqlStackGuiInstallAction -IsElevated $script:IsElevated -Model $script:InstallPreview -SaveProblem $(if ($script:InstallSave.Ok) { '' } else { [string]$script:InstallSave.Reason })
        if ($act.Kind -eq 'Off') { $word = 'not ready'; $color = 'Warning' } else { $word = 'ready'; $color = 'Info' }
        $tip = [string]$act.Reason
    }
    foreach ($row in @($gridStages.Rows)) {
        if ([int]$row.Tag -ne 10) { continue }
        $row.Cells['Status'].Value = $word
        Set-SqlStackGuiCellColor -Cell $row.Cells['Status'] -Color $script:Ui[$color]
        $row.Cells['Status'].ToolTipText = $tip
    }
}

function Show-SqlStackGuiStage {
    # The rail's selection: 0 = the Host view, 1 = the Plan view, 2-9 = a
    # stage, 10 = the Install view.
    param([int]$Index)
    $script:WbSelectedStage = $Index
    $isStage = (($Index -ge 2) -and ($Index -le 9))
    $viewHost.Visible = ($Index -eq 0)
    $viewPlan.Visible = ($Index -eq 1)
    $viewStage.Visible = $isStage
    $viewInstall.Visible = ($Index -eq 10)
    if ($isStage) { Update-SqlStackGuiStageView }
    Update-SqlStackGuiDrawer
    if ($Index -eq 10) {
        # AFTER this event returns: the preview saves the plan, which redraws
        # the rail, and a grid may not be rebuilt inside its own selection event.
        if ($form.IsHandleCreated) { [void]$form.BeginInvoke([System.Action]{ Update-SqlStackGuiInstallPreview }) }
        else { Update-SqlStackGuiInstallPreview }
    }
}

function Update-SqlStackGuiStageView {
    $s = @($script:WbState.Stages | Where-Object { $_.Id -eq $script:WbSelectedStage }) | Select-Object -First 1
    if (-not $s) { return }
    $w = Get-SqlStackGuiStatusWord -Status $s.Status
    $lblStageTitle.Text = ('{0}. {1}: {2}' -f $s.Id, $s.Name, $w.Word)
    $lblStageWords.Text = [string]$s.Words
    $lblStageWords.ForeColor = $script:Ui[$w.Color]
    $lblStageWords.Visible = $true
    $btnCompare.Visible = ($s.Id -eq 8)
    $btnCompare.Enabled = (($script:WbState.SnapshotA.Status -eq 'Done') -and ($script:WbState.SnapshotB.Status -eq 'Done'))
    $btnTidy.Visible = ($s.Id -eq 9)
    $btnTidy.Enabled = ($s.Status -ne 'Done')
    $lines = New-Object System.Collections.ArrayList
    foreach ($d in @($s.Detail)) { [void]$lines.Add([string]$d) }
    if (($s.Id -eq 8) -and $script:WbCompareText) { [void]$lines.Add(''); [void]$lines.Add($script:WbCompareText) }
    if ($lines.Count -eq 0) { [void]$lines.Add('Nothing more to say about this stage yet.') }
    $txtStage.Text = ($lines -join "`r`n")
}

function Update-SqlStackGuiDrawer {
    # The drawer for the selected stage. Its command text comes ONLY from the ONE
    # builder (census 'W4-one-command-builder'); a stage with no command shows the
    # builder's reason instead, and its Copy button is off.
    $id = [int]$script:WbSelectedStage
    $s = @($script:WbState.Stages | Where-Object { $_.Id -eq $id }) | Select-Object -First 1
    if (($id -eq 0) -or ($id -eq 10)) {
        $lblDrawerTitle.Text = $(if ($id -eq 0) { 'Host (read only)' } else { 'Install' })
        $lblDrawerNote.Text = $(if ($id -eq 0) { 'Nothing to run: this view only shows what was read about this host.' } else { 'Nothing to paste: Install runs from its own button, in the centre.' })
        # Gate F1: the note is the card's subtitle, born hidden (an empty -Subtitle);
        # it is shown whenever it has text. Census 'V1-hidden-text-shown'.
        $lblDrawerNote.Visible = $true
        $txtCommand.Text = ''
        $btnCopy.Enabled = $false; $btnCopySnippet.Enabled = $false; $btnCopyCompare.Enabled = $false
        $lblPreview.Text = 'Preview'
        $txtPreview.Text = ''
        return
    }
    $cmd = Get-SqlStackGuiCommand -Stage $id -State $script:WbState -ToolDir $script:WbToolDir -MapRoot $script:WbMapRoot
    $lblDrawerTitle.Text = ('Next step: {0}. {1}' -f $id, $s.Name)
    $lblDrawerNote.Text = $(if ($cmd.Ok) { $(if ($cmd.Elevated) { 'Run it in YOUR OWN ELEVATED Windows PowerShell, not inside the Claude desktop app. This window never runs it.' } else { 'Run it in your own Windows PowerShell (unelevated is fine). This window never runs it.' }) }
                            else { [string]$cmd.Reason })
    $lblDrawerNote.Visible = [bool]$lblDrawerNote.Text
    $parts = New-Object System.Collections.ArrayList
    if ($cmd.Ok) { [void]$parts.Add($cmd.Text) }
    # Gate F8: the builder gives a snippet only WITH a command, so no "BEFORE it"
    # line stands under an empty command ('command (F8):' in -SelfTest).
    if ($cmd.Snippet) { if ($parts.Count) { [void]$parts.Add('') }; [void]$parts.Add('# BEFORE it, in the same elevated shell: the pending-reboot check (RUNBOOK step 4). Good result: count 0, CBS False, WU False.'); [void]$parts.Add($cmd.Snippet) }
    if ($cmd.Compare) { if ($parts.Count) { [void]$parts.Add('') }; [void]$parts.Add($(if ($cmd.Ok) { '# Then RUNBOOK step 8''s compare block. Read OK first, then EMPTY, then the lines:' } else { '# RUNBOOK step 8''s compare block. Read OK first, then EMPTY, then the lines:' })); [void]$parts.Add($cmd.Compare) }
    elseif ($cmd.CompareReason) { if ($parts.Count) { [void]$parts.Add('') }; [void]$parts.Add('# ' + $cmd.CompareReason) }
    $txtCommand.Text = ($parts -join "`r`n")
    $btnCopy.Enabled = [bool]$cmd.Ok
    $btnCopySnippet.Enabled = [bool]$cmd.Snippet
    $btnCopyCompare.Enabled = [bool]$cmd.Compare
    # The preview: stage 1 shows the spec as Save spec would write it NOW (finding
    # 1: the spec is the main path); other stages show their own file.
    if ($id -eq 1) {
        $sn = Get-SqlStackGuiCurrentSpec
        $lblPreview.Text = $(if ($sn.Ok) { 'spec.json as Save spec would write it now' } else { 'spec.json cannot be written yet:' })
        $txtPreview.Text = $(if ($sn.Ok) { [string]$sn.Text } else { ((@($sn.Problems) | ForEach-Object { '- ' + $_ }) -join "`r`n") })
    } elseif ($s -and $s.Preview) {
        $lblPreview.Text = ('File: {0}' -f [IO.Path]::GetFileName($s.Preview))
        $t = Read-SqlStackGuiText -Path $s.Preview
        $txtPreview.Text = $(if ($null -eq $t) { '(the file could not be read)' } elseif ($t.Length -gt 200000) { $t.Substring(0, 200000) + "`r`n... (shortened: open the file to read the rest)" } else { $t -replace "`r?`n", "`r`n" })
    } else {
        $lblPreview.Text = 'Preview'
        $txtPreview.Text = '(no file for this stage yet)'
    }
    $txtPreview.SelectionStart = 0; $txtPreview.SelectionLength = 0
    $revTabs.SelectedTab = $tpPreview
}

function Invoke-SqlStackGuiCopy {
    # Every Copy button: the ONE clipboard write, which copies only what the builder built.
    param([ValidateSet('Command', 'Compare', 'Snippet')][string]$Part)
    $r = Copy-SqlStackGuiCommand -Stage ([int]$script:WbSelectedStage) -State $script:WbState -Part $Part -ToolDir $script:WbToolDir -MapRoot $script:WbMapRoot
    $statusLabel.Text = $(if ($r.Ok) { ('Copied the {0} for stage {1}. Paste it into your own PowerShell window.' -f $Part.ToLowerInvariant(), $script:WbSelectedStage) } else { ('Nothing copied: ' + $r.Reason) })
    Write-SqlStackGuiLog 'UI' $statusLabel.Text
}

# ===========================================================================
# The Install screen's behaviour (2026-11-16). The decisions and the worker's
# lines are the pure functions of THE INSTALL SPINE, above the self-test; these
# only move them onto the screen.
# ===========================================================================
function Initialize-SqlStackGuiInstallNic {
    # The network cards of this machine that are up, and the choice saved in
    # this run folder (install.json), into the two controls. A READ.
    $script:InstallUiLoading = $true
    try {
        $cards = @([System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
                Where-Object { ([string]$_.OperationalStatus -eq 'Up') -and ([string]$_.NetworkInterfaceType -ne 'Loopback') } | ForEach-Object { [string]$_.Name })
        $saved = Read-SqlStackGuiInstallChoice -Root $script:WbRoot
        $cboNic.Items.Clear()
        foreach ($c in $cards) { [void]$cboNic.Items.Add($c) }
        if ($cboNic.Items.Count -gt 0) { $cboNic.SelectedIndex = [Math]::Max(0, $cboNic.Items.IndexOf([string]$saved.InterfaceAlias)) }
        $numPrefix.Value = [Math]::Min(128, [Math]::Max(1, [int]$saved.PrefixLength))
        $chkIgnorePending.Checked = [bool]$saved.IgnorePendingRestart
        $script:InstallNicLoaded = $true
    } finally { $script:InstallUiLoading = $false }
}

function Save-SqlStackGuiInstallChoice {
    # The chosen network card and prefix length, and this host's name, into the
    # run folder (install.json), so they are there after a restart of Windows;
    # and each new instance's updates folder, which the install worker reads.
    # Before the Install screen has loaded the network cards (Save plan on the
    # Plan screen), the card and prefix already saved are kept.
    $alias = [string]$cboNic.SelectedItem; $prefix = [int]$numPrefix.Value; $ignore = [bool]$chkIgnorePending.Checked
    if (-not $script:InstallNicLoaded) { $saved = Read-SqlStackGuiInstallChoice -Root $script:WbRoot; $alias = [string]$saved.InterfaceAlias; $prefix = [int]$saved.PrefixLength; $ignore = [bool]$saved.IgnorePendingRestart }
    $doc = [ordered]@{ host = [string]$env:COMPUTERNAME; interfaceAlias = $alias; prefixLength = $prefix; ignorePendingRestart = $ignore; updates = (Get-SqlStackGuiUpdatesMap -Plan $script:Plan.ToArray()); savedUtc = [datetime]::UtcNow.ToString('o') }
    [void](Write-SqlStackGuiRunFile -Root $script:WbRoot -Item 'Install' -Text (ConvertTo-Json $doc -Depth 4))
}

function Save-SqlStackGuiPlanFiles {
    <#
      What opening the Install screen does first, with NO dialog: save the plan
      (spec.json, and spec-absent.json for a throwaway) and write one ini and
      one post-install script per new instance into <run>\export, replacing
      what is there and removing a file left from an earlier plan (the worker
      installs every ini it finds). A plan that cannot be saved is said in
      words and NOTHING is written.
      ONE exception, the second press after a restart of Windows or a failed
      run: the instances this folder installed are now installed, so its spec
      is read only here. When this folder was saved for an install on THIS
      host before (install.json names this host and the export files are
      there), Install goes on from those files.
      Returns ONE object: .Ok .Reason .Resumed
    #>
    $o = [pscustomobject]@{ Ok = $false; Reason = ''; Resumed = $false }
    Save-DetailToPlan
    Update-Validation
    $newRows = @($script:Plan | Where-Object { -not $_.Fixed }).Count
    $spec = Get-SqlStackGuiCurrentSpec
    $sa = Get-SqlStackGuiSpecActionState -Errors ([int]$script:ValidationCounts.Errors) -NewRows $newRows -ReadOnly ([bool]$script:WbReadOnly) -SpecProblems @($spec.Problems)
    if (-not $sa.Enabled) {
        $choice = Read-SqlStackGuiInstallChoice -Root $script:WbRoot
        if ($script:WbReadOnly -and $choice.Exists -and $choice.HasFiles -and ([string]$choice.HostName -ieq [string]$env:COMPUTERNAME)) {
            $o.Ok = $true; $o.Resumed = $true
            $o.Reason = 'This run folder was saved for an install on this host before, and its plan is read only now. Install goes on from the files already saved in it.'
            Write-SqlStackGuiLog 'INSTALL' $o.Reason
            return $o
        }
        $o.Reason = ([string]$sa.Reason -creplace 'Save spec is off', 'The plan cannot be saved yet')
        return $o
    }
    try {
        [void](Write-SqlStackGuiRunFile -Root $script:WbRoot -Item 'Spec' -Text $spec.Text)
        $abs = Get-SqlStackGuiCurrentSpec -Absent
        if ($abs.Ok -and ($abs.AbsentCount -gt 0)) { [void](Write-SqlStackGuiRunFile -Root $script:WbRoot -Item 'SpecAbsent' -Text $abs.Text) }
        $when = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz')
        $set = @(Get-SqlStackGuiFileSet -Plan $script:Plan.ToArray() -Browser $script:BrowserRead -HostName $env:COMPUTERNAME -When $when -SysAdmin $script:WbSysAdmin)
        $bad = @($set | Where-Object { -not $_.Ok })
        if ($bad.Count -gt 0) {
            $o.Reason = ('The setup file {0} cannot be written completely: {1}' -f $bad[0].Name, [string](@($bad[0].Problems) | Select-Object -First 1))
            return $o
        }
        $res = Write-SqlStackGuiFileSet -Folder (Initialize-SqlStackGuiRunFolder -Root $script:WbRoot -Item 'Export') -FileSet $set -ConfirmOverwrite { $true } -RemoveOthers
        $script:LastFileSet = $set
        $script:LastFileSetFingerprint = Get-SqlStackGuiPlanFingerprint -Plan $script:Plan.ToArray()
        Save-SqlStackGuiInstallChoice
        Write-SqlStackGuiLog 'INSTALL' ('saved the plan and {0} setup file(s) into {1}; removed {2} left from an earlier plan' -f @($res.Written).Count, $res.Folder, @($res.Removed).Count)
    } catch {
        Write-SqlStackGuiLogError 'ERROR' ('saving the plan and its setup files into ' + $script:WbRoot) $_
        $o.Reason = ('The plan could not be saved into {0}: {1}' -f $script:WbRoot, $_.Exception.Message)
        return $o
    }
    $o.Ok = $true
    Update-SqlStackGuiRunState
    return $o
}

function Update-SqlStackGuiInstallGrid {
    # The Install grid, from the model. Its rows are rebuilt only when the
    # instances change; a new state changes the State cell in place.
    if ($gridInstall.Columns.Count -eq 0) {
        [void](Add-SqlStackGuiGridColumn -Grid $gridInstall -Name 'Instance')
        [void](Add-SqlStackGuiGridColumn -Grid $gridInstall -Name 'State' -Tip 'Before Install: will be installed, or already installed. While it runs: waiting, adding address, installing (or waiting for you in the SQL Server setup window, when a password was left blank), configuring, restarting, checking. At the end: done, FAILED, reboot needed, needs attention or installed, check failed.')
        [void](Add-SqlStackGuiGridColumn -Grid $gridInstall -Name 'What will happen' -Fill -Wrap)
    }
    $rows = @(Get-SqlStackGuiInstallRows -Model $script:InstallModel)
    $have = @($gridInstall.Rows | ForEach-Object { [string]$_.Cells['Instance'].Value })
    if (($have -join '|') -cne ((@($rows) | ForEach-Object { $_.Name }) -join '|')) {
        $gridInstall.Rows.Clear()
        foreach ($r in $rows) { [void]$gridInstall.Rows.Add(@($r.Name, '', '')) }
    }
    for ($i = 0; $i -lt $rows.Count; $i++) {
        $cells = $gridInstall.Rows[$i].Cells
        if ([string]$cells['State'].Value -cne [string]$rows[$i].Word) { $cells['State'].Value = [string]$rows[$i].Word }
        Set-SqlStackGuiCellColor -Cell $cells['State'] -Color $script:Ui[$rows[$i].Color]
        $cells['State'].ToolTipText = [string]$rows[$i].Detail
        if ([string]$cells['What will happen'].Value -cne [string]$rows[$i].Steps) { $cells['What will happen'].Value = [string]$rows[$i].Steps }
    }
    Update-SqlStackGuiFillColumns -Grid $gridInstall
}

function Update-SqlStackGuiInstallView {
    # Everything on the Install screen but the log, from the model and the ONE
    # decision about the button (Get-SqlStackGuiInstallAction).
    # The button, the passwords line and the network card follow the last
    # PREVIEW; the grid follows what is shown (the preview, or the run).
    Update-SqlStackGuiInstallGrid
    $m = $script:InstallPreview
    $flpNic.Visible = (@($m.Addresses).Count -gt 0)
    $flpNic.Enabled = (-not $script:InstallRunning)
    $lblInstallNeeds.Text = $(if (@($m.Order).Count -gt 0) { Get-SqlStackGuiInstallNeedsText -Model $m } else { '' })
    $act = Get-SqlStackGuiInstallAction -IsElevated $script:IsElevated -Model $m -Running ([bool]$script:InstallRunning) -SaveProblem $(if ($script:InstallSave -and (-not $script:InstallSave.Ok)) { [string]$script:InstallSave.Reason } else { '' })
    $btnInstall.Text = $act.Text
    $btnInstall.Enabled = ($act.Kind -ne 'Off')
    $btnInstallCheck.Enabled = (-not $script:InstallRunning)
    $why = [string]$act.Reason
    if (($act.Kind -ne 'Off') -and $script:InstallSave -and $script:InstallSave.Resumed) { $why = ([string]$script:InstallSave.Reason + ' ' + $why) }
    $lblInstallWhy.Text = $why
    $lblInstallWhy.ForeColor = $(if (($act.Kind -eq 'Off') -and (-not $script:InstallRunning)) { $script:Ui.Error } else { $script:Ui.Secondary })
    # A restart of Windows that is pending, and the two buttons after "reboot needed".
    $lblPending.Text = Get-SqlStackGuiPendingText -Pending ([string]$m.Pending) -Ignore ([bool]$chkIgnorePending.Checked)
    $flpPending.Visible = ([bool]$m.Pending -and (-not $script:InstallRunning))
    $flpReboot.Visible = (($null -ne $script:InstallOutcome) -and ([string]$script:InstallOutcome.Kind -ceq 'Reboot') -and (-not $script:InstallRebootLater) -and (-not $script:InstallRunning))
    Update-SqlStackGuiInstallRailWord
}

function Update-SqlStackGuiInstallPreview {
    # Opening the Install screen, and Check again: save the plan and its files
    # with no dialog, run the worker in PREVIEW mode (it changes nothing) and
    # show what it said. Never while an install runs.
    if ($script:InstallRunning) { Update-SqlStackGuiInstallView; return }
    $form.Cursor = [System.Windows.Forms.Cursors]::WaitCursor
    try {
        Initialize-SqlStackGuiInstallNic
        $script:InstallSave = Save-SqlStackGuiPlanFiles
        $model = New-SqlStackGuiInstallModel
        if ($script:InstallSave.Ok) {
            try {
                $w = Start-SqlStackGuiInstallWorker -RunFolder $script:WbRoot -Mode 'Preview' -InterfaceAlias ([string]$cboNic.SelectedItem) -PrefixLength ([int]$numPrefix.Value) -IgnorePendingRestart ([bool]$chkIgnorePending.Checked)
                try { [void](Wait-SqlStackGuiWorker -Worker $w -Model $model -TimeoutSec 120) } finally { $w.Dispose() }
            } catch {
                Write-SqlStackGuiLogError 'ERROR' 'the install preview' $_
                [void]$model.Problems.Add(('the install preview could not run: ' + $_.Exception.Message))
                $model.Finished = $true; $model.ExitCode = 1
            }
        }
        $script:InstallModel = $model
        $script:InstallPreview = $model
        $txtInstallLog.Text = ((@($model.Lines) | Where-Object { -not ([string]$_).StartsWith('@@') }) -join "`r`n")
        Write-SqlStackGuiLog 'INSTALL' ('preview: saved={0}; {1} instance(s); {2} problem(s); exit {3}' -f $script:InstallSave.Ok, @($model.Order).Count, @($model.Problems).Count, $model.ExitCode)
    } finally { $form.Cursor = [System.Windows.Forms.Cursors]::Default }
    Update-SqlStackGuiInstallView
}

function Show-SqlStackGuiPasswordDialog {
    <#
      ONE masked dialog for every password the worker's preview named: sa typed
      twice, each distinct account once. Each is checked as the worker will
      check it (Get-SqlStackGuiPasswordProblem). Returns key -> password in the
      preview's order, or $null when the operator cancels. The boxes are
      cleared before it returns; nothing is written anywhere.
    #>
    param([object[]]$Needs = @())
    $pwForm = New-Object System.Windows.Forms.Form
    $pwForm.Text = 'SqlStack - passwords for this install'
    $pwForm.StartPosition = 'CenterParent'
    $pwForm.FormBorderStyle = 'FixedDialog'
    $pwForm.MaximizeBox = $false; $pwForm.MinimizeBox = $false; $pwForm.ShowInTaskbar = $false
    $pwForm.Font = $script:UiFont.Body
    $pwForm.BackColor = $script:Ui.Card
    $pwForm.ForeColor = $script:Ui.Text
    $pwForm.AutoSize = $true
    $pwForm.AutoSizeMode = 'GrowAndShrink'
    $pwTable = New-Object System.Windows.Forms.TableLayoutPanel
    $pwTable.AutoSize = $true; $pwTable.AutoSizeMode = 'GrowAndShrink'
    $pwTable.Dock = 'Fill'
    $pwTable.ColumnCount = 2
    $pwTable.Padding = New-Object System.Windows.Forms.Padding(16, 14, 16, 12)
    $pwTable.BackColor = $script:Ui.Card
    $pwRow = 0
    $pwIntro = New-Object System.Windows.Forms.Label
    $pwIntro.AutoSize = $true; $pwIntro.UseMnemonic = $false
    $pwIntro.MaximumSize = New-Object System.Drawing.Size(520, 0)
    $pwIntro.Margin = New-Object System.Windows.Forms.Padding(0, 0, 0, 10)
    $pwIntro.Text = 'Type each password. They go to SQL Server setup for this install and are saved nowhere: not in the plan, not in a file, not in the log. Setup receives them on its command line.' + "`r`n`r`n" + 'Every password is optional. Leave one blank and SQL Server setup opens its own window for that instance, where you type it.'
    $pwTable.Controls.Add($pwIntro, 0, $pwRow); $pwTable.SetColumnSpan($pwIntro, 2); $pwRow++
    $entries = New-Object System.Collections.ArrayList
    foreach ($n in @($Needs)) {
        $isSa = ([string]$n.Key -ceq '#sa')
        $labels = @($(if ($isSa) { 'sa password' } else { ('Password for ' + [string]$n.Label) }))
        if ($isSa) { $labels += 'sa password again' }
        $boxes = New-Object System.Collections.ArrayList
        foreach ($lt in $labels) {
            $pwLabel = New-Object System.Windows.Forms.Label
            $pwLabel.AutoSize = $true; $pwLabel.UseMnemonic = $false; $pwLabel.Anchor = 'Left'
            $pwLabel.Margin = New-Object System.Windows.Forms.Padding(0, 6, 10, 6)
            $pwLabel.Text = $lt
            $pwBox = New-Object System.Windows.Forms.TextBox
            $pwBox.UseSystemPasswordChar = $true
            $pwBox.Anchor = 'Left,Right'
            $pwBox.MinimumSize = New-Object System.Drawing.Size(280, 0)
            $pwBox.Margin = New-Object System.Windows.Forms.Padding(0, 3, 0, 3)
            $pwTable.Controls.Add($pwLabel, 0, $pwRow); $pwTable.Controls.Add($pwBox, 1, $pwRow); $pwRow++
            [void]$boxes.Add($pwBox)
        }
        [void]$entries.Add([pscustomobject]@{ Key = [string]$n.Key; Name = $(if ($isSa) { 'sa' } else { [string]$n.Label }); Boxes = $boxes })
    }
    $pwWhy = New-Object System.Windows.Forms.Label
    $pwWhy.AutoSize = $true; $pwWhy.UseMnemonic = $false
    $pwWhy.MaximumSize = New-Object System.Drawing.Size(520, 0)
    $pwWhy.ForeColor = $script:Ui.Error
    $pwWhy.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 6)
    $pwTable.Controls.Add($pwWhy, 0, $pwRow); $pwTable.SetColumnSpan($pwWhy, 2); $pwRow++
    $pwButtons = New-Object System.Windows.Forms.FlowLayoutPanel
    $pwButtons.AutoSize = $true; $pwButtons.AutoSizeMode = 'GrowAndShrink'
    $pwButtons.Margin = New-Object System.Windows.Forms.Padding(0, 6, 0, 0)
    $pwOk = New-Object System.Windows.Forms.Button
    $pwOk.Text = 'Install'
    Initialize-SqlStackGuiButton -Button $pwOk -Primary
    $pwCancel = New-Object System.Windows.Forms.Button
    $pwCancel.Text = 'Cancel'
    Initialize-SqlStackGuiButton -Button $pwCancel
    $pwCancel.DialogResult = 'Cancel'
    $pwButtons.Controls.AddRange(@($pwOk, $pwCancel))
    $pwTable.Controls.Add($pwButtons, 0, $pwRow); $pwTable.SetColumnSpan($pwButtons, 2)
    $pwForm.Controls.Add($pwTable)
    $pwForm.AcceptButton = $pwOk
    $pwForm.CancelButton = $pwCancel
    $pwForm.Tag = $entries
    $pwOk.Tag = $pwWhy
    $pwOk.Add_Click({
        # Checked here, in plain words; the dialog closes only when every one is usable.
        $dlg = $this.FindForm()
        $bad = ''
        foreach ($e in @($dlg.Tag)) {
            $t = [string]$e.Boxes[0].Text
            if (($e.Boxes.Count -gt 1) -and ($t -cne [string]$e.Boxes[1].Text)) { $bad = ('The two entries for {0} differ. Type them again.' -f $e.Name); break }
            # Blank is allowed: that password is typed in setup's own window.
            if ($t -eq '') { continue }
            $p = Get-SqlStackGuiPasswordProblem -Text $t
            if ($p) { $bad = ('The password for {0} cannot be used: {1}.' -f $e.Name, $p); break }
        }
        $this.Tag.Text = $bad
        if (-not $bad) { $dlg.DialogResult = [System.Windows.Forms.DialogResult]::OK }
    })
    # G1: the dialog's ONE scaling pass, after its controls are in its tree.
    $pwForm.AutoScaleDimensions = New-Object System.Drawing.SizeF(96, 96)
    $pwForm.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
    $result = $null
    try {
        if ($pwForm.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK) {
            $result = [ordered]@{}
            foreach ($e in @($entries)) { $result[[string]$e.Key] = [string]$e.Boxes[0].Text }
        }
    } finally {
        foreach ($e in @($entries)) { foreach ($b in @($e.Boxes)) { $b.Text = '' } }
        $pwForm.Dispose()
    }
    return $result
}

function Invoke-SqlStackGuiInstallNow {
    <#
      THE INSTALL BUTTON, and the ONE place a real install starts (INV-6,
      census 'I2-install-one-place'). It previews again (so what is confirmed
      is what is saved now), asks the ONE decision, and then either restarts
      this window as administrator on this run folder, or: one confirm naming
      the instances, one password dialog, and the worker as a hidden child
      whose lines the timer drains (Step-SqlStackGuiInstallRun).
    #>
    if ($script:InstallRunning) { return }
    Update-SqlStackGuiInstallPreview
    $m = $script:InstallPreview
    $act = Get-SqlStackGuiInstallAction -IsElevated $script:IsElevated -Model $m -Running $false -SaveProblem $(if ($script:InstallSave -and (-not $script:InstallSave.Ok)) { [string]$script:InstallSave.Reason } else { '' })
    if ($act.Kind -eq 'Off') { $statusLabel.Text = ('Install is off: ' + $act.Reason); return }
    if ($act.Kind -eq 'Elevate') {
        # A window started as administrator cannot see a mapped drive: no relaunch from one.
        $onNet = @(@((Split-Path -Parent $script:EntryScriptPath), [string]$script:WbRoot) | Where-Object { Test-SqlStackGuiNetworkPath -Path $_ })
        if ($onNet.Count -gt 0) {
            $netText = 'Copy the SqlStack folder and the run folder to a local disk first. An administrator window cannot see mapped drives.'
            Write-SqlStackGuiLog 'INSTALL' ('not started as administrator: on a network or mapped drive: ' + ($onNet -join ', '))
            $statusLabel.Text = $netText
            $lblInstallResult.ForeColor = $script:Ui.Error
            $lblInstallResult.Text = $netText
            return
        }
        try {
            [void](Start-SqlStackGuiElevatedWindow -RunFolder $script:WbRoot -Advanced ([bool]$script:WbAdvanced) -StatePath ([string]$script:EntryArgs['StatePath']) -PortBase ([int]$script:PortBaseInUse))
        } catch {
            Write-SqlStackGuiLogError 'ERROR' 'starting this window again as administrator' $_
            $statusLabel.Text = ('Windows did not start SqlStack as administrator ({0}). Nothing was changed.' -f $_.Exception.Message)
            return
        }
        Write-SqlStackGuiLog 'INSTALL' 'started this window again as administrator on the same run folder; closing this one'
        $form.Close()
        return
    }
    $attNames = @(@($m.Order) | Where-Object { [string]$m.Instances[$_].State -ceq 'needs attention' })
    $newNames = @(@($m.Order) | Where-Object { (-not $m.Instances[$_].Installed) -and ($attNames -notcontains $_) })
    $oldNames = @(@($m.Order) | Where-Object { $m.Instances[$_].Installed })
    $ask = New-Object System.Collections.ArrayList
    [void]$ask.Add('Install now?')
    [void]$ask.Add('')
    if ($newNames.Count -gt 0) { [void]$ask.Add(('New SQL Server instances to install: {0}' -f ($newNames -join ', '))) }
    if ($oldNames.Count -gt 0) { [void]$ask.Add(('Already installed, only configured and checked: {0}' -f ($oldNames -join ', '))) }
    if ($attNames.Count -gt 0) { [void]$ask.Add(('Needs attention, nothing is changed for it and the run stops there: {0}' -f ($attNames -join ', '))) }
    if (@($m.Addresses).Count -gt 0) { [void]$ask.Add(('Addresses to add to the network card "{0}": {1}' -f [string]$cboNic.SelectedItem, ((@($m.Addresses) | ForEach-Object { '{0}/{1}' -f $_.Ip, [int]$numPrefix.Value }) -join ', '))) }
    [void]$ask.Add('')
    [void]$ask.Add('This changes this machine, and only for the instances named here. Setup can take a long time; keep this window open.')
    if ([System.Windows.Forms.MessageBox]::Show(($ask -join "`r`n"), 'SqlStack - Install', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning, [System.Windows.Forms.MessageBoxDefaultButton]::Button2) -ne [System.Windows.Forms.DialogResult]::Yes) {
        $statusLabel.Text = 'Install was not confirmed. Nothing was changed.'
        return
    }
    $secrets = $null
    if (@($m.Needs).Count -gt 0) {
        $secrets = Show-SqlStackGuiPasswordDialog -Needs @($m.Needs)
        if ($null -eq $secrets) { $statusLabel.Text = 'Install was cancelled at the password dialog. Nothing was changed.'; return }
        # Only what was typed is sent; a blank one is typed in setup's own window.
        $secrets = Select-SqlStackGuiTypedSecrets -Secrets $secrets
    }
    $script:InstallRebootLater = $false
    $runModel = New-SqlStackGuiInstallModel
    try {
        $w = Start-SqlStackGuiInstallWorker -RunFolder $script:WbRoot -Mode 'Install' -InterfaceAlias ([string]$cboNic.SelectedItem) -PrefixLength ([int]$numPrefix.Value) -IgnorePendingRestart ([bool]$chkIgnorePending.Checked -and [bool]$m.Pending)
        Send-SqlStackGuiWorkerSecrets -Worker $w -Secrets $secrets
    } catch {
        Write-SqlStackGuiLogError 'ERROR' 'starting the install worker' $_
        $statusLabel.Text = ('The install could not be started: {0}' -f $_.Exception.Message)
        return
    } finally {
        if ($secrets) { $secrets.Clear() }
    }
    $script:InstallWorker = $w
    $script:InstallModel = $runModel
    $script:InstallOutcome = $null
    $script:InstallRunning = $true
    $txtInstallLog.Text = ''
    $lblInstallResult.ForeColor = $script:Ui.Text
    $lblInstallResult.Text = 'Install is running. Keep this window open; setup takes a while.'
    $statusLabel.Text = 'Install is running.'
    Write-SqlStackGuiLog 'INSTALL' ('started the install worker (process {0}) for {1}' -f $w.Id, (@($m.Order) -join ', '))
    Update-SqlStackGuiInstallView
    $script:InstallTimer.Enabled = $true
}

function Invoke-SqlStackGuiRestartNow {
    <#
      THE RESTART BUTTONS (the owner's ruling, 2026-11-17). -Resume $false:
      "Restart Windows now", beside a pending restart. -Resume $true: "Restart
      Windows now and continue", after "reboot needed": the worker first
      registers the ONE task that opens this window again on this run folder,
      on the Install screen, when this user signs in. The confirm and the
      order are Invoke-SqlStackGuiWindowsRestart's; the task and the restart
      are the worker's (INV-5). No password is stored anywhere: the window
      asks again after the restart.
    #>
    param([bool]$Resume = $false)
    if ($script:InstallRunning) { return }
    $resumeArgs = ''
    if ($Resume) { $resumeArgs = Get-SqlStackGuiElevatedArguments -ScriptPath $script:EntryScriptPath -RunFolder $script:WbRoot -Advanced ([bool]$script:WbAdvanced) -StatePath ([string]$script:EntryArgs['StatePath']) -PortBase ([int]$script:PortBaseInUse) }
    $r = Invoke-SqlStackGuiWindowsRestart -MachineName ([string]$env:COMPUTERNAME) -Resume $Resume -Confirm {
        param($question)
        ([System.Windows.Forms.MessageBox]::Show([string]$question, 'SqlStack - restart Windows', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning, [System.Windows.Forms.MessageBoxDefaultButton]::Button2) -eq [System.Windows.Forms.DialogResult]::Yes)
    } -RunWorker {
        param($withResume)
        $model = New-SqlStackGuiInstallModel
        $w = Start-SqlStackGuiInstallWorker -RunFolder $script:WbRoot -Mode 'Restart' -ResumeArguments $resumeArgs
        try { $w.CloseInput(); [void](Wait-SqlStackGuiWorker -Worker $w -Model $model -TimeoutSec 120) } finally { $w.Dispose() }
        $model
    }
    Write-SqlStackGuiLog 'INSTALL' ('restart of Windows (resume={0}): {1}: {2}' -f $Resume, $r.Kind, $r.Text)
    $statusLabel.Text = [string]$r.Text
    if ($r.Kind -ceq 'Failed') { $lblInstallResult.ForeColor = $script:Ui.Error; $lblInstallResult.Text = [string]$r.Text }
}

function Clear-SqlStackGuiResume {
    # When the window starts: the task that opened it after a restart of
    # Windows has done its work, so it is removed. Looking for it is a READ;
    # removing it is the worker's (INV-5), and needs administrator rights: a
    # window that is not elevated says so in its log and leaves it.
    try {
        if (-not (Get-ScheduledTask -TaskName 'SqlStack-Resume' -ErrorAction SilentlyContinue)) { return }
        $model = New-SqlStackGuiInstallModel
        $w = Start-SqlStackGuiInstallWorker -RunFolder $script:WbRoot -Mode 'ForgetResume'
        try { $w.CloseInput(); [void](Wait-SqlStackGuiWorker -Worker $w -Model $model -TimeoutSec 60) } finally { $w.Dispose() }
        Write-SqlStackGuiLog 'INSTALL' ('the task SqlStack-Resume was found; the worker ended with exit code {0}: {1}' -f $model.ExitCode, $model.EndText)
    } catch { Write-SqlStackGuiLogError 'ERROR' 'removing the task SqlStack-Resume' $_ }
}

function Step-SqlStackGuiInstallRun {
    # The timer's tick, on the UI thread: drain what the worker printed since
    # the last tick into the model, the grid and the log box; when the worker
    # has ended, say what happened. It never throws into the message loop.
    $w = $script:InstallWorker
    if ($null -eq $w) { $script:InstallTimer.Enabled = $false; return }
    try {
        $lines = @(Read-SqlStackGuiWorkerOutput -Worker $w -Model $script:InstallModel)
        $show = @($lines | Where-Object { -not ([string]$_).StartsWith('@@') })
        if ($show.Count -gt 0) {
            # Text and the caret, not the box's own append method: census row W1
            # reads that method name as a file write on any receiver.
            $txtInstallLog.Text = ([string]$txtInstallLog.Text + (($show -join "`r`n") + "`r`n"))
            $txtInstallLog.SelectionStart = $txtInstallLog.Text.Length
            $txtInstallLog.ScrollToCaret()
        }
        if ($lines.Count -gt 0) { Update-SqlStackGuiInstallGrid }
        if ($script:InstallModel.Finished) { Complete-SqlStackGuiInstallRun }
    } catch {
        $script:InstallTimer.Enabled = $false
        $script:InstallRunning = $false
        Write-SqlStackGuiLogError 'ERROR' 'reading the install worker' $_
        $lblInstallResult.ForeColor = $script:Ui.Error
        $lblInstallResult.Text = ('This window lost track of the install worker ({0}). It may still be running: read its log in the run folder before pressing Install again.' -f $_.Exception.Message)
        Update-SqlStackGuiInstallView
    }
}

function Complete-SqlStackGuiInstallRun {
    # The worker has ended: a result per instance in the grid, and the ONE
    # sentence on what to do next (Get-SqlStackGuiInstallOutcome).
    $script:InstallTimer.Enabled = $false
    $script:InstallRunning = $false
    $out = Get-SqlStackGuiInstallOutcome -Model $script:InstallModel -RunFolder $script:WbRoot
    $script:InstallOutcome = $out
    if ($script:InstallWorker) { $script:InstallWorker.Dispose() }
    $script:InstallWorker = $null
    Update-SqlStackGuiInstallView
    for ($i = 0; ($i -lt @($out.Rows).Count) -and ($i -lt $gridInstall.Rows.Count); $i++) {
        $gridInstall.Rows[$i].Cells['What will happen'].Value = ('Result: ' + [string]$out.Rows[$i].Result)
        # An instance the worker never reached reads 'not run', not 'waiting'.
        if ([string]$out.Rows[$i].Result -ceq 'not run') {
            $gridInstall.Rows[$i].Cells['State'].Value = 'not run'
            Set-SqlStackGuiCellColor -Cell $gridInstall.Rows[$i].Cells['State'] -Color $script:Ui.Secondary
        }
    }
    Update-SqlStackGuiFillColumns -Grid $gridInstall
    $lblInstallResult.ForeColor = $(switch ([string]$out.Kind) { 'Done' { $script:Ui.Ok } 'Reboot' { $script:Ui.Warning } default { $script:Ui.Error } })
    $lblInstallResult.Text = [string]$out.Next
    $statusLabel.Text = [string]$out.Next
    Write-SqlStackGuiLog 'INSTALL' ('the worker ended with exit code {0}: {1}' -f $script:InstallModel.ExitCode, $out.Kind)
    foreach ($r in @($out.Rows)) { Write-SqlStackGuiLog 'INSTALL' ('  {0}: {1}' -f $r.Name, $r.Result) }
}

function Select-SqlStackGuiRailRow {
    # Select the rail row that opens view -Index (0 Host, 1 Plan, 10 Install, 2-9 a stage).
    param([int]$Index)
    foreach ($row in @($gridStages.Rows)) { if ([int]$row.Tag -eq $Index) { $gridStages.CurrentCell = $row.Cells[0]; break } }
    if ([int]$script:WbSelectedStage -ne $Index) { Show-SqlStackGuiStage -Index $Index }
}

$script:InstallTimer = New-Object System.Windows.Forms.Timer
$script:InstallTimer.Interval = 200
$script:InstallTimer.Add_Tick({ Step-SqlStackGuiInstallRun })
$btnInstall.Add_Click({ Invoke-SqlStackGuiInstallNow })
$btnInstallCheck.Add_Click({ Update-SqlStackGuiInstallPreview })
$btnRestartNow.Add_Click({ Invoke-SqlStackGuiRestartNow -Resume $false })
$btnRestartContinue.Add_Click({ Invoke-SqlStackGuiRestartNow -Resume $true })
$btnContinueLater.Add_Click({
    $script:InstallRebootLater = $true
    $statusLabel.Text = 'Nothing was left behind. Restart Windows when it suits you, open SqlStack, press Open run folder, choose this run folder and press Install again.'
    Update-SqlStackGuiInstallView
})
$cboNic.Add_SelectedIndexChanged({
    if ($script:InstallUiLoading -or $script:InstallRunning) { return }
    Save-SqlStackGuiInstallChoice
    Update-SqlStackGuiInstallPreview
})
$numPrefix.Add_ValueChanged({
    if ($script:InstallUiLoading -or $script:InstallRunning) { return }
    Save-SqlStackGuiInstallChoice
    Update-SqlStackGuiInstallPreview
})
$chkIgnorePending.Add_CheckedChanged({
    if ($script:InstallUiLoading -or $script:InstallRunning) { return }
    Save-SqlStackGuiInstallChoice
    Update-SqlStackGuiInstallPreview
})
$form.Add_FormClosing({
    param($s, $e)
    # The worker is this window's child and reports to it: closing now would
    # leave an install running with nobody reading it.
    if ($script:InstallRunning) {
        $e.Cancel = $true
        $statusLabel.Text = 'Install is running. Wait for it to finish before closing this window.'
    }
})

$lstPlan.Add_SelectedIndexChanged({ Load-PlanToDetail })
foreach ($k in $script:DetailControls.Keys) {
    $c = $script:DetailControls[$k]
    if ($c -is [System.Windows.Forms.NumericUpDown]) { $c.Add_ValueChanged({ Save-DetailToPlan; Update-Validation }) }
    elseif ($c -is [System.Windows.Forms.CheckBox]) { $c.Add_CheckedChanged({ Save-DetailToPlan; Update-Validation }) }
    elseif (($c -is [System.Windows.Forms.ComboBox]) -and ([string]$c.DropDownStyle -eq 'DropDown')) {
        # An account box: the words under it follow every keystroke; the plan
        # and Validation follow a choice from the list or leaving the box.
        $c.Add_TextChanged({ if (-not $script:Loading) { Update-SqlStackGuiAccountNote } })
        $c.Add_SelectedIndexChanged({ Save-DetailToPlan; Update-Validation })
        $c.Add_Leave({ Save-DetailToPlan; Update-Validation })
    }
    elseif ($c -is [System.Windows.Forms.ComboBox]) { $c.Add_SelectedIndexChanged({ Save-DetailToPlan; Update-Validation }) }
    elseif ($k -eq 'MediaPath') { $c.Add_Leave({ Save-DetailToPlan; Update-SqlStackGuiMediaStatus; Update-PlanList; Update-Validation }) }
    else { $c.Add_Leave({ Save-DetailToPlan; Update-PlanList; Update-Validation }) }
}
$cboEdition.Add_SelectedIndexChanged({ Update-Validation })
$numCeiling.Add_ValueChanged({
    if ($script:Loading) { return }
    $i = $lstPlan.SelectedIndex
    if (($i -lt 0) -or ($i -ge $script:Plan.Count) -or (-not $script:Plan[$i].Fixed)) { return }
    $script:Plan[$i].TypedCeilingMb = [int]$numCeiling.Value
    Set-SqlStackGuiInstalledCeiling -Plan $script:Plan.ToArray() -Ceilings $script:WbCeilings
    $txtFixed.Text = (@($script:Plan[$i].Facts) -join "`r`n")
    Update-Validation
})

$btnAdd.Add_Click({
    $n = 1
    $name = ('INST{0:D2}' -f $n)
    while (@($script:Plan | Where-Object { $_.Name -eq $name }).Count -gt 0) { $n++; $name = ('INST{0:D2}' -f $n) }
    [void]$script:Plan.Add((New-PlanRowFromName -Name $name -Ordinal ($script:Plan.Count + 1)))
    Update-ComputedPlan
    Update-PlanList; $lstPlan.SelectedIndex = $lstPlan.Items.Count - 1; Load-PlanToDetail; Update-Validation
})

$btnRemove.Add_Click({
    $i = $lstPlan.SelectedIndex
    if ($i -lt 0) { return }
    # Finding 4: an installed row is a constraint and is never removed.
    if ($script:Plan[$i].Fixed) { $statusLabel.Text = ('{0} is installed: it stays in the plan as a locked constraint.' -f $script:Plan[$i].Name); return }
    $script:Plan.RemoveAt($i)
    $o = 0; foreach ($p in $script:Plan) { $o++; $p.Ordinal = $o }
    Update-ComputedPlan
    Update-PlanList; Load-PlanToDetail; Update-Validation
})

$btnGen.Add_Click({
    Save-DetailToPlan
    # D1 + D2: the ONE file set, for NEW instances only, one ini and one script
    # each. What is shown here is exactly what Export writes; Export refuses if
    # the plan changes after this.
    $when = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss zzz')
    $script:LastFileSet = @(Get-SqlStackGuiFileSet -Plan $script:Plan.ToArray() -Browser $script:BrowserRead -HostName $env:COMPUTERNAME -When $when -SysAdmin $script:WbSysAdmin)
    $script:LastFileSetFingerprint = Get-SqlStackGuiPlanFingerprint -Plan $script:Plan.ToArray()
    $iniAll = New-Object System.Collections.ArrayList
    $sqlAll = New-Object System.Collections.ArrayList
    foreach ($f in $script:LastFileSet) {
        if ($f.Kind -eq 'ini') { [void]$iniAll.Add(('; ======== file {0} ========' -f $f.Name)); [void]$iniAll.Add($f.Text); [void]$iniAll.Add('') }
        else { [void]$sqlAll.Add(('-- ======== file {0} ========' -f $f.Name)); [void]$sqlAll.Add($f.Text); [void]$sqlAll.Add('') }
    }
    $txtIni.Text = ($iniAll -join "`r`n")
    $txtSql.Text = ($sqlAll -join "`r`n")
    $revTabs.SelectedTab = $tpIni
    $newCount = @($script:LastFileSet | Where-Object { $_.Kind -eq 'ini' }).Count
    $bad = @($script:LastFileSet | Where-Object { -not $_.Ok })
    $statusLabel.Text = ("Previewed {0} file(s) for {1} new instance(s) in the drawer; installed instances get none.{2} They are the UNGUARDED route; the spec is the main one. Nothing was executed." -f `
        $script:LastFileSet.Count, $newCount, $(if ($bad.Count -gt 0) { (' {0} file(s) are INCOMPLETE: read their PROBLEM lines.' -f $bad.Count) } else { '' }))
    Update-SqlStackGuiActions -Errors $script:ValidationCounts.Errors -NewRows @($script:Plan | Where-Object { -not $_.Fixed }).Count
})

$btnSave.Add_Click({
    # The UNGUARDED route (finding 1): the previewed .ini/.sql, into <run>\export.
    if (-not (Test-SqlStackGuiHasFileSet -FileSet $script:LastFileSet)) { $statusLabel.Text = 'Preview the .ini/.sql first.'; return }
    if ((Get-SqlStackGuiPlanFingerprint -Plan $script:Plan.ToArray()) -ne $script:LastFileSetFingerprint) {
        $statusLabel.Text = 'The plan changed after the preview. Preview again, review, then Export.'
        return
    }
    # D2(iv): nothing existing is replaced without a yes.
    $res = Write-SqlStackGuiFileSet -Folder (Initialize-SqlStackGuiRunFolder -Root $script:WbRoot -Item 'Export') -FileSet $script:LastFileSet -ConfirmOverwrite {
        param($existing)
        $msg = ("These file(s) already exist in that folder and would be replaced:`r`n`r`n{0}`r`n`r`nReplace them?" -f (@($existing) -join "`r`n"))
        ([System.Windows.Forms.MessageBox]::Show($msg, 'SqlStack', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Warning) -eq [System.Windows.Forms.DialogResult]::Yes)
    }
    if ($res.Cancelled) { $statusLabel.Text = ('Nothing was exported: {0} file(s) already exist in {1} and were not replaced.' -f @($res.Existing).Count, $res.Folder) }
    else { $statusLabel.Text = ('Exported {0} file(s) to {1}. They run by hand only, with none of SqlStack''s rails.' -f @($res.Written).Count, $res.Folder) }
    Write-SqlStackGuiLog 'FILES' $statusLabel.Text
})

$btnSpec.Add_Click({
    # Build it FIRST and refuse on its own problems: no dialog at all now, because
    # the spec has ONE place, spec.json in the run folder (INV-1).
    Save-DetailToPlan
    $spec = Get-SqlStackGuiCurrentSpec
    Write-SqlStackGuiLog 'SPEC' ('Save spec: Ok={0}, {1} new, {2} protected, edition {3}, {4} problem(s)' -f `
        $spec.Ok, $spec.InstanceCount, $spec.ProtectedCount, [string]$cboEdition.SelectedItem, @($spec.Problems).Count)
    foreach ($pb in @($spec.Problems)) { Write-SqlStackGuiLog 'SPEC' ('  problem: ' + $pb) }
    if (-not $spec.Ok) {
        $statusLabel.Text = ('No spec was written: {0} problem(s). The first is: {1}' -f @($spec.Problems).Count, (@($spec.Problems) | Select-Object -First 1))
        return
    }
    $written = @()
    try {
        # UTF-8 with NO BOM, like every other file this window writes: the loader
        # reads JSON and a BOM is a byte it did not ask for.
        $written += Write-SqlStackGuiRunFile -Root $script:WbRoot -Item 'Spec' -Text $spec.Text
        $abs = Get-SqlStackGuiCurrentSpec -Absent
        if ($abs.Ok -and ($abs.AbsentCount -gt 0)) { $written += Write-SqlStackGuiRunFile -Root $script:WbRoot -Item 'SpecAbsent' -Text $abs.Text }
        # install.json too: the updates folders are saved there, not in the spec.
        Save-SqlStackGuiInstallChoice
    } catch {
        Write-SqlStackGuiLogError 'ERROR' ('writing the spec into ' + $script:WbRoot) $_
        $statusLabel.Text = ('The spec was NOT written: ' + $_.Exception.Message)
        return
    }
    foreach ($w in $written) { Write-SqlStackGuiLog 'SPEC' ('wrote ' + $w) }
    $statusLabel.Text = ('Saved {0} into the run folder ({1} new instance(s), {2} installed carried as protected). Any earlier dry run of it is now stale: the next step is stage 3, the dry run.' -f `
                         ((@($written) | ForEach-Object { [IO.Path]::GetFileName($_) }) -join ' and '), $spec.InstanceCount, $spec.ProtectedCount)
    if (-not $script:WbAdvanced) { $statusLabel.Text = ('Saved the plan into the run folder ({0} new instance(s)). Open Install when you are ready.' -f $spec.InstanceCount) }
    Update-SqlStackGuiRunState
    Update-SqlStackGuiDrawer
})

$btnCopy.Add_Click({ Invoke-SqlStackGuiCopy -Part 'Command' })
$btnCopySnippet.Add_Click({ Invoke-SqlStackGuiCopy -Part 'Snippet' })
$btnCopyCompare.Add_Click({ Invoke-SqlStackGuiCopy -Part 'Compare' })

$btnRefresh.Add_Click({
    Update-SqlStackGuiRunState
    Show-SqlStackGuiStage -Index ([int]$script:WbSelectedStage)
    $statusLabel.Text = ('Read the run folder and the state folder again at {0}.' -f (Get-Date).ToString('HH:mm:ss'))
})

$btnOpenRun.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = 'Choose a run folder. Its spec.json, if there is one, is loaded back into the plan.'
    $dlg.ShowNewFolderButton = $true
    if ($dlg.ShowDialog() -ne 'OK') { return }
    Set-SqlStackGuiRunFolder -Root $dlg.SelectedPath
    Show-SqlStackGuiStage -Index ([int]$script:WbSelectedStage)
})

$btnNewRun.Add_Click({
    Set-SqlStackGuiRunFolder -Root (Get-SqlStackGuiDefaultRunFolder -HostName $env:COMPUTERNAME -Now (Get-Date))
    Show-SqlStackGuiStage -Index ([int]$script:WbSelectedStage)
    $statusLabel.Text = 'A new run folder is open. Save spec writes the plan into it.'
})

$btnCompare.Add_Click({
    # K15 (ruled): the comparison runs HERE, in-process, because the engine's
    # Compare-SqlStackSnapshot only reads the two bundles.
    $cmp = Invoke-SqlStackGuiCompare -State $script:WbState -MapRoot $script:WbMapRoot
    $script:WbCompareText = ((@($cmp.Lines)) -join "`r`n")
    Write-SqlStackGuiLog 'RUN' ('compare: ' + $cmp.Headline)
    Update-SqlStackGuiStageView
    $statusLabel.Text = $cmp.Headline
})

$btnTidy.Add_Click({
    $p = Write-SqlStackGuiRunFile -Root $script:WbRoot -Item 'TidyUp' -Text (ConvertTo-Json ([ordered]@{ tidiedUtc = [datetime]::UtcNow.ToString('o'); by = 'the operator, in the SqlStack window' }))
    Write-SqlStackGuiLog 'RUN' ('tidy-up marked done: ' + $p)
    Update-SqlStackGuiRunState
    Show-SqlStackGuiStage -Index 9
})

$gridStages.Add_SelectionChanged({
    # SelectedRows, not CurrentCell: SelectionChanged is raised BEFORE CurrentCell
    # moves, so CurrentCell still names the previous row here (MEASURED by the
    # lane's harness 2026-11-03: every view was one row behind).
    if ($script:WbRailUpdating) { return }
    if ($gridStages.SelectedRows.Count -gt 0) { Show-SqlStackGuiStage -Index ([int]$gridStages.SelectedRows[0].Tag) }
})

# G1: the ONE scaling pass, now that every control is in the tree: the design
# DPI first (the form's mode is still Inherit, so nothing runs yet), then Dpi
# mode, whose pass scales every constant by (display DPI / 96). The grids'
# columns and rows come after it: their pixels are read from fonts that
# already follow the DPI.
$form.AutoScaleDimensions = New-Object System.Drawing.SizeF(96, 96)
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
Set-SqlStackGuiCentreFloor
Update-VolumeGrid
Update-InstanceGrid
Update-HostIpGrid
[void](Add-SqlStackGuiInstalledRows)
Update-ComputedPlan
Set-SqlStackGuiRunFolder -Root $script:WbRoot
Update-PlanList; Load-PlanToDetail; Update-Validation
$gridStages.CurrentCell = $gridStages.Rows[1].Cells[0]
Show-SqlStackGuiStage -Index 1
$form.Add_Shown({
    Set-SqlStackGuiGridHeightToRows -Grid $gridVols
    Write-SqlStackGuiLog 'UI' 'the window is shown and the first layout pass is done'
    # The task that opens this window after a restart of Windows is one-time.
    Clear-SqlStackGuiResume
    # Started again as administrator from the Install screen: straight back onto it.
    if ($script:EntryArgs['OpenInstall']) { Select-SqlStackGuiRailRow -Index 10 }
})

function Close-SqlStackGuiLog {
    <#
      THE FOOTER, and the thing that makes this file safe to send.

      The log is run through the ENGINE'S OWN Test-ScrubGate - the gate the
      collector's bundles pass - and the verdict is written into the log itself.
      So the person about to paste it reads, in the file, whether it carries an
      email address, a UNC path or a DOMAIN\account. Findings are printed by
      their location and kind, never with the value, because the footer ships
      inside the very file it is describing.

      It is a REPORT, not a redaction: this log is a developer trace, and
      silently rewriting a path would destroy the evidence it exists to carry.
      The operator decides what to do with a finding.
    #>
    if (-not $script:LogEnabled) { return }
    # ⚠ ONCE ONLY. When the window THROWS, the script-scope trap calls this and
    # the finally block around ShowDialog calls it again - so the log ended with
    # two footers and the console printed two scrub verdicts, which reads as if
    # the file were checked twice or as if the second verdict superseded the
    # first. Review found it.
    if ($script:LogClosed) { return }
    $script:LogClosed = $true
    try {
        Write-SqlStackGuiLog 'END' ('the window closed; {0} line(s) written' -f $script:LogLines)
        $gate = @()
        $gateRan = $false
        if (Get-Command Test-ScrubGate -ErrorAction SilentlyContinue) {
            # NO @() AROUND THIS CALL. Test-ScrubGate comma-returns, so an array
            # subexpression over it yields a ONE-element array holding the array,
            # and a CLEAN log would have reported '1 FINDING(S)'. The engine's
            # wrap census caught exactly that here on 2026-10-12.
            $gate = Test-ScrubGate -Path $script:LogFile
            $gateRan = $true
        }
        if (-not $gateRan) {
            Write-SqlStackGuiLog 'END' 'SCRUB GATE: NOT RUN - the engine did not load, so this file has NOT been checked. Read it before sending it.'
        } elseif (@($gate).Count -eq 0) {
            Write-SqlStackGuiLog 'END' 'SCRUB GATE: CLEAN - no email address, UNC path or DOMAIN\account found.'
            # Said plainly, because "clean" invites more trust than the gate earns:
            # it tests three SHAPES. A local path like C:\Users\<someone>\... is
            # none of them and will not be reported, so a Windows user name can
            # still be in this file. That is usually fine for a trace; read it.
            Write-SqlStackGuiLog 'END' '  The gate tests three shapes only. Local paths here may still contain a Windows user name, which it does not flag.'
        } else {
            Write-SqlStackGuiLog 'END' ('SCRUB GATE: {0} FINDING(S) - read these lines and remove them before sending:' -f @($gate).Count)
            foreach ($f in @($gate)) { Write-SqlStackGuiLog 'END' ('  ' + $f) }
        }
        Write-Host ''
        Write-Host ("Trace log written: {0}" -f $script:LogFile)
        Write-Host ("Scrub gate: {0}" -f $(if (-not $gateRan) { 'NOT RUN - read the file before sending it' }
                                           elseif (@($gate).Count -eq 0) { 'clean - safe to send' }
                                           else { ('{0} finding(s) - see the end of the file' -f @($gate).Count) }))
    } catch { $script:LogEnabled = $false }
}

try {
    Write-SqlStackGuiLog 'UI' 'calling ShowDialog'
    [void]$form.ShowDialog()
} catch {
    # An exception out of the message loop, or out of building the form above,
    # otherwise reaches a console that is about to close. It lands here first.
    Write-SqlStackGuiLogError 'ERROR' 'the window' $_
    throw
} finally {
    Close-SqlStackGuiLog
}
