@echo off
powershell -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0SqlStack\SqlStack.ps1"
