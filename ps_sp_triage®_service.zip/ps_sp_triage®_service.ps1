Set-Location C:\temp
$init = 0
$debug = 1
$regchar = [char]0x00AE #Â®
$actionday = [System.DayOfWeek]::Saturday #This is the day most things will happen
$forceall = 0 #used to force everything to run

while($true) 
{

	if($init -eq 0)
	{
        #Run init sequence for first run
        $Logfile = ".\ps_sp_triage"+$regchar+"_service_log.txt"
        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Starting up...."}
		import-module dbatools
		
		[int]$ticks = 0
		$saturdayflag = 0
		$init = 1 #set to 0 to keep reading init with every tick
       # $sleepforseconds = 60 #3600
       $newday = 0
       #this will flags once a new day starts
        
        $configfile = ".\ps_sp_triage"+$regchar+"_service_settings.ini"
        Get-Content  $configfile | foreach-object -begin {$h=@{}} -process { $k = [regex]::split($_,'='); if(($k[0].CompareTo("") -ne 0) -and ($k[0].StartsWith("[") -ne $True)) { $h.Add($k[0], $k[1]) } }
        $client =  $h["Client"]
        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Reading config file. Client:[$client]. Should not be empty"}
        [int]$sleepforseconds = $h["WaitForSeconds"]
        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Reading config file. WaitforSeconds: $sleepforseconds"}
       
        if($sleepforseconds -lt 60)
        {
        $logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Reading config file. WaitForSeconds cannot be less than 60 seconds, forcing 60 seconds"
        
            $sleepforseconds = 60
        }
		$folder = $h["Workingfolder"] #="D:\sp_triage_ps"
		if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Reading config file. Workingfolder: $folder"}
		$debug = $h["Debug"]

	}

	if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Tick: $ticks "}
	$PreviousTickDate = Get-Date -format "yyyyMMdd"
    #Your PS code
    #Start with variables
    [int]$hour = get-date -format HH
    [int]$minute = get-date -format mm
    $weekday = (Get-Date).DayOfWeek
    if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Weekday $weekday hour $hour"}
       
    #0. Perhaps pick up some local directory configuration file so we can update stuff without complicating this script
    #from http://tlingenf.spaces.live.com/blog/cns!B1B09F516B5BAEBF!213.entry
    # On every tick reload config file

    #Reset some tick
    if($PreviousTickDate -ne (Get-Date -format "yyyyMMdd"))
    {
        $newday = 1;  
        $downloadscript = 1;
    }

    #Run new day sequence only once per day
    if( $newday -eq 1  -or $forceall -eq 1)
    {
        #create folder
        $TimeMe = (Get-Date -Format u).Substring(0,10).Replace("-","_")+"_"
        $TimeFolder = (Get-Date -Format u).Substring(0,10).Replace("-","_")
        try {
            $diditmakethefolder = New-Item -Path "$folder\$TimeFolder" -ItemType Directory
        }
        catch {
            $message = $_
            if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - New folder: $message"}
        }
        #create folder finished

        #get server list
        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Servers: $servers"}
         $servers =@()
         #Take servers from config file thingy
         $servers = $h["SQLServers"].Replace('"','').split(";")
        #get server list finished


        foreach($s in $servers)
        {
            if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - SQL Instance: $s"}

            try 
            {
                #To overcome the error The certificate chain was issued by an authority that is not trusted, we try trusted connections first
                $server = Connect-DbaInstance -SqlInstance $s -Database master -ConnectTimeout 5 -TrustServerCertificate
            }
            catch 
            {
                $message = $_
                if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Connect Error: $message"}
            }
            $cleanserver = $s.Replace("\","_")

###########################################
# >>>>>>>>>      QUICKVIEW
###########################################
            $qvpath = "$folder\$TimeFolder\$TimeMe" + "$cleanserver" + "_quickview.csv"
			if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - quickview Path: $qvpath"}
            try 
            {
                $qvquery = "IF EXISTS (SELECT OBJECT_ID('msdb.dbo.SP_DBA_QUICKVIEW')) EXEC msdb.dbo.SP_DBA_QUICKVIEW @Client = '$client', @SendEmail = 0, @SumJobs = 1;"
                $sp_quickview_sp_out = Invoke-DbaQuery -SqlInstance $server -Query $qvquery
                #great, now you have some possible data, check if there are rows before processing to Azure
                if($sp_quickview_sp_out.count -gt 0)
                {
                    #We dont want empty files
                    if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Quickviewout more than 2 lines, dump to CSV"}
                    $sp_quickview_sp_out | Export-Csv -NoTypeInformation -Path $qvpath -Force
                    #$sp_quickview_sp_out | out-file  "$folder\$TimeFolder\$TimeMe"+"$cleanserver"+"_log_query_quickview.txt"

                    if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Upload Quickview file to Azure Blob"}
                }
            }
            catch 
            {
                $message = $_
                
                if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Execute Error: $message"}
            }
###########################################
#              QUICKVIEW          <<<<<<<<<
###########################################

###########################################
# >>>>>>>>>     ACTIONDAY
###########################################

            if($weekday -eq $actionday -or $forceall -eq 1)
            {

                ###########################################
                # >>>>>>>>>  UPDATESCRIPTS
                ###########################################
                if($forceall -eq 1)
                {
                    $downloadscript -eq 1  
                }
                if($downloadscript -eq 1)
                {
                    #we dont want to download files for every server loop
                    #Download the latest scripts from the Azure container, drop them in the working directory and run them for each instance
                    $azout = .\azcopy copy 'https://sqldbaorgstorage.blob.core.windows.net/lastestscripts/*?sp=rl&st=2023-10-14T07:22:56Z&se=2026-10-14T15:22:56Z&spr=https&sv=2022-11-02&sr=c&sig=h07mm%2BrBERt1%2F%2B56siGlygFOjCxXptdYQQXhKRRlJoQ%3D' "$folder" --overwrite=true
                    $downloadscript = 0; #this will reset again on newday
                    $knownsqlfiles = @()
                    $knownsqlfiles.Add("SQLDBA.ORG.sp_triage.sql")
                    $knownsqlfiles.Add("sps_needed.sql")
                    #if adding more later, do version check.
                }
                #run this on the the newday tick of the actionday. Asume that is Saturday then this will run first thing in the morning, before the diagnostics run
                #update section
                try 
                {
                    foreach($knownfile in $knownsqlfiles)
                    {
                        $sqlfile = "$folder\" + "$knownfile"
                        #loop known SQL files and run for each server
                        try
                        {
                            $sp_quickview_sp_out = Invoke-DbaQuery -SqlInstance $server -File $sqlfile
                        }
                        catch
                        {
                            $message = $_
                            if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Problem with SQL script $knownfile : $message"}
                        }
                    }
                }
                catch 
                {
                    $message = $_
                    if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - General issue with updating SQL scripts: $message"}
                }
                ###########################################
                #           UPDATESCRIPTS        <<<<<<<<<
                ###########################################

                ###########################################
                # >>>>>>>>>       TRIAGE
                ###########################################
                if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Today is action day, prep for triage out"}
                $TimeMe = (Get-Date -Format u).Substring(0,10).Replace("-","_")+"_"
                $TimeFolder = (Get-Date -Format u).Substring(0,10).Replace("-","_")
                try {
                    $foldercreated = New-Item -Path "$folder\$TimeFolder" -ItemType Directory
                }
                catch {
                    $message = $_
                    if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - New folder: $message"}
                }

                if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Triage connect to $s"}

                $triagepath = "$folder\$TimeFolder\$TimeMe" + "$cleanserver" + "_sqlmagic.csv"
                #check if the last diagnostics is older than 5 days
                $triagequery = "SELECT CASE WHEN MAX(evaldate) < DATEADD(DAY,-5,GETDATE()) THEN 1 ELSE 0 END AS evaldate FROM master.dbo.[sqldba_sp_triage"+$regchar+"_output]"
                $sp_triage_check = Invoke-DbaQuery -SqlInstance $server -Query $triagequery
                $sp_triage_check_out = $sp_triage_check.evaldate
				if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Triage check: $sp_triage_check_out"}
            
                #if evaldate = 1 then older than the expected timestamp
                if($sp_triage_check.evaldate -eq 1 -or $forceall -eq 1)
                {
                    try 
                    {
                        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Server $s out of date"}
                        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Running Blitz on $s"}
                        $sp_triage_blitz_out = Invoke-DbaQuery -SqlInstance $server.Name -Query "EXEC  [master].[dbo].[sqldba_sp_Blitz] @CheckUserDatabaseObjects = 1 , @CheckProcedureCache = 1 , @OutputType = 'TABLE' , @OutputProcedureCache = 0 , @CheckProcedureCacheFilter = NULL, @CheckServerInfo = 1, @OutputDatabaseName = 'master', @OutputSchemaName = 'dbo', @OutputTableName = 'sqldba_sp_Blitz_output', @BringThePain = 1;"
                    }
                    catch 
                    {
                        $message = $_
                        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Error with blitz: $message"}
                    }

                    try 
                    {
                        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Running triage on $s"}
                        $sp_triage_sp_out = Invoke-DbaQuery -SqlInstance $server.Name -Query "EXEC [master].[dbo].[sp_triage$regchar];"    
                    }
                    catch 
                    {
                        $message = $_
                        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Error with sp_triage: $message"}
                    }

                }
				if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Running triage VIEW on $s"}
                try 
                {
                    $triage_out_query = "[master].[dbo].[sqldba_sp_triage"+$regchar+"_view]"
                    $sp_triage_out = Invoke-DbaQuery -SqlInstance $server -Query $triage_out_query  
                }
                catch 
                {
                    $message = $_
                    if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Error with sp_triage_view.. weird..: $message"}
                }
                
                if($sp_triage_out.count -gt 2)
                {
                #We dont want empty files
					if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - sp_triage_out more than 2 lines dump to CSV"}
                    $sp_triage_out | Export-Csv -NoTypeInformation -Path $triagepath -Force
                    try 
                    {
                        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Uploading sqlmagic files to Azure"}
                                      
                    }
                    catch 
                    {
                        $message = $_
                        if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Error uploading to azure..: $message"}
                    }  
                }
                ###########################################
                #                 TRIAGE          <<<<<<<<<
                ###########################################

                $pathtoazure = "$folder\$TimeFolder\*"
                $azout = .\azcopy.exe copy "$pathtoazure " "https://sqldbaorgstorage.blob.core.windows.net/raw/ready?sp=acw&st=2023-04-05T21:18:07Z&se=2033-06-04T05:18:07Z&spr=https&sv=2021-12-02&sr=d&sig=zCRXJULTwR6aTB5%2FBvt0T7dX98avVCafRtLOJzCT0y0%3D&sdd=1" --check-length=false
                        
            }#end of actionday loop
    


###########################################
#              ACTIONDAY          <<<<<<<<<
###########################################

        } #end of foreach server loop

        $newday = 0
    } #end of newday loop

######################

    #2. Check if this is a Saturday and run 
    # Saturday is action day. This is where everything happens.

    if($weekday -eq [System.DayOfWeek]::Wednesday)
    {
		if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Today is Wednesday, nice"}
        #Reset flags
        #$saturdayflag = 0
    }

    #Sleeps for tick count. Modifying this will change the behaviour of everything
	if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - End of loop. Start sleep $sleepforseconds seconds "}
    Start-Sleep -Seconds $sleepforseconds
    $ticks ++
	#if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - Next tick $ticks"}
    $PreviousTickDate = Get-Date -format "yyyyMMdd"
	#if($debug -eq 1){$logdate = Get-Date -format "yyyyMMdd hh:mm:ss"; Add-content $Logfile -value  "$logdate - PreviousTickDate: $PreviousTickDate "}
  } #end of while true loop
  




