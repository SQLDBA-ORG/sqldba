/*Bismillah*/
/*This script's intent has changed from looking for alerts to incoporating all default stuff that we want on a server
1. Database mail
2. Alerts for Corruption 
3. Set Model DB defaults
4. Daily Adaptive Cycle Error Logs

Last Update: 2020-10-21. Changed to Resolution Script, added VLF fixes
2020-10-26. Added Pagerduty email

Other things:
/*https://www.vmware.com/content/dam/digitalmarketing/vmware/en/pdf/solutions/sql-server-on-vmware-best-practices-guide.pdf*/
--Netsh int tcp show global
--netsh interface tcp set global rss=enabled
*/
DECLARE @ConfigureDBGOVERNOR BIT
DECLARE @UpdateOla BIT
DECLARE @AddMappedDrive BIT
DECLARE @NeedEmptyFile BIT


SET @ConfigureDBGOVERNOR = 1
SET @UpdateOla = 0
SET @AddMappedDrive = 0
SET @NeedEmptyFile = 0

/*
IF @ConfigureDBGOVERNOR = 1
BEGIN
	USE DB_GOVERNOR
	exec [usp_gov_Update_INPUT_D_CUSTOMER] @PK=N'1',@DESCRIPTION=N'Max Fashions and Barkers',@CUSTOMER_NAME=N'Max Barkers',@OPERATION=N'UPDATE'
	exec [usp_gov_Update_INPUT_D_SERVICE] @PK=N'1',@SERVICE=N'Primary',@REMARKS=N'Ontempo',@OPERATION=N'UPDATE'
	exec [usp_gov_Update_INPUT_D_PERSON] @SEND_EMAIL_ALERTS=N'True',@PERSON_NAME=N'Adrian Sullivan',@PK=N'1',@REMARKS=N'',@EMAIL=N'sqlalerts@sqldba.org',@PERSON_INITIALS=N'AFS',@OPERATION=N'UPDATE'
	exec [usp_gov_UpdateSettings] @SETTING=N'DBMAIL_PROFILE_NAME',@VALUE=N'DBA Mail Profile'
	exec usp_gov_UpdateWatchdogSettings @PK_WATCHDOG=N'1',@FK_ACTION=N'2'
	exec usp_gov_UpdateWatchdogSettings @PK_WATCHDOG=N'2',@FK_ACTION=N'2'
	exec usp_gov_UpdateWatchdogSettings @PK_WATCHDOG=N'3',@FK_ACTION=N'2'
	/*Deadlocks*/
	exec usp_gov_UpdateAlertSettings @PK=N'24',@YELLOW_VALUE=N'2',@RED_VALUE=N'1',@WARNING_MAIL=1,@ALERT_MAIL=1,@GRAIN=N'INSTANCE',@PREDICTION=0,@SLA=2,@IS_CRITICAL=1,@PATTERN=0,@ANOMALY=0
	/*Database warnings*/

	
	USE master

END*/

/*Capture configs*/
IF OBJECT_ID('master.dbo.DBA_SYS_DATABASES') IS NULL
BEGIN
	SELECT GETDATE() [timestamp],* 
	INTO master.dbo.DBA_SYS_DATABASES
	FROM sys.databases
END 
ELSE
BEGIN
	INSERT INTO master.dbo.DBA_SYS_DATABASES
	SELECT GETDATE() [timestamp],* 
	FROM sys.databases
END

IF OBJECT_ID('master.dbo.DBA_SYS_DATABASE_FILES') IS NULL
BEGIN
	SELECT GETDAte() [Timestamp], SD.name [DB], SF.*
	INTO master.dbo.DBA_SYS_DATABASE_FILES
	FROM sys.sysaltfiles SF
	INNER JOIN sys.databases SD ON SD.database_id = SF.dbid
END 
ELSE
BEGIN
	INSERT  INTO master.dbo.DBA_SYS_DATABASE_FILES
	SELECT GETDAte() [Timestamp], SD.name [DB], SF.*
	FROM sys.sysaltfiles SF
	INNER JOIN sys.databases SD ON SD.database_id = SF.dbid
END

IF OBJECT_ID('master.dbo.DBA_SYS_TRACEFLAGS') IS NULL
BEGIN
	create table master.dbo.DBA_SYS_TRACEFLAGS ([name] int, [status] int, [global] int, [session] int)
	insert into master.dbo.DBA_SYS_TRACEFLAGS exec('dbcc tracestatus()')
END 
ELSE
BEGIN
	insert into master.dbo.DBA_SYS_TRACEFLAGS exec('dbcc tracestatus()')
END
IF @AddMappedDrive = 1
BEGIN
	/*Need a mapped drive for the SQL service?*/
	DECLARE @MappedDriveCMD NVARCHAR(200)
	DECLARE @MappedDriveDomainName NVARCHAR(200)

	DECLARE @MappedDriveDomainPassword NVARCHAR(200)
	SET @MappedDriveDomainName = 'DOMAIN\administrator'
	SET @MappedDriveDomainPassword = 'PASSWORD'
	SET @MappedDriveCMD = 'net use s: \\server\Backup\SQLServer /USER:'+@MappedDriveDomainName+' '+@MappedDriveDomainPassword+' /p:yes'
	EXEC sp_configure 'show advanced options', 1;
	RECONFIGURE;
	EXEC sp_configure 'xp_cmdshell',1
	RECONFIGURE
	EXEC xp_cmdshell @MappedDriveCMD

END
IF @NeedEmptyFile = 1
BEGIN
	PRINT 'How about creating a 10GB empty file'
	EXEC xp_cmdshell ' fsutil file createnew C:\MyEmergencyFile.dat 10737418240'
END



/*
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Update Ola Jobs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
*/
/*REMEMEBER to add to OLA @MaxTransferSize = 131072,*/
 IF @UpdateOla = 1
 BEGIN
/*Adrian*/
DECLARE @schedule_id_01 int
  DECLARE @schedule_id_02 int
  DECLARE @schedule_id_03 int
  DECLARE @schedule_id_04 int
  DECLARE @schedule_id_05 int
  DECLARE @schedule_id_06 int
  DECLARE @RandomStartHours BIGINT
  DECLARE @RandomStartMinutes BIGINT
  DECLARE @RandomStartSeconds BIGINT
  DECLARE @RandomTime BIGINT
  DECLARE @StartStamp NVARCHAR(20)
SELECT @StartStamp = LEFT(REPLACE(CONVERT(NVARCHAR,GETDATE(),120),'-',''),8)

--@Numberoffiles=5
  
  
  IF NOT EXISTS (SELECT * FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Daily Backups')
  BEGIN
  SET @RandomStartHours = CONVERT(BIGINT,RAND()*2)*10000 /*Between 12:00 and 03:00 am*/
  SET @RandomStartMinutes = CONVERT(BIGINT,RAND()*59)*100 /*Between 00 ~ 60 minutes*/
  SET @RandomStartSeconds = CONVERT(BIGINT,RAND()*59) /*Between 00 ~ 60 seconds*/
  SET @RandomTime = @RandomStartHours + @RandomStartMinutes + @RandomStartSeconds 
   EXEC msdb.dbo.sp_add_schedule @schedule_name=N'SQLDBA.ORG - Daily Backups', @enabled=1, @freq_type=4, @freq_interval=1
	  , @freq_subday_type=8, @freq_subday_interval=12, @freq_relative_interval=0, @freq_recurrence_factor=1
	  , @active_start_date=@StartStamp, @active_end_date=99991231, @active_start_time=@RandomTime, @active_end_time=235959, @schedule_id = @schedule_id_01 OUTPUT
  	END
	ELSE
	BEGIN
		SELECT @schedule_id_01 =  schedule_id FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Daily Backups'
	END
	
	IF NOT EXISTS (SELECT * FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Weekly Backups')
	  BEGIN
	  SET @RandomStartHours = CONVERT(BIGINT,RAND()*2)*10000 /*Between 12:00 and 03:00 am*/
	  SET @RandomStartMinutes = CONVERT(BIGINT,RAND()*59)*100 /*Between 00 ~ 60 minutes*/
	  SET @RandomStartSeconds = CONVERT(BIGINT,RAND()*59) /*Between 00 ~ 60 seconds*/
	  SET @RandomTime = @RandomStartHours + @RandomStartMinutes + @RandomStartSeconds 
	  EXEC msdb.dbo.sp_add_schedule @schedule_name=N'SQLDBA.ORG - Weekly Backups', @enabled=1, @freq_type=8, @freq_interval=64
  , @freq_subday_type=1, @freq_subday_interval=0, @freq_relative_interval=0, @freq_recurrence_factor=1, @active_start_date=@StartStamp
  , @active_end_date=99991231, @active_start_time=100000, @active_end_time=235959, @schedule_id = @schedule_id_06 OUTPUT

  	END
	ELSE
	BEGIN
		SELECT @schedule_id_06 =  schedule_id FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Weekly Backups'
	END
	
  IF NOT EXISTS (SELECT * FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Log Backups')
  BEGIN
  EXEC msdb.dbo.sp_add_schedule @schedule_name=N'SQLDBA.ORG - Log Backups', @enabled=1, @freq_type=4, @freq_interval=1, @freq_subday_type=4
  , @freq_subday_interval=15, @freq_relative_interval=0, @freq_recurrence_factor=1, @active_start_date=@StartStamp, @active_end_date=99991231
  , @active_start_time=0, @active_end_time=235959, @schedule_id = @schedule_id_02 OUTPUT
  	END
	ELSE
	BEGIN
		SELECT @schedule_id_02 =  schedule_id FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Log Backups'
	END

  IF NOT EXISTS (SELECT * FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Daily DBCC')
  BEGIN
  SET @RandomStartHours = CONVERT(BIGINT,((RAND()*4)+19))*10000 /*Between 19:00 and 00:00 am*/
  SET @RandomStartMinutes = CONVERT(BIGINT,RAND()*59)*100 /*Between 00 ~ 60 minutes*/
  SET @RandomStartSeconds = CONVERT(BIGINT,RAND()*59) /*Between 00 ~ 60 seconds*/
  SET @RandomTime = @RandomStartHours + @RandomStartMinutes + @RandomStartSeconds
  EXEC msdb.dbo.sp_add_schedule @schedule_name=N'SQLDBA.ORG - Daily DBCC', @enabled=1, @freq_type=4, @freq_interval=1
  , @freq_subday_type=1, @freq_subday_interval=0, @freq_relative_interval=0, @freq_recurrence_factor=1, @active_start_date=@StartStamp
  , @active_end_date=99991231, @active_start_time=@RandomTime, @active_end_time=235959, @schedule_id = @schedule_id_03 OUTPUT
  	END
	ELSE
	BEGIN
		SELECT @schedule_id_03 =  schedule_id FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Daily DBCC'
	END

  IF NOT EXISTS (SELECT * FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Daily Maintenance')
  BEGIN 
  SET @RandomStartHours = CONVERT(BIGINT,((RAND()*2)+3))*10000 /*Between 03:00 and 05:00 am*/
  SET @RandomStartMinutes = CONVERT(BIGINT,RAND()*59)*100 /*Between 00 ~ 60 minutes*/
  SET @RandomStartSeconds = CONVERT(BIGINT,RAND()*59) /*Between 00 ~ 60 seconds*/
  SET @RandomTime = @RandomStartHours + @RandomStartMinutes + @RandomStartSeconds
  EXEC msdb.dbo.sp_add_schedule @schedule_name=N'SQLDBA.ORG - Daily Maintenance', @enabled=1, @freq_type=4, @freq_interval=1
  , @freq_subday_type=1, @freq_subday_interval=0, @freq_relative_interval=0, @freq_recurrence_factor=1, @active_start_date=@StartStamp
  , @active_end_date=99991231, @active_start_time=@RandomTime, @active_end_time=235959, @schedule_id = @schedule_id_04 OUTPUT
  	END
	ELSE
	BEGIN
		SELECT @schedule_id_04 =  schedule_id FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Weekly Maintenance'
	END
  IF NOT EXISTS (SELECT * FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Weekly Maintenance')
  BEGIN
  SET @RandomStartHours = CONVERT(BIGINT,((RAND()*2)+1))*10000 /*Between 02:00 and 03:00 am*/
  SET @RandomStartMinutes = CONVERT(BIGINT,RAND()*59)*100 /*Between 00 ~ 60 minutes*/
  SET @RandomStartSeconds = CONVERT(BIGINT,RAND()*59) /*Between 00 ~ 60 seconds*/
  SET @RandomTime = @RandomStartHours + @RandomStartMinutes + @RandomStartSeconds
  EXEC msdb.dbo.sp_add_schedule @schedule_name=N'SQLDBA.ORG - Weekly Maintenance', @enabled=1, @freq_type=8, @freq_interval=64
  , @freq_subday_type=1, @freq_subday_interval=0, @freq_relative_interval=0, @freq_recurrence_factor=1, @active_start_date=@StartStamp
  , @active_end_date=99991231, @active_start_time=@RandomTime, @active_end_time=235959, @schedule_id = @schedule_id_05 OUTPUT
	END
	ELSE
	BEGIN
		SELECT @schedule_id_05 =  schedule_id FROM msdb.dbo.sysschedules WHERE [name] = N'SQLDBA.ORG - Weekly Maintenance'
	END

DECLARE @the_job_Id BINARY(16)
DECLARE @the_job_name NVARCHAR(200)

SET @the_job_name =  'IndexOptimize - USER_DATABASES'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
	EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_04
	EXEC msdb.dbo.sp_update_jobstep @job_id=@the_job_Id, @step_id=1 , 
		@command=N'EXECUTE [dbo].[IndexOptimize] @Databases = ''ALL_DATABASES'',@FragmentationHigh = ''INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'', @FragmentationMedium = ''INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE'', @FragmentationLevel1 = 5, @FragmentationLevel2 = 30,@OnlyModifiedStatistics = ''Y'', @UpdateStatistics=''ALL'', @LogToTable = ''Y'''
		--EXECUTE [dbo].[IndexOptimize] @Databases = 'ALL_DATABASES',@FragmentationHigh = 'INDEX_REORGANIZE,INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE', @FragmentationMedium = 'INDEX_REBUILD_ONLINE,INDEX_REBUILD_OFFLINE', @FragmentationLevel1 = 5, @FragmentationLevel2 = 30,@OnlyModifiedStatistics = 'Y', @UpdateStatistics='ALL', @LogToTable = 'Y'

END



---@availabilitygroupDirectoryStructure='{servername}${instancename}{directoryseparator}{databaseName}{directoryseparator}{backuptype}'               




SET @the_job_name =  'DatabaseBackup - SYSTEM_DATABASES - FULL'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name 
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_01
END

SET @the_job_name =  'DatabaseBackup - USER_DATABASES - FULL'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_06
END

SET @the_job_name =  'DatabaseBackup - USER_DATABASES - DIFF'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN
  SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_01
END

SET @the_job_name =  'DatabaseBackup - USER_DATABASES - LOG'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN 
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_02
END

SET @the_job_name =  'DatabaseIntegrityCheck - SYSTEM_DATABASES'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN 
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_03
END

SET @the_job_name =  'DatabaseIntegrityCheck - USER_DATABASES'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN 
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_03
END

SET @the_job_name =  'sp_delete_backuphistory'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN 
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_05
  	EXEC msdb.dbo.sp_update_jobstep @job_id=@the_job_Id, @step_id=1 , 
		@command=N'DECLARE @CleanupDate datetime 
SET @CleanupDate = DATEADD(dd,-90,GETDATE())
EXECUTE dbo.sp_delete_backuphistory @oldest_date = @CleanupDate', @subsystem=N'TSQL'
END

SET @the_job_name =  'sp_purge_jobhistory'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN 
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_05
END

SET @the_job_name =  'Output File Cleanup'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN  
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_04
END

SET @the_job_name =  'CommandLog Cleanup'
IF EXISTS(SELECT job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name)
BEGIN 
SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name
  EXEC msdb.dbo.sp_attach_schedule @job_id=@the_job_Id, @schedule_id = @schedule_id_05
END

  /* <<< OLA stuff up to here*/
END

/*
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Chaning Defaults
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
*/

GO
/*Enable Advanced options*/
EXEC sys.sp_configure N'show advanced options', N'1'
RECONFIGURE WITH OVERRIDE
GO
/*Enable Database Mail*/
EXEC sp_configure 'Database Mail XPs', 1
RECONFIGURE WITH OVERRIDE
PRINT 'Action: Enabled database mail'
GO

USE [master]
GO
-- Limit error logs
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'NumErrorLogs', REG_DWORD, 30
GO
PRINT 'Action: Set Errorlogs to 30'
-- Set sp_configure settings

EXEC sys.sp_configure N'remote admin connections', N'1'
RECONFIGURE WITH OVERRIDE
GO
PRINT 'Action: Enabled remote admin mail'


GO
EXEC sys.sp_configure N'recovery interval (min)', N'1'
PRINT 'Action: Set recovery interval'
GO
EXEC sys.sp_configure N'max text repl size (B)', N'-1'
PRINT 'Action: Set max text replication size'
GO

/*Check if server version > SQL 2008R2*/
DECLARE @SQLVersion INT
SELECT @SQLVersion = @@MicrosoftVersion / 0x01000000  OPTION (RECOMPILE)-- Get major version

IF @SQLVersion >= 10
BEGIN
	BEGIN TRY
		EXEC sys.sp_configure N'backup checksum default', N'1'
		RECONFIGURE WITH OVERRIDE
		PRINT 'Action: Set backup checksum'
	END TRY
	BEGIN CATCH
		PRINT 'Failed to configure backup checksum default'
	END CATCH
	EXEC sys.sp_configure N'contained database authentication', N'1'
	RECONFIGURE WITH OVERRIDE
	PRINT 'Action: Enabled contained DBs'
END





/*Configure memory*/
DECLARE @CPUcount INT;
DECLARE @CPUsocketcount INT;
DECLARE @CPUHyperthreadratio MONEY;
	SELECT @CPUcount = cpu_count 
	, @CPUsocketcount = [cpu_count] / [hyperthread_ratio]
	, @CPUHyperthreadratio = [hyperthread_ratio]
	FROM sys.dm_os_sys_info;

-- Use 'backup compression default' when server is NOT CPU bound
IF CONVERT(int, (@@microsoftversion / 0x1000000) & 0xff) >= 10
EXEC sys.sp_configure N'backup compression default', N'1'
RECONFIGURE WITH OVERRIDE
GO
PRINT 'Action: Set backup compression'
-- Use 'optimize for ad hoc workloads' for OLTP workloads ONLY
IF CONVERT(int, (@@microsoftversion / 0x1000000) & 0xff) >= 10
EXEC sys.sp_configure N'optimize for ad hoc workloads', N'1'
RECONFIGURE WITH OVERRIDE
PRINT 'Action: Set optimize for ad hoc'
GO
EXEC sys.sp_configure N'show advanced options', N'0'
RECONFIGURE WITH OVERRIDE
GO

/*Let's set agent history, don't want no huge msdb please*/
USE [msdb]
GO
EXEC msdb.dbo.sp_set_sqlagent_properties @jobhistory_max_rows=10000, 
		@jobhistory_max_rows_per_job=100
GO
PRINT 'Action: Set jobhistory to 10k, rows per job 100'



EXEC sys.sp_configure N'show advanced options', N'0'
RECONFIGURE WITH OVERRIDE
GO

DECLARE @DatabaseName SYSNAME;
DECLARE @Databasei_Count INT;
DECLARE @Databasei_Max INT;
DECLARE @DynamicSQL NVARCHAR(4000);
DECLARE @DynamicSQLforDB NVARCHAR(4000);
DECLARE @state INT
DECLARE @AutoClose INT
DECLARE @AutoShrink INT
DECLARE @AutoStats INT
DECLARE @AutoCreateStats INT
DECLARE @AutoStatsAsync INT
DECLARE @AutoStatsInc INT
DECLARE @RecoveryModel INT
DECLARE @PageVerify INT



DECLARE @Databases TABLE
	(
		id INT IDENTITY(1,1)
		, databasename VARCHAR(250)
		, [compatibility_level] BIGINT
		, user_access BIGINT
		, user_access_desc VARCHAR(50)
		, [state] BIGINT
		, state_desc  VARCHAR(50)
		, recovery_model INT
		, recovery_model_desc  VARCHAR(50)
		, create_date DATETIME
		, is_auto_close_on INT
		, is_auto_shrink_on INT
		, is_auto_create_stats_on INT
		, is_auto_update_stats_on INT
		, is_auto_update_stats_async_on INT
		, is_auto_create_stats_incremental_on INT
		, page_verify_option INT
	);
SET @DynamicSQL = 'SELECT 
	db.name
	, db.compatibility_level
	, db.user_access
	, db.user_access_desc
	, db.state
	, db.state_desc
	, db.recovery_model
	, db.recovery_model_desc
	, db.create_date
	, db.is_auto_close_on
	, db.is_auto_shrink_on
	, db.is_auto_create_stats_on
	, db.is_auto_update_stats_on
	, db.is_auto_update_stats_async_on
	' + CASE WHEN SERVERPROPERTY('productversion') < 12 THEN ', NULL' ELSE ', db.is_auto_create_stats_incremental_on' END +'
	, db.page_verify_option
	FROM sys.databases db ';
IF 'Yes please dont do the system databases' IS NOT NULL
BEGIN
	SET @DynamicSQL = @DynamicSQL + ' WHERE database_id > 4 AND state NOT IN (1,2,3,6)';
END
SET @DynamicSQL = @DynamicSQL + ' OPTION (RECOMPILE)'
INSERT INTO @Databases 
EXEC sp_executesql @DynamicSQL ;
SET @Databasei_Max = (SELECT MAX(id) FROM @Databases );


SET @Databasei_Count = 1; 
WHILE @Databasei_Count <= @Databasei_Max 
BEGIN 
	SET @DynamicSQLforDB = '';
	SELECT 
	@state = state
	, @DatabaseName = d.databasename
	, @AutoClose = is_auto_close_on
	, @AutoShrink = is_auto_shrink_on
	, @AutoCreateStats = is_auto_create_stats_on
	, @AutoStats = is_auto_update_stats_on
	, @AutoStatsAsync = is_auto_update_stats_async_on
	, @AutoStatsInc = is_auto_create_stats_incremental_on
	, @RecoveryModel = recovery_model --3 = simple
	, @PageVerify = page_verify_option --2 = checksum		
	FROM @Databases d WHERE id = @Databasei_Count

	IF @AutoClose = 1 
		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET AUTO_CLOSE OFF WITH NO_WAIT'
	IF @AutoShrink = 1
		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET AUTO_SHRINK OFF WITH NO_WAIT'
	IF @PageVerify <> 2
		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET PAGE_VERIFY CHECKSUM WITH NO_WAIT'
	IF @AutoCreateStats = 0
		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET AUTO_CREATE_STATISTICS ON WITH NO_WAIT'
	IF @AutoStats = 0
		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET AUTO_UPDATE_STATISTICS ON WITH NO_WAIT'
	/*
	IF @AutoStatsInc = 0
		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET AUTO_CREATE_STATISTICS ON(INCREMENTAL = ON)'
	
	IF @AutoStatsAsync = 0
		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET AUTO_UPDATE_STATISTICS_ASYNC ON WITH NO_WAIT'
	*/
--	IF @RecoveryModel <> 1
--		SET @DynamicSQLforDB = @DynamicSQLforDB + CHAR(13)+CHAR(10) + 'ALTER DATABASE [' + @DatabaseName + '] SET RECOVERY FULL WITH NO_WAIT'

	PRINT @DynamicSQLforDB
	EXECUTE( @DynamicSQLforDB)
	SET @Databasei_Count = @Databasei_Count + 1
END

DECLARE @sql nvarchar(max) = N'';
SELECT @sql += CASE
  WHEN (ag.role = N'PRIMARY' AND ag.ag_status = N'READ_WRITE') OR ag.role IS NULL THEN N'
    ALTER DATABASE ' + QUOTENAME(d.name) + N' SET TARGET_RECOVERY_TIME = 60 SECONDS;' 
  ELSE N'
    PRINT N''-- fix ' + QUOTENAME(d.name) + N' on Primary.'';' 
  END
FROM sys.databases AS d 
OUTER APPLY
(
  SELECT role = s.role_desc, 
    ag_status = DATABASEPROPERTYEX(c.database_name, N'Updateability')
    FROM sys.dm_hadr_availability_replica_states AS s
    INNER JOIN sys.availability_databases_cluster AS c
       ON s.group_id = c.group_id 
       AND d.name = c.database_name
    WHERE s.is_local = 1
) AS ag
WHERE d.target_recovery_time_in_seconds <> 60
  AND d.database_id > 4 
  AND d.[state] = 0 
  AND d.is_in_standby = 0 
  AND d.is_read_only = 0;
SELECT DatabaseCount = @@ROWCOUNT, Version = @@VERSION, cmd = @sql;
EXEC sys.sp_executesql @sql;

/*Now to recommend code to fix autogrowth*/
/*
****MODIFICATION REQUIRED for AUTOGROWTH -- See line 64 below****
1) Use this script to change the auto growth setting of
   for all databases
2) If you want to exclude any database add the DBs in the
   WHERE Clause -- See line 50 below
3) Tested in 2012 and 2014 SQL Servers
*/
DECLARE @TargetDATAGrowth NVARCHAR(50)
SET @TargetDATAGrowth = '512'
DECLARE @TargetLOGGrowth NVARCHAR(50)
SET @TargetLOGGrowth = '128'


DECLARE @ConfigAutoGrowth TABLE
(
	iDBID INT
	, sDBName SYSNAME
	, vFileName NVARCHAR(2000)
	, [MB Growth] MONEY
	, [File Type] VARCHAR(20)
	, vGrowthOption VARCHAR(12)
	, [Option] NVARCHAR(500)
	, [Action Needed] TINYINT
	, [Command] NVARCHAR(500)
)

-- Inserting data into staging table
INSERT INTO @ConfigAutoGrowth
SELECT
	SD.database_id
	,SD.name
	,SF.name
	, SF.growth /128 [MB Growth]
	, CASE SF.status
		WHEN 2 THEN 'Data'
		WHEN 1048578 THEN 'Data'
		WHEN 66 THEN 'Log'
		WHEN 1048642 THEN 'Log'
	END [File Type]
	, CASE SF.status
		WHEN 1048578 THEN '%'
		WHEN 1048642 THEN '%'
	ELSE 'MB' END AS 'GROWTH Option'
	
	, CASE 
		WHEN SF.status = 2			AND (SF.growth /128)+2 < @TargetDATAGrowth THEN 'Increase Data file to ' + @TargetDATAGrowth
		WHEN SF.status = 1048578	THEN 'Change Data file to MB growth'
		WHEN SF.status = 66			AND (SF.growth /128)+2 < @TargetLOGGrowth THEN 'Increase Log file to ' + @TargetLOGGrowth /*Add 2 MB to counter rounding issues, if any*/
		WHEN SF.status = 1048642	THEN 'Change Log file to MB growth'
		ELSE 'No change it seems'
	END [Option]
	,CASE 
		WHEN SF.status = 2			AND (SF.growth /128)+2 <= @TargetDATAGrowth THEN 1
		WHEN SF.status = 1048578	THEN 1
		WHEN SF.status = 66			AND (SF.growth /128)+2 <= @TargetLOGGrowth THEN 1 /*Add 2 MB to counter rounding issues, if any*/
		WHEN SF.status = 1048642	THEN 1
		ELSE 0
	END [Action Needed]
	, CASE 
		WHEN SF.status = 2			AND (SF.growth /128)+2 < @TargetDATAGrowth THEN 'ALTER DATABASE '+ '[' + SD.name + ']' +' MODIFY FILE (NAME = '+ '[' +SF.name + ']' +',FILEGROWTH = '+ @TargetDATAGrowth + 'MB)'
		WHEN SF.status = 1048578	THEN 'ALTER DATABASE '+ '[' + SD.name + ']' +' MODIFY FILE (NAME = '+ '[' +SF.name + ']' +',FILEGROWTH = '+ @TargetDATAGrowth + 'MB)'
		WHEN SF.status = 66			AND (SF.growth /128)+2 < @TargetLOGGrowth THEN 'ALTER DATABASE '+ '[' + SD.name + ']' +' MODIFY FILE (NAME = '+ '[' +SF.name + ']' +',FILEGROWTH = '+ @TargetLOGGrowth + 'MB)'
		WHEN SF.status = 1048642	THEN 'ALTER DATABASE '+ '[' + SD.name + ']' +' MODIFY FILE (NAME = '+ '[' +SF.name + ']' +',FILEGROWTH = '+ @TargetLOGGrowth + 'MB)'
		ELSE ''
	END [Command]

FROM sys.sysaltfiles SF
INNER JOIN sys.databases SD ON SD.database_id = SF.dbid

 
-- Dynamically alters the file to set auto growth option to fixed mb
DECLARE @name VARCHAR ( 500 ) -- Database Name
DECLARE @dbid INT -- DBID
DECLARE @vFileName VARCHAR ( 500 ) -- Logical file name
DECLARE @vGrowthOption VARCHAR ( 500 ) -- Growth option
DECLARE @Query NVARCHAR(2000) -- Variable to store dynamic sql
DECLARE @Option NVARCHAR(500)
 
DECLARE db_cursor CURSOR FOR
SELECT
iDBID,sDBName,vFileName,vGrowthOption, [Command], [Option]
FROM @ConfigAutoGrowth T
WHERE [Action Needed] = 1
--sdbname NOT IN ( 'master' ,'msdb' ) --<<--ADD DBs TO EXCLUDE
--AND vgrowthoption IN( 'Percentage', 'Mb')
 
OPEN db_cursor
FETCH NEXT FROM db_cursor INTO @dbid,@name,@vFileName,@vGrowthOption, @Query, @Option
WHILE @@FETCH_STATUS = 0
BEGIN
	PRINT '/*DB: '+ UPPER(@name) +'. ' + @Option + '*/'
 
	/*EXECUTE(@Query) DONT EXECUTE UNLESS YOU HAVE SOME CLEVER IDEAS*/
	RAISERROR (@Query,0,1) WITH NOWAIT; 
	BEGIN TRY
		EXEC sp_executesql @Query
		PRINT @Query
	END TRY
	BEGIN CATCH
		RAISERROR ('Could not alter database',0,1) WITH NOWAIT;
	END CATCH
 
	FETCH NEXT FROM db_cursor INTO @dbid,@name,@vFileName,@vGrowthOption, @Query, @Option
END
CLOSE db_cursor -- Closing the curson
DEALLOCATE db_cursor -- deallocating the cursor
 

-- Querying system views to see if the changes are applied
DECLARE @sname VARCHAR(3)
SET @SQL=' USE [?]
SELECT ''?'' [Dbname]
,[name] [Filename]
,CASE is_percent_growth
WHEN 1 THEN CONVERT(VARCHAR(5),growth)+''%''
ELSE CONVERT(VARCHAR(20),(growth/128))+'' MB''
END [Autogrow_Value]
,CASE max_size
WHEN -1 THEN CASE growth
WHEN 0 THEN CONVERT(VARCHAR(30),''Restricted'')
ELSE CONVERT(VARCHAR(30),''Unlimited'') END
ELSE CONVERT(VARCHAR(25),max_size/128)
END [Max_Size]
FROM [?].sys.database_files'
 

DECLARE @Fdetails TABLE 
(Dbname VARCHAR(500),Filename VARCHAR(500),Autogrow_Value VARCHAR(15),Max_Size VARCHAR(30))
INSERT INTO @Fdetails 
EXEC sp_MSforeachdb @SQL


/* We will assume you have Datbase Mail enabled and configured*/
/*Thanks:
Brent Ozar Unlimited, https://www.brentozar.com/blitz/configure-sql-server-alerts/
@KeefOnToast and Chuck
*/

/*This script needs to be run in one go and will create all the bits needed*/

/*ADD alerts for AG movement*/

GO

RAISERROR ('Congratulations you awesome DBA you! Now go herd some more cats'  ,0,1) WITH NOWAIT;





-- Now let us add traceflags
/******************************************************************************
Source link: https://blog.waynesheffield.com/wayne/archive/2017/09/registry-sql-server-startup-parameters/
Author: Wayne Sheffield

Globally enable / disable the specified trace flags.
Use DBCC TRACEON/TRACEOFF to enable disable globally trace flags, then adjust
the SQL Server instance startup parameters for these trace flags.
 
SQL Server startup parameters are stored in the registry at:
HKLM\Software\Microsoft\Microsoft SQL Server\MSSQL12.SQL2014\MSSQLServer\Parameters
 
To use the xp_instance_reg... XPs, use:
HKLM\Software\Microsoft\MSSQLSERVER\MSSQLServer\Parameters.
 
To use:
1. Add the Trace Flags that you want modified to the @TraceFlags table variable.
2. Set the @DebugLevel variable to 1 to see what will happen on your system first.
3. When satisified what will happen, set @DebugLevel to 0 to actually execute the statements.
********************************************************************************
                               MODIFICATION LOG
********************************************************************************
2016-08-03 WGS Initial Creation.
*******************************************************************************/
SET NOCOUNT ON;
-- Declare and initialize variables.
-- To use with SQL 2005, cannot set the variables in the declare statement.
DECLARE @MaxValue   INTEGER,
        @SQLCMD     VARCHAR(MAX),
        @RegHive    VARCHAR(50),
        @RegKey     VARCHAR(100),
        @DebugLevel TINYINT;
 
SET @RegHive = 'HKEY_LOCAL_MACHINE';
SET @RegKey  = 'Software\Microsoft\MSSQLSERVER\MSSQLServer\Parameters';
SET @DebugLevel = 0;  -- only makes changes if set to zero!
	
DBCC TRACESTATUS()

 /* for a text file
  Windows Registry Editor Version 5.00
[HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL14.MSSQLSERVER\MSSQLServer\Parameters]
"SQLArg3"="-T1204"
"SQLArg4"="-T1222"
"SQLArg5"="-T2371"
"SQLArg6"="-T2453"
"SQLArg7"="-T3226"
"SQLArg8"="-T9488"
"SQLArg9"="-T9567"

*/
-- Add the trace flags that you want changed here.
-- If enable = 1, DBCC TRACEON will be run; if enable = 0 then DBCC TRACEOFF will be run.
-- If enable_on_startup = 1, then this TF will be added to start up on service restart; 
-- If enable_on_startup - 0, then this TF will be removed from starting up service restart
DECLARE @TraceFlags TABLE (
    TF                  INTEGER,
    enable              BIT,
    enable_on_startup   BIT,
    TF2                 AS '-T' + CONVERT(VARCHAR(15), TF)
);

-- To work with SQL 2005, cannot use a table value constructor.
-- So, use SELECT statements with UNION ALL for each TF to modify.
DECLARE @SQLVersion INT
SELECT @SQLVersion = @@MicrosoftVersion / 0x01000000  OPTION (RECOMPILE)-- Get major version

INSERT INTO @TraceFlags (TF, enable, enable_on_startup)
SELECT 1204, 1, 1 UNION ALL /*Deadlock related*/
SELECT 1222, 1, 1 --UNION ALL /*Deadlock related*/
--SELECT 1224, 1, 1  /*Lock escalation*/

/*
1488, Enables Replication to continue when the secondary node is down
*/
IF @SQLVersion >= 10
BEGIN
	INSERT INTO @TraceFlags (TF, enable, enable_on_startup)
	SELECT 1117, 1, 1 UNION ALL
	SELECT 1118, 1, 1 UNION ALL
	SELECT 2371, 1, 1 UNION ALL
	SELECT 3226, 1, 1  /*Supress backup log information in SQL event log*/
	UNION ALL
	
END
DECLARE @sqledition NVARCHAR(500)
SELECT @sqledition = CONVERT(NVARCHAR(500),SERVERPROPERTY('edition') )
IF @SQLVersion >= 10 AND @sqledition LIKE '%Express%'
BEGIN
	INSERT INTO @TraceFlags (TF, enable, enable_on_startup)
	SELECT 7806,1,1 /*Always enable DAC for SQL Express*/
END


IF @SQLVersion >= 11
BEGIN
	INSERT INTO @TraceFlags (TF, enable, enable_on_startup)
	SELECT 2453, 1, 1 UNION ALL /*Table variable fix*/
	SELECT 1800, 1, 1 UNION ALL /*Assume the machine is likely a VM, so for 4K Transaction log cluster size*/
	SELECT 9488, 1, 1  /*TAble valued function fixed estimation*/
END


IF @SQLVersion >= 13
BEGIN
	INSERT INTO @TraceFlags (TF, enable, enable_on_startup)
	SELECT 9567, 1, 1  /*Compress AG seed workload*/
	UNION ALL
	SELECT 4199,1,1 /* Trace Flag 4199 is not enabled to control multiple query optimizer changes
*/
END

/*
-T7806 - Force Direct Admin Connection on.
;-T1117;-T1118;-T1204;-T1222;-T2371;-T3226;-T2453,-T9488,-T9567
DBCC TRACEON(,-1)
*/


-- Get all of the arguments / parameters when starting up the service.
DECLARE @SQLArgs TABLE (
    Value   VARCHAR(50),
    Data    VARCHAR(500),
    ArgNum  AS CONVERT(INTEGER, REPLACE(Value, 'SQLArg', '')));
INSERT INTO @SQLArgs
    EXECUTE master.sys.xp_instance_regenumvalues @RegHive, @RegKey;


-- Get the highest argument number that is currently set
SELECT  @MaxValue = MAX(ArgNum) 
FROM    @SQLArgs;
RAISERROR('MaxValue: %i', 10, 1, @MaxValue) WITH NOWAIT;
 
-- Disable specified trace flags
SELECT  @SQLCMD = 'DBCC TRACEOFF(' + 
        STUFF((SELECT ',' + CONVERT(VARCHAR(15), TF)
               FROM   @TraceFlags
               WHERE  enable = 0
               ORDER BY TF
               FOR XML PATH(''), TYPE).value('.','varchar(max)')
              ,1,1,'') + ', -1);'

IF @DebugLevel = 0 EXECUTE (@SQLCMD);
RAISERROR('Disable TFs Command: "%s"', 10, 1, @SQLCMD) WITH NOWAIT;

-- Enable specified trace flags
SELECT  @SQLCMD = 'DBCC TRACEON(' + 
        STUFF((SELECT ',' + CONVERT(VARCHAR(15), TF)
               FROM   @TraceFlags
               WHERE  enable = 1
               ORDER BY TF
               FOR XML PATH(''), TYPE).value('.','varchar(max)')
              ,1,1,'') + ', -1);'
 
IF @DebugLevel = 0 EXECUTE (@SQLCMD);
RAISERROR('Enable TFs Command:  "%s"', 10, 1, @SQLCMD) WITH NOWAIT;

DECLARE cSQLParams CURSOR LOCAL FAST_FORWARD FOR
WITH cte AS
(
    -- Current arguments, with new TFs added at the end. Get a row number to sort by.
    SELECT  *,
            ROW_NUMBER() OVER (ORDER BY ISNULL(ArgNum, 999999999), TF) - 1 AS RN
    FROM    @SQLArgs arg
    FULL OUTER JOIN @TraceFlags tf ON arg.Data = tf.TF2
), cte2 AS
(
    -- Use the row number to calc the SQLArg# for new TFs. 
    -- Use the original Value (SQLArg#) and Data for all rows if possible, 
    -- Otherwise use the calculated SQLArg# and the calculated TF2 column.
    -- Only get the original non-TF-matched parameters, and the TFs set to be enabled
    -- (existing startup TFs not in @TraceFlags are left alone).
    SELECT  ca.Value,
            ca.Data
            -- in case any TFs are removed, calculate new row numbers in order 
            -- to renumber the SQLArg values
            , ROW_NUMBER() OVER (ORDER BY RN) - 1 AS RN2
    FROM    cte
            -- Again, for SQL 2005, use SELECT statement instead of VALUES.
            CROSS APPLY (SELECT ISNULL(Value, 'SQLArg' + CONVERT(VARCHAR(15), RN)), 
                                ISNULL(Data, TF2) ) ca(Value, Data)
    WHERE   ISNULL(enable_on_startup, 1) = 1  -- ISNULL handles non-TF parameters
)
-- The first three parameters are the location of the errorlog directory,
-- and the master database file locations. Ignore these.
-- This returns the remaining parameters that should be set.
-- Also return the highest number of parameters, so can determine if any need to be deleted.
SELECT  'SQLArg' + CONVERT(VARCHAR(15), RN2) AS Value,
        Data,
        MAX(RN2) OVER () AS MaxRN2
FROM    cte2
WHERE   RN2 > 2
ORDER BY RN2;
 
DECLARE @Value VARCHAR(50),
        @Data  VARCHAR(500),
        @MaxRN2 INTEGER;
OPEN cSQLParams;
FETCH NEXT FROM cSQLParams INTO @Value, @Data, @MaxRN2;
WHILE @@FETCH_STATUS = 0 
BEGIN
    IF @DebugLevel = 0 
	BEGIN
		BEGIN TRY
			EXECUTE master.sys.xp_instance_regwrite @RegHive, @RegKey, @Value, 'REG_SZ', @Data;
		END TRY
		BEGIN CATCH
			RAISERROR('WARNING! Registry Access is Denied', 10, 1)
		END CATCH
	END
    RAISERROR('EXECUTE master.sys.xp_instance_regwrite ''%s'', ''%s'', ''%s'', ''REG_SZ'', ''%s''', 10, 1, @RegHive, @RegKey, @Value, @Data) WITH NOWAIT;
    FETCH NEXT FROM cSQLParams INTO @Value, @Data, @MaxRN2;
END;
CLOSE cSQLParams;
DEALLOCATE cSQLParams;

-- In case deleting more TFs than added, there may be extra SQLArg values left behind. 
-- Need to delete the extras now.
WHILE @MaxValue > @MaxRN2
BEGIN
  SET @Value = 'SQLArg' + CONVERT(VARCHAR(15), @MaxValue);
  IF @DebugLevel = 0 EXECUTE master.sys.xp_instance_regdeletevalue @RegHive, @RegKey, @Value;
    RAISERROR('EXECUTE master.sys.xp_instance_regdeletevalue ''%s'', ''%s'', ''%s''', 10, 1, @RegHive, @RegKey, @Value) WITH NOWAIT;
  SET @MaxValue = @MaxValue - 1;
END;




GO

BEGIN TRY
	EXEC msdb.dbo.sp_update_operator @name=N'Lexel DBA', 
		@enabled=1, 
		@pager_days=0, 
		@email_address=N'alerts@sqldba.org', 
		@pager_address=N''
		/*Rename*/
		EXEC msdb.dbo.sp_update_operator 
		@name = 'Lexel DBA', 
		@new_name = 'SQLDBA';
END TRY
BEGIN CATCH
	PRINT 'Error with Lexel DBA Operator'
END CATCH


--Now create alerts
DECLARE @Operator NVARCHAR(500);
DECLARE @DynamicSQL NVARCHAR(4000);
DECLARE @Severity TINYINT;
DECLARE @AlertName NVARCHAR(500);
DECLARE @StepDescription NVARCHAR(500);
DECLARE @WhereToSend TINYINT;
DECLARE @SQLDBANotification NVARCHAR(200);
SET @SQLDBANotification= N'Possible P2/P3. Assign to SQL Engineers/DBA';

-- Change @OperatorName as needed
DECLARE @OperatorName sysname 
SET @OperatorName= N'SQLDBA';
		
SET @WhereToSend = 1 /*Change this to 7 to cover Email(1), Pager(2) and Net Send(4)*/
SET @Operator = @OperatorName;
SET @DynamicSQL =' EXEC msdb.dbo.sp_add_operator @name=N''' + @Operator + ''', 
@enabled=1, 
@weekday_pager_start_time=90000, 
@weekday_pager_end_time=180000, 
@saturday_pager_start_time=90000, 
@saturday_pager_end_time=180000, 
@sunday_pager_start_time=90000, 
@sunday_pager_end_time=180000, 
@pager_days=0, 
@email_address=N''alerts@sqldba.org'', 
@category_name=N''[Uncategorized]''; '
BEGIN TRY
		EXEC sp_executesql @DynamicSQL;
		SET @StepDescription = 'Operator created: ' + @Operator;
END TRY
BEGIN CATCH
		SET @StepDescription = 'Operator already exists for: ' + @Operator;
		EXEC msdb.dbo.sp_update_operator @name=N'SQLDBA', 
		@enabled=1, 
		@pager_days=0, 
		@email_address=N'alerts@sqldba.org', 
		@pager_address=N''

END CATCH
RAISERROR (@StepDescription,0,1) WITH NOWAIT;


---------------------------------------------------------------------------------------------------------
/* Adapted by Adrian Sullivan from Glenn Berry's script*/

-- Add important SQL Agent Alerts to your instance

-- This will work with SQL Server 2008 and newer
-- Glenn Berry
-- SQLskills.com
-- Last Modified: August 11, 2014
-- http://sqlserverperformance.wordpress.com/
-- http://sqlskills.com/blogs/glenn/
-- Twitter: GlennAlanBerry

-- Listen to my Pluralsight courses
-- http://www.pluralsight.com/author/glenn-berry

-- Change the @OperatorName as needed





-- Change @CategoryName as needed
DECLARE @CategoryName sysname 
SET @CategoryName = N'SQL Server Agent Alerts';

-- Make sure you have an Agent Operator defined that matches the name you supplied
IF NOT EXISTS(SELECT * FROM msdb.dbo.sysoperators WHERE name = @OperatorName)
    BEGIN
        RAISERROR ('There is no SQL Operator with a name of %s' , 18 , 16 , @OperatorName);
        RETURN;
    END

-- Add Alert Category if it does not exist
IF NOT EXISTS (SELECT *
               FROM msdb.dbo.syscategories
               WHERE category_class = 2  -- ALERT
               AND category_type = 3
               AND name = @CategoryName)
    BEGIN
        EXEC msdb.dbo.sp_add_category @class = N'ALERT', @type = N'NONE', @name = @CategoryName;
    END

-- Get the server name
DECLARE @ServerName sysname 
SET @ServerName = (SELECT @@SERVERNAME);


-- Alert Names start with the name of the server 
DECLARE @Sev19AlertName sysname 
SET @Sev19AlertName = @ServerName + N' Alert - Sev 19 Error: Fatal Error in Resource';
DECLARE @Sev20AlertName sysname 
SET @Sev20AlertName = @ServerName + N' Alert - Sev 20 Error: Fatal Error in Current Process';
DECLARE @Sev21AlertName sysname 
SET @Sev21AlertName= @ServerName + N' Alert - Sev 21 Error: Fatal Error in Database Process';
DECLARE @Sev22AlertName sysname 
SET @Sev22AlertName= @ServerName + N' Alert - Sev 22 Error: Fatal Error: Table Integrity Suspect';
DECLARE @Sev23AlertName sysname 
SET @Sev23AlertName = @ServerName + N' Alert - Sev 23 Error: Fatal Error Database Integrity Suspect';
DECLARE @Sev24AlertName sysname 
SET @Sev24AlertName= @ServerName + N' Alert - Sev 24 Error: Fatal Hardware Error';
DECLARE @Sev25AlertName sysname 
SET @Sev25AlertName = @ServerName + N' Alert - Sev 25 Error: Fatal Error';
DECLARE @Error823AlertName sysname 
SET @Error823AlertName = @ServerName + N' Alert - Error 823: The operating system returned an error';
DECLARE @Error824AlertName sysname 
SET @Error824AlertName= @ServerName + N' Alert - Error 824: Logical consistency-based I/O error';
DECLARE @Error825AlertName sysname 
SET @Error825AlertName = @ServerName + N' Alert - Error 825: Read-Retry Required';
DECLARE @Error832AlertName sysname 
SET @Error832AlertName = @ServerName + N' Alert - Error 832: Constant page has changed';
DECLARE @Error855AlertName sysname 
SET @Error855AlertName = @ServerName + N' Alert - Error 855: Uncorrectable hardware memory corruption detected';
DECLARE @Error856AlertName sysname 
SET @Error856AlertName = @ServerName + N' Alert - Error 856: SQL Server has detected hardware memory corruption, but has recovered the page';
DECLARE @Error1205AlertName sysname 
SET @Error1205AlertName = @ServerName + N' Alert - Error 1205: Deadlock';
DECLARE @Error3928AlertName sysname 
SET @Error3928AlertName = @ServerName + N' Alert - Error 3928: Deadlock';
DECLARE @AG35265AlertName sysname 
SET @AG35265AlertName = @ServerName + N' Alert - AG 35265: AG Data Movement - Resumed';
DECLARE @AG35264AlertName sysname 
SET @AG35264AlertName = @ServerName + N' Alert - AG 35264: AG Data Movement - Suspended';
DECLARE @AG28034AlertName sysname 
SET @AG28034AlertName = @ServerName + N' Alert - AG 28034: Connection handshake on broker';
DECLARE @AG1480AlertName sysname 
SET @AG1480AlertName = @ServerName + N' Alert - AG 1480: AG Role Change';
DECLARE @AGAlertName41091 sysname 
SET @AGAlertName41091 = @ServerName + N' Alert - AG 41091: Replica Going Offline'
DECLARE @AGAlertName41131 sysname 
SET @AGAlertName41131= @ServerName + N' Alert - AG 41131: Failed to Bring AG ONLINE'
DECLARE @AGAlertName41142 sysname 
SET @AGAlertName41142= @ServerName + N' Alert - AG 41142: Replica Cannot become primary'
DECLARE @AGAlertName41406 sysname 
SET @AGAlertName41406= @ServerName + N' Alert - AG 41406: AG not Ready for Auto Failover'
DECLARE @AGAlertName41414 sysname 
SET @AGAlertName41414= @ServerName + N' Alert - AG 41414: Secondary not Connected'
DECLARE @Error9002AlertName sysname 
SET @Error9002AlertName = @ServerName + N' Alert - Error 9002: Log File FULL';
DECLARE @Error1101AlertName sysname 
SET @Error1101AlertName = @ServerName + N' Alert - Error 1101: Database filegroup out of space';
DECLARE @Error28036AlertName sysname 
SET @Error28036AlertName = @ServerName + N' Alert - Error 28036: Connection handshake failed. The certificate used by this endpoint was not found'
DECLARE @Error610AlertName sysname 
SET @Error610AlertName = @ServerName + N' Alert - Error 610: Invalid header value from a page. Run DBCC CHECKDB to check for a data corruption.'
DECLARE @Error2511AlertName sysname 
SET @Error2511AlertName = @ServerName + N' Alert - Error 2511: Table error. Keys out of order on page'
DECLARE @Error5228AlertName sysname 
SET @Error5228AlertName = @ServerName + N' Alert - Error 5228: Table error. DBCC detected incomplete cleanup'
DECLARE @Error5229AlertName sysname 
SET @Error5229AlertName = @ServerName + N' Alert - Error 5229: Table error. contains an anti-matter column'
DECLARE @Error5242AlertName sysname 
SET @Error5242AlertName = @ServerName + N' Alert - Error 5242: An inconsistency was detected during an internal operation in database'
DECLARE @Error5243AlertName sysname 
SET @Error5243AlertName = @ServerName + N' Alert - Error 5243: An inconsistency was detected during an internal operation'
DECLARE @Error5250AlertName sysname 
SET @Error5250AlertName = @ServerName + N' Alert - Error 5250: Database error. This error cannot be repaired'

DECLARE @Error983AlertName sysname 
SET @Error983AlertName = @ServerName + N' Alert - Error 983: Unable to access availability database'
DECLARE @Error35264AlertName sysname 
SET @Error35264AlertName = @ServerName + N' Alert - Error 35264: AG data movement for database has been suspended '
DECLARE @Error35276AlertName sysname 
SET @Error35276AlertName = @ServerName + N' Alert - Error 35276: Failed to allocate and schedule an AG task for database'
DECLARE @Error41091AlertName sysname 
SET @Error41091AlertName = @ServerName + N' Alert - Error 41091: AG lease expired or lease renewal failed'
DECLARE @Error41406AlertName sysname 
SET @Error41406AlertName = @ServerName + N' Alert - Error 41406: The availability group is not ready for automatic failover.'



/*Ensure these log for SCOM*/
Exec sp_altermessage 1205, 'WITH_LOG', 'true'
Exec sp_altermessage 823, 'WITH_LOG', 'true'		
Exec sp_altermessage 824, 'WITH_LOG', 'true'		
Exec sp_altermessage 825, 'WITH_LOG', 'true'		
Exec sp_altermessage 832, 'WITH_LOG', 'true'		
Exec sp_altermessage 855, 'WITH_LOG', 'true'		
Exec sp_altermessage 856, 'WITH_LOG', 'true'		
Exec sp_altermessage 1205, 'WITH_LOG', 'true'	
Exec sp_altermessage 3928, 'WITH_LOG', 'true'	
Exec sp_altermessage 35265, 'WITH_LOG', 'true'	
Exec sp_altermessage 35264, 'WITH_LOG', 'true'	
Exec sp_altermessage 28034, 'WITH_LOG', 'true'	
Exec sp_altermessage 1480, 'WITH_LOG', 'true'	
Exec sp_altermessage 41091, 'WITH_LOG', 'true'	
Exec sp_altermessage 41131, 'WITH_LOG', 'true'	
Exec sp_altermessage 41142, 'WITH_LOG', 'true'	
Exec sp_altermessage 41406, 'WITH_LOG', 'true'	
Exec sp_altermessage 41414, 'WITH_LOG', 'true'	
Exec sp_altermessage 9002, 'WITH_LOG', 'true'	
Exec sp_altermessage 1101, 'WITH_LOG', 'true'
Exec sp_altermessage 28036, 'WITH_LOG', 'true'
Exec sp_altermessage 610  , 'WITH_LOG', 'true'
Exec sp_altermessage 2511 , 'WITH_LOG', 'true'
Exec sp_altermessage 5228 , 'WITH_LOG', 'true'
Exec sp_altermessage 5229 , 'WITH_LOG', 'true'
Exec sp_altermessage 5242 , 'WITH_LOG', 'true'
Exec sp_altermessage 5243 , 'WITH_LOG', 'true'
Exec sp_altermessage 5250 , 'WITH_LOG', 'true'
Exec sp_altermessage 983 , 'WITH_LOG', 'true'
Exec sp_altermessage 35264 , 'WITH_LOG', 'true'
Exec sp_altermessage 35276 , 'WITH_LOG', 'true'
Exec sp_altermessage 41091 , 'WITH_LOG', 'true'
Exec sp_altermessage 41406 , 'WITH_LOG', 'true'


DECLARE @AlertTable TABLE (ID INT IDENTITY(1,1), AlertType NVARCHAR(50),AlertName sysname, TheNumber INT)
INSERT INTO @AlertTable VALUES ('Severity',@Sev19AlertName,19)
INSERT INTO @AlertTable VALUES ('Severity',@Sev20AlertName,20)
INSERT INTO @AlertTable VALUES ('Severity',@Sev21AlertName,21)
INSERT INTO @AlertTable VALUES ('Severity',@Sev22AlertName,22)
INSERT INTO @AlertTable VALUES ('Severity',@Sev23AlertName,23)
INSERT INTO @AlertTable VALUES ('Severity',@Sev24AlertName,24)
INSERT INTO @AlertTable VALUES ('Severity',@Sev25AlertName,25)
INSERT INTO @AlertTable VALUES ('Error',@Error823AlertName,823)
INSERT INTO @AlertTable VALUES ('Error',@Error824AlertName,824)
INSERT INTO @AlertTable VALUES ('Error',@Error825AlertName,825)
INSERT INTO @AlertTable VALUES ('Error',@Error832AlertName,832)
INSERT INTO @AlertTable VALUES ('Error',@Error855AlertName,855)
INSERT INTO @AlertTable VALUES ('Error',@Error856AlertName,856)
INSERT INTO @AlertTable VALUES ('Error',@Error1205AlertName,1205)
INSERT INTO @AlertTable VALUES ('Error',@Error3928AlertName,3928)

INSERT INTO @AlertTable VALUES ('Error',@AG35265AlertName,35265)
INSERT INTO @AlertTable VALUES ('Error',@AG35264AlertName,35264)
INSERT INTO @AlertTable VALUES ('Error',@AG28034AlertName,28034)
INSERT INTO @AlertTable VALUES ('Error',@AG1480AlertName ,1480)

INSERT INTO @AlertTable VALUES ('Error',@AGAlertName41091,41091)
INSERT INTO @AlertTable VALUES ('Error',@AGAlertName41131,41131)
INSERT INTO @AlertTable VALUES ('Error',@AGAlertName41142,41142)
INSERT INTO @AlertTable VALUES ('Error',@AGAlertName41406,41406)
INSERT INTO @AlertTable VALUES ('Error',@AGAlertName41414,41414)

INSERT INTO @AlertTable VALUES ('Error',@Error9002AlertName,9002)
INSERT INTO @AlertTable VALUES ('Error',@Error1101AlertName,1101)

INSERT INTO @AlertTable VALUES ('Error',@Error28036AlertName,28036)
INSERT INTO @AlertTable VALUES ('Error',@Error610AlertName  ,610  )
INSERT INTO @AlertTable VALUES ('Error',@Error2511AlertName ,2511 )
INSERT INTO @AlertTable VALUES ('Error',@Error5228AlertName ,5228 )
INSERT INTO @AlertTable VALUES ('Error',@Error5229AlertName ,5229 )
INSERT INTO @AlertTable VALUES ('Error',@Error5242AlertName ,5242 )
INSERT INTO @AlertTable VALUES ('Error',@Error5243AlertName ,5243 )
INSERT INTO @AlertTable VALUES ('Error',@Error5250AlertName ,5250 )

INSERT INTO @AlertTable VALUES ('Error', @Error983AlertName   ,983 )
INSERT INTO @AlertTable VALUES ('Error', @Error35264AlertName ,35264)
INSERT INTO @AlertTable VALUES ('Error', @Error35276AlertName ,35276 )
INSERT INTO @AlertTable VALUES ('Error', @Error41091AlertName ,41091 )
INSERT INTO @AlertTable VALUES ('Error', @Error41406AlertName ,41406 )

DECLARE @MaxAlerts TINYINT
DECLARE @AlertCounter TINYINT 
SET @AlertCounter = 1
DECLARE @ThisName sysname
DECLARE @ThisAlert INT
DECLARE @ThisMessage INT
DECLARE @ThisAlertType NVARCHAR(50)
SELECT @MaxAlerts = MAX(ID) FROM @AlertTable
USE msdb
WHILE @AlertCounter < @MaxAlerts
BEGIN
	SELECT @ThisName = AlertName
	, @ThisAlert = TheNumber
	, @ThisAlertType = AlertType
	FROM @AlertTable WHERE ID = @AlertCounter
	IF @ThisAlertType = 'Error'
	BEGIN
		SET @ThisMessage = @ThisAlert
		SET @ThisAlert = 0
	END
	IF NOT EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = @ThisName)
	BEGIN
		IF @ThisAlert <> 0
			PRINT @ThisAlert
		BEGIN TRY
	    EXEC msdb.dbo.sp_add_alert @name = @ThisName, 
	                  @message_id = @ThisMessage, @severity = @ThisAlert, @enabled = 1, 
	                  @delay_between_responses = 900, @include_event_description_in = 1,@notification_message=@SQLDBANotification,
	                  @category_name = @CategoryName, 
	                 @job_id = N'00000000-0000-0000-0000-000000000000';
		IF NOT EXISTS(SELECT *
              FROM msdb.dbo.sysalerts AS sa
              INNER JOIN dbo.sysnotifications AS sn
              ON sa.id = sn.alert_id
              WHERE sa.name = @ThisName)
		BEGIN
			EXEC msdb.dbo.sp_add_notification @alert_name = @ThisName, @operator_name = @OperatorName, @notification_method = 1;
			--EXEC msdb.dbo.sp_add_notification @alert_name = @ThisName, @operator_name = @ServiceDesk, @notification_method = 1;
		END

		END TRY
		BEGIN CATCH
			PRINT 'Failed to configure alert'
		END CATCH
	END		  
	SET @AlertCounter = @AlertCounter + 1
END


-- Error 823: Operating System Error
-- How to troubleshoot a Msg 823 error in SQL Server	
-- http://support.microsoft.com/kb/2015755

-- Error 824: Logical consistency-based I/O error
-- How to troubleshoot Msg 824 in SQL Server
-- http://support.microsoft.com/kb/2015756

-- Error 825: Read-Retry Required
-- How to troubleshoot Msg 825 (read retry) in SQL Server
-- http://support.microsoft.com/kb/2015757

-- Error 832: Constant page has changed
-- http://www.sqlskills.com/blogs/paul/dont-confuse-error-823-and-error-832/
-- http://support.microsoft.com/kb/2015759


-- Memory Error Correction alerts added on 10/30/2013

-- Mitigation of RAM Hardware Errors
-- When SQL Server 2012 Enterprise Edition is installed on a Windows 2012 operating system with hardware that supports bad memory diagnostics, 
-- you will notice new error messages like 854, 855, and 856 instead of the 832 errors that LazyWriter usually generates.
-- Error 854 is just informing you that your instance supports memory error correction

-- Using SQL Server in Windows 8 and Windows Server 2012 environments
-- http://support.microsoft.com/kb/2681562


-- Check for SQL Server 2012 or greater and Enterprise Edition
-- You also need Windows Server 2012 or greater, plus hardware that supports memory error correction
IF LEFT(CONVERT(CHAR(2),SERVERPROPERTY('ProductVersion')), 2) >= '11' AND SERVERPROPERTY('EngineEdition') = 3
    BEGIN
        -- Error 855: Uncorrectable hardware memory corruption detected
        IF NOT EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = @Error855AlertName)
            EXEC msdb.dbo.sp_add_alert @name = @Error855AlertName, 
                          @message_id = 855, @severity = 0, @enabled = 1, 
                          @delay_between_responses = 900, @include_event_description_in = 1, @notification_message=@SQLDBANotification,
                          @category_name = @CategoryName, 
                          @job_id  = N'00000000-0000-0000-0000-000000000000';


        -- Add a notification if it does not exist
        IF NOT EXISTS(SELECT *
                      FROM dbo.sysalerts AS sa
                      INNER JOIN dbo.sysnotifications AS sn
                      ON sa.id = sn.alert_id
                      WHERE sa.name = @Error855AlertName)
            BEGIN
                EXEC msdb.dbo.sp_add_notification @alert_name = @Error855AlertName, @operator_name = @OperatorName, @notification_method = 1;
            END

        -- Error 856: SQL Server has detected hardware memory corruption, but has recovered the page
        IF NOT EXISTS (SELECT name FROM msdb.dbo.sysalerts WHERE name = @Error856AlertName)
            EXEC msdb.dbo.sp_add_alert @name = @Error856AlertName, 
                          @message_id = 856, @severity = 0, @enabled = 1, 
                          @delay_between_responses = 900, @include_event_description_in = 1, 
                          @category_name = @CategoryName, 
                          @job_id  = N'00000000-0000-0000-0000-000000000000';


        -- Add a notification if it does not exist
        IF NOT EXISTS(SELECT *
                      FROM dbo.sysalerts AS sa
                      INNER JOIN dbo.sysnotifications AS sn
                      ON sa.id = sn.alert_id
                      WHERE sa.name = @Error856AlertName)
            BEGIN
                EXEC msdb.dbo.sp_add_notification @alert_name = @Error856AlertName, @operator_name = @OperatorName, @notification_method = 1;
            END
    END







	
	/* CYCLE daily Error Logs*/


IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Daily Cycle Errorlog')
EXEC msdb.dbo.sp_delete_job @job_name=N'Daily Cycle Errorlog', @delete_unused_schedule=1
BEGIN TRANSACTION

-- Set the Operator name to receive notifications, if any. Set the job owner, if not sa.
DECLARE @jobowner sysname
SET @jobowner = 'sa'

DECLARE @ReturnCode INT
SELECT @ReturnCode = 0

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
IF EXISTS (SELECT name FROM msdb.dbo.sysoperators WHERE name = @OperatorName)
BEGIN
	EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Daily Cycle Errorlog', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=2, 
		@notify_level_page=2, 
		@delete_level=0, 
		@description=N'Cycles Errorlog when its size is over 20MB or its age over 15 days.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=@jobowner, 
		@notify_email_operator_name=@OperatorName,
		@job_id = @jobId OUTPUT
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
END
ELSE
BEGIN
	EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Daily Cycle Errorlog', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Cycles Errorlog when its size is over 20MB or its age over 15 days.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=@jobowner,
		@job_id = @jobId OUTPUT
	IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
END

EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Adaptive Cycle Errorlog', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'SET NOCOUNT ON;
DECLARE @CycleMessage VARCHAR(255), @return_value int, @Output VARCHAR(32)
DECLARE @ErrorLogs TABLE (ArchiveNumber tinyint, DateCreated DATETIME, LogFileSizeBytes int)
INSERT into @ErrorLogs (ArchiveNumber, DateCreated, LogFileSizeBytes )
EXEC master.dbo.sp_enumerrorlogs

SELECT @CycleMessage = ''Current SQL Server ErrorLog was created on '' + CONVERT(VARCHAR, DateCreated , 105) + '' and is using '' +
CASE WHEN LogFileSizeBytes BETWEEN 1024 AND 1048575 THEN CAST(LogFileSizeBytes/1024 AS VARCHAR(10)) + '' KB.''
WHEN LogFileSizeBytes > 1048575 THEN CAST((LogFileSizeBytes/1024)/1024 AS VARCHAR(10)) + '' MB.''
ELSE CAST(LogFileSizeBytes AS VARCHAR(4)) + '' Bytes.''
END 
+ CASE WHEN LogFileSizeBytes > 20971520 THEN '' The ErrorLog will be cycled because of its size.'' -- over 20MB
WHEN DateCreated <= DATEADD(dd, -15,GETDATE()) THEN '' The ErrorLog will be cycled because of its age.'' -- over 15 days
ELSE '' The ErrorLog will not be cycled.'' end
FROM @ErrorLogs where ArchiveNumber = 1

PRINT @CycleMessage

IF @CycleMessage LIKE ''%will be cycled%''
BEGIN
	EXEC @return_value = sp_cycle_errorlog
	SELECT @Output = CASE WHEN @return_value = 0 THEN ''ErrorLog was sucessfully cycled.'' ELSE ''Failure cycling Errorlog.'' END
	PRINT @Output
END', 
		@database_name=N'master', 
		@flags=4
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily Cycle Errorlog', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20120529, 
		@active_end_date=99991231, 
		@active_start_time=235900, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

PRINT 'Daily Cycle Log job created';


/*Configure Failure Alerts for jobs with no alerts*/

DECLARE @the_job_Id BINARY(16)
DECLARE @jobs TABLE (id INT IDENTITY(1,1), job_id BINARY(16), [name]  NVARCHAR(500))
INSERT @jobs
SELECT
job_id,name  FROM msdb.dbo.sysjobs 
WHERE notify_level_email = 0 /*These ones need email alerts*/
AND enabled = 1
DECLARE @Thisjob INT
SET @Thisjob = 1
DECLARE @jobmax INT
SELECT @jobmax = COUNT(*) FROM @jobs
WHILE @Thisjob <= @jobmax
BEGIN
	SELECT @the_job_Id = job_id FROM @jobs WHERE id = @Thisjob
	EXEC msdb.dbo.sp_update_job @job_id=@the_job_Id
		, @notify_level_email=2
		, @notify_level_page=2
		, @notify_level_eventlog=2
		, @notify_email_operator_name=N'SQLDBA'
		
	SET @Thisjob = @Thisjob + 1
END

/*Configure Agent alert conditions*/
USE [msdb]
EXEC msdb.dbo.sp_set_sqlagent_properties @cpu_poller_enabled=1
USE [msdb]
EXEC master.dbo.sp_MSsetalertinfo @failsafeoperator=N'SQLDBA', 
		@notificationmethod=1
USE [msdb]
EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=1, 
		@cpu_poller_enabled=1
USE [msdb]
EXEC msdb.dbo.sp_set_sqlagent_properties @jobhistory_max_rows=90000, 
		@jobhistory_max_rows_per_job=110, 
		@email_save_in_sent_folder=1, 
		@cpu_poller_enabled=1

GO

PRINT 'Creating deadlock capture thingy';
/*https://social.technet.microsoft.com/wiki/contents/articles/38068.sql-server-capture-database-deadlock-by-xevent-job-alerts-and-send-email-to-you.aspx*/
Use master 
GO
IF OBJECT_ID('master.dbo.DBA_DEADLOCKS') IS NULL
BEGIN
	CREATE TABLE [master].[dbo].[DBA_DEADLOCKS](
	[no] [int] IDENTITY(1,1) NOT NULL,
	[deadlock_timeout] [datetime] NULL,
	[deadlock1_id] NVARCHAR(100) NULL,
	[deadlock1_duration] [float] NULL,
	[deadlock1_transactionname] NVARCHAR(100) NULL,
	[deadlock1_locktype] NVARCHAR(50) NULL,
	[deadlock1_clientapp] NVARCHAR(200) NULL,
	[deadlock1_hostname] NVARCHAR(50) NULL,
	[deadlock1_loginname] NVARCHAR(50) NULL,
	[deadlock1_query] NVARCHAR(max) NULL,
	[deadlock2_id] NVARCHAR(100) NULL,
	[deadlock2_duration] [float] NULL,
	[deadlock2_transactionname] NVARCHAR(100) NULL,
	[deadlock2_locktype] NVARCHAR(50) NULL,
	[deadlock2_clientapp] NVARCHAR(200) NULL,
	[deadlock2_hostname] NVARCHAR(50) NULL,
	[deadlock2_loginname] NVARCHAR(50) NULL,
	[deadlock2_query] NVARCHAR(max) NULL,
	PRIMARY KEY CLUSTERED
	(
	[no] ASC
	) ON [PRIMARY]
	) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
 

	CREATE NONCLUSTERED INDEX [IX_SQLDBA_deadlocktimeout] ON [dbo].[DBA_DEADLOCKS]
	(
	[deadlock_timeout] ASC
	) ON [PRIMARY]
END
Use [master]
IF OBJECT_ID('dbo.[sqldba_sp_triage®_view]') IS NULL
  EXEC ('CREATE PROCEDURE dbo.[sqldba_sp_triage®_view] AS RETURN 0;');
GO
ALTER PROCEDURE [dbo].[sqldba_sp_triage®_view]
AS
SELECT TOP (100) PERCENT 
ID, evaldate, domain, SQLInstance, SectionID, Section, Summary, Severity, Details, HoursToResolveWithTesting, QueryPlan

FROM 
 (SELECT         CONVERT(NVARCHAR(25), T1.ID) AS ID, REPLACE(T1.evaldate, '~', '-') AS evaldate, REPLACE(T1.domain, '~', '-') AS domain, REPLACE(T1.SQLInstance, '~', '-') 
AS SQLInstance, REPLACE(CONVERT(NVARCHAR(10), T1.SectionID), '~', '-') AS SectionID, REPLACE(T1.Section, '~', '-') AS Section, REPLACE(T1.Summary, '~', '-') AS Summary, 
 REPLACE(T1.Severity, '~', '-') AS Severity, REPLACE(REPLACE(REPLACE(REPLACE(ISNULL(REPLACE(T1.Details, '~', '-'), N''), CHAR(9), ' '), CHAR(10), ' '), CHAR(13), ' '), ' ', ' ') AS Details, 
 REPLACE(CONVERT(NVARCHAR(10), T1.HoursToResolveWithTesting), '~', '-') AS HoursToResolveWithTesting, REPLACE(T1.QueryPlan, '~', '-') AS QueryPlan, T1.ID AS Sorter
FROM            dbo.[sqldba_sp_triage®_output] AS T1 INNER JOIN
(SELECT        MAX(evaldate) AS evaldate
FROM            dbo.[sqldba_sp_triage®_output]) AS T2 ON T1.evaldate = T2.evaldate) AS T3
ORDER BY Sorter ASC

GO
use [master]
GO
IF NOT EXISTS (SELECT * FROM master.sys.objects WHERE type = 'P' AND OBJECT_ID = OBJECT_ID('dbo.spDeadLockReport'))
   exec('CREATE PROCEDURE [dbo].[spDeadLockReport] AS BEGIN SET NOCOUNT ON; END')
GO

ALTER PROCEDURE [dbo].[spDeadLockReport]
AS
begin
DECLARE @mStartDate DATETIME;
SET @mStartDate=(SELECT isnull(MAX([deadlock_timeout]),getdate()-1) FROM master.dbo.[DBA_DEADLOCKS])
 
INSERT INTO master.dbo.[DBA_DEADLOCKS]([deadlock_timeout], [deadlock1_id], [deadlock1_duration], [deadlock1_transactionname], [deadlock1_locktype], [deadlock1_clientapp], [deadlock1_hostname], [deadlock1_loginname], [deadlock1_query], [deadlock2_id], [deadlock2_duration], [deadlock2_transactionname], [deadlock2_locktype], [deadlock2_clientapp], [deadlock2_hostname], [deadlock2_loginname], [deadlock2_query])
SELECT x.y.value('(@timestamp)[1]', 'datetime')                                                        '[deadlock_timeout]',
       x.y.value('(./data/value/deadlock/process-list/process/@id)[1]', 'NVARCHAR(100)')               '[deadlock1_id]',
       x.y.value('(./data/value/deadlock/process-list/process/@waittime)[1]', 'float') / 1000          '[deadlock1_duration]',
       x.y.value('(./data/value/deadlock/process-list/process/@transactionname)[1]', N'NVARCHAR(100)') AS '[deadlock1_transactionname]',
       x.y.value('(./data/value/deadlock/process-list/process/@lockMode)[1]', N'NVARCHAR(50)')         AS '[deadlock1_locktype]',
       x.y.value('(./data/value/deadlock/process-list/process/@clientapp)[1]', N'NVARCHAR(200)')       AS '[deadlock1_clientapp]',
       x.y.value('(./data/value/deadlock/process-list/process/@hostname)[1]', N'NVARCHAR(50)')         AS '[deadlock1_hostname]',
       x.y.value('(./data/value/deadlock/process-list/process/@loginname)[1]', N'NVARCHAR(50)')        AS '[deadlock1_loginname]',
       x.y.value('(./data/value/deadlock/process-list/process/inputbuf)[1]', N'NVARCHAR(max)')         AS '[deadlock1_query]',
       x.y.value('(./data/value/deadlock/process-list/process/@id)[2]', 'NVARCHAR(100)')               '[deadlock2_id]',
       x.y.value('(./data/value/deadlock/process-list/process/@waittime)[2]', 'float') / 1000          '[deadlock2_duration]',
       x.y.value('(./data/value/deadlock/process-list/process/@transactionname)[2]', N'NVARCHAR(100)') AS '[deadlock2_transactionname]',
       x.y.value('(./data/value/deadlock/process-list/process/@lockMode)[2]', N'NVARCHAR(50)')         AS '[deadlock2_locktype]',
       x.y.value('(./data/value/deadlock/process-list/process/@clientapp)[2]', N'NVARCHAR(200)')       AS '[deadlock2_clientapp]',
       x.y.value('(./data/value/deadlock/process-list/process/@hostname)[2]', N'NVARCHAR(50)')         AS '[deadlock2_hostname]',
       x.y.value('(./data/value/deadlock/process-list/process/@loginname)[2]', N'NVARCHAR(50)')        AS '[deadlock2_loginname]',
       x.y.value('(./data/value/deadlock/process-list/process/inputbuf)[2]', N'NVARCHAR(max)')         AS '[deadlock2_query]'
FROM   (SELECT Cast([target_data] AS XML) [target_data]
        FROM   sys.dm_xe_session_targets AS st
               INNER JOIN sys.dm_xe_sessions AS s
                       ON s.[address] = st.[event_session_address]
        WHERE  s.[name] = 'DeadlockReport') AS [deadlock]
       CROSS APPLY [target_data].nodes('/RingBufferTarget/event') AS x(y)
WHERE  x.y.query('.').exist('/event[@timestamp > sql:variable("@mStartDate") and @name="xml_deadlock_report"]') = 1
end
GO
--CREATE DEADLOCK XEVENT
IF NOT EXISTS (SELECT *
      FROM sys.server_event_sessions
      WHERE name = 'DeadlockReport')
BEGIN

	CREATE EVENT SESSION [DeadlockReport] ON SERVER
	ADD EVENT sqlserver.xml_deadlock_report
	ADD TARGET package0.ring_buffer
	WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,
	MAX_DISPATCH_LATENCY=1 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,
	TRACK_CAUSALITY=OFF,STARTUP_STATE=OFF)
END

IF EXISTS (SELECT *
      FROM sys.server_event_sessions
      WHERE name = 'DeadlockReport')
BEGIN TRY
--XEVENT START
	ALTER EVENT SESSION [DeadlockReport] ON SERVER
	STATE = START
END TRY
BEGIN CATCH
	 PRINT 'Already started.. it seems'
END CATCH
GO

USE [msdb]
GO



DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
DECLARE @the_job_Id BINARY(16)
DECLARE @the_job_name NVARCHAR(200)
SET @the_job_name =  '996. Deadlocks'

SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name 

IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
	EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
 


IF NOT EXISTS(SELECT job_id,*  FROM msdb.dbo.sysjobs WHERE [name] =  '996. Deadlocks')
BEGIN
	DECLARE @jobId BINARY(16)
	EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'996. Deadlocks',
	@enabled=1,
	@notify_level_eventlog=2,
	@notify_level_email=0,
	@notify_level_netsend=0,
	@notify_level_page=0,
	@delete_level=0,
	@description=N'no description',
	@category_name=N'[Uncategorized (Local)]',
	@owner_login_name=N'sa', @job_id = @jobId OUTPUT

	EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'deadlock',
	@step_id=1,
	@cmdexec_success_code=0,
	@on_success_action=1,
	@on_success_step_id=0,
	@on_fail_action=2,
	@on_fail_step_id=0,
	@retry_attempts=0,
	@retry_interval=0,
	@os_run_priority=0, @subsystem=N'TSQL',
	@command=N'EXEC master.dbo.spDeadLockReport',
	@database_name=N'master',
	@flags=0
 
	EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
	EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
END

SELECT @the_job_Id = job_id  FROM msdb.dbo.sysjobs WHERE [name] =  @the_job_name 
/****** Object:  Alert [[SQLDBA]Deadlock Alerts]    Script Date: 20/08/2022 1:19:11 PM ******/
EXEC msdb.dbo.sp_add_alert @name=N'[SQLDBA]Deadlock Alerts', 
		@message_id=0, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=0, 
		@category_name=N'[Uncategorized]', 
		@performance_condition=N'Locks|Number of Deadlocks/sec|_Total|>|0', 
		@job_id=@the_job_Id
GO


--Event Notifications

--For modern versions of SQL we would use SQL Audit, but we need event notifications for backwards compatibility
--As mentioned before, we cannot use SQL Audit for SQL 2008 and R2 Standard Edition or SQL 2005. As an alternative, you can setup event notifications which will capture messages via Service Broker. The scripts below are based on the scripts of Aaron but I’ve added more events to it as I wanted to trace more than just “change password”

--code from https://pietervanhove.azurewebsites.net/?p=3798
--Create the following table in the msdb database

/*
USE [msdb];
GO
 if not exists (select * from sysobjects where name='SecurityChangeLog' and xtype='U')
 begin
CREATE TABLE dbo.SecurityChangeLog
(
    ChangeLogID          int IDENTITY(1,1),
    LoginName            SYSNAME,
    UserName             SYSNAME,
    DatabaseName         SYSNAME,
    SchemaName           SYSNAME,
    ObjectName           SYSNAME,
    ObjectType           VARCHAR(50),
    DDLCommand           VARCHAR(MAX),
    EventTime            DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT PK_ChangeLogID PRIMARY KEY (ChangeLogID)
);
 end

go
if not exists (select 1 from sys.service_queues where name='SecurityChangeQueue')

CREATE QUEUE SecurityChangeQueue;
GO
if not exists (select 1 from sys.services where name='SecurityChangeService')
 
CREATE SERVICE SecurityChangeService ON QUEUE SecurityChangeQueue
  ([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);
GO
 

--Setup the event notificiation. If you check the “FOR”-clause, you will notice that these are the same actions as defined in the SQL Audit Specification.
-- Create Event Notification if not exists
IF NOT EXISTS (SELECT 1
    FROM sys.server_event_notifications
    WHERE name = 'CreateLoginNotification')
begin 
CREATE EVENT NOTIFICATION CreateLoginNotification
    ON SERVER WITH FAN_IN
    FOR CREATE_LOGIN,ALTER_LOGIN,DROP_LOGIN,CREATE_USER,ALTER_USER,DROP_USER,ADD_SERVER_ROLE_MEMBER,DROP_SERVER_ROLE_MEMBER,ADD_ROLE_MEMBER,DROP_ROLE_MEMBER
    TO SERVICE 'SecurityChangeService', 'current database';
end 
GO
 

--Install the following stored procedure to log all the event notifications into the table we’ve just created. You might notice in the loop that I’m checking the version of SQL Server for some events. This is because the event notification content is different for SQL 2008 (R2) and SQL 2005.

USE [msdb];
GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE type = 'P' AND object_id = OBJECT_ID('dbo.usp_LogSecurityChange'))
   exec('CREATE PROCEDURE [dbo].[usp_LogSecurityChange] AS BEGIN SET NOCOUNT ON; END')
GO
alter PROCEDURE [dbo].[usp_LogSecurityChange]
WITH EXECUTE AS OWNER
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @version int
    DECLARE @message_body XML;
    set @version = (SELECT convert (int,REPLACE (LEFT (CONVERT (varchar, SERVERPROPERTY ('ProductVersion')),2), '.', '')))
 
    WHILE (1 = 1)
    BEGIN
       WAITFOR 
       ( 
         RECEIVE TOP(1) @message_body = message_body
         FROM dbo.SecurityChangeQueue
       ), TIMEOUT 1000;
 
       IF (@@ROWCOUNT = 1)
       BEGIN
        if CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/EventType)')) in ('DROP_USER','CREATE_USER','ALTER_USER') or @version>9
        BEGIN
            INSERT dbo.SecurityChangeLog(LoginName,UserName,DatabaseName,SchemaName,ObjectName,ObjectType,DDLCommand) 
            SELECT CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/LoginName)')), 
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/UserName)')),
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/DatabaseName)')),
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/DefaultSchema)')),
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/ObjectName)')),
                CONVERT(VARCHAR(50), @message_body.query('data(/EVENT_INSTANCE/ObjectType)')),
                CONVERT(VARCHAR(MAX), @message_body.query('data(/EVENT_INSTANCE/TSQLCommand/CommandText)'))
        END
        ELSE
        BEGIN
            INSERT dbo.SecurityChangeLog(LoginName,UserName,DatabaseName,SchemaName,ObjectName,ObjectType,DDLCommand) 
            SELECT CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/LoginName)')), 
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/UserName)')),
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/DatabaseName)')),
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/SchemaName)')),
                CONVERT(SYSNAME, @message_body.query('data(/EVENT_INSTANCE/ObjectName)')),
                CONVERT(VARCHAR(50), @message_body.query('data(/EVENT_INSTANCE/ObjectType)')),
                CONVERT(VARCHAR(MAX), @message_body.query('data(/EVENT_INSTANCE/EventType)')) + ' ' + 
                CONVERT(VARCHAR(MAX), @message_body.query('data(/EVENT_INSTANCE/RoleName)')) + ' FOR ' +
                CONVERT(VARCHAR(MAX), @message_body.query('data(/EVENT_INSTANCE/LoginType)')) + ' ' +
                CONVERT(VARCHAR(MAX), @message_body.query('data(/EVENT_INSTANCE/ObjectName)'))
        END
       END
    END
END
 go

--Last step is modifying the queue so that it will use the stored procedure and starts tracking the login and user changes.


if exists (select 1 from sys.service_queues where name='SecurityChangeQueue')

ALTER QUEUE SecurityChangeQueue
WITH ACTIVATION
(
   STATUS = ON,
   PROCEDURE_NAME = dbo.usp_LogSecurityChange,
   MAX_QUEUE_READERS = 1,
   EXECUTE AS OWNER
);
GO


/*Fix endpoints*/
IF EXISTS
( 
		SELECT 1
		FROM master.sys.endpoints e
		INNER JOIN master.sys.server_principals sp
		ON e.principal_id = sp.principal_id
		RIGHT OUTER JOIN ( VALUES ( 2, 'TSQL'),
		( 3, 'SERVICE_BROKER'), ( 4, 'DATABASE_MIRRORING') )
		AS et ( typeid, PayloadType )
		ON et.typeid = e.type
		WHERE sp.name <> 'sa'
		AND sp.name IS NOT NULL
)
SELECT e.name as EndpointName,
sp.name AS EndpointOwner,
et.PayloadType,
e.state_desc
, CASE 
WHEN et.PayloadType IN ('DATABASE_MIRRORING','SERVICE_BROKER')
THEN 'ALTER AUTHORIZATION ON ENDPOINT::' +e.name +' TO sa'
END
FROM master.sys.endpoints e
INNER JOIN master.sys.server_principals sp
ON e.principal_id = sp.principal_id
RIGHT OUTER JOIN ( VALUES ( 2, 'TSQL'),
( 3, 'SERVICE_BROKER'), ( 4, 'DATABASE_MIRRORING') )
AS et ( typeid, PayloadType )
ON et.typeid = e.type
WHERE sp.name <> 'sa'
AND sp.name IS NOT NULL


-T1204-T1222-T1800-T2371-T2453-T3226-T4199-T7806-T9488-T9567
*/

/*
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Fix VLF Issues
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
https://github.com/microsoft/tigertoolbox/blob/master/Fixing-VLFs/Fix_VLFs.sql

*/
SET NOCOUNT ON;
-- 2011-05-24 Pedro Lopes (Microsoft) pedro.lopes@microsoft.com (http://aka.ms/sqlinsights)
--
-- 2012-03-25 Added SQL 2012 support
-- 2012-09-19 Simplified logic
-- 2012-09-20 Changed grow settings if not SQL Server 2012
--
-- Generates the sql statements to preemtively fix VLF issues in all DBs within the server, based on the transaction log current size.
--
SET NOCOUNT ON;

DECLARE @query VARCHAR(1000), @dbname VARCHAR(255), @count int, @usedlogsize bigint, @logsize bigint
DECLARE @sqlcmd NVARCHAR(1000), @sqlparam NVARCHAR(100), @filename VARCHAR(255), @i int, @recmodel NVARCHAR(128)
DECLARE @potsize int, @n_iter int, @n_iter_final int, @initgrow int, @n_init_iter int, @bckpath NVARCHAR(255)
DECLARE @majorver smallint, @minorver smallint, @build smallint

CREATE TABLE #loginfo (dbname varchar(100), num_of_rows int, used_logsize_MB DECIMAL(20,1))

DECLARE @tblvlf TABLE (dbname varchar(100), 
	Actual_log_size_MB DECIMAL(20,1), 
	Potential_log_size_MB DECIMAL(20,1), 
	Actual_VLFs int, 
	Potential_VLFs int, 
	Growth_iterations int,
	Log_Initial_size_MB DECIMAL(20,1), 
	File_autogrow_MB DECIMAL(20,1))
	
SELECT TOP 1 @bckpath = REVERSE(RIGHT(REVERSE(physical_device_name), LEN(physical_device_name)-CHARINDEX('\',REVERSE(physical_device_name),0))) FROM msdb.dbo.backupmediafamily WHERE device_type = 2

SELECT @majorver = (@@microsoftversion / 0x1000000) & 0xff, @minorver = (@@microsoftversion / 0x10000) & 0xff, @build = @@microsoftversion & 0xffff
 
--DECLARE csr CURSOR FAST_FORWARD FOR SELECT name FROM master..sysdatabases WHERE dbid > 4 AND DATABASEPROPERTYEX(name,'status') = 'ONLINE' AND DATABASEPROPERTYEX(name,'Updateability') = 'READ_WRITE' AND name <> 'tempdb' AND name <> 'ReportServerTempDB'
DECLARE csr CURSOR FAST_FORWARD FOR SELECT name FROM master.sys.databases WHERE is_read_only = 0 AND state = 0 AND database_id <> 2;
OPEN csr
FETCH NEXT FROM csr INTO @dbname
WHILE (@@FETCH_STATUS <> -1)
BEGIN
	CREATE TABLE #log_info (recoveryunitid int NULL,
	fileid tinyint,
	file_size bigint,
	start_offset bigint,
	FSeqNo int,
	[status] tinyint,
	parity tinyint,
	create_lsn numeric(25,0))

	SET @query = 'DBCC LOGINFO (' + '''' + @dbname + ''') WITH NO_INFOMSGS'
	IF @majorver < 11
	BEGIN
		INSERT INTO #log_info (fileid, file_size, start_offset, FSeqNo, [status], parity, create_lsn)
		EXEC (@query)
	END
	ELSE
	BEGIN
		INSERT INTO #log_info (recoveryunitid, fileid, file_size, start_offset, FSeqNo, [status], parity, create_lsn)
		EXEC (@query)
	END
	SET @count = @@ROWCOUNT
	SET @usedlogsize = (SELECT (MIN(l.start_offset) + SUM(CASE WHEN l.status <> 0 THEN l.file_size ELSE 0 END))/1024.00/1024.00 FROM #log_info l)
	DROP TABLE #log_info;
	INSERT #loginfo
	VALUES(@dbname, @count, @usedlogsize);
	FETCH NEXT FROM csr INTO @dbname
END

CLOSE csr
DEALLOCATE csr

PRINT '/* Generated on ' + CONVERT (VARCHAR, GETDATE()) + ' in ' + @@SERVERNAME + ' */' + CHAR(10)
	
DECLARE cshrk CURSOR FAST_FORWARD FOR SELECT dbname, num_of_rows FROM #loginfo 
WHERE num_of_rows >= 50 --My rule of thumb is 50 VLFs. Your mileage may vary.
ORDER BY dbname
OPEN cshrk
FETCH NEXT FROM cshrk INTO @dbname, @count
WHILE (@@FETCH_STATUS <> -1)
BEGIN
	SET @sqlcmd = 'SELECT @nameout = name, @logsizeout = (CAST(size AS BIGINT)*8)/1024 FROM [' + @dbname + '].dbo.sysfiles WHERE (64 & status) = 64'
	SET @sqlparam = '@nameout NVARCHAR(100) OUTPUT, @logsizeout bigint OUTPUT'
	EXEC sp_executesql @sqlcmd, @sqlparam, @nameout = @filename OUTPUT, @logsizeout = @logsize OUTPUT;
	PRINT '---------------------------------------------------------------------------------------------------------- '
	PRINT CHAR(13) + 'USE ' + QUOTENAME(@dbname) + ';'
	PRINT 'DBCC SHRINKFILE (N''' + @filename + ''', 1, TRUNCATEONLY);'
	PRINT '--'
	PRINT '-- CHECK: if the tlog file has shrunk with the following query:'
	PRINT 'SELECT name, (size*8)/1024 AS log_MB FROM [' + @dbname + '].dbo.sysfiles WHERE (64 & status) = 64'
	PRINT '--'
	SET @recmodel = CONVERT(NVARCHAR, DATABASEPROPERTYEX(@dbname,'Recovery'))
	IF @recmodel <> 'SIMPLE' 
	AND SERVERPROPERTY('EngineEdition') <> 8 -- This cannot be applied on Managed Instance
	BEGIN
		PRINT '-- If the log has not shrunk, you must backup the transaction log next.'
		PRINT '-- Repeat the backup and shrink process alternatively until you get the desired log size (about 1MB).'
		PRINT '--'
		PRINT '-- METHOD: Backup -> Shrink (repeat the backup and shrink process until the log has shrunk):'
		PRINT '--'
		PRINT '-- Create example logical backup device.' 
		PRINT 'USE master;' + CHAR(13) + 'EXEC sp_addumpdevice ''disk'', ''BckLog'', ''' + @bckpath + '\example_bck.trn'';'
		PRINT 'USE ' + QUOTENAME(@dbname) + ';'
		PRINT '-- Backup Log'
		PRINT 'BACKUP LOG ' + QUOTENAME(@dbname) + ' TO BckLog;'
		PRINT '-- Shrink'
		PRINT 'DBCC SHRINKFILE (N''' + @filename + ''', 1);'
		PRINT '--'
		PRINT '-- METHOD: Alter recovery model -> Shrink:'
		PRINT '-- NOTE: Because the database is in ' + @recmodel + ' recovery model, one alternative is to set it to SIMPLE to truncate the log, shrink it, and reset it to ' + @recmodel + '.'
		PRINT '-- NOTE2: This method of setting the recovery model to SIMPLE and back again WILL BREAK log chaining, and thus any log shipping or mirroring.'
		PRINT 'USE [master]; ' + CHAR(13) + 'ALTER DATABASE ' + QUOTENAME(@dbname) + ' SET RECOVERY SIMPLE;'
		PRINT 'USE ' + QUOTENAME(@dbname) + ';' + CHAR(13) + 'DBCC SHRINKFILE (N''' + @filename + ''', 1);'
		PRINT 'USE [master]; ' + CHAR(13) + 'ALTER DATABASE ' + QUOTENAME(@dbname) + ' SET RECOVERY ' + @recmodel + ';'
		PRINT '--'
		PRINT '-- CHECK: if the tlog file has shrunk with the following query:'
		PRINT 'SELECT name, (size*8)/1024 AS log_MB FROM [' + @dbname + '].dbo.sysfiles WHERE (64 & status) = 64'
	END
	ELSE
	BEGIN
		PRINT '-- If not, then proceed to the next step (it may be necessary to execute multiple times):'
		PRINT 'DBCC SHRINKFILE (N''' + @filename + ''', 1);'
		PRINT '-- CHECK: if the tlog file has shrunk with the following query:'
		PRINT 'SELECT name, (size*8)/1024 AS log_MB FROM [' + @dbname + '].dbo.sysfiles WHERE (64 & status) = 64'
	END

	-- We are growing in MB instead of GB because of known issue prior to SQL 2012.
	-- More detail here: http://www.sqlskills.com/BLOGS/PAUL/post/Bug-log-file-growth-broken-for-multiples-of-4GB.aspx
	-- and http://connect.microsoft.com/SQLServer/feedback/details/481594/log-growth-not-working-properly-with-specific-growth-sizes-vlfs-also-not-created-appropriately
	-- or https://connect.microsoft.com/SQLServer/feedback/details/357502/transaction-log-file-size-will-not-grow-exactly-4gb-when-filegrowth-4gb
	IF @majorver >= 11
	BEGIN
		SET @n_iter = (SELECT CASE WHEN @logsize <= 64 THEN 1
			WHEN @logsize > 64 AND @logsize < 256 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/256, 0)
			WHEN @logsize >= 256 AND @logsize < 1024 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/512, 0)
			WHEN @logsize >= 1024 AND @logsize < 4096 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/1024, 0)
			WHEN @logsize >= 4096 AND @logsize < 8192 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/2048, 0)
			WHEN @logsize >= 8192 AND @logsize < 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/4096, 0)
			WHEN @logsize >= 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/8192, 0)
			END)
		SET @potsize = (SELECT CASE WHEN @logsize <= 64 THEN 1*64
			WHEN @logsize > 64 AND @logsize < 256 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/256, 0)*256
			WHEN @logsize >= 256 AND @logsize < 1024 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/512, 0)*512
			WHEN @logsize >= 1024 AND @logsize < 4096 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/1024, 0)*1024
			WHEN @logsize >= 4096 AND @logsize < 8192 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/2048, 0)*2048
			WHEN @logsize >= 8192 AND @logsize < 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/4096, 0)*4096
			WHEN @logsize >= 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/8192, 0)*8192
			END)
	END
	ELSE
	BEGIN
		SET @n_iter = (SELECT CASE WHEN @logsize <= 64 THEN 1
			WHEN @logsize > 64 AND @logsize < 256 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/256, 0)
			WHEN @logsize >= 256 AND @logsize < 1024 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/512, 0)
			WHEN @logsize >= 1024 AND @logsize < 4096 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/1024, 0)
			WHEN @logsize >= 4096 AND @logsize < 8192 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/2048, 0)
			WHEN @logsize >= 8192 AND @logsize < 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/4000, 0)
			WHEN @logsize >= 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/8000, 0)
			END)
		SET @potsize = (SELECT CASE WHEN @logsize <= 64 THEN 1*64
			WHEN @logsize > 64 AND @logsize < 256 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/256, 0)*256
			WHEN @logsize >= 256 AND @logsize < 1024 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/512, 0)*512
			WHEN @logsize >= 1024 AND @logsize < 4096 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/1024, 0)*1024
			WHEN @logsize >= 4096 AND @logsize < 8192 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/2048, 0)*2048
			WHEN @logsize >= 8192 AND @logsize < 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/4000, 0)*4000
			WHEN @logsize >= 16384 THEN ROUND(CONVERT(FLOAT, ROUND(@logsize, -2))/8000, 0)*8000
			END)
	END
	
	-- If the proposed log size is smaller than current log, and also smaller than 4GB,
	-- and there is less than 512MB of diff between the current size and proposed size, add 1 grow.
	SET @n_iter_final = @n_iter
	IF @logsize > @potsize AND @potsize <= 4096 AND ABS(@logsize - @potsize) < 512
	BEGIN
		SET @n_iter_final = @n_iter + 1
	END
	-- If the proposed log size is larger than current log, and also larger than 50GB, 
	-- and there is less than 1GB of diff between the current size and proposed size, take 1 grow.
	ELSE IF @logsize < @potsize AND @potsize <= 51200 AND ABS(@logsize - @potsize) > 1024
	BEGIN
		SET @n_iter_final = @n_iter - 1
	END

	IF @potsize = 0 
	BEGIN 
		SET @potsize = 64 
	END
	IF @n_iter = 0 
	BEGIN 
		SET @n_iter = 1
	END
	
	SET @potsize = (SELECT CASE WHEN @n_iter < @n_iter_final THEN @potsize + (@potsize/@n_iter) 
			WHEN @n_iter > @n_iter_final THEN @potsize - (@potsize/@n_iter) 
			ELSE @potsize END)
	
	SET @n_init_iter = @n_iter_final
	IF @potsize >= 8192
	BEGIN
		SET @initgrow = @potsize/@n_iter_final
	END
	IF @potsize >= 64 AND @potsize <= 512
	BEGIN
		SET @n_init_iter = 1
		SET @initgrow = 512
	END
	IF @potsize > 512 AND @potsize <= 1024
	BEGIN
		SET @n_init_iter = 1
		SET @initgrow = 1023
	END
	IF @potsize > 1024 AND @potsize < 8192
	BEGIN
		SET @n_init_iter = 1
		SET @initgrow = @potsize
	END

	INSERT INTO @tblvlf
	SELECT @dbname, @logsize, @potsize, @count, 
		CASE WHEN @potsize <= 64 THEN (@potsize/(@potsize/@n_init_iter))*4
			WHEN @potsize > 64 AND @potsize < 1024 THEN (@potsize/(@potsize/@n_init_iter))*8
			WHEN @potsize >= 1024 THEN (@potsize/(@potsize/@n_init_iter))*16
			END, 
		@n_init_iter, @initgrow, CASE WHEN (@potsize/@n_iter_final) <= 1024 THEN (@potsize/@n_iter_final) ELSE 1024 END
	
	SET @i = 0
	WHILE @i <= @n_init_iter
	BEGIN
		IF @i = 1
		BEGIN
			--Log Autogrow should not be above 1GB
			PRINT CHAR(13) + '-- Now for the log file growth:'
			PRINT 'ALTER DATABASE [' + @dbname + '] MODIFY FILE ( NAME = N''' + @filename + ''', SIZE = ' + CONVERT(VARCHAR, @initgrow) + 'MB , FILEGROWTH = ' + CASE WHEN (@potsize/@n_iter_final) <= 1024 THEN CONVERT(VARCHAR, (@potsize/@n_iter_final)) ELSE '1024' END + 'MB );'
		END
		IF @i > 1
		BEGIN
			PRINT 'ALTER DATABASE [' + @dbname + '] MODIFY FILE ( NAME = N''' + @filename + ''', SIZE = ' + CONVERT(VARCHAR, @initgrow*@i)+ 'MB );'
		END		
		SET @i = @i + 1
		CONTINUE
	END
	FETCH NEXT FROM cshrk INTO @dbname, @count
END
CLOSE cshrk
DEALLOCATE cshrk;

DROP TABLE #loginfo;

SELECT dbname AS [Database_Name], Actual_log_size_MB, Potential_log_size_MB, Actual_VLFs, 
	Potential_VLFs, Growth_iterations, Log_Initial_size_MB, File_autogrow_MB
FROM @tblvlf;
GO















