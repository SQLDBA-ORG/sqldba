$regchar = [char]0x00AE #Â®

$#nssm = (Get-Command nssm).Source
$serviceName = 'SQLDBA Reporting'
$powershell = (Get-Command powershell).Source
$scriptPath = "C:/sp_triage_ps/ps_sp_triage"+$regchar+"_service.ps1"
$arguments = '-ExecutionPolicy Bypass -NoProfile -File "{0}"' -f $scriptPath
 .\nssm.exe install $serviceName $powershell $arguments
 .\nssm.exe status $serviceName
Start-Service $serviceName
Get-Service $serviceName

[System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
#Invoke-Expression (Invoke-WebRequest -UseBasicParsing https://dbatools.io/in)
install-module dbatools
$dbainstances = Find-DbaInstance -DiscoveryType DomainSPN, Domain, DataSourceEnumeration, DomainServer
$dbainstances 