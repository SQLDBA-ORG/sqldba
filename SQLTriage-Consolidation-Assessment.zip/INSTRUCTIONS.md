# SQL Server Consolidation Self-Assessment

A read-only collection script plus a worksheet method that lets your own DBA
team take a first pass at the question: **"How many of our SQL Servers could
share hardware, and what would that do to our licence renewal?"**

If the person running the collection is not a DBA, hand them
**QUICKSTART-NON-DBA.md** instead - it covers steps 1-3 with no SQL
knowledge assumed; this document is for whoever interprets the results.

This is the screening pass, not the engineering pass. It is designed to be
runnable inside a normal change window with no approvals beyond "a DBA may
run a read-only diagnostic query." It looks like most estates this size find
the renewal-relevant answers (idle cores, downgrade candidates, mis-licensed
passive replicas) in this pass alone; the precise host-packing plan needs
longer-horizon data (see "Where this stops", below).

---

## 1. What gets collected

One result set per instance: version, edition, core/socket/memory shape, CPU
utilisation (last ~4 hours plus a since-startup average), memory pressure,
IO volume and latency, database footprint, top wait types, Availability
Group topology and replica roles, Enterprise-only feature usage per
database, and Query Store status.

**What does NOT get collected:** no query text, no execution plans, no
table or row data, no logins or security configuration. Metadata and
aggregate counters only. The script makes no changes to any database (it
uses one temporary table in tempdb and drops it).

Runtime is typically under 15 seconds per instance.

## 2. Permissions

Easiest: run as `sysadmin`. Least-privilege alternative: a login with
`VIEW SERVER STATE` and `VIEW ANY DATABASE` at the server level, plus
`VIEW DATABASE STATE` in each user database. Databases the login cannot
read are reported as "unreadable" rather than silently skipped, and a
login missing server-level permissions produces partial output with the
missing sections named - so a first pass with an imperfect account is
still worth running.

## 3. How to run it

Run against **every instance**, including every AG replica and every FCI
node's active instance. Secondaries are not optional - replica licensing is
usually where the money is.

**Option A - a few servers:** open
`SQLTriage-Consolidation-Collector.sql` in SSMS, connect to each instance,
execute, save results as CSV (right-click results grid > Save Results As).

**Option B - the whole estate (recommended for 50+ instances):** put one
instance name per line in `servers.txt`, then from this folder:

```powershell
.\Run-Collector.ps1
```

It uses your Windows credentials via `sqlcmd`, writes one file per instance
to `.\out\`, merges everything into `out\consolidation-assessment-all.psv`
(pipe-delimited - import to Excel with "|" as the delimiter), and writes
**`out\SUMMARY.md`** - the screening tests below computed automatically,
with per-instance flags and the estate-level rough estimates. Failed
instances are listed at the end; rerun those individually, then refresh the
summary with `.\Run-Collector.ps1 -AnalyzeOnly`.

For the second (batch-window) run use a separate folder so the two
snapshots can be compared: `.\Run-Collector.ps1 -OutDir .\out-batch`.

Robustness notes: pre-2012 instances are rejected with a readable message
(record those manually); Azure SQL DB / Managed Instance connections are
collected but marked inventory-only (vCore subscription pricing, not
per-core licences); a login missing some permissions produces partial
output with the gaps named, rather than nothing.

**Option C - Central Management Server:** if you already have a CMS,
open the .sql in a multi-server query window against your server group.
The output shape (InstanceName | Section | Item | Value) is designed to
merge cleanly.

### When to run

The CPU section's ring-buffer window only covers the **last ~4 hours**, so
run it twice per instance and keep both outputs:

1. once during your **business peak** (e.g. 11am on a normal weekday), and
2. once during your **batch/overnight window** (or first thing after it).

If your renewal sizing is driven by month-end processing, add a month-end
run. The `AvgCoresBusySinceStart` figure smooths over the whole uptime and
is your sanity check against catching an unrepresentative window.

## 4. Build the estate worksheet

If you used Option B, `out\SUMMARY.md` already contains this table and the
section 5/6 results - use the worksheet below to verify or extend it, or if
you collected via SSMS/CMS (Options A/C). Pivot the merged output (or
hand-fill from per-server results) into one row per instance with these
columns:

| Column | From (Section / Item) |
|---|---|
| Instance | INSTANCE / ServerName |
| Machine (spot shared hosts) | INSTANCE / MachineName |
| Edition | INSTANCE / Edition |
| Version | INSTANCE / ProductVersion |
| Cores (logical) | INSTANCE / LogicalCpuCount |
| Cores (physical) | SocketCount x CoresPerSocket |
| VM? | INSTANCE / VirtualMachineType |
| RAM GB | INSTANCE / PhysicalMemoryGB |
| Max server memory GB | INSTANCE / MaxServerMemoryMB / 1024 |
| CPU avg % (peak run) | CPU / TotalCpuAvgPct |
| CPU P95 % (peak run) | CPU / TotalCpuP95Pct |
| Avg cores busy | CPU / AvgCoresBusySinceStart |
| PLE sec | MEMORY / PageLifeExpectancySec |
| Read latency ms | IO / AvgReadLatencyMs |
| IO GB/day | IO / TotalReadGBPerDay + TotalWriteGBPerDay |
| Data GB | STORAGE / TotalDataFileGB |
| AG role / passive? | HADR rows |
| EE features in use? | EDITIONFEATURES (any row not "(none...)") |
| FCI? | INSTANCE / IsClustered_FCI |

## 5. The six screening tests

Work through these per instance. They are deliberately conservative,
public rules of thumb - when a test is borderline, mark it amber and move
on rather than arguing the edge case.

### Test 1 - CPU headroom (the consolidation candidate test)
GREEN if **P95 total CPU < 40%** during the peak-window run AND
**AvgCoresBusySinceStart < 25% of logical cores**. A 16-core server
averaging 2 busy cores looks like a consolidation candidate. RED if P95 >
70% on either run - that server keeps its own hardware (or gets more).

### Test 2 - Memory pressure (the hidden stacking cost)
A consolidated host must hold the sum of what instances actually *use*,
not what they're capped at. AMBER if `TotalServerMemoryGB` has reached
`TargetServerMemoryGB` AND PLE is low for the buffer pool size (rule of
thumb: PLE below ~300 seconds per 4 GB of buffer pool). RED if
`MemoryGrantsPending` > 0 on any run. Memory-pressured instances still
consolidate, but budget their full target memory, not their average.

### Test 3 - Edition downgrade (often the single biggest line item)
For every **Enterprise** instance where ALL databases report
`(none - no edition-locked features)` in EDITIONFEATURES, AND logical
cores <= 24, AND max server memory <= 128 GB: it looks like there could be
a Standard Edition downgrade here. At 2022 US list, Enterprise is roughly
**$7,560/core vs $1,970/core** for Standard - around a 74% per-core
difference (verify against your EA pricing, not list).
Three caveats before you bank it: (a) `dm_db_persisted_sku_features` only
catches *persisted* features - online index rebuilds, readable AG
secondaries and >1 AG secondary are Enterprise behaviours it cannot see,
so check your HA design against section 6; (b) the DMV still lists
features that STOPPED being Enterprise-only: from **2016 SP1**,
`Compression`, `ColumnStoreIndex`, `Partitioning` and `InMemoryOLTP` are
Standard-supported (with memory caps), and from **2019** so is TDE - on
those versions these entries do NOT block a downgrade; on older versions
they do; (c) instances restarted recently may not have exercised every
workload yet.

### Test 4 - Passive replicas (check before you pay the renewal)
In the HADR rows, every replica showing `SECONDARY` with
`readable_secondary=NO` is, if you have Software Assurance, a **free
passive replica** (one free passive per licensed primary under SA, plus
DR rights). Count them, then check your renewal quote: it is common for
true-up counts to include passives that should not be there. Any replica
with `readable_secondary=ALL` or `READ_ONLY` is NOT passive and must be
fully licensed - and readable secondaries are Enterprise-only.

### Test 5 - IO compatibility (who can share a datastore)
Instances with `AvgReadLatencyMs` > 20ms are already storage-constrained;
stacking them with high `IO GB/day` neighbours makes both worse. Sort the
worksheet by IO GB/day - the top decile usually shouldn't share storage
paths with each other. Latency < 10ms and modest GB/day = stack freely.

### Test 6 - Things that veto co-location
Keep separate regardless of headroom: instances with different patching
or compliance regimes; FCI nodes (consolidate the *workload*, not the
cluster); anything with `VisibleOnlineSchedulers` < `LogicalCpuCount`
(already core-capped - investigate why before moving it); vendor apps
whose support agreement names a dedicated server.

## 6. The stacking maths (how many hosts)

For each group of GREEN/AMBER candidates you'd like to co-locate:

- **Optimistic floor** = sum of `AvgCoresBusySinceStart`. Real peaks
  overlap, so you will need more than this.
- **Conservative ceiling** = sum of each instance's
  (`TotalCpuP95Pct` x logical cores / 100). Peaks rarely ALL coincide, so
  you will need less than this.
- The defensible target sits between the two. Without time-aligned data
  you cannot know where, so for a renewal decision use:
  **host cores = ceiling figure x 0.7, rounded up to the next licensing
  increment (2-core packs, 4-core minimum per VM/instance), plus 25%
  headroom for failover.**

Memory: sum of `TargetServerMemoryGB` for everything on the host, plus OS
overhead. Memory does not statistically multiplex the way CPU does - do
not thin-provision it on paper.

**Shared hosts:** instances installed on the same machine (same
`MachineName`) each report the machine's FULL core count - summing them
double-counts the hardware. Count shared machines once; the generated
SUMMARY.md flags these automatically.

Licensing end-state worth pricing: for dense virtualised estates, licensing
the **hosts** with Enterprise + SA (unlimited virtualisation rights) is
frequently cheaper past roughly 8-10 SQL VMs per host than licensing each
VM. Price both ways.

## 7. Worked example (three instances)

| Instance | Cores | Edition | P95 CPU | Avg cores busy | EE features |
|---|---|---|---|---|---|
| ERP-SQL01 | 16 | Enterprise | 22% | 1.8 | (none) |
| RPT-SQL02 | 24 | Enterprise | 35% | 4.1 | Compression |
| APP-SQL03 | 8 | Standard | 18% | 0.9 | n/a |

- Floor = 1.8 + 4.1 + 0.9 = **6.8 cores**. Ceiling = 3.5 + 8.4 + 1.4 =
  **13.3 cores**. Target = 13.3 x 0.7 = 9.3 -> a **12-core host** (with
  headroom) replaces 48 licensed cores.
- ERP-SQL01 additionally passes the downgrade screen (16 cores, no EE
  features) - it looks like there could be an EE->SE conversion worth
  roughly 16 x ($7,560 - $1,970) = ~$89k at list *on top of* the
  consolidation saving, if its HA design allows it.
- RPT-SQL02 lists Compression -> check the version: on 2016 SP1 or later
  Compression is Standard-supported and does not block the downgrade; on
  an older build it does (remediate or stay Enterprise).

Across 150 servers the same arithmetic typically surfaces the renewal
conversation you actually want to have with your reseller.

## 8. Where this stops (honest limits)

- The ring buffer is a 4-hour keyhole and `AvgCoresBusySinceStart` is a
  smoothed floor (plan-cache eviction undercounts it). Two snapshots
  bracket reality; they don't capture it.
- The floor/ceiling band can be wide. Closing it requires weeks of
  time-aligned samples per instance so that overlapping peaks are
  *measured*, not assumed - that is precisely what our full evaluation
  does (Query Store-backed CPU chains, time-synchronised percentile
  stacking, per-server confidence grading, and a costed host-packing plan
  priced at your EA rates, not list).
- This pass shows whether savings *look* real and roughly how large they
  could be. The full evaluation shows *which servers move where*, in what
  order, with what confidence - the version you can take to procurement.

## 9. Getting a second pair of eyes (optional)

Everything above computes on your side - nothing has to leave your
network for the screening to work.

It sounds like many organisations can't share infrastructure details
externally, and that's exactly the right instinct. For that case the
runner has a built-in pseudonymiser:

```powershell
.\Run-Collector.ps1 -AnalyzeOnly -Anonymise
```

It writes an `out-anon` folder where machine, instance, Availability
Group and database names become consistent pseudonyms (`SAUSAGE\THING01`,
`AG01`, `DB003`...) while versions, editions, core counts and the
topology relationships stay intact - open any file in Notepad to verify
nothing identifiable remains. The translation map
(`out\anonymisation-map.csv`) **stays with you**; it is the only way to
decode findings back to real names, and we never need it.

If you'd like our read against your renewal: send the `out-anon` folder
(or the plain `out` folder, if your policy allows) to
**adrian@sqldba.org**, together with the core counts from your renewal
quote. Findings come back in the same pseudonyms and you translate them
locally with the map. A first-pass read of an estate this size is
usually a same-week turnaround - would it be unreasonable to have these
numbers checked before the renewal is signed?

---
*SQLTriage - read-only estate diagnostics. Version 1.0 (2025-03-02), rev. 2026-06-12.*
