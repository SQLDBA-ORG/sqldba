#Requires -Version 3.0
<#
.SYNOPSIS
    Runs the SQLTriage consolidation collector against a list of SQL Server
    instances, merges the results, and writes a rough-estimate SUMMARY.md.

.DESCRIPTION
    Reads instance names from servers.txt (one per line; comments with #),
    runs SQLTriage-Consolidation-Collector.sql against each using sqlcmd with
    Windows authentication, writes one output file per instance under .\out\,
    merges everything into consolidation-assessment-all.psv, then applies the
    screening tests from INSTRUCTIONS.md and writes out\SUMMARY.md.

    The summary is a SCREENING estimate built from point-in-time data and
    US list prices. It tells you where to look, not what to sign.

    Read-only. Requires sqlcmd (installed with SSMS or SQL command-line
    utilities) and a login with the permissions listed in the .sql header.

.PARAMETER AnalyzeOnly
    Skip collection; re-summarise whatever is already in -OutDir.

.PARAMETER Anonymise
    Additionally write an "<OutDir>-anon" folder where machine, instance,
    Availability Group and database names are replaced by consistent
    pseudonyms (SAUSAGE\THING01, AG01, DB003...) so results can be shared
    outside your organisation. Versions, editions, core counts and topology
    relationships are preserved. The translation map is written to
    <OutDir>\anonymisation-map.csv and must STAY WITH YOU - send only the
    -anon folder.

.PARAMETER LegacySqlcmd
    Omit the -C (trust server certificate) flag for very old sqlcmd builds
    that reject it. Only needed if every server fails with "Invalid option".

.EXAMPLE
    .\Run-Collector.ps1
    .\Run-Collector.ps1 -OutDir .\out-batch      # second run (overnight window)
    .\Run-Collector.ps1 -AnalyzeOnly             # re-summarise existing .\out\
#>
param(
    [string]$ServerList = (Join-Path $PSScriptRoot 'servers.txt'),
    [string]$OutDir     = (Join-Path $PSScriptRoot 'out'),
    [string]$Script     = (Join-Path $PSScriptRoot 'SQLTriage-Consolidation-Collector.sql'),
    [switch]$AnalyzeOnly,
    [Alias('Anonymize')]
    [switch]$Anonymise,
    [switch]$LegacySqlcmd
)

$ErrorActionPreference = "Stop"

# US list, SQL Server 2022, per core (2-core packs / 2). Verify against your EA.
$EEPerCore = 7560
$SEPerCore = 1970

#==============================================================================
# 1. COLLECT
#==============================================================================
if (-not $AnalyzeOnly) {
    if (-not (Test-Path $ServerList)) {
        Write-Host "Server list not found: $ServerList" -ForegroundColor Red
        Write-Host "Create it with one instance per line, e.g.:"
        Write-Host "    PRODSQL01"
        Write-Host "    PRODSQL02\INST1"
        Write-Host "    DRSQL01   # comments allowed"
        exit 1
    }
    if (-not (Test-Path $Script)) { Write-Host "Collector script not found: $Script" -ForegroundColor Red; exit 1 }
    if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }

    $servers = @(Get-Content $ServerList |
        ForEach-Object { ($_ -split '#')[0].Trim() } |
        Where-Object { $_ -ne "" })

    $ok = 0; $failed = @(); $i = 0
    foreach ($s in $servers) {
        $i++
        $safe = $s -replace '[\\\/:,]', '_'
        $file = Join-Path $OutDir "$safe.psv"
        Write-Host "[$i/$($servers.Count)] $s ... " -NoNewline
        $sqlArgs = @('-S', $s, '-d', 'master', '-E',
                     '-i', $Script, '-o', $file,
                     '-s', '|', '-W', '-b', '-l', '15', '-t', '60', '-u')
        if (-not $LegacySqlcmd) { $sqlArgs += '-C' }   # newer sqlcmd enforces TLS; trust the server cert
        sqlcmd @sqlArgs
        if ($LASTEXITCODE -eq 0) {
            Write-Host "ok" -ForegroundColor Green
            $ok++
        } else {
            Write-Host "FAILED (see $file)" -ForegroundColor Red
            $failed += $s
        }
    }

    # Merge: keep one header, drop sqlcmd's dashed underline rows
    $merged = Join-Path $OutDir "consolidation-assessment-all.psv"
    "InstanceName|Section|Item|Value" | Out-File $merged -Encoding utf8
    Get-ChildItem $OutDir -Filter "*.psv" |
        Where-Object { $_.Name -ne "consolidation-assessment-all.psv" } |
        ForEach-Object {
            Get-Content $_.FullName |
                Where-Object { $_ -match '\|' -and $_ -notmatch '^-+\|' -and $_ -notmatch '^InstanceName\|' } |
                Add-Content $merged -Encoding utf8
        }

    Write-Host ""
    Write-Host "Collected $ok of $($servers.Count) instances."
    if ($failed.Count -gt 0) {
        Write-Host "Failed instances (rerun individually or check connectivity/permissions):" -ForegroundColor Yellow
        $failed | ForEach-Object { Write-Host "  $_" }
    }
}

#==============================================================================
# 2. ANALYSE - screening tests from INSTRUCTIONS.md, nothing fancier
#==============================================================================
if (-not (Test-Path $OutDir)) { Write-Host "Output folder not found: $OutDir" -ForegroundColor Red; exit 1 }

$rows = New-Object System.Collections.ArrayList
$instSource = @{}   # InstanceName -> first file seen in; detects double collection
$dupes = @{}
Get-ChildItem $OutDir -Filter "*.psv" |
    Where-Object { $_.Name -ne "consolidation-assessment-all.psv" } |
    ForEach-Object {
        $fname = $_.Name
        Get-Content $_.FullName | Where-Object { $_ -match '\|' -and $_ -notmatch '^-+\|' -and $_ -notmatch '^InstanceName\|' } |
            ForEach-Object {
                $p = $_ -split '\|', 4   # Value may itself contain " | " (HADR rows)
                if ($p.Count -eq 4) {
                    [void]$rows.Add([pscustomobject]@{ Inst = $p[0]; Sec = $p[1]; Item = $p[2]; Val = $p[3] })
                    if (-not $instSource.ContainsKey($p[0])) { $instSource[$p[0]] = $fname }
                    elseif ($instSource[$p[0]] -ne $fname)   { $dupes[$p[0]] = $true }
                }
            }
    }
if ($rows.Count -eq 0) { Write-Host "No collector output found in $OutDir - nothing to summarise." -ForegroundColor Red; exit 1 }

# Index once: 150 servers x ~60 rows must not mean repeated full scans
$byInst = @{}
foreach ($row in $rows) {
    if (-not $byInst.ContainsKey($row.Inst)) {
        $byInst[$row.Inst] = @{ Map = @{}; List = New-Object System.Collections.ArrayList }
    }
    $b = $byInst[$row.Inst]
    [void]$b.List.Add($row)
    $k = $row.Sec + '|' + $row.Item
    if (-not $b.Map.ContainsKey($k)) { $b.Map[$k] = $row.Val }   # first wins (dupes warned above)
}

function Get-CVal($inst, $sec, $item) {
    $b = $byInst[$inst]; if ($null -eq $b) { return $null }
    $v = $b.Map[$sec + '|' + $item]
    if ($v -eq 'NULL' -or $v -eq '') { $null } else { $v }      # sqlcmd renders SQL NULL literally
}
function Get-CNum($inst, $sec, $item) {
    $v = Get-CVal $inst $sec $item
    $r = 0.0
    if ($null -ne $v -and [double]::TryParse($v, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$r)) { $r } else { $null }
}
function Get-CRows($inst, $sec) {
    @($byInst[$inst].List | Where-Object { $_.Sec -eq $sec })
}

# Features no longer Enterprise-only on newer versions (still listed by the DMV)
$se2016Features = @('Compression', 'ColumnStoreIndex', 'Partitioning', 'InMemoryOLTP')

$instances = @($byInst.Keys | Sort-Object)
$report = @()
foreach ($inst in $instances) {
    $o = [ordered]@{}
    $o.Inst      = $inst
    $o.Machine   = Get-CVal $inst 'INSTANCE' 'MachineName'
    $o.Edition   = Get-CVal $inst 'INSTANCE' 'Edition'
    $o.Version   = Get-CVal $inst 'INSTANCE' 'ProductVersion'
    $o.Major     = 0; if ($o.Version) { $o.Major = [int](($o.Version -split '\.')[0]) }
    $ee          = Get-CNum $inst 'INSTANCE' 'EngineEdition'
    $o.IsAzure   = ($null -ne $ee -and $ee -in @(5, 8))
    $o.Cores     = Get-CNum $inst 'INSTANCE' 'LogicalCpuCount'
    $o.RamGB     = Get-CNum $inst 'INSTANCE' 'PhysicalMemoryGB'
    $o.MaxMemMB  = Get-CNum $inst 'INSTANCE' 'MaxServerMemoryMB'
    $o.Sched     = Get-CNum $inst 'INSTANCE' 'VisibleOnlineSchedulers'
    $o.FCI       = (Get-CVal $inst 'INSTANCE' 'IsClustered_FCI') -eq '1'
    $o.UptimeDays = Get-CNum $inst 'INSTANCE' 'UptimeDays'

    $o.P95Pct    = Get-CNum $inst 'CPU' 'TotalCpuP95Pct'
    $o.AvgBusy   = Get-CNum $inst 'CPU' 'AvgCoresBusySinceStart'
    $o.P95Cores  = $null
    if ($null -ne $o.P95Pct -and $null -ne $o.Cores) { $o.P95Cores = [math]::Round($o.P95Pct / 100.0 * $o.Cores, 1) }

    $o.PLE       = Get-CNum $inst 'MEMORY' 'PageLifeExpectancySec'
    $o.TgtMemGB  = Get-CNum $inst 'MEMORY' 'TargetServerMemoryGB'
    $o.TotMemGB  = Get-CNum $inst 'MEMORY' 'TotalServerMemoryGB'
    $o.Grants    = Get-CNum $inst 'MEMORY' 'MemoryGrantsPending'

    $o.ReadLat   = Get-CNum $inst 'IO' 'AvgReadLatencyMs'
    $rd = Get-CNum $inst 'IO' 'TotalReadGBPerDay'; $wr = Get-CNum $inst 'IO' 'TotalWriteGBPerDay'
    $o.IoGBDay   = $null; if ($null -ne $rd -and $null -ne $wr) { $o.IoGBDay = [math]::Round($rd + $wr, 1) }

    # --- Test 1: CPU headroom
    if ($null -ne $o.P95Pct -and $null -ne $o.AvgBusy -and $null -ne $o.Cores) {
        if     ($o.P95Pct -gt 70)                                          { $o.CpuFlag = 'RED' }
        elseif ($o.P95Pct -lt 40 -and $o.AvgBusy -lt (0.25 * $o.Cores))    { $o.CpuFlag = 'GREEN' }
        else                                                               { $o.CpuFlag = 'AMBER' }
    } else { $o.CpuFlag = 'UNKNOWN' }

    # --- Test 2: memory pressure
    if ($null -eq $o.PLE -and $null -eq $o.TgtMemGB -and $null -eq $o.Grants) { $o.MemFlag = 'UNKNOWN' }
    elseif ($null -ne $o.Grants -and $o.Grants -gt 0) { $o.MemFlag = 'RED' }
    else {
        $o.MemFlag = 'GREEN'
        if ($null -ne $o.TgtMemGB -and $null -ne $o.TotMemGB -and $null -ne $o.PLE) {
            $pleFloor = ($o.TotMemGB / 4.0) * 300
            if ($o.TotMemGB -ge (0.98 * $o.TgtMemGB) -and $o.PLE -lt $pleFloor) { $o.MemFlag = 'AMBER' }
        }
    }

    # --- Test 5: IO
    if ($null -eq $o.ReadLat) { $o.IoFlag = 'UNKNOWN' }
    elseif ($o.ReadLat -gt 20) { $o.IoFlag = 'RED' }
    elseif ($o.ReadLat -gt 10) { $o.IoFlag = 'AMBER' }
    else { $o.IoFlag = 'GREEN' }

    # --- Test 3: edition-downgrade screen (version-aware feature filter)
    $o.Blocking   = @()
    $o.Unreadable = 0
    $o.Verify2016 = $false
    foreach ($fr in (Get-CRows $inst 'EDITIONFEATURES')) {
        if ($fr.Val -like 'unreadable:*') { $o.Unreadable++; continue }
        if ($fr.Val -like '(none*')      { continue }
        foreach ($f in ($fr.Val -split ';\s*')) {
            $f = $f.Trim(); if ($f -eq '') { continue }
            $nonBlocking = $false
            if ($o.Major -ge 14 -and $se2016Features -contains $f) { $nonBlocking = $true }
            if ($o.Major -eq 13 -and $se2016Features -contains $f) { $nonBlocking = $true; $o.Verify2016 = $true }
            if ($o.Major -ge 15 -and $f -eq 'TransparentDataEncryption') { $nonBlocking = $true }
            if (-not $nonBlocking -and $o.Blocking -notcontains $f) { $o.Blocking += $f }
        }
    }
    $o.Licensable   = ($null -ne $o.Edition) -and ($o.Edition -notmatch 'Developer|Express|Evaluation') -and (-not $o.IsAzure)
    $o.IsEnterprise = ($o.Edition -match 'Enterprise') -and $o.Licensable
    $o.HasAG        = @(Get-CRows $inst 'HADR' | Where-Object { $_.Item -like 'AG: *' }).Count -gt 0
    $o.Downgrade = $o.IsEnterprise -and
                   ($null -ne $o.Cores -and $o.Cores -le 24) -and
                   ($null -ne $o.MaxMemMB -and $o.MaxMemMB -le 131072) -and
                   ($o.Blocking.Count -eq 0) -and ($o.Unreadable -eq 0)

    # --- Test 6: vetoes / notes (incl. collection-quality signals)
    $o.Notes = @()
    if ($o.IsAzure) { $o.Notes += 'Azure SQL - inventory only, excluded from maths' }
    if (-not $o.Licensable -and -not $o.IsAzure -and $null -ne $o.Edition) { $o.Notes += 'non-production edition' }
    if ($null -ne $o.Sched -and $null -ne $o.Cores -and $o.Sched -lt $o.Cores) { $o.Notes += "core-capped ($([int]$o.Sched)/$([int]$o.Cores) schedulers)" }
    if ($o.FCI) { $o.Notes += 'FCI node' }
    if ($null -ne $o.UptimeDays -and $o.UptimeDays -lt 7) { $o.Notes += "only $($o.UptimeDays)d uptime - averages thin" }
    if ($o.Unreadable -gt 0) { $o.Notes += "$($o.Unreadable) unreadable DB(s)" }
    if ($o.Verify2016) { $o.Notes += '2016: features need SP1+ to be SE-safe - verify build' }
    if ($dupes.ContainsKey($inst)) { $o.Notes += 'collected via multiple names (listener + node?) - counted once' }
    $errSecs = @(($byInst[$inst].List | Where-Object { $_.Item -match 'Error$' }) | Select-Object -ExpandProperty Sec -Unique)
    if ($errSecs.Count -gt 0) { $o.Notes += "incomplete sections: $($errSecs -join ', ')" }

    $report += [pscustomobject]$o
}

# Multiple instances on one machine each report the machine's FULL core count;
# flag the sharing so cores aren't read (or licensed) twice.
$sharedHosts = @($report | Where-Object { $null -ne $_.Machine } | Group-Object Machine | Where-Object { $_.Count -gt 1 })
foreach ($g in $sharedHosts) {
    foreach ($r in $g.Group) { $r.Notes += "1 of $($g.Count) instances on host $($g.Name) - host cores shown $($g.Count)x" }
}

# --- Test 4: passive replicas (deduped estate-wide - every instance in an AG
#     reports the same cluster-wide replica rows)
$agRows = @($rows | Where-Object { $_.Sec -eq 'HADR' -and $_.Item -like 'AG: *' } |
            Sort-Object Item -Unique)
$passives  = @($agRows | Where-Object { $_.Val -match '^SECONDARY' -and $_.Val -match 'readable_secondary=NO' })
$readables = @($agRows | Where-Object { $_.Val -match 'readable_secondary=(ALL|READ_ONLY)' -and $_.Val -notmatch '^PRIMARY' })

# --- Stacking band over GREEN + AMBER CPU candidates (Azure and core-capped excluded)
$cand = @($report | Where-Object { $_.CpuFlag -in @('GREEN','AMBER') -and (-not $_.IsAzure) -and ($_.Notes -notmatch 'core-capped') })
$floor = (@($cand | Where-Object { $null -ne $_.AvgBusy })  | Measure-Object -Property AvgBusy  -Sum).Sum
$ceil  = (@($cand | Where-Object { $null -ne $_.P95Cores }) | Measure-Object -Property P95Cores -Sum).Sum
$candCores = (@($cand | Where-Object { $null -ne $_.Cores }) | Measure-Object -Property Cores -Sum).Sum
$candMemGB = (@($cand | Where-Object { $null -ne $_.TgtMemGB }) | Measure-Object -Property TgtMemGB -Sum).Sum
$licCores  = (@($cand | Where-Object { $_.Licensable -and $null -ne $_.Cores }) | Measure-Object -Property Cores -Sum).Sum
foreach ($n in 'floor','ceil','candCores','candMemGB','licCores') {
    if ($null -eq (Get-Variable $n -ValueOnly)) { Set-Variable $n 0 }
}
$target = $null
if ($null -ne $ceil -and $ceil -gt 0) {
    $target = [math]::Ceiling($ceil * 0.7)
    if ($target % 2 -ne 0) { $target++ }          # 2-core licensing increments
    if ($target -lt 4) { $target = 4 }            # 4-core minimum
}

$downgrades = @($report | Where-Object { $_.Downgrade })
$dgCores = 0; foreach ($d in $downgrades) { $dgCores += [math]::Max([int]$d.Cores, 4) }
$dgSaving = $dgCores * ($EEPerCore - $SEPerCore)
$unknowns = @($report | Where-Object { $_.CpuFlag -eq 'UNKNOWN' -and -not $_.IsAzure })

#==============================================================================
# 3. SUMMARY.md
#==============================================================================
function Fmt($v, $dec = 0) { if ($null -eq $v) { 'n/a' } else { $v.ToString("N$dec", [Globalization.CultureInfo]::InvariantCulture) } }

$md = @()
$md += '# Consolidation Screening Summary (rough estimate)'
$md += ''
$md += "Generated $(Get-Date -Format 'yyyy-MM-dd HH:mm') from $($instances.Count) instance(s) in ``$(Split-Path $OutDir -Leaf)``."
$md += ''
$md += '> **Read this first:** these figures come from point-in-time snapshots and'
$md += '> US list prices. They are a screening estimate - good enough to decide'
$md += '> whether a conversation is worth having, not good enough to sign a'
$md += '> renewal against. See INSTRUCTIONS.md sections 6 and 8 for the maths'
$md += '> and its limits.'
$md += ''
$md += '## Estate at a glance'
$md += ''
$md += "| | |"
$md += "|---|---|"
$md += "| Instances analysed | $($instances.Count) |"
$md += "| Total logical cores | $(Fmt ((@($report | Where-Object { $null -ne $_.Cores }) | Measure-Object -Property Cores -Sum).Sum)) |"
$md += "| Enterprise (licensable) instances | $(@($report | Where-Object IsEnterprise).Count) |"
$md += "| Azure SQL instances (inventory only) | $(@($report | Where-Object IsAzure).Count) |"
$md += "| CPU screening: GREEN / AMBER / RED / no data | $(@($report | Where-Object CpuFlag -eq 'GREEN').Count) / $(@($report | Where-Object CpuFlag -eq 'AMBER').Count) / $(@($report | Where-Object CpuFlag -eq 'RED').Count) / $($unknowns.Count) |"
$md += "| Edition-downgrade candidates | $($downgrades.Count) |"
$md += "| AG replicas seen (deduped) / passive / readable-secondary | $($agRows.Count) / $($passives.Count) / $($readables.Count) |"
$md += ''
$md += '## Per-instance screening'
$md += ''
$md += '| Instance | Edition | Cores | P95 CPU % | Avg cores busy | CPU | Mem | IO | IO GB/day | Downgrade? | Notes |'
$md += '|---|---|---:|---:|---:|---|---|---|---:|---|---|'
foreach ($r in $report) {
    $dg = ''
    if ($r.Downgrade) { $dg = 'CANDIDATE' }
    elseif ($r.IsEnterprise -and $r.Blocking.Count -gt 0) { $dg = 'blocked: ' + ($r.Blocking -join ', ') }
    elseif ($r.IsEnterprise) { $dg = 'no (size/visibility)' }
    elseif (-not $r.Licensable) { $dg = 'n/a' }
    $md += "| $($r.Inst) | $($r.Edition) | $(Fmt $r.Cores) | $(Fmt $r.P95Pct) | $(Fmt $r.AvgBusy 2) | $($r.CpuFlag) | $($r.MemFlag) | $($r.IoFlag) | $(Fmt $r.IoGBDay 1) | $dg | $($r.Notes -join '; ') |"
}
$md += ''
$md += '## What it looks like the numbers are saying'
$md += ''
if ($cand.Count -gt 0) {
    $md += "### Consolidation stacking band ($($cand.Count) candidate instance(s), $(Fmt $candCores) cores today, $(Fmt $licCores) of them licensable)"
    $md += ''
    $md += "- Optimistic floor (sum of average busy cores): **$(Fmt $floor 1) cores**"
    $md += "- Conservative ceiling (sum of per-instance P95 cores): **$(Fmt $ceil 1) cores**"
    $md += "- Screening target (ceiling x 0.7, rounded to licensing increments): **~$(Fmt $target) cores** (+25% failover headroom when you size hosts)"
    $md += "- Memory the consolidated host(s) must hold: **~$(Fmt $candMemGB 0) GB** (sum of target server memory - do not thin-provision)"
    if ($sharedHosts.Count -gt 0) {
        $md += "- **Caution:** $($sharedHosts.Count) physical host(s) carry multiple instances - each instance reports the full host core count, so the figures above double-count shared hardware. License and size by host, not by instance, for those."
    }
    if ($null -ne $target -and $null -ne $licCores -and $licCores -gt $target) {
        $saveLow  = ($licCores - $target) * $SEPerCore
        $saveHigh = ($licCores - $target) * $EEPerCore
        $md += "- It looks like there could be a reduction of **~$(Fmt ($licCores - $target)) licensed cores** (licensable instances only), worth roughly **`$$(Fmt $saveLow) - `$$(Fmt $saveHigh)** at US list depending on edition mix (verify against your EA)."
    }
    $md += ''
}
if ($unknowns.Count -gt 0) {
    $md += "### Insufficient data ($($unknowns.Count)) - excluded from the maths"
    $md += ''
    foreach ($u in $unknowns) { $md += "- $($u.Inst) ($($u.Notes -join '; '))" }
    $md += '- Re-run the collector against these (check the .psv file for section errors) before relying on estate totals.'
    $md += ''
}
if ($downgrades.Count -gt 0) {
    $md += "### Edition downgrade candidates ($($downgrades.Count))"
    $md += ''
    foreach ($d in $downgrades) {
        $agNote = ''
        if ($d.HasAG) { $agNote = ' **In an AG** - confirm secondaries are non-readable and single before banking this.' }
        $md += "- **$($d.Inst)** - $(Fmt $d.Cores) cores, no blocking persisted features: ~`$$(Fmt ([math]::Max([int]$d.Cores,4) * ($EEPerCore - $SEPerCore))) at list if Standard fits the HA design.$agNote"
    }
    $md += "- Combined indicative figure: **~`$$(Fmt $dgSaving)** at US list. Confirm HA behaviours (readable secondaries, >1 secondary, online index rebuilds) before banking any of it."
    $md += ''
}
if ($passives.Count -gt 0) {
    $md += "### Passive replicas to check against the renewal ($($passives.Count))"
    $md += ''
    foreach ($p in $passives) { $md += "- $($p.Item)" }
    $md += "- Under Software Assurance these should not consume licences. Check the renewal quote's core counts include none of them."
    $md += ''
}
if ($readables.Count -gt 0) {
    $md += "### Readable secondaries ($($readables.Count)) - fully licensed AND Enterprise-only"
    $md += ''
    foreach ($p in $readables) { $md += "- $($p.Item)" }
    $md += ''
}
$reds = @($report | Where-Object { $_.CpuFlag -eq 'RED' -or $_.MemFlag -eq 'RED' -or $_.IoFlag -eq 'RED' })
if ($reds.Count -gt 0) {
    $md += "### Keep on their own hardware (RED on at least one test)"
    $md += ''
    foreach ($r in $reds) { $md += "- $($r.Inst) (CPU $($r.CpuFlag), Mem $($r.MemFlag), IO $($r.IoFlag))" }
    $md += ''
}
$md += '## Next step'
$md += ''
$md += 'Does this match what you suspected about the estate? This screening shows'
$md += 'whether savings *look* real - deciding which servers move where, in what'
$md += 'order and with what confidence, needs weeks of time-aligned samples.'
$md += 'INSTRUCTIONS.md section 9 covers getting a second pair of eyes on these'
$md += 'numbers without any real server names leaving your network. Would it be'
$md += 'unreasonable to have them checked before the renewal is signed?'

$summaryPath = Join-Path $OutDir 'SUMMARY.md'
$md -join "`r`n" | Out-File $summaryPath -Encoding utf8

Write-Host ""
Write-Host "Summary written: $summaryPath"
Write-Host "Merged output:   $(Join-Path $OutDir 'consolidation-assessment-all.psv')"
Write-Host "Detail and method: INSTRUCTIONS.md"

#==============================================================================
# 4. ANONYMISE (opt-in) - pseudonymised copy that is safe to share externally
#==============================================================================
if ($Anonymise) {
    $anonDir = "$OutDir-anon"
    if (-not (Test-Path $anonDir)) { New-Item -ItemType Directory -Path $anonDir | Out-Null }
    Remove-Item (Join-Path $anonDir '*') -Recurse -Force -ErrorAction SilentlyContinue

    $foods = @('SAUSAGE','PICKLE','WAFFLE','TACO','BAGEL','NOODLE','MUFFIN','PRETZEL','BISCUIT','KEBAB',
               'PANCAKE','DUMPLING','CRUMPET','TOFFEE','NUGGET','BURRITO','LASAGNE','SCONE','PAVLOVA','FRITTER',
               'GHERKIN','PORRIDGE','STRUDEL','PUDDING','CUSTARD','TRIFLE','FLAPJACK','CHUTNEY','RISOTTO','GNOCCHI',
               'PAELLA','FONDUE','QUICHE','BRIOCHE','CROISSANT','MACARON','PRALINE','SORBET','TANDOORI','FALAFEL')
    $map      = New-Object System.Collections.ArrayList
    $lookupCI = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::OrdinalIgnoreCase)

    function Add-Anon($type, $orig, $anon) {
        if ([string]::IsNullOrWhiteSpace($orig) -or $lookupCI.ContainsKey($orig)) { return }
        $lookupCI[$orig] = $anon
        [void]$map.Add([pscustomobject]@{ Type = $type; Original = $orig; Anonymised = $anon })
    }

    # 1) machine names -> food words (wrap to WORD2, WORD3... past 40 hosts)
    $machines = @($report | Where-Object { $null -ne $_.Machine } | Select-Object -ExpandProperty Machine -Unique)
    $mi = 0
    foreach ($m in $machines) {
        $word = $foods[$mi % $foods.Count]
        $round = [math]::Floor($mi / $foods.Count); if ($round -gt 0) { $word = "$word$($round + 1)" }
        Add-Anon 'Machine' $m $word
        $mi++
    }

    # 2) server\instance names (incl. AG replica names) -> MACHINE\THINGnn
    $serverNames = New-Object System.Collections.ArrayList
    foreach ($inst in $instances) {
        [void]$serverNames.Add($inst)
        $sv = Get-CVal $inst 'INSTANCE' 'ServerName'; if ($sv) { [void]$serverNames.Add($sv) }
    }
    foreach ($r in @($rows | Where-Object { $_.Sec -eq 'HADR' -and $_.Item -like 'AG: *' })) {
        $rep = ($r.Item.Substring(4) -split ' / ', 2)
        if ($rep.Count -eq 2) { [void]$serverNames.Add($rep[1]) }
    }
    $ti = 0
    foreach ($sn in @($serverNames | Sort-Object -Unique)) {
        if ($lookupCI.ContainsKey($sn)) { continue }
        $parts = $sn -split '\\', 2
        if (-not $lookupCI.ContainsKey($parts[0])) {
            $word = $foods[$mi % $foods.Count]
            $round = [math]::Floor($mi / $foods.Count); if ($round -gt 0) { $word = "$word$($round + 1)" }
            Add-Anon 'Machine' $parts[0] $word
            $mi++
        }
        $mAnon = $lookupCI[$parts[0]]
        if ($parts.Count -eq 2) { $ti++; Add-Anon 'Instance' $sn ('{0}\THING{1:D2}' -f $mAnon, $ti) }
        else                    { Add-Anon 'Instance' $sn $mAnon }
    }

    # 3) Availability Group names -> AGnn
    $agi = 0
    $agNames = @($rows | Where-Object { $_.Sec -eq 'HADR' } | ForEach-Object {
        if ($_.Item -like 'AG: *')                 { ($_.Item.Substring(4) -split ' / ', 2)[0] }
        elseif ($_.Item -like 'AG database count: *') { $_.Item.Substring(19) }
    } | Sort-Object -Unique)
    foreach ($ag in $agNames) { $agi++; Add-Anon 'AG' $ag ('AG{0:D2}' -f $agi) }

    # 4) database names -> DBnnn (system DB names are not sensitive; keep them)
    $sysDbs = @('master', 'model', 'msdb', 'tempdb')
    $dbi = 0
    $dbNames = @($rows | ForEach-Object {
        if ($_.Sec -in @('EDITIONFEATURES', 'QUERYSTORE') -and $_.Item -notmatch 'Error$|^QueryStore$') { $_.Item }
        elseif ($_.Sec -eq 'IO' -and $_.Item -like 'TopIoDb: *') { $_.Item.Substring(9) }
    } | Sort-Object -Unique | Where-Object { $_ -and $sysDbs -notcontains $_ })
    foreach ($db in $dbNames) { $dbi++; Add-Anon 'Database' $db ('DB{0:D3}' -f $dbi) }

    # One pass per line: longest-first alternation so SERVER10 wins over SERVER1
    $ordered = @($map | Sort-Object { $_.Original.Length } -Descending)
    $pattern = '(?<![A-Za-z0-9_])(?:' + (($ordered | ForEach-Object { [regex]::Escape($_.Original) }) -join '|') + ')(?![A-Za-z0-9_])'
    $rx = New-Object regex($pattern, ([Text.RegularExpressions.RegexOptions]::IgnoreCase))
    $evaluator = { param($m) $lookupCI[$m.Value] }

    Get-ChildItem $OutDir -Filter '*.psv' |
        Where-Object { $_.Name -ne 'consolidation-assessment-all.psv' } |
        ForEach-Object {
            $tx = @(Get-Content $_.FullName | ForEach-Object { $rx.Replace($_, $evaluator) })
            $first = $tx | Where-Object { $_ -match '\|' -and $_ -notmatch '^-+\|' -and $_ -notmatch '^InstanceName\|' } | Select-Object -First 1
            $anonName = (($first -split '\|', 2)[0] -replace '[\\\/:,]', '_') + '.psv'
            $tx | Out-File (Join-Path $anonDir $anonName) -Encoding utf8
        }
    $mergedSrc = Join-Path $OutDir 'consolidation-assessment-all.psv'
    if (Test-Path $mergedSrc) {
        Get-Content $mergedSrc | ForEach-Object { $rx.Replace($_, $evaluator) } |
            Out-File (Join-Path $anonDir 'consolidation-assessment-all.psv') -Encoding utf8
    }

    # Regenerate the summary from the anonymised data so it carries no real names
    & $PSCommandPath -AnalyzeOnly -OutDir $anonDir

    $mapPath = Join-Path $OutDir 'anonymisation-map.csv'
    $map | Export-Csv $mapPath -NoTypeInformation -Encoding UTF8

    Write-Host ""
    Write-Host "Anonymised copy (safe to send): $anonDir" -ForegroundColor Green
    Write-Host "Translation map (DO NOT SEND - keep to decode findings): $mapPath" -ForegroundColor Yellow
}
