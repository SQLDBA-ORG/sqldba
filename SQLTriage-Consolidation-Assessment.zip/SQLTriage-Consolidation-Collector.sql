/*============================================================================
  SQLTriage - Consolidation Self-Assessment Collector
  Version 1.0 (2025-03-02), rev. 2026-06-12

  WHAT IT DOES
    Collects instance-level capacity, licensing, and HA topology metadata
    needed for a first-pass SQL Server consolidation / licensing evaluation.

  WHAT IT DOES *NOT* DO
    - No writes to any user database (one #temp table only).
    - No query text, no plan XML, no table/row data is collected.
      Output is metadata and aggregate counters only.
    - No traces, no XEvents, nothing left behind after it finishes.

  PERMISSIONS
    Easiest: run as sysadmin.
    Least-privilege: VIEW SERVER STATE + VIEW ANY DATABASE, plus
    VIEW DATABASE STATE in each user database (for the Enterprise-feature
    section; databases it cannot read are reported as such, not skipped
    silently).

  RUNTIME
    Typically under 15 seconds. Read-only DMV queries only.

  SUPPORTED VERSIONS
    SQL Server 2012 and later. Sections that need newer DMV columns
    (Query Store, socket counts) detect availability and degrade politely.

  OUTPUT
    One result set: InstanceName | Section | Item | Value
    Designed so output from many servers can be appended into a single
    spreadsheet. See INSTRUCTIONS.md for how to read it.
============================================================================*/
SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;  -- required for XML methods; sqlcmd defaults OFF
SET ANSI_NULLS ON;
SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;

/* Version gate in its own batch: on pre-2012 instances the main batch below
   would fail to compile (newer functions/columns), so abort here with a
   readable message instead. sqlcmd -b stops at this error; in SSMS you will
   see this message above any compile errors. */
DECLARE @ver varchar(32) = CAST(SERVERPROPERTY('ProductVersion') AS varchar(32));
IF CAST(PARSENAME(@ver, 4) AS int) < 11
    RAISERROR('SQLTriage collector requires SQL Server 2012 or later; this instance is %s. Record it in the worksheet manually.', 16, 1, @ver);
GO

IF OBJECT_ID('tempdb..#r') IS NOT NULL DROP TABLE #r;
CREATE TABLE #r
(
    seq      int IDENTITY(1,1),
    Section  varchar(30)    NOT NULL,
    Item     nvarchar(256)  NOT NULL,
    Value    nvarchar(4000) NULL
);

DECLARE @start  datetime,
        @upsec  bigint,
        @updays decimal(10,2),
        @sql    nvarchar(max),
        @v      nvarchar(4000);

BEGIN TRY
    SELECT @start = sqlserver_start_time FROM sys.dm_os_sys_info;
END TRY
BEGIN CATCH
    INSERT #r VALUES ('SCOPE', 'PermissionError',
        N'VIEW SERVER STATE appears to be denied - most sections will be unavailable: ' + ERROR_MESSAGE());
END CATCH;
SET @upsec  = DATEDIFF(SECOND, @start, GETDATE());
SET @updays = @upsec / 86400.0;

/*---------------------------------------------------------------------------
  1. INSTANCE - identity, version, edition, hardware shape
---------------------------------------------------------------------------*/
INSERT #r (Section, Item, Value)
SELECT 'INSTANCE', 'CollectedAtUtc',     CONVERT(nvarchar(30), GETUTCDATE(), 126)
UNION ALL SELECT 'INSTANCE', 'ServerName',         CAST(SERVERPROPERTY('ServerName') AS nvarchar(256))
UNION ALL SELECT 'INSTANCE', 'MachineName',        CAST(SERVERPROPERTY('MachineName') AS nvarchar(256))
UNION ALL SELECT 'INSTANCE', 'ProductVersion',     CAST(SERVERPROPERTY('ProductVersion') AS nvarchar(64))
UNION ALL SELECT 'INSTANCE', 'ProductLevel',       CAST(SERVERPROPERTY('ProductLevel') AS nvarchar(64))
UNION ALL SELECT 'INSTANCE', 'Edition',            CAST(SERVERPROPERTY('Edition') AS nvarchar(128))
UNION ALL SELECT 'INSTANCE', 'IsClustered_FCI',    CAST(SERVERPROPERTY('IsClustered') AS nvarchar(4))
UNION ALL SELECT 'INSTANCE', 'IsHadrEnabled_AG',   CAST(ISNULL(SERVERPROPERTY('IsHadrEnabled'),0) AS nvarchar(4))
UNION ALL SELECT 'INSTANCE', 'EngineEdition',      CAST(SERVERPROPERTY('EngineEdition') AS nvarchar(4))
UNION ALL SELECT 'INSTANCE', 'SqlServerStartTime', CONVERT(nvarchar(30), @start, 126)
UNION ALL SELECT 'INSTANCE', 'UptimeDays',         CAST(@updays AS nvarchar(20));

/* Azure SQL Database (5) / Managed Instance (8): vCore subscription pricing,
   not per-core licences - exclude from on-prem consolidation maths. */
IF CAST(SERVERPROPERTY('EngineEdition') AS int) IN (5, 8)
    INSERT #r VALUES ('SCOPE', 'AzureNotice',
        N'Azure SQL platform (EngineEdition=' + CAST(SERVERPROPERTY('EngineEdition') AS nvarchar(4))
        + N') - on-prem per-core consolidation maths does not apply; inventory only');

BEGIN TRY
INSERT #r (Section, Item, Value)
SELECT 'INSTANCE', 'LogicalCpuCount',     CAST(cpu_count AS nvarchar(10))            FROM sys.dm_os_sys_info
UNION ALL
SELECT 'INSTANCE', 'HyperthreadRatio',    CAST(hyperthread_ratio AS nvarchar(10))    FROM sys.dm_os_sys_info
UNION ALL
SELECT 'INSTANCE', 'PhysicalMemoryGB',    CAST(CAST(physical_memory_kb/1048576.0 AS decimal(10,1)) AS nvarchar(20)) FROM sys.dm_os_sys_info
UNION ALL
SELECT 'INSTANCE', 'VirtualMachineType',  virtual_machine_type_desc                  FROM sys.dm_os_sys_info;

/* socket / physical core counts: 2012 SP3+ / 2014 SP2+ / 2016 SP1+ */
IF COL_LENGTH('sys.dm_os_sys_info', 'socket_count') IS NOT NULL
    EXEC sp_executesql N'
        INSERT #r (Section, Item, Value)
        SELECT ''INSTANCE'', ''SocketCount'',    CAST(socket_count AS nvarchar(10))    FROM sys.dm_os_sys_info
        UNION ALL
        SELECT ''INSTANCE'', ''CoresPerSocket'', CAST(cores_per_socket AS nvarchar(10)) FROM sys.dm_os_sys_info';
ELSE
    INSERT #r VALUES ('INSTANCE', 'SocketCount', 'n/a (pre-2016SP1 build - record physical cores manually)');

/* Schedulers actually usable - fewer than LogicalCpuCount means an edition
   core cap or affinity mask is already limiting this instance. */
INSERT #r (Section, Item, Value)
SELECT 'INSTANCE', 'VisibleOnlineSchedulers', CAST(COUNT(*) AS nvarchar(10))
FROM sys.dm_os_schedulers WHERE status = 'VISIBLE ONLINE';

INSERT #r (Section, Item, Value)
SELECT 'INSTANCE', 'MaxServerMemoryMB', CAST(CAST(value_in_use AS bigint) AS nvarchar(20))
FROM sys.configurations WHERE name = 'max server memory (MB)'
UNION ALL
SELECT 'INSTANCE', 'MinServerMemoryMB', CAST(CAST(value_in_use AS bigint) AS nvarchar(20))
FROM sys.configurations WHERE name = 'min server memory (MB)';
END TRY
BEGIN CATCH
    INSERT #r VALUES ('INSTANCE', 'SectionError', ERROR_MESSAGE());
END CATCH;

/*---------------------------------------------------------------------------
  2. CPU - last ~4 hours from the scheduler-monitor ring buffer,
           plus a long-horizon "average cores busy" proxy from the plan cache
---------------------------------------------------------------------------*/
BEGIN TRY
    ;WITH rb AS
    (
        SELECT CONVERT(xml, record) AS r
        FROM sys.dm_os_ring_buffers
        WHERE ring_buffer_type = N'RING_BUFFER_SCHEDULER_MONITOR'
          AND record LIKE N'%<SystemHealth>%'
    ),
    s AS
    (
        SELECT
            r.value('(./Record/SchedulerMonitorEvent/SystemHealth/ProcessUtilization)[1]','int') AS sql_cpu,
            100 - r.value('(./Record/SchedulerMonitorEvent/SystemHealth/SystemIdle)[1]','int')   AS total_cpu
        FROM rb
    )
    INSERT #r (Section, Item, Value)
    SELECT 'CPU', 'WindowMinutes',   CAST(COUNT(*) AS nvarchar(10))                       FROM s
    UNION ALL SELECT 'CPU', 'SqlCpuAvgPct',    CAST(AVG(sql_cpu)   AS nvarchar(10))       FROM s
    UNION ALL SELECT 'CPU', 'SqlCpuMaxPct',    CAST(MAX(sql_cpu)   AS nvarchar(10))       FROM s
    UNION ALL SELECT 'CPU', 'TotalCpuAvgPct',  CAST(AVG(total_cpu) AS nvarchar(10))       FROM s
    UNION ALL SELECT 'CPU', 'TotalCpuMaxPct',  CAST(MAX(total_cpu) AS nvarchar(10))       FROM s
    UNION ALL
    SELECT TOP (1) 'CPU', 'TotalCpuP95Pct',
           CAST(CAST(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY total_cpu) OVER () AS int) AS nvarchar(10))
    FROM s;
END TRY
BEGIN CATCH
    INSERT #r VALUES ('CPU', 'RingBufferError', ERROR_MESSAGE());
END CATCH;

/* Average cores kept busy by SQL since startup (plan-cache worker time).
   Undercounts if plans have been evicted; treat as a floor, not a ceiling.
   ISNULL: an empty plan cache (recent flush) legitimately reads as ~0. */
BEGIN TRY
    INSERT #r (Section, Item, Value)
    SELECT 'CPU', 'AvgCoresBusySinceStart',
           CAST(CAST(ISNULL(SUM(total_worker_time), 0) / 1000000.0 / NULLIF(@upsec,0) AS decimal(10,2)) AS nvarchar(20))
    FROM sys.dm_exec_query_stats;
END TRY
BEGIN CATCH
    INSERT #r VALUES ('CPU', 'SectionError', ERROR_MESSAGE());
END CATCH;

/*---------------------------------------------------------------------------
  3. MEMORY - pressure signals
---------------------------------------------------------------------------*/
BEGIN TRY
INSERT #r (Section, Item, Value)
SELECT 'MEMORY', 'PageLifeExpectancySec', CAST(cntr_value AS nvarchar(20))
FROM sys.dm_os_performance_counters
WHERE object_name LIKE '%Buffer Manager%' AND counter_name = 'Page life expectancy'
UNION ALL
SELECT 'MEMORY', 'TargetServerMemoryGB',
       CAST(CAST(cntr_value/1048576.0 AS decimal(10,1)) AS nvarchar(20))
FROM sys.dm_os_performance_counters
WHERE object_name LIKE '%Memory Manager%' AND counter_name = 'Target Server Memory (KB)'
UNION ALL
SELECT 'MEMORY', 'TotalServerMemoryGB',
       CAST(CAST(cntr_value/1048576.0 AS decimal(10,1)) AS nvarchar(20))
FROM sys.dm_os_performance_counters
WHERE object_name LIKE '%Memory Manager%' AND counter_name = 'Total Server Memory (KB)'
UNION ALL
SELECT 'MEMORY', 'MemoryGrantsPending', CAST(cntr_value AS nvarchar(20))
FROM sys.dm_os_performance_counters
WHERE object_name LIKE '%Memory Manager%' AND counter_name = 'Memory Grants Pending';
END TRY
BEGIN CATCH
    INSERT #r VALUES ('MEMORY', 'SectionError', ERROR_MESSAGE());
END CATCH;

/*---------------------------------------------------------------------------
  4. IO - cumulative since startup, normalised per day
---------------------------------------------------------------------------*/
BEGIN TRY
INSERT #r (Section, Item, Value)
SELECT 'IO', 'TotalReadGBPerDay',
       CAST(CAST(SUM(num_of_bytes_read)/1073741824.0/NULLIF(@updays,0) AS decimal(12,1)) AS nvarchar(20))
FROM sys.dm_io_virtual_file_stats(NULL, NULL)
UNION ALL
SELECT 'IO', 'TotalWriteGBPerDay',
       CAST(CAST(SUM(num_of_bytes_written)/1073741824.0/NULLIF(@updays,0) AS decimal(12,1)) AS nvarchar(20))
FROM sys.dm_io_virtual_file_stats(NULL, NULL)
UNION ALL
SELECT 'IO', 'AvgReadLatencyMs',
       CAST(CAST(SUM(io_stall_read_ms)*1.0/NULLIF(SUM(num_of_reads),0) AS decimal(10,1)) AS nvarchar(20))
FROM sys.dm_io_virtual_file_stats(NULL, NULL)
UNION ALL
SELECT 'IO', 'AvgWriteLatencyMs',
       CAST(CAST(SUM(io_stall_write_ms)*1.0/NULLIF(SUM(num_of_writes),0) AS decimal(10,1)) AS nvarchar(20))
FROM sys.dm_io_virtual_file_stats(NULL, NULL);

/* Top 5 databases by IO volume - the ones that dominate stacking decisions */
INSERT #r (Section, Item, Value)
SELECT TOP (5)
       'IO',
       'TopIoDb: ' + ISNULL(DB_NAME(database_id), CAST(database_id AS nvarchar(10))),
       CAST(CAST(SUM(num_of_bytes_read + num_of_bytes_written)/1073741824.0/NULLIF(@updays,0) AS decimal(12,1)) AS nvarchar(20)) + N' GB/day'
FROM sys.dm_io_virtual_file_stats(NULL, NULL)
GROUP BY database_id
ORDER BY SUM(num_of_bytes_read + num_of_bytes_written) DESC;
END TRY
BEGIN CATCH
    INSERT #r VALUES ('IO', 'SectionError', ERROR_MESSAGE());
END CATCH;

/*---------------------------------------------------------------------------
  5. STORAGE - database footprint (database snapshots excluded)
---------------------------------------------------------------------------*/
BEGIN TRY
INSERT #r (Section, Item, Value)
SELECT 'STORAGE', 'UserDatabaseCount', CAST(COUNT(*) AS nvarchar(10))
FROM sys.databases WHERE database_id > 4 AND source_database_id IS NULL
UNION ALL
SELECT 'STORAGE', 'TotalDataFileGB',
       CAST(CAST(SUM(CASE WHEN type = 0 THEN CAST(size AS bigint) ELSE 0 END)*8/1048576.0 AS decimal(12,1)) AS nvarchar(20))
FROM sys.master_files
WHERE database_id IN (SELECT database_id FROM sys.databases WHERE source_database_id IS NULL)
UNION ALL
SELECT 'STORAGE', 'TotalLogFileGB',
       CAST(CAST(SUM(CASE WHEN type = 1 THEN CAST(size AS bigint) ELSE 0 END)*8/1048576.0 AS decimal(12,1)) AS nvarchar(20))
FROM sys.master_files
WHERE database_id IN (SELECT database_id FROM sys.databases WHERE source_database_id IS NULL);
END TRY
BEGIN CATCH
    INSERT #r VALUES ('STORAGE', 'SectionError', ERROR_MESSAGE());
END CATCH;

/*---------------------------------------------------------------------------
  6. WAITS - top 10 non-benign waits since startup
---------------------------------------------------------------------------*/
BEGIN TRY
;WITH w AS
(
    SELECT wait_type, wait_time_ms
    FROM sys.dm_os_wait_stats
    WHERE wait_type NOT IN
    (N'BROKER_EVENTHANDLER',N'BROKER_RECEIVE_WAITFOR',N'BROKER_TASK_STOP',N'BROKER_TO_FLUSH',
     N'BROKER_TRANSMITTER',N'CHECKPOINT_QUEUE',N'CLR_AUTO_EVENT',N'CLR_MANUAL_EVENT',
     N'CLR_SEMAPHORE',N'DBMIRROR_DBM_EVENT',N'DBMIRROR_EVENTS_QUEUE',N'DBMIRROR_WORKER_QUEUE',
     N'DBMIRRORING_CMD',N'DIRTY_PAGE_POLL',N'DISPATCHER_QUEUE_SEMAPHORE',N'FT_IFTS_SCHEDULER_IDLE_WAIT',
     N'FT_IFTSHC_MUTEX',N'HADR_CLUSAPI_CALL',N'HADR_FILESTREAM_IOMGR_IOCOMPLETION',N'HADR_LOGCAPTURE_WAIT',
     N'HADR_NOTIFICATION_DEQUEUE',N'HADR_TIMER_TASK',N'HADR_WORK_QUEUE',N'KSOURCE_WAKEUP',
     N'LAZYWRITER_SLEEP',N'LOGMGR_QUEUE',N'MEMORY_ALLOCATION_EXT',N'ONDEMAND_TASK_QUEUE',
     N'PVS_PREALLOCATE',N'PREEMPTIVE_XE_DISPATCHER',N'PREEMPTIVE_XE_CALLBACKEXECUTE',
     N'PREEMPTIVE_XE_SESSIONCOMMIT',N'XE_FILE_TARGET_TVF',N'PARALLEL_REDO_DRAIN_WORKER',
     N'PARALLEL_REDO_LOG_CACHE',N'PARALLEL_REDO_TRAN_LIST',N'PARALLEL_REDO_WORKER_SYNC',
     N'PARALLEL_REDO_WORKER_WAIT_WORK',N'PREEMPTIVE_OS_FLUSHFILEBUFFERS',N'PREEMPTIVE_XE_GETTARGETSTATE',
     N'PWAIT_ALL_COMPONENTS_INITIALIZED',N'PWAIT_DIRECTLOGCONSUMER_GETNEXT',N'QDS_ASYNC_QUEUE',
     N'QDS_CLEANUP_STALE_QUERIES_TASK_MAIN_LOOP_SLEEP',N'QDS_PERSIST_TASK_MAIN_LOOP_SLEEP',
     N'QDS_SHUTDOWN_QUEUE',N'REDO_THREAD_PENDING_WORK',N'REQUEST_FOR_DEADLOCK_SEARCH',
     N'RESOURCE_QUEUE',N'SERVER_IDLE_CHECK',N'SLEEP_BPOOL_FLUSH',N'SLEEP_DBSTARTUP',
     N'SLEEP_DCOMSTARTUP',N'SLEEP_MASTERDBREADY',N'SLEEP_MASTERMDREADY',N'SLEEP_MASTERUPGRADED',
     N'SLEEP_MSDBSTARTUP',N'SLEEP_SYSTEMTASK',N'SLEEP_TASK',N'SLEEP_TEMPDBSTARTUP',
     N'SNI_HTTP_ACCEPT',N'SOS_WORK_DISPATCHER',N'SP_SERVER_DIAGNOSTICS_SLEEP',
     N'SQLTRACE_BUFFER_FLUSH',N'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',N'SQLTRACE_WAIT_ENTRIES',
     N'WAIT_FOR_RESULTS',N'WAITFOR',N'WAITFOR_TASKSHUTDOWN',N'WAIT_XTP_HOST_WAIT',
     N'WAIT_XTP_OFFLINE_CKPT_NEW_LOG',N'WAIT_XTP_CKPT_CLOSE',N'WAIT_XTP_RECOVERY',
     N'XE_BUFFERMGR_ALLPROCESSED_EVENT',N'XE_DISPATCHER_JOIN',N'XE_DISPATCHER_WAIT',
     N'XE_LIVE_TARGET_TVF',N'XE_TIMER_EVENT')
      AND wait_time_ms > 0
)
INSERT #r (Section, Item, Value)
SELECT TOP (10)
       'WAITS',
       wait_type,
       CAST(CAST(wait_time_ms/1000.0/NULLIF(@updays,0) AS decimal(12,0)) AS nvarchar(20)) + N' sec/day ('
       + CAST(CAST(100.0 * wait_time_ms / NULLIF(SUM(wait_time_ms) OVER (),0) AS decimal(5,1)) AS nvarchar(10)) + N'% of waits)'
FROM w
ORDER BY wait_time_ms DESC;
END TRY
BEGIN CATCH
    INSERT #r VALUES ('WAITS', 'SectionError', ERROR_MESSAGE());
END CATCH;

/*---------------------------------------------------------------------------
  7. HADR - AG topology and replica roles (licensing-critical)
---------------------------------------------------------------------------*/
IF CAST(ISNULL(SERVERPROPERTY('IsHadrEnabled'), 0) AS int) = 1
BEGIN
    BEGIN TRY
        INSERT #r (Section, Item, Value)
        SELECT 'HADR',
               N'AG: ' + ag.name + N' / ' + ar.replica_server_name,
               ISNULL(ars.role_desc, N'(role visible on primary)')
               + N' | ' + ar.availability_mode_desc
               + N' | failover=' + ar.failover_mode_desc
               + N' | readable_secondary=' + ar.secondary_role_allow_connections_desc
        FROM sys.availability_groups ag
        JOIN sys.availability_replicas ar
             ON ar.group_id = ag.group_id
        LEFT JOIN sys.dm_hadr_availability_replica_states ars
             ON ars.replica_id = ar.replica_id;

        INSERT #r (Section, Item, Value)
        SELECT 'HADR',
               N'AG database count: ' + ag.name,
               CAST(COUNT(adc.group_database_id) AS nvarchar(10))
        FROM sys.availability_groups ag
        LEFT JOIN sys.availability_databases_cluster adc
             ON adc.group_id = ag.group_id
        GROUP BY ag.name;
    END TRY
    BEGIN CATCH
        INSERT #r VALUES ('HADR', 'AgQueryError', ERROR_MESSAGE());
    END CATCH;
END
ELSE
    INSERT #r VALUES ('HADR', 'AvailabilityGroups', 'none (HADR not enabled)');

/*---------------------------------------------------------------------------
  8. EDITIONFEATURES - Enterprise-only features in use, per database.
     An EMPTY list on an Enterprise instance is the headline finding:
     nothing in that database blocks an edition downgrade.
     NOTE: from 2016 SP1, Compression/ColumnStoreIndex/Partitioning/
     InMemoryOLTP (and TDE from 2019) are Standard-supported - the DMV
     still lists them but they no longer block a downgrade there.
---------------------------------------------------------------------------*/
DECLARE @db sysname, @f nvarchar(4000);
DECLARE dbs CURSOR LOCAL FAST_FORWARD FOR
    SELECT name FROM sys.databases
    WHERE database_id > 4 AND state_desc = 'ONLINE' AND source_database_id IS NULL
    ORDER BY name;
OPEN dbs;
FETCH NEXT FROM dbs INTO @db;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @f = NULL;
    BEGIN TRY
        SET @sql = N'SELECT @f = STUFF((SELECT N''; '' + feature_name FROM '
                 + QUOTENAME(@db) + N'.sys.dm_db_persisted_sku_features FOR XML PATH('''')), 1, 2, N'''')';
        EXEC sp_executesql @sql, N'@f nvarchar(4000) OUTPUT', @f = @f OUTPUT;
        INSERT #r VALUES ('EDITIONFEATURES', @db, ISNULL(@f, N'(none - no edition-locked features)'));
    END TRY
    BEGIN CATCH
        INSERT #r VALUES ('EDITIONFEATURES', @db, N'unreadable: ' + ERROR_MESSAGE());
    END CATCH;
    FETCH NEXT FROM dbs INTO @db;
END
CLOSE dbs; DEALLOCATE dbs;

/*---------------------------------------------------------------------------
  9. QUERYSTORE - which databases have history available for the full
     (engagement-grade) evaluation. SQL 2016+.
---------------------------------------------------------------------------*/
BEGIN TRY
    IF COL_LENGTH('sys.databases', 'is_query_store_on') IS NOT NULL
        EXEC sp_executesql N'
            INSERT #r (Section, Item, Value)
            SELECT ''QUERYSTORE'', name, CASE is_query_store_on WHEN 1 THEN ''ON'' ELSE ''OFF'' END
            FROM sys.databases WHERE database_id > 4 AND state_desc = ''ONLINE'' AND source_database_id IS NULL';
    ELSE
        INSERT #r VALUES ('QUERYSTORE', 'QueryStore', 'n/a (pre-2016 instance)');
END TRY
BEGIN CATCH
    INSERT #r VALUES ('QUERYSTORE', 'SectionError', ERROR_MESSAGE());
END CATCH;

/*---------------------------------------------------------------------------
  Final output - single result set
---------------------------------------------------------------------------*/
SELECT CAST(SERVERPROPERTY('ServerName') AS nvarchar(256)) AS InstanceName,
       Section, Item, Value
FROM #r
ORDER BY seq;

DROP TABLE #r;
