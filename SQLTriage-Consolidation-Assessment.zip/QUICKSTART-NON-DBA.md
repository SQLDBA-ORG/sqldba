# Quick Start (no SQL Server knowledge needed)

You've been asked to run a small diagnostic against your company's SQL
Servers. This page is everything you need. Total hands-on time for a large
estate is usually under an hour, most of it waiting.

## What this does, in plain language

It asks each SQL Server a set of read-only questions - "how big are you,
how busy are you, what edition are you" - and saves the answers to a text
file. Think of it as a stocktake, not surgery.

**It cannot change anything.** The script only reads built-in statistics
that SQL Server already keeps. It does not look at the data inside your
databases - no customer records, no financials, no document contents. You
can open any output file in Notepad and see exactly what was captured.

## What you need before starting

1. **This folder**, copied to a Windows machine that can reach the SQL
   Servers over the network (a management server or your own PC on the
   right network is fine).
2. **The list of SQL Server names.** Ask whoever manages them, or pull it
   from your CMDB/monitoring tool. You want *instance* names - they look
   like `PRODSQL01` or `PRODSQL02\PAYROLL` (the part after the backslash
   matters - include it exactly).
3. **A Windows account that is allowed to read from SQL Server.** Ask the
   SQL admin or whoever installed the servers for "a login with sysadmin,
   or at least VIEW SERVER STATE, on all instances - it's for a read-only
   diagnostic." Log on to Windows as that account (or hold Shift,
   right-click PowerShell, "Run as different user").
4. **The `sqlcmd` tool.** Already present if SQL Server Management Studio
   or SQL Server itself is installed on the machine. To check: open
   PowerShell, type `sqlcmd -?`, press Enter. If you get a help page,
   you're set. If not, install "Microsoft Command Line Utilities for SQL
   Server" (small, free, no reboot) or run from a machine that has SSMS.

## Steps

1. Open the file `servers.txt` in this folder (create it if missing,
   with Notepad). Put **one server name per line**:

   ```
   PRODSQL01
   PRODSQL02\PAYROLL
   DRSQL01
   ```

2. Open PowerShell **in this folder** (in File Explorer: File menu >
   "Open Windows PowerShell", or Shift+right-click in the folder >
   "Open PowerShell window here").

3. Type the following and press Enter:

   ```powershell
   .\Run-Collector.ps1
   ```

   If Windows refuses with a message about scripts being disabled, run
   this instead (one line, allows scripts for this window only):

   ```powershell
   powershell -ExecutionPolicy Bypass -File .\Run-Collector.ps1
   ```

4. Watch the list scroll by. Each server shows `ok` or `FAILED`. A few
   failures are normal on the first pass - see the table below, fix what
   you can, and simply run the same command again (it re-collects
   everything; that's fine and harmless).

5. **Important:** run the whole thing **twice** - once mid-morning on a
   normal business day, and once first thing in the morning (to catch the
   overnight processing window). Keep both `out` folders - rename the
   first one to `out-peak` before the second run.

6. A file called `SUMMARY.md` appears inside each output folder - that is
   an automatic first-pass read of the results (open it in any text
   editor; it's plain text). Include it in the zip.

7. **If results need to go outside your company** and policy doesn't
   allow sharing server names: run this once per output folder -

   ```powershell
   .\Run-Collector.ps1 -AnalyzeOnly -Anonymise -OutDir .\out
   ```

   It creates a sibling folder (e.g. `out-anon`) where every server,
   cluster and database name is replaced by a harmless pseudonym
   (servers become SAUSAGE, PICKLE, WAFFLE...). Send the `-anon`
   folder(s) only. The file `anonymisation-map.csv` inside the original
   folder is the decoder ring - **keep it; never send it**.

8. Right-click the folder(s) you're sharing > "Send to" > "Compressed
   (zipped) folder", and send the zips back to whoever asked for this,
   along with the list of any servers that stayed FAILED.

That's it. You do not need to interpret anything - the analysis happens
on the other end (or by your DBA team using INSTRUCTIONS.md).

## If something fails

| Message contains | What it means | What to do |
|---|---|---|
| `Login failed for user` | Your account isn't allowed on that server | Ask the SQL admin to grant it (read-only is enough), rerun |
| `Could not open a connection` / `network-related` | Wrong name, firewall, or the server is off | Check the name spelling incl. `\INSTANCE` part; ping the machine; ask if it's decommissioned |
| `timeout` | Server is slow or far away | Rerun just that one - it usually passes second time |
| `sqlcmd is not recognized` | The sqlcmd tool isn't installed | Install the command-line utilities, or run from a machine with SSMS |
| `VIEW SERVER STATE permission was denied` | Account can connect but can't read statistics | Ask the SQL admin for VIEW SERVER STATE on that instance |
| A server shows `ok` but the file mentions `unreadable:` for some databases | Normal on standby/mirror servers | Nothing - it's expected and noted in the output |
| `certificate` / `SSL` error | Server's certificate isn't trusted by your machine | The script already handles the common case; if it persists, ask the SQL admin |
| `Invalid option` or `unknown option -C` on every server | Your sqlcmd is very old | Rerun as `.\Run-Collector.ps1 -LegacySqlcmd` |
| `requires SQL Server 2012 or later` | That server is too old for the script | Note its name, version and core count by hand - it still matters for licensing |

## Common questions

**Will this slow the servers down?** No measurably - it reads counters
SQL Server maintains anyway. It finishes in seconds per server and is
safe during business hours.

**Is this safe on our DR / standby servers?** Yes, and please include
them - they matter most for the licensing question.

**Does it install anything or leave anything behind?** No. It runs, asks
its questions, writes a text file on *your* machine, and is done.

**Who sees the output?** Only whoever you send the zip to. Open any file
in Notepad first if you want to review it - it's readable text.
